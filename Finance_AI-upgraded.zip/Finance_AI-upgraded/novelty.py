"""
novelty.py — novelty scoring via pgvector comparison against a rolling
48-hour embedding window.

A story that closely echoes recent narratives → low novelty (repeated signal).
A story with no near-neighbours in the 48h window     → high novelty (new info).

Score range: [0.0, 1.0]
    1.0 → completely novel (no similar story in last 48h)
    0.0 → exact duplicate of something recent (should already be deduped)

The novelty score is designed to be combined with materiality and sentiment
in the signal ranker:

    alpha ∝ materiality × novelty × credibility × recency_decay
"""
from __future__ import annotations

import logging
import math
import time
from typing import Optional

try:
    from asyncpg.pool import Pool
except ImportError:
    Pool = object  # type: ignore — asyncpg not installed in test env

from config import settings

logger = logging.getLogger(__name__)

# How many nearest neighbours to sample for the novelty calculation
_K_NEIGHBOURS = 5

# Window within which to look for similar stories
_LOOKBACK_HOURS = 48

# Similarity above this is "strongly similar" → novelty penalty kicks in hard
_HIGH_SIM_THRESHOLD = 0.85

# Similarity above this is "somewhat similar" → moderate penalty
_MED_SIM_THRESHOLD = 0.70


async def compute_novelty_score(
    pool: Pool,
    embedding: Optional[list[float]],
    event_id_to_exclude: Optional[str] = None,
    reference_time: Optional[float] = None,      # NEW: Unix timestamp; defaults to NOW()
) -> float:
    """
    Return a novelty score in [0, 1].

    Parameters
    ----------
    pool                  asyncpg pool
    embedding             the embedding of the new article
    event_id_to_exclude   skip self-match when re-scoring stored events
    reference_time        Unix timestamp to use as "now" for the lookback window.
                          CRITICAL: always pass the event's scraped_at unix timestamp
                          so we only compare against PAST events, never future ones.
                          Defaults to the current wall-clock time (safe for live use).
    """
    if embedding is None:
        return 0.5

    # Compute the strict past-only cutoff timestamp
    # Using reference_time ensures we never accidentally peek at future embeddings
    import datetime as _dt
    if reference_time is not None:
        ref_dt = _dt.datetime.fromtimestamp(reference_time, tz=_dt.timezone.utc)
    else:
        ref_dt = _dt.datetime.now(_dt.timezone.utc)

    cutoff_dt = ref_dt - _dt.timedelta(hours=_LOOKBACK_HOURS)

    emb_str = f"[{','.join(str(x) for x in embedding)}]"

    try:
        if event_id_to_exclude:
            rows = await pool.fetch(
                """
                SELECT 1 - (embedding <=> $1::vector) AS similarity
                FROM   scraped_events
                WHERE  scraped_at >= $2
                  AND  scraped_at <= $3
                  AND  NOT is_duplicate
                  AND  embedding IS NOT NULL
                  AND  event_id != $4::uuid
                ORDER  BY embedding <=> $1::vector
                LIMIT  $5
                """,
                emb_str,
                cutoff_dt,
                ref_dt,           # STRICT upper bound: only past events
                event_id_to_exclude,
                _K_NEIGHBOURS,
            )
        else:
            rows = await pool.fetch(
                """
                SELECT 1 - (embedding <=> $1::vector) AS similarity
                FROM   scraped_events
                WHERE  scraped_at >= $2
                  AND  scraped_at <= $3
                  AND  NOT is_duplicate
                  AND  embedding IS NOT NULL
                ORDER  BY embedding <=> $1::vector
                LIMIT  $4
                """,
                emb_str,
                cutoff_dt,
                ref_dt,           # STRICT upper bound
                _K_NEIGHBOURS,
            )
    except Exception as exc:
        logger.warning("novelty query failed: %s", exc)
        return 0.5

    if not rows:
        return 1.0

    similarities   = [float(r["similarity"]) for r in rows]
    max_sim        = max(similarities)
    avg_sim        = sum(similarities) / len(similarities)
    weighted_sim   = 0.7 * max_sim + 0.3 * avg_sim
    novelty        = max(0.0, min(1.0, 1.0 - weighted_sim))
    return round(novelty, 4)


def novelty_label(score: float) -> str:
    """Human-readable tier for a novelty score."""
    if score >= 0.80:
        return "NOVEL"
    if score >= 0.50:
        return "PARTIAL"
    if score >= 0.20:
        return "REPEATED"
    return "DUPLICATE"


# ---------------------------------------------------------------------------
# Narrative cluster novelty (in-memory, complements DB check)
# ---------------------------------------------------------------------------

def narrative_novelty(
    embedding: list[float],
    cluster_centroids: list[list[float]],
    window_timestamps: list[float],
    decay_halflife_days: float = 2.0,
) -> float:
    """
    Lightweight in-process novelty check against known cluster centroids.
    Incorporates time-decay so older clusters contribute less.

    Returns novelty in [0, 1].  Used by NarrativeEngine.
    """
    import numpy as np

    if not cluster_centroids:
        return 1.0

    emb = np.array(embedding)
    now = time.time()
    decay_lambda = math.log(2) / (decay_halflife_days * 86400)

    max_weighted_sim = 0.0
    for centroid, ts in zip(cluster_centroids, window_timestamps):
        sim   = float(np.dot(emb, np.array(centroid)))
        age_s = now - ts
        decay = math.exp(-decay_lambda * max(0.0, age_s))
        max_weighted_sim = max(max_weighted_sim, sim * decay)

    return round(max(0.0, min(1.0, 1.0 - max_weighted_sim)), 4)
