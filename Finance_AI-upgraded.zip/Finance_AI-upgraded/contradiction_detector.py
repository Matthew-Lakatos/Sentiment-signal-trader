"""
contradiction_detector.py — §21 Contradiction & Reflexivity Detection.

Identifies four types of market inefficiency signals:

1. Analyst/Social/Options Disagreement
   When multiple sentiment sources disagree on the same entity, the
   disagreement itself is an alpha signal (short the crowd consensus,
   long the outlier view — or wait for resolution).

2. Price-leading-narrative (price discovery before news)
   Stock price has already moved strongly in the direction of the article
   before publication → narrative is stale, signal is already priced.

3. Narrative-leading-price (news front-runs market)
   Strong news signal but price has NOT yet moved → genuine alpha
   opportunity before market digestion.

4. Reflexive momentum / Crowding reversal
   A narrative that has been uniformly positive for N consecutive
   articles (crowd consensus) tends to revert.  Detecting this allows
   contrarian positioning.

All detectors work without real-time price data (using yfinance lookback)
and degrade gracefully to ContradictionResult with is_contradicting=False
when data is unavailable.

Usage
-----
    from contradiction_detector import ContradictionDetector

    detector = ContradictionDetector(pool)
    result = await detector.analyse(
        entity          = "NVIDIA",
        ticker          = "NVDA",
        sentiment_score = 0.72,
        signal_score    = 0.65,
        scraped_at      = datetime.now(timezone.utc),
    )

    print(result.price_leading_narrative)   # True → already priced
    print(result.narrative_leading_price)   # True → genuine alpha
    print(result.crowd_consensus_reversal)  # True → contrarian signal
    print(result.disagreement_score)        # [0,1] cross-source disagreement
    print(result.signal_adjustment)         # [-1,1] recommended score multiplier
"""
from __future__ import annotations

import asyncio
import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------

# Price already moved ≥ this fraction before article → narrative stale
_PRICE_LEAD_THRESHOLD     = 0.025     # 2.5% pre-move → stale signal

# Price has NOT moved ≥ this fraction → genuine alpha window
_NARRATIVE_LEAD_THRESHOLD = 0.005     # < 0.5% price move → fresh alpha

# Crowd consensus: N consecutive same-direction articles in cluster
_CROWDING_N               = 5

# Disagreement: std of signed sentiments > this → significant disagreement
_DISAGREEMENT_STD_THRESHOLD = 0.3

# Pre-event price lookback window (hours)
_PRICE_LOOKBACK_HOURS       = 4
# Post-event price window to confirm digestion (hours)
_PRICE_FORWARD_HOURS        = 2


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class ContradictionResult:
    """Contradiction and reflexivity indicators for a single event."""
    # Disagreement
    disagreement_score:       float = 0.0    # [0,1]; higher = more cross-source disagreement
    n_sources_sampled:        int   = 0
    source_sentiment_std:     float = 0.0

    # Price-narrative lead/lag
    price_return_pre:         Optional[float] = None  # price move in the 4h before article
    price_return_post:        Optional[float] = None  # price move in the 2h after article
    price_leading_narrative:  bool            = False  # price already moved → stale
    narrative_leading_price:  bool            = False  # price hasn't moved yet → fresh

    # Crowd / reflexivity
    consecutive_same_direction: int  = 0
    crowd_consensus_reversal:   bool = False  # N+ same-direction → contrarian signal

    # Composite
    is_contradicting:         bool  = False   # any major contradiction detected
    signal_adjustment:        float = 1.0     # multiply original score by this [0.1, 1.5]
    adjustment_reasons:       list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Main detector
# ---------------------------------------------------------------------------

class ContradictionDetector:
    """
    Detects contradiction and reflexivity signals for incoming events.

    Parameters
    ----------
    pool        asyncpg pool (may be None — all features degrade gracefully)
    ticker_map  optional {entity_name → ticker} override dict
    """

    def __init__(
        self,
        pool,
        ticker_map: Optional[dict[str, str]] = None,
    ):
        self._pool       = pool
        self._ticker_map = ticker_map or {}
        self._price_cache: dict[str, tuple[float, object]] = {}  # {ticker: (expires, df)}
        self._cache_ttl = 300.0   # 5-minute price cache

    async def analyse(
        self,
        entity:          str,
        ticker:          Optional[str],
        sentiment_score: float,
        signal_score:    float,
        scraped_at:      datetime,
        canonical_id:    Optional[str] = None,
    ) -> ContradictionResult:
        """
        Run all contradiction detectors for one incoming article.

        Parameters
        ----------
        entity          Primary entity name (e.g. "NVIDIA")
        ticker          Equity ticker (e.g. "NVDA"); may be None
        sentiment_score Signed sentiment [-1, 1]
        signal_score    Composite signal score [-1, 1]
        scraped_at      Publication timestamp
        canonical_id    Cluster ID (for crowd-consensus check)
        """
        result = ContradictionResult()

        # Resolve ticker from map if not provided
        if not ticker and entity:
            ticker = self._ticker_map.get(entity.lower())

        tasks = [
            self._check_disagreement(entity, sentiment_score, scraped_at),
            self._check_price_lead_lag(ticker, sentiment_score, scraped_at),
            self._check_crowd_consensus(canonical_id, sentiment_score),
        ]

        disagreement, price_signals, crowd = await asyncio.gather(
            *tasks, return_exceptions=True
        )

        # Disagreement
        if not isinstance(disagreement, Exception) and disagreement:
            result.disagreement_score    = disagreement["score"]
            result.n_sources_sampled     = disagreement["n"]
            result.source_sentiment_std  = disagreement["std"]

        # Price lead/lag
        if not isinstance(price_signals, Exception) and price_signals:
            result.price_return_pre         = price_signals.get("pre_ret")
            result.price_return_post        = price_signals.get("post_ret")
            result.price_leading_narrative  = price_signals.get("price_leading", False)
            result.narrative_leading_price  = price_signals.get("narrative_leading", False)

        # Crowd consensus
        if not isinstance(crowd, Exception) and crowd:
            result.consecutive_same_direction = crowd.get("consecutive", 0)
            result.crowd_consensus_reversal   = crowd.get("reversal", False)

        # Compute composite signal adjustment
        result = self._compute_adjustment(result, signal_score)
        return result

    # ── Disagreement ────────────────────────────────────────────────────────

    async def _check_disagreement(
        self,
        entity:    str,
        current:   float,
        scraped_at: datetime,
    ) -> dict:
        """
        Query recent articles from DIFFERENT domains about the same entity.
        High std of signed sentiments → disagreement.
        """
        if not self._pool or not entity:
            return {"score": 0.0, "n": 0, "std": 0.0}

        window_start = scraped_at - timedelta(hours=12)
        try:
            rows = await self._pool.fetch("""
                SELECT DISTINCT ON (source_domain)
                    CASE sentiment_label
                        WHEN 'POSITIVE' THEN  sentiment_score
                        WHEN 'NEGATIVE' THEN -sentiment_score
                        ELSE 0.0
                    END AS signed_sent,
                    source_domain
                FROM scraped_events
                WHERE scraped_at >= $1
                  AND scraped_at <  $2
                  AND NOT is_duplicate
                  AND LOWER(summary) LIKE $3
                ORDER BY source_domain, scraped_at DESC
                LIMIT 20
            """, window_start, scraped_at, f"%{entity.lower()[:20]}%")

            if len(rows) < 2:
                return {"score": 0.0, "n": len(rows), "std": 0.0}

            sents = [float(r["signed_sent"]) for r in rows]
            sents.append(current)   # include current article
            n    = len(sents)
            mu   = sum(sents) / n
            var  = sum((s - mu) ** 2 for s in sents) / max(n - 1, 1)
            std  = math.sqrt(var)
            score = min(1.0, std / _DISAGREEMENT_STD_THRESHOLD)

            return {"score": round(score, 4), "n": n, "std": round(std, 4)}

        except Exception as exc:
            logger.debug("Disagreement query failed: %s", exc)
            return {"score": 0.0, "n": 0, "std": 0.0}

    # ── Price lead/lag ───────────────────────────────────────────────────────

    async def _check_price_lead_lag(
        self,
        ticker:    Optional[str],
        sentiment: float,
        scraped_at: datetime,
    ) -> dict:
        """
        Fetch price returns in the window before and after the article.
        Detect whether price has already moved (stale) or not yet (fresh).
        """
        if not ticker:
            return {}

        loop = asyncio.get_running_loop()
        try:
            df = await loop.run_in_executor(None, self._get_price_data, ticker)
        except Exception as exc:
            logger.debug("Price fetch failed for %s: %s", ticker, exc)
            return {}

        if df is None or df.empty:
            return {}

        try:
            import pandas as pd
            df.index = pd.to_datetime(df.index, utc=True)

            pre_start  = scraped_at - timedelta(hours=_PRICE_LOOKBACK_HOURS)
            pre_end    = scraped_at
            post_start = scraped_at
            post_end   = scraped_at + timedelta(hours=_PRICE_FORWARD_HOURS)

            def _window_return(start, end):
                mask   = (df.index >= start) & (df.index <= end)
                window = df.loc[mask, "Close"]
                if len(window) < 2:
                    return None
                return float(window.iloc[-1] / window.iloc[0] - 1)

            pre_ret  = _window_return(pre_start,  pre_end)
            post_ret = _window_return(post_start, post_end)

            # Directional consistency
            signal_dir = 1.0 if sentiment > 0 else (-1.0 if sentiment < 0 else 0.0)
            pre_aligned  = (pre_ret  is not None and signal_dir * pre_ret  > 0)
            post_aligned = (post_ret is not None and signal_dir * post_ret > 0)

            price_leading    = (pre_ret  is not None and abs(pre_ret)  >= _PRICE_LEAD_THRESHOLD
                                and pre_aligned)
            narrative_leading = (post_ret is None
                                 or (abs(post_ret or 0) < _NARRATIVE_LEAD_THRESHOLD))

            return {
                "pre_ret":          pre_ret,
                "post_ret":         post_ret,
                "price_leading":    price_leading,
                "narrative_leading":narrative_leading,
            }

        except Exception as exc:
            logger.debug("Price lead/lag computation failed: %s", exc)
            return {}

    def _get_price_data(self, ticker: str):
        """Synchronous yfinance fetch with in-process cache."""
        import time as _time
        mono = _time.monotonic()
        cached = self._price_cache.get(ticker)
        if cached and mono < cached[0]:
            return cached[1]

        try:
            import yfinance as yf
            df = yf.download(
                ticker, period="2d", interval="30m",
                progress=False, auto_adjust=True,
            )
            if df.empty:
                df = None
        except Exception:
            df = None

        self._price_cache[ticker] = (mono + self._cache_ttl, df)
        return df

    # ── Crowd consensus ──────────────────────────────────────────────────────

    async def _check_crowd_consensus(
        self,
        canonical_id: Optional[str],
        current_sent: float,
    ) -> dict:
        """
        Count consecutive same-direction articles in the canonical cluster.
        N ≥ _CROWDING_N → crowding reversal signal.
        """
        if not self._pool or not canonical_id:
            return {"consecutive": 0, "reversal": False}

        try:
            rows = await self._pool.fetch("""
                SELECT sentiment_label, sentiment_score
                FROM scraped_events
                WHERE canonical_event_id::text = $1
                  AND NOT is_duplicate
                ORDER BY scraped_at DESC
                LIMIT 10
            """, canonical_id)

            if not rows:
                return {"consecutive": 0, "reversal": False}

            current_dir = "POS" if current_sent > 0 else ("NEG" if current_sent < 0 else "NEU")
            consecutive = 1   # count current article

            for row in rows:
                label = (row["sentiment_label"] or "NEUTRAL").upper()
                if label == "POSITIVE" and current_dir == "POS":
                    consecutive += 1
                elif label == "NEGATIVE" and current_dir == "NEG":
                    consecutive += 1
                else:
                    break

            reversal = consecutive >= _CROWDING_N
            return {"consecutive": consecutive, "reversal": reversal}

        except Exception as exc:
            logger.debug("Crowd consensus query failed: %s", exc)
            return {"consecutive": 0, "reversal": False}

    # ── Signal adjustment ────────────────────────────────────────────────────

    @staticmethod
    def _compute_adjustment(result: ContradictionResult, signal_score: float) -> ContradictionResult:
        """
        Compute signal_adjustment multiplier based on all detected contradictions.

        Adjustments are multiplicative and clamped to [0.1, 1.5]:
          price_leading_narrative  → 0.3×  (signal already priced)
          narrative_leading_price  → 1.20× (genuine alpha window)
          crowd_consensus_reversal → 0.4×  (contrarian: fade the crowd)
          high disagreement        → 0.7×  (conflicting signals reduce conviction)
        """
        adj = 1.0
        reasons = []

        if result.price_leading_narrative:
            adj *= 0.30
            reasons.append(f"price_already_moved({result.price_return_pre:.3f})")

        if result.narrative_leading_price:
            adj *= 1.20
            reasons.append("genuine_alpha_window")

        if result.crowd_consensus_reversal:
            adj *= 0.40
            reasons.append(f"crowd_consensus_n={result.consecutive_same_direction}")

        if result.disagreement_score > 0.6:
            adj *= 0.70
            reasons.append(f"disagreement={result.disagreement_score:.2f}")

        adj = round(max(0.10, min(1.50, adj)), 4)

        result.signal_adjustment    = adj
        result.adjustment_reasons   = reasons
        result.is_contradicting     = len(reasons) > 0

        return result


# ---------------------------------------------------------------------------
# Standalone helpers
# ---------------------------------------------------------------------------

def disagreement_score_from_sentiments(sentiments: list[float]) -> float:
    """
    Compute cross-source disagreement score from a list of signed sentiments.
    Returns a value in [0, 1]; 1 = maximum disagreement.
    """
    n = len(sentiments)
    if n < 2:
        return 0.0
    mu  = sum(sentiments) / n
    var = sum((s - mu) ** 2 for s in sentiments) / max(n - 1, 1)
    std = math.sqrt(var)
    return round(min(1.0, std / _DISAGREEMENT_STD_THRESHOLD), 4)


def is_crowded(
    recent_directions: list[str],
    current_direction: str,
    threshold: int = _CROWDING_N,
) -> tuple[int, bool]:
    """
    Determine if a narrative is crowded given a list of recent directions.

    Parameters
    ----------
    recent_directions  List of "POS"/"NEG"/"NEU" for the N most recent articles
                       (most-recent first)
    current_direction  Direction of the current article ("POS"/"NEG"/"NEU")
    threshold          Number of consecutive same-direction articles to flag

    Returns
    -------
    (consecutive_count, is_crowded)
    """
    consecutive = 1
    for d in recent_directions:
        if d == current_direction:
            consecutive += 1
        else:
            break
    return consecutive, consecutive >= threshold
