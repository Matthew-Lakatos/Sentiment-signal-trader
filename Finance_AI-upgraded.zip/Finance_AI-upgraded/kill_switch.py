"""
kill_switch.py — §23 Kill-Switch + Failure Engine.

Prevents catastrophic deployment failure by maintaining a state machine
that monitors hard-stop conditions across the entire platform.

Philosophy
----------
Survival outranks optimisation. When in doubt, the system stops.

State machine
-------------
    ACTIVE ──► WARNING ──► SUSPENDED ──► KILLED
                 │                          │
                 └──── auto-recover ────────┘ (KILLED requires manual reset)

    ACTIVE    — normal operation
    WARNING   — soft threshold breached; reduced operations, alerts sent
    SUSPENDED — hard threshold breached; no new positions, pending exits
    KILLED    — catastrophic condition; system halted, manual reset required

Trigger categories
------------------
  1. GOVERNANCE_COLLAPSE   — governance_confidence below hard floor for N cycles
  2. EXECUTION_FAILURE     — consecutive execution errors above threshold
  3. LIQUIDITY_COLLAPSE    — liquidity stress exceeds critical threshold
  4. INFRASTRUCTURE_ERROR  — DB errors, data pipeline failures
  5. MODEL_INSTABILITY     — extreme IC collapse or divergent model disagreement
  6. DATA_ANOMALY          — impossible/corrupted data detected in pipeline
  7. CONSECUTIVE_LOSSES    — realised PnL losses exceed drawdown limit
  8. MANUAL               — operator-triggered

All triggers that result in SUSPENDED or KILLED emit a structured alert
event to the alert_engine and write a permanent record to the DB kill_switch_events table.

Auto-recovery
-------------
WARNING → ACTIVE:   after KILL_RECOVERY_CYCLES consecutive clean cycles
SUSPENDED → ACTIVE: only if the triggering condition has fully cleared AND
                    KILL_RECOVERY_CYCLES consecutive clean cycles pass.
KILLED → any:       NEVER automatic. Requires manual reset() call with reason.

Usage
-----
    from kill_switch import KillSwitch, KillTrigger

    ks = KillSwitch(pool=pool)

    # On each pipeline cycle:
    ks.record_cycle(
        governance_confidence = report.governance_confidence,
        liquidity_stress      = liq_snap.liquidity_stress_index,
        execution_errors      = 0,
        infrastructure_errors = 0,
        ic                    = health.rolling_ic,
    )

    if not ks.is_active():
        logger.critical("Kill switch engaged: %s", ks.current_state)
        return

    # Operator reset (after manual investigation):
    ks.reset(reason="Investigated and cleared — governance recovered", operator="alice")
"""
from __future__ import annotations

import asyncio
import logging
import os
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration (env-overridable)
# ---------------------------------------------------------------------------

def _float_env(key: str, default: float) -> float:
    try:
        return float(os.environ[key])
    except (KeyError, ValueError):
        return default


def _int_env(key: str, default: int) -> int:
    try:
        return int(os.environ[key])
    except (KeyError, ValueError):
        return default


# Governance thresholds
_GOV_WARNING_FLOOR   = _float_env("KILL_GOV_WARNING_FLOOR",   0.35)
_GOV_SUSPEND_FLOOR   = _float_env("KILL_GOV_SUSPEND_FLOOR",   0.20)
_GOV_KILL_FLOOR      = _float_env("KILL_GOV_KILL_FLOOR",      0.10)
_GOV_CYCLES_WARNING  = _int_env("KILL_GOV_CYCLES_WARNING",    2)
_GOV_CYCLES_SUSPEND  = _int_env("KILL_GOV_CYCLES_SUSPEND",    3)

# Liquidity thresholds
_LIQ_WARNING_THRESH  = _float_env("KILL_LIQ_WARNING_THRESH",  0.75)
_LIQ_SUSPEND_THRESH  = _float_env("KILL_LIQ_SUSPEND_THRESH",  0.90)

# Execution errors (per cycle)
_EXEC_WARNING_THRESH = _int_env("KILL_EXEC_WARNING_THRESH",   3)
_EXEC_SUSPEND_THRESH = _int_env("KILL_EXEC_SUSPEND_THRESH",   8)

# Infrastructure errors (per cycle)
_INFRA_WARNING_THRESH = _int_env("KILL_INFRA_WARNING_THRESH",  2)
_INFRA_SUSPEND_THRESH = _int_env("KILL_INFRA_SUSPEND_THRESH",  5)

# IC collapse (rolling IC below this for N cycles triggers)
_IC_WARNING_FLOOR    = _float_env("KILL_IC_WARNING_FLOOR",   -0.05)
_IC_SUSPEND_FLOOR    = _float_env("KILL_IC_SUSPEND_FLOOR",   -0.10)
_IC_CYCLES_WARNING   = _int_env("KILL_IC_CYCLES_WARNING",    3)
_IC_CYCLES_SUSPEND   = _int_env("KILL_IC_CYCLES_SUSPEND",    5)

# Recovery
_RECOVERY_CYCLES     = _int_env("KILL_RECOVERY_CYCLES",      3)


# ---------------------------------------------------------------------------
# Kill trigger enum
# ---------------------------------------------------------------------------

class KillTrigger(str, Enum):
    GOVERNANCE_COLLAPSE  = "GOVERNANCE_COLLAPSE"
    EXECUTION_FAILURE    = "EXECUTION_FAILURE"
    LIQUIDITY_COLLAPSE   = "LIQUIDITY_COLLAPSE"
    INFRASTRUCTURE_ERROR = "INFRASTRUCTURE_ERROR"
    MODEL_INSTABILITY    = "MODEL_INSTABILITY"
    DATA_ANOMALY         = "DATA_ANOMALY"
    CONSECUTIVE_LOSSES   = "CONSECUTIVE_LOSSES"
    MANUAL               = "MANUAL"
    NONE                 = "NONE"


# ---------------------------------------------------------------------------
# State
# ---------------------------------------------------------------------------

class KillState(str, Enum):
    ACTIVE    = "ACTIVE"
    WARNING   = "WARNING"
    SUSPENDED = "SUSPENDED"
    KILLED    = "KILLED"


@dataclass
class KillEvent:
    """A record of a state transition."""
    from_state:  str
    to_state:    str
    trigger:     str
    reason:      str
    timestamp:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    operator:    Optional[str] = None   # set on manual actions


# ---------------------------------------------------------------------------
# Cycle observation
# ---------------------------------------------------------------------------

@dataclass
class CycleObservation:
    """A single pipeline cycle's health readings."""
    governance_confidence: Optional[float]  = None
    liquidity_stress:      Optional[float]  = None
    execution_errors:      int              = 0
    infrastructure_errors: int              = 0
    ic:                    Optional[float]  = None
    data_anomaly:          bool             = False
    consecutive_losses:    int              = 0
    timestamp:             datetime         = field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# KillSwitch
# ---------------------------------------------------------------------------

class KillSwitch:
    """
    Platform-level kill-switch state machine.

    Tightening is immediate. Recovery requires ``_RECOVERY_CYCLES``
    consecutive clean cycles. KILLED state requires manual reset().
    """

    def __init__(self, pool=None) -> None:
        self._pool            = pool
        self._state           = KillState.ACTIVE
        self._trigger         = KillTrigger.NONE
        self._history:        list[KillEvent]        = []
        self._observations:   list[CycleObservation] = []
        self._clean_cycles:   int = 0
        self._lock            = asyncio.Lock()

        # Sustained breach counters
        self._gov_breach_count:   int = 0
        self._ic_breach_count:    int = 0

        # #4 Severity levels: track how many times each trigger has fired
        self._trigger_counts: dict[str, int] = {}

        # #4 Exponential backoff: require more clean cycles after repeated breaches
        # Base _RECOVERY_CYCLES × 2^(prior_breach_count - 1), capped at 20
        self._prior_breach_count: int = 0
        self._effective_recovery_cycles: int = _RECOVERY_CYCLES

        # #4 Cooldown windows: after SUSPENDED, enforce minimum cooldown before re-opening
        self._suspended_at:  Optional[float] = None   # monotonic time of suspension
        self._cooldown_secs: float = 1800.0            # 30 min default

    @property
    def _recovery_cycles_needed(self) -> int:
        """Exponential backoff: each prior suspension doubles the recovery requirement."""
        base = _RECOVERY_CYCLES
        backoff = min(base * (2 ** self._prior_breach_count), 20)
        return backoff

    # ------------------------------------------------------------------
    # Main cycle recording entry point
    # ------------------------------------------------------------------

    async def record_cycle(
        self,
        governance_confidence: Optional[float] = None,
        liquidity_stress:      Optional[float] = None,
        execution_errors:      int             = 0,
        infrastructure_errors: int             = 0,
        ic:                    Optional[float] = None,
        data_anomaly:          bool            = False,
        consecutive_losses:    int             = 0,
    ) -> KillState:
        """
        Record one pipeline cycle and evaluate all kill conditions.
        Returns the current state after evaluation.
        """
        async with self._lock:
            if self._state == KillState.KILLED:
                logger.critical("System is KILLED — skipping cycle evaluation")
                return self._state

            obs = CycleObservation(
                governance_confidence = governance_confidence,
                liquidity_stress      = liquidity_stress,
                execution_errors      = execution_errors,
                infrastructure_errors = infrastructure_errors,
                ic                    = ic,
                data_anomaly          = data_anomaly,
                consecutive_losses    = consecutive_losses,
            )
            self._observations.append(obs)
            # Bound history to last 100 cycles
            if len(self._observations) > 100:
                self._observations = self._observations[-100:]

            self._evaluate(obs)
            return self._state

    # ------------------------------------------------------------------
    # Evaluation logic
    # ------------------------------------------------------------------

    def _evaluate(self, obs: CycleObservation) -> None:
        """Run all trigger checks and transition state accordingly."""
        triggered_level, triggered_by, reason = self._check_triggers(obs)

        if triggered_level == KillState.KILLED:
            self._transition(KillState.KILLED, triggered_by, reason)
            self._clean_cycles = 0

        elif triggered_level == KillState.SUSPENDED:
            if self._state in (KillState.ACTIVE, KillState.WARNING):
                self._transition(KillState.SUSPENDED, triggered_by, reason)
                self._suspended_at = time.monotonic()   # #4 start cooldown
            self._clean_cycles = 0

        elif triggered_level == KillState.WARNING:
            if self._state == KillState.ACTIVE:
                self._transition(KillState.WARNING, triggered_by, reason)
            self._clean_cycles = 0

        else:
            # No trigger fired this cycle
            self._clean_cycles += 1

            # #4 Cooldown enforcement: don't recover from SUSPENDED until cooldown elapsed
            if self._state == KillState.SUSPENDED and self._suspended_at is not None:
                elapsed = time.monotonic() - self._suspended_at
                if elapsed < self._cooldown_secs:
                    remaining = self._cooldown_secs - elapsed
                    logger.debug("Cooldown active: %.0f s remaining", remaining)
                    return   # don't evaluate recovery yet

            # Auto-recovery with backoff-adjusted cycle requirement
            recovery_needed = self._recovery_cycles_needed
            if self._state == KillState.WARNING and self._clean_cycles >= recovery_needed:
                self._transition(KillState.ACTIVE, KillTrigger.NONE,
                    f"Auto-recovered after {self._clean_cycles} clean cycles "
                    f"(backoff={recovery_needed})")
            elif self._state == KillState.SUSPENDED and self._clean_cycles >= recovery_needed:
                self._transition(KillState.ACTIVE, KillTrigger.NONE,
                    f"Auto-recovered from SUSPENDED after {self._clean_cycles} clean cycles "
                    f"(backoff={recovery_needed})")

    def _check_triggers(
        self, obs: CycleObservation
    ) -> tuple[KillState, KillTrigger, str]:
        """
        Evaluate all trigger conditions.
        Returns (highest_severity_state, trigger, reason).
        """
        level    = KillState.ACTIVE
        trigger  = KillTrigger.NONE
        reason   = "clean"

        def _upgrade(new_level, new_trigger, new_reason):
            nonlocal level, trigger, reason
            _order = {KillState.ACTIVE: 0, KillState.WARNING: 1,
                      KillState.SUSPENDED: 2, KillState.KILLED: 3}
            if _order[new_level] > _order[level]:
                level, trigger, reason = new_level, new_trigger, new_reason

        # ── Data anomaly — immediate suspend ────────────────────────────────
        if obs.data_anomaly:
            _upgrade(KillState.SUSPENDED, KillTrigger.DATA_ANOMALY, "Data anomaly detected in pipeline")

        # ── Infrastructure errors ────────────────────────────────────────────
        if obs.infrastructure_errors >= _INFRA_SUSPEND_THRESH:
            _upgrade(KillState.SUSPENDED, KillTrigger.INFRASTRUCTURE_ERROR,
                     f"Infrastructure errors={obs.infrastructure_errors} >= {_INFRA_SUSPEND_THRESH}")
        elif obs.infrastructure_errors >= _INFRA_WARNING_THRESH:
            _upgrade(KillState.WARNING, KillTrigger.INFRASTRUCTURE_ERROR,
                     f"Infrastructure errors={obs.infrastructure_errors} >= {_INFRA_WARNING_THRESH}")

        # ── Execution failures ───────────────────────────────────────────────
        if obs.execution_errors >= _EXEC_SUSPEND_THRESH:
            _upgrade(KillState.SUSPENDED, KillTrigger.EXECUTION_FAILURE,
                     f"Execution errors={obs.execution_errors} >= {_EXEC_SUSPEND_THRESH}")
        elif obs.execution_errors >= _EXEC_WARNING_THRESH:
            _upgrade(KillState.WARNING, KillTrigger.EXECUTION_FAILURE,
                     f"Execution errors={obs.execution_errors} >= {_EXEC_WARNING_THRESH}")

        # ── Liquidity collapse ───────────────────────────────────────────────
        if obs.liquidity_stress is not None:
            if obs.liquidity_stress >= _LIQ_SUSPEND_THRESH:
                _upgrade(KillState.SUSPENDED, KillTrigger.LIQUIDITY_COLLAPSE,
                         f"Liquidity stress={obs.liquidity_stress:.3f} >= {_LIQ_SUSPEND_THRESH}")
            elif obs.liquidity_stress >= _LIQ_WARNING_THRESH:
                _upgrade(KillState.WARNING, KillTrigger.LIQUIDITY_COLLAPSE,
                         f"Liquidity stress={obs.liquidity_stress:.3f} >= {_LIQ_WARNING_THRESH}")

        # ── IC collapse (sustained) ──────────────────────────────────────────
        if obs.ic is not None:
            if obs.ic < _IC_SUSPEND_FLOOR:
                self._ic_breach_count += 1
            elif obs.ic < _IC_WARNING_FLOOR:
                self._ic_breach_count += 1
            else:
                self._ic_breach_count = max(0, self._ic_breach_count - 1)

            if self._ic_breach_count >= _IC_CYCLES_SUSPEND:
                _upgrade(KillState.SUSPENDED, KillTrigger.MODEL_INSTABILITY,
                         f"IC={obs.ic:.4f} below {_IC_SUSPEND_FLOOR} for "
                         f"{self._ic_breach_count} cycles")
            elif self._ic_breach_count >= _IC_CYCLES_WARNING:
                _upgrade(KillState.WARNING, KillTrigger.MODEL_INSTABILITY,
                         f"IC={obs.ic:.4f} below {_IC_WARNING_FLOOR} for "
                         f"{self._ic_breach_count} cycles")

        # ── Governance collapse ──────────────────────────────────────────────
        if obs.governance_confidence is not None:
            gc = obs.governance_confidence

            if gc < _GOV_KILL_FLOOR:
                # Catastrophic — immediate kill
                _upgrade(KillState.KILLED, KillTrigger.GOVERNANCE_COLLAPSE,
                         f"Governance confidence={gc:.3f} below catastrophic floor {_GOV_KILL_FLOOR}")
                self._gov_breach_count = 0

            elif gc < _GOV_SUSPEND_FLOOR:
                self._gov_breach_count += 1
                if self._gov_breach_count >= _GOV_CYCLES_SUSPEND:
                    _upgrade(KillState.SUSPENDED, KillTrigger.GOVERNANCE_COLLAPSE,
                             f"Governance confidence={gc:.3f} below {_GOV_SUSPEND_FLOOR} "
                             f"for {self._gov_breach_count} cycles")

            elif gc < _GOV_WARNING_FLOOR:
                self._gov_breach_count += 1
                if self._gov_breach_count >= _GOV_CYCLES_WARNING:
                    _upgrade(KillState.WARNING, KillTrigger.GOVERNANCE_COLLAPSE,
                             f"Governance confidence={gc:.3f} below {_GOV_WARNING_FLOOR} "
                             f"for {self._gov_breach_count} cycles")
            else:
                self._gov_breach_count = max(0, self._gov_breach_count - 1)

        # ── Consecutive losses ───────────────────────────────────────────────
        if obs.consecutive_losses >= 10:
            _upgrade(KillState.KILLED, KillTrigger.CONSECUTIVE_LOSSES,
                     f"Consecutive losses={obs.consecutive_losses} — maximum drawdown likely exceeded")
        elif obs.consecutive_losses >= 5:
            _upgrade(KillState.SUSPENDED, KillTrigger.CONSECUTIVE_LOSSES,
                     f"Consecutive losses={obs.consecutive_losses}")
        elif obs.consecutive_losses >= 3:
            _upgrade(KillState.WARNING, KillTrigger.CONSECUTIVE_LOSSES,
                     f"Consecutive losses={obs.consecutive_losses}")

        return level, trigger, reason

    # ------------------------------------------------------------------
    # State transitions
    # ------------------------------------------------------------------

    def _transition(self, new_state: KillState, trigger: KillTrigger, reason: str) -> None:
        if new_state == self._state:
            return

        # #4 Track trigger severity counts
        if trigger != KillTrigger.NONE:
            self._trigger_counts[trigger.value] = self._trigger_counts.get(trigger.value, 0) + 1

        # #4 Increment backoff counter on SUSPENDED transitions
        if new_state == KillState.SUSPENDED and self._state == KillState.ACTIVE:
            self._prior_breach_count += 1
            new_recovery = min(_RECOVERY_CYCLES * (2 ** (self._prior_breach_count - 1)), 20)
            logger.warning(
                "Backoff updated: prior_breaches=%d  recovery_needed=%d cycles",
                self._prior_breach_count, new_recovery,
            )

        event = KillEvent(
            from_state = self._state.value,
            to_state   = new_state.value,
            trigger    = trigger.value,
            reason     = reason,
        )
        self._history.append(event)
        self._trigger = trigger

        log_fn = logger.critical if new_state == KillState.KILLED else (
            logger.error if new_state == KillState.SUSPENDED else logger.warning
        )
        log_fn(
            "KILL SWITCH [severity=%s]: %s → %s | trigger=%s | reason=%s",
            self._trigger_counts.get(trigger.value, 1),
            self._state.value, new_state.value, trigger.value, reason,
        )

        self._state = new_state

        asyncio.get_event_loop().call_soon(
            lambda: asyncio.ensure_future(self._persist_event(event))
        )

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    async def _persist_event(self, event: KillEvent) -> None:
        """Write kill event to the DB for auditing."""
        if self._pool is None:
            return
        try:
            await self._pool.execute("""
                INSERT INTO kill_switch_events
                    (from_state, to_state, trigger, reason, timestamp, operator)
                VALUES ($1, $2, $3, $4, $5, $6)
                ON CONFLICT DO NOTHING
            """,
                event.from_state, event.to_state,
                event.trigger, event.reason,
                event.timestamp, event.operator,
            )
        except Exception as exc:
            logger.error("Failed to persist kill switch event: %s", exc)

    # ------------------------------------------------------------------
    # Public accessors
    # ------------------------------------------------------------------

    @property
    def current_state(self) -> KillState:
        return self._state

    @property
    def current_trigger(self) -> KillTrigger:
        return self._trigger

    def is_active(self) -> bool:
        """True if the system is in normal operational state."""
        return self._state == KillState.ACTIVE

    def is_deployable(self) -> bool:
        """True if new positions may be opened (ACTIVE or WARNING only)."""
        return self._state in (KillState.ACTIVE, KillState.WARNING)

    def status(self) -> dict:
        """Machine-readable status dict for API endpoints and alerting."""
        return {
            "state":             self._state.value,
            "trigger":           self._trigger.value,
            "clean_cycles":      self._clean_cycles,
            "gov_breach_count":  self._gov_breach_count,
            "ic_breach_count":   self._ic_breach_count,
            "history_length":    len(self._history),
            "last_event":        {
                "from":    self._history[-1].from_state,
                "to":      self._history[-1].to_state,
                "trigger": self._history[-1].trigger,
                "reason":  self._history[-1].reason,
                "at":      self._history[-1].timestamp.isoformat(),
            } if self._history else None,
        }

    # ------------------------------------------------------------------
    # Manual controls
    # ------------------------------------------------------------------

    def manual_suspend(self, reason: str, operator: Optional[str] = None) -> None:
        """Operator-triggered suspension."""
        self._transition(KillState.SUSPENDED, KillTrigger.MANUAL, f"[{operator}] {reason}")
        if self._history:
            self._history[-1].operator = operator

    def manual_kill(self, reason: str, operator: Optional[str] = None) -> None:
        """Operator-triggered kill. Requires manual reset."""
        self._transition(KillState.KILLED, KillTrigger.MANUAL, f"[{operator}] {reason}")
        if self._history:
            self._history[-1].operator = operator

    def reset(self, reason: str, operator: Optional[str] = None) -> None:
        """
        Reset from KILLED or SUSPENDED state.
        This is the ONLY way to exit KILLED state.
        Requires a documented reason and an operator name.
        """
        if not reason or not operator:
            raise ValueError("Both reason and operator are required to reset the kill switch")

        prev = self._state
        self._state           = KillState.ACTIVE
        self._trigger         = KillTrigger.NONE
        self._clean_cycles    = 0
        self._gov_breach_count = 0
        self._ic_breach_count  = 0

        event = KillEvent(
            from_state = prev.value,
            to_state   = KillState.ACTIVE.value,
            trigger    = KillTrigger.MANUAL.value,
            reason     = f"MANUAL RESET by {operator}: {reason}",
            operator   = operator,
        )
        self._history.append(event)
        logger.warning(
            "KILL SWITCH RESET by %s: %s → ACTIVE | reason=%s",
            operator, prev.value, reason,
        )

    def event_history(self) -> list[dict]:
        return [
            {
                "from_state": e.from_state,
                "to_state":   e.to_state,
                "trigger":    e.trigger,
                "reason":     e.reason,
                "timestamp":  e.timestamp.isoformat(),
                "operator":   e.operator,
            }
            for e in self._history
        ]


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_switch: Optional[KillSwitch] = None


def get_switch(pool=None) -> KillSwitch:
    global _switch
    if _switch is None:
        _switch = KillSwitch(pool=pool)
    return _switch
