"""
Add Phase 6 tables: portfolio_lifecycle, state_vectors, scenario_stress_results,
alt_data_events, feature_attribution_snapshots.

Revision ID: 0008
Depends-on:  0007
"""
from alembic import op

revision      = "0008"
down_revision = "0007"


def upgrade() -> None:

    # ── Portfolio lifecycle audit log (§18) ──────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS portfolio_lifecycle (
            id                              BIGSERIAL   PRIMARY KEY,
            event_id                        TEXT        NOT NULL UNIQUE,
            ticker                          TEXT        NOT NULL,
            direction                       TEXT        NOT NULL,
            signal_score                    REAL        NOT NULL,
            signal_tier                     TEXT,
            entry_reason                    TEXT,
            governance_confidence_at_entry  REAL,
            governance_uncertainty_at_entry REAL,
            throttle_mode_at_entry          TEXT,
            kill_switch_state_at_entry      TEXT,
            liquidity_regime_at_entry       TEXT,
            market_regime_at_entry          TEXT,
            notional                        REAL,
            filled_notional                 REAL,
            fill_pct                        REAL,
            size_scalar_applied             REAL,
            is_shadow_trade                 BOOLEAN     NOT NULL DEFAULT FALSE,
            opened_at                       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            exit_reason                     TEXT,
            realised_pct                    REAL,
            realised_pnl                    REAL,
            governance_confidence_at_exit   REAL,
            kill_switch_state_at_exit       TEXT,
            liquidity_regime_at_exit        TEXT,
            closed_at                       TIMESTAMPTZ,
            hold_days                       REAL
        )
    """)
    op.execute("""
        SELECT create_hypertable('portfolio_lifecycle','opened_at',if_not_exists=>TRUE)
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_pl_ticker    ON portfolio_lifecycle (ticker, opened_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_pl_mode      ON portfolio_lifecycle (throttle_mode_at_entry, opened_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_pl_shadow    ON portfolio_lifecycle (is_shadow_trade, opened_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_pl_exit      ON portfolio_lifecycle (exit_reason, closed_at DESC) WHERE closed_at IS NOT NULL")

    # ── Versioned state vectors (§9) ─────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS state_vectors (
            id           BIGSERIAL   PRIMARY KEY,
            schema_name  TEXT        NOT NULL,
            version      TEXT        NOT NULL DEFAULT '1.0',
            source       TEXT        NOT NULL,
            schema_hash  TEXT        NOT NULL,
            data_hash    TEXT        NOT NULL UNIQUE,
            parent_hash  TEXT,
            created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            tags_json    TEXT,
            data_json    TEXT        NOT NULL
        )
    """)
    op.execute("""
        SELECT create_hypertable('state_vectors','created_at',if_not_exists=>TRUE)
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_sv_schema    ON state_vectors (schema_name, created_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_sv_data_hash ON state_vectors (data_hash)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_sv_source    ON state_vectors (source, created_at DESC)")

    # ── Scenario stress results (§26) ────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS scenario_stress_results (
            id                         BIGSERIAL   PRIMARY KEY,
            run_at                     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            scenario                   TEXT        NOT NULL,
            passed                     BOOLEAN     NOT NULL,
            kill_switch_engaged        BOOLEAN     NOT NULL,
            throttle_mode_at_peak      TEXT,
            governance_confidence_min  REAL,
            governance_confidence_mean REAL,
            n_cycles_run               INT,
            failures_json              TEXT,
            warnings_json              TEXT,
            notes_json                 TEXT
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_stress_run_at  ON scenario_stress_results (run_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_stress_scenario ON scenario_stress_results (scenario, run_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_stress_passed   ON scenario_stress_results (passed, run_at DESC)")

    # ── Alternative data events (alt_data_sources) ───────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS alt_data_events (
            id             BIGSERIAL   PRIMARY KEY,
            fetched_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            ticker         TEXT        NOT NULL,
            source         TEXT        NOT NULL,
            category       TEXT        NOT NULL,
            title          TEXT        NOT NULL,
            url            TEXT,
            text           TEXT,
            published_at   TIMESTAMPTZ,
            sentiment_hint REAL,
            metadata_json  TEXT
        )
    """)
    op.execute("""
        SELECT create_hypertable('alt_data_events','fetched_at',if_not_exists=>TRUE)
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_alt_ticker   ON alt_data_events (ticker, fetched_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_alt_category ON alt_data_events (category, fetched_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_alt_source   ON alt_data_events (source, fetched_at DESC)")

    # ── Feature attribution snapshots (§25) ─────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS feature_attribution_snapshots (
            id            BIGSERIAL   PRIMARY KEY,
            computed_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            horizon       TEXT        NOT NULL DEFAULT '1d',
            n_events      INT,
            ic_json       TEXT,       -- {feature: ic_value}
            sharpe_json   TEXT,       -- {feature: sharpe_contrib}
            drift_json    TEXT,       -- {feature: z_score}
            stability_json TEXT,      -- {feature: autocorr}
            top_feature   TEXT,
            worst_feature TEXT,
            n_significant INT
        )
    """)
    op.execute("""
        SELECT create_hypertable('feature_attribution_snapshots','computed_at',if_not_exists=>TRUE)
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_fa_computed ON feature_attribution_snapshots (computed_at DESC)")

    # ── Causal propagation edges ─────────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS causal_edges (
            id                   BIGSERIAL   PRIMARY KEY,
            source_entity        TEXT        NOT NULL,
            topic                TEXT        NOT NULL,
            target_entity        TEXT        NOT NULL,
            co_occurrence_count  INT         NOT NULL DEFAULT 0,
            propagation_count    INT         NOT NULL DEFAULT 0,
            avg_lag_days         REAL,
            avg_impact           REAL,
            probability          REAL
                CHECK (probability IS NULL OR probability BETWEEN 0 AND 1),
            confidence           REAL
                CHECK (confidence IS NULL OR confidence BETWEEN 0 AND 1),
            last_updated         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            UNIQUE (source_entity, topic, target_entity)
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_causal_source  ON causal_edges (source_entity, probability DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_causal_topic   ON causal_edges (topic, probability DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_causal_target  ON causal_edges (target_entity)")

    # ── Meta-model health snapshots ──────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS meta_model_health_snapshots (
            id                    BIGSERIAL   PRIMARY KEY,
            computed_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            health_score          REAL        NOT NULL
                CHECK (health_score BETWEEN 0 AND 1),
            degradation_severity  TEXT        NOT NULL,
            requires_retraining   BOOLEAN     NOT NULL,
            attribution_stability REAL,
            calibration_stability REAL,
            regime_consistency    REAL,
            model_agreement       REAL,
            health_trend          REAL,
            warnings_json         TEXT,
            recommendations_json  TEXT
        )
    """)
    op.execute("""
        SELECT create_hypertable('meta_model_health_snapshots','computed_at',if_not_exists=>TRUE)
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_mmh_computed ON meta_model_health_snapshots (computed_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_mmh_severity ON meta_model_health_snapshots (degradation_severity, computed_at DESC)")


def downgrade() -> None:
    for table in [
        "meta_model_health_snapshots", "causal_edges",
        "feature_attribution_snapshots", "alt_data_events",
        "scenario_stress_results", "state_vectors", "portfolio_lifecycle",
    ]:
        op.execute(f"DROP TABLE IF EXISTS {table} CASCADE")
