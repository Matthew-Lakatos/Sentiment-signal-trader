"""Initial schema: scraped_events hypertable, source_health, alert_log.

Revision ID: 0001
"""
from alembic import op

revision = "0001"
down_revision = None


def upgrade() -> None:
    op.execute("CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE")
    op.execute("CREATE EXTENSION IF NOT EXISTS vector")

    op.execute("""
        CREATE TABLE IF NOT EXISTS scraped_events (
            event_id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            url               TEXT        NOT NULL,
            source_domain     TEXT        NOT NULL,
            scraped_at        TIMESTAMPTZ NOT NULL,
            http_status       SMALLINT,
            raw_text_hash     CHAR(64)    NOT NULL,
            summary           TEXT        NOT NULL DEFAULT '',
            sentiment_label   TEXT        CHECK (sentiment_label IN
                                ('POSITIVE','NEGATIVE','NEUTRAL','UNCERTAIN')),
            sentiment_score   REAL        CHECK (sentiment_score BETWEEN 0 AND 1),
            sentiment_confident BOOLEAN   NOT NULL DEFAULT TRUE,
            keywords          TEXT[]      NOT NULL DEFAULT '{}',
            topics            TEXT[]      NOT NULL DEFAULT '{}',
            emotions          JSONB       NOT NULL DEFAULT '{}',
            embedding         VECTOR(384),
            embedding_model   TEXT        NOT NULL DEFAULT '',
            credibility_score REAL        CHECK (credibility_score BETWEEN 0 AND 1),
            propaganda_score  REAL        CHECK (propaganda_score  BETWEEN 0 AND 1),
            propaganda_flags  TEXT[]      NOT NULL DEFAULT '{}',
            materiality_score REAL        NOT NULL DEFAULT 0.0,
            materiality_tier  TEXT        NOT NULL DEFAULT 'LOW'
                                CHECK (materiality_tier IN ('CRITICAL','HIGH','MEDIUM','LOW')),
            is_duplicate      BOOLEAN     NOT NULL DEFAULT FALSE,
            canonical_event_id UUID       REFERENCES scraped_events(event_id)
        )
    """)

    op.execute("""
        SELECT create_hypertable(
            'scraped_events', 'scraped_at',
            chunk_time_interval => INTERVAL '1 day',
            if_not_exists => TRUE
        )
    """)

    # Indexes
    op.execute("CREATE INDEX IF NOT EXISTS idx_se_domain_time ON scraped_events (source_domain, scraped_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_se_hash ON scraped_events (raw_text_hash) WHERE NOT is_duplicate")
    op.execute("CREATE INDEX IF NOT EXISTS idx_se_keywords ON scraped_events USING GIN (keywords)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_se_topics   ON scraped_events USING GIN (topics)")

    # Continuous aggregate: hourly sentiment roll-up
    op.execute("""
        CREATE MATERIALIZED VIEW IF NOT EXISTS hourly_sentiment
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 hour', scraped_at)  AS bucket,
            source_domain,
            sentiment_label,
            COUNT(*)                           AS event_count,
            AVG(sentiment_score)               AS avg_score,
            AVG(materiality_score)             AS avg_materiality
        FROM   scraped_events
        WHERE  NOT is_duplicate
        GROUP  BY 1, 2, 3
    """)

    # Source health table
    op.execute("""
        CREATE TABLE IF NOT EXISTS source_health (
            domain              TEXT        PRIMARY KEY,
            last_success_at     TIMESTAMPTZ,
            consecutive_fails   SMALLINT    NOT NULL DEFAULT 0,
            is_dead             BOOLEAN     NOT NULL DEFAULT FALSE,
            dead_since          TIMESTAMPTZ,
            robots_delay_s      REAL        NOT NULL DEFAULT 1.0
        )
    """)

    # Alert log table
    op.execute("""
        CREATE TABLE IF NOT EXISTS alert_log (
            alert_id       UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            fired_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            alert_type     TEXT        NOT NULL,
            severity       TEXT        NOT NULL DEFAULT 'MEDIUM',
            source_domain  TEXT,
            payload        JSONB       NOT NULL DEFAULT '{}',
            delivered      BOOLEAN     NOT NULL DEFAULT FALSE,
            delivery_error TEXT,
            UNIQUE (alert_type, source_domain, date_trunc('hour', fired_at))
        )
    """)

    # URL scrape cache
    op.execute("""
        CREATE TABLE IF NOT EXISTS scrape_cache (
            url             TEXT        PRIMARY KEY,
            last_scraped_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
    """)

    # Crawler queue (persistent)
    op.execute("""
        CREATE TABLE IF NOT EXISTS crawl_queue (
            url        TEXT        PRIMARY KEY,
            added_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            crawled    BOOLEAN     NOT NULL DEFAULT FALSE,
            crawled_at TIMESTAMPTZ
        )
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS crawl_queue")
    op.execute("DROP TABLE IF EXISTS scrape_cache")
    op.execute("DROP TABLE IF EXISTS alert_log")
    op.execute("DROP TABLE IF EXISTS source_health")
    op.execute("DROP MATERIALIZED VIEW IF EXISTS hourly_sentiment")
    op.execute("DROP TABLE IF EXISTS scraped_events")
