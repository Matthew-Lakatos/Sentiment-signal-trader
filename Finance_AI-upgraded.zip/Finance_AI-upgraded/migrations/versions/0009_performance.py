"""
Migration 0009: pgvector HNSW index + performance infrastructure columns.

Changes:
1. Replace IVFFlat embedding index with HNSW (C++ ANN, 100x faster search)
2. Add infrastructure_meta table for ONNX/FAISS/accumulator state tracking
3. Add amihud_daily table for incremental accumulator persistence
4. Add ticker_resolution_cache table (mirror of SQLite sidecar in DB)
5. Add performance_log table for latency budget audit trail

Revision ID: 0009
Depends-on:  0008
"""
from alembic import op

revision      = "0009"
down_revision = "0008"


def upgrade() -> None:

    # ── 1. HNSW index on embeddings — 100x faster than IVFFlat exact scan ───
    # Drop existing IVFFlat index if present, then create HNSW
    op.execute("DROP INDEX IF EXISTS idx_events_embedding")
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_events_embedding_hnsw
            ON scraped_events
            USING hnsw (embedding vector_cosine_ops)
            WITH (m = 16, ef_construction = 64)
    """)
    # Also add a separate IVFFlat for compatibility with pgvector < 0.5 fallback
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_events_embedding_ivf
            ON scraped_events
            USING ivfflat (embedding vector_cosine_ops)
            WITH (lists = 100)
    """)

    # ── 2. Infrastructure meta — track ONNX/FAISS/accumulator state ──────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS infrastructure_meta (
            key         TEXT        PRIMARY KEY,
            value       TEXT        NOT NULL,
            updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            notes       TEXT
        )
    """)
    # Seed known keys
    op.execute("""
        INSERT INTO infrastructure_meta (key, value, notes)
        VALUES
            ('faiss_index_size',    '0',     'Number of vectors in FAISS index'),
            ('faiss_index_built',   'false', 'Whether index has been built this session'),
            ('onnx_model_path',     '',      'Path to ONNX embedding model (empty = PyTorch)'),
            ('embedding_backend',   'pytorch', 'pytorch | onnx'),
            ('dedup_backend',       'pgvector', 'pgvector | faiss'),
            ('amihud_accum_tickers','[]',    'JSON list of tickers with warm accumulators')
        ON CONFLICT (key) DO NOTHING
    """)

    # ── 3. Amihud daily bars — persist accumulator state across restarts ──────
    op.execute("""
        CREATE TABLE IF NOT EXISTS amihud_daily (
            ticker          TEXT        NOT NULL,
            price_date      TEXT        NOT NULL,
            close_price     REAL        NOT NULL,
            volume          REAL        NOT NULL,
            log_return      REAL,
            dollar_volume   REAL,
            amihud_bar      REAL,
            ewma_amihud     REAL,
            normalised_score REAL,
            PRIMARY KEY (ticker, price_date)
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_amihud_ticker ON amihud_daily (ticker, price_date DESC)")

    # ── 4. Ticker resolution cache in DB (mirrors SQLite sidecar) ─────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS ticker_resolution_cache (
            normalised_name TEXT        PRIMARY KEY,
            ticker          TEXT,
            source          TEXT        NOT NULL,
            resolved_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_ticker_res_ticker ON ticker_resolution_cache (ticker) WHERE ticker IS NOT NULL")

    # ── 5. Performance audit log ───────────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS performance_log (
            id              BIGSERIAL   PRIMARY KEY,
            cycle_id        TEXT        NOT NULL,
            stage           TEXT        NOT NULL,
            elapsed_s       REAL        NOT NULL,
            budget_s        REAL,
            exceeded        BOOLEAN     NOT NULL DEFAULT FALSE,
            recorded_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            metadata_json   TEXT
        )
    """)
    op.execute("""
        SELECT create_hypertable('performance_log','recorded_at',if_not_exists=>TRUE)
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_perf_stage ON performance_log (stage, recorded_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_perf_exceeded ON performance_log (exceeded, recorded_at DESC) WHERE exceeded")

    # ── 6. Rate limiter audit log ──────────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS rate_limiter_stats (
            id              BIGSERIAL   PRIMARY KEY,
            recorded_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            connector       TEXT        NOT NULL,
            state           TEXT        NOT NULL,
            total_calls     INT,
            total_waits     INT,
            total_failures  INT
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_rl_connector ON rate_limiter_stats (connector, recorded_at DESC)")


def downgrade() -> None:
    for tbl in ["rate_limiter_stats", "performance_log", "ticker_resolution_cache",
                "amihud_daily", "infrastructure_meta"]:
        op.execute(f"DROP TABLE IF EXISTS {tbl} CASCADE")
    op.execute("DROP INDEX IF EXISTS idx_events_embedding_hnsw")
    op.execute("DROP INDEX IF EXISTS idx_events_embedding_ivf")
