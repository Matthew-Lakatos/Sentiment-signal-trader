"""Add Phase 1 columns: entity targets, sector, surprise, factor-neutral, cross-sectional, market context.

Revision ID: 0003
Depends-on:  0002
"""
from alembic import op

revision      = "0003"
down_revision = "0002"


def upgrade() -> None:
    # ── §2 Expectation surprise ─────────────────────────────────────────────
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS targets                 TEXT[]
                NOT NULL DEFAULT '{}',
            ADD COLUMN IF NOT EXISTS surprise_score          REAL
                CHECK (surprise_score IS NULL OR surprise_score BETWEEN -1 AND 1),
            ADD COLUMN IF NOT EXISTS guidance_revision_score REAL
                CHECK (guidance_revision_score IS NULL OR guidance_revision_score BETWEEN -1 AND 1)
    """)

    # ── §11 Factor neutralisation ───────────────────────────────────────────
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS primary_sector       TEXT    NOT NULL DEFAULT 'unknown',
            ADD COLUMN IF NOT EXISTS factor_neutral_score REAL
                CHECK (factor_neutral_score IS NULL OR factor_neutral_score BETWEEN -1 AND 1)
    """)

    # ── §10 Cross-sectional ranking ─────────────────────────────────────────
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS cs_percentile        REAL
                CHECK (cs_percentile IS NULL OR cs_percentile BETWEEN 0 AND 1),
            ADD COLUMN IF NOT EXISTS cs_sector_percentile REAL
                CHECK (cs_sector_percentile IS NULL OR cs_sector_percentile BETWEEN 0 AND 1),
            ADD COLUMN IF NOT EXISTS cs_score             REAL
                CHECK (cs_score IS NULL OR cs_score BETWEEN -1 AND 1)
    """)

    # ── §9 Market-state context ─────────────────────────────────────────────
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS market_regime      TEXT NOT NULL DEFAULT 'NEUTRAL',
            ADD COLUMN IF NOT EXISTS vix_level          REAL,
            ADD COLUMN IF NOT EXISTS yield_curve_slope  REAL
    """)

    # ── Indexes for Phase 1 query patterns ─────────────────────────────────
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_primary_sector
            ON scraped_events (primary_sector, scraped_at DESC)
            WHERE NOT is_duplicate
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_cs_score
            ON scraped_events (cs_score DESC NULLS LAST)
            WHERE NOT is_duplicate
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_factor_neutral
            ON scraped_events (factor_neutral_score DESC NULLS LAST)
            WHERE NOT is_duplicate
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_market_regime
            ON scraped_events (market_regime, scraped_at DESC)
            WHERE NOT is_duplicate
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_surprise
            ON scraped_events (surprise_score DESC NULLS LAST)
            WHERE NOT is_duplicate AND surprise_score IS NOT NULL
    """)

    # ── Continuous aggregate: Phase 1 regime rollup (daily) ────────────────
    op.execute("""
        CREATE MATERIALIZED VIEW IF NOT EXISTS daily_regime_signals
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 day', scraped_at)   AS bucket,
            market_regime,
            primary_sector,
            COUNT(*)                           AS event_count,
            AVG(signal_score)                  AS avg_signal,
            AVG(factor_neutral_score)          AS avg_factor_neutral,
            AVG(cs_score)                      AS avg_cs_score,
            AVG(surprise_score)                AS avg_surprise,
            AVG(vix_level)                     AS avg_vix
        FROM   scraped_events
        WHERE  NOT is_duplicate
        GROUP  BY 1, 2, 3
    """)


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS daily_regime_signals")
    op.execute("DROP INDEX IF EXISTS idx_se_surprise")
    op.execute("DROP INDEX IF EXISTS idx_se_market_regime")
    op.execute("DROP INDEX IF EXISTS idx_se_factor_neutral")
    op.execute("DROP INDEX IF EXISTS idx_se_cs_score")
    op.execute("DROP INDEX IF EXISTS idx_se_primary_sector")
    op.execute("""
        ALTER TABLE scraped_events
            DROP COLUMN IF EXISTS targets,
            DROP COLUMN IF EXISTS surprise_score,
            DROP COLUMN IF EXISTS guidance_revision_score,
            DROP COLUMN IF EXISTS primary_sector,
            DROP COLUMN IF EXISTS factor_neutral_score,
            DROP COLUMN IF EXISTS cs_percentile,
            DROP COLUMN IF EXISTS cs_sector_percentile,
            DROP COLUMN IF EXISTS cs_score,
            DROP COLUMN IF EXISTS market_regime,
            DROP COLUMN IF EXISTS vix_level,
            DROP COLUMN IF EXISTS yield_curve_slope
    """)
