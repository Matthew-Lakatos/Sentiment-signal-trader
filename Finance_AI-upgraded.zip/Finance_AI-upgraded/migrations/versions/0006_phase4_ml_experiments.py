"""Add Phase 4 tables: experiment runs, ML model registry, contradiction log.

Revision ID: 0006
Depends-on:  0005
"""
from alembic import op

revision      = "0006"
down_revision = "0005"


def upgrade() -> None:
    # ── §23 Experiment run log ──────────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS experiment_runs (
            run_id           UUID        PRIMARY KEY,
            experiment_name  TEXT        NOT NULL,
            status           TEXT        NOT NULL DEFAULT 'running',
            started_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            ended_at         TIMESTAMPTZ,
            duration_seconds REAL,
            params_json      JSONB       NOT NULL DEFAULT '{}',
            metrics_json     JSONB       NOT NULL DEFAULT '{}',
            tags_json        JSONB       NOT NULL DEFAULT '{}',
            artifact_paths   TEXT[]      NOT NULL DEFAULT '{}',
            dataset_hash     TEXT,
            error            TEXT
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_exp_name_started
            ON experiment_runs (experiment_name, started_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_exp_status
            ON experiment_runs (status, experiment_name)
    """)

    # ── §19 ML model registry ───────────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS ml_model_registry (
            model_id        UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            registered_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            experiment_name TEXT        NOT NULL,
            run_id          UUID        REFERENCES experiment_runs(run_id),
            method          TEXT        NOT NULL,
            horizon         SMALLINT    NOT NULL DEFAULT 1,
            ic_oos          REAL,
            ic_is           REAL,
            n_samples       INT,
            weights_json    JSONB       NOT NULL DEFAULT '{}',
            feature_names   TEXT[]      NOT NULL DEFAULT '{}',
            notes           TEXT,
            is_production   BOOLEAN     NOT NULL DEFAULT FALSE
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_mlreg_method_horizon
            ON ml_model_registry (method, horizon, registered_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_mlreg_production
            ON ml_model_registry (is_production, horizon)
            WHERE is_production = TRUE
    """)

    # ── §21 Contradiction detection log ────────────────────────────────────
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS contradiction_score     REAL
                CHECK (contradiction_score IS NULL OR contradiction_score BETWEEN 0 AND 1),
            ADD COLUMN IF NOT EXISTS signal_adjustment       REAL
                CHECK (signal_adjustment IS NULL OR signal_adjustment BETWEEN 0 AND 2),
            ADD COLUMN IF NOT EXISTS price_leading_narrative BOOLEAN NOT NULL DEFAULT FALSE,
            ADD COLUMN IF NOT EXISTS narrative_leading_price BOOLEAN NOT NULL DEFAULT FALSE,
            ADD COLUMN IF NOT EXISTS crowd_reversal_signal   BOOLEAN NOT NULL DEFAULT FALSE,
            ADD COLUMN IF NOT EXISTS adjusted_signal_score   REAL
                CHECK (adjusted_signal_score IS NULL OR adjusted_signal_score BETWEEN -1 AND 1)
    """)

    op.execute("""
        CREATE TABLE IF NOT EXISTS contradiction_log (
            log_id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            event_id              UUID        NOT NULL,
            logged_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            entity                TEXT        NOT NULL,
            ticker                TEXT,
            disagreement_score    REAL,
            price_return_pre      REAL,
            price_return_post     REAL,
            price_leading         BOOLEAN     NOT NULL DEFAULT FALSE,
            narrative_leading     BOOLEAN     NOT NULL DEFAULT FALSE,
            crowd_reversal        BOOLEAN     NOT NULL DEFAULT FALSE,
            consecutive_same_dir  SMALLINT,
            signal_adjustment     REAL        NOT NULL DEFAULT 1.0,
            adjustment_reasons    TEXT[]      NOT NULL DEFAULT '{}'
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_contra_event
            ON contradiction_log (event_id, logged_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_contra_entity
            ON contradiction_log (entity, logged_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_contra_adjustments
            ON contradiction_log (signal_adjustment, logged_at DESC)
            WHERE signal_adjustment != 1.0
    """)

    # ── Indexes for Phase 4 query patterns ─────────────────────────────────
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_adjusted_signal
            ON scraped_events (adjusted_signal_score DESC NULLS LAST)
            WHERE NOT is_duplicate AND adjusted_signal_score IS NOT NULL
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_price_leading
            ON scraped_events (price_leading_narrative, scraped_at DESC)
            WHERE NOT is_duplicate AND price_leading_narrative = TRUE
    """)


def downgrade() -> None:
    op.execute("DROP INDEX IF EXISTS idx_se_price_leading")
    op.execute("DROP INDEX IF EXISTS idx_se_adjusted_signal")
    op.execute("DROP INDEX IF EXISTS idx_contra_adjustments")
    op.execute("DROP INDEX IF EXISTS idx_contra_entity")
    op.execute("DROP INDEX IF EXISTS idx_contra_event")
    op.execute("DROP TABLE IF EXISTS contradiction_log")
    op.execute("""
        ALTER TABLE scraped_events
            DROP COLUMN IF EXISTS contradiction_score,
            DROP COLUMN IF EXISTS signal_adjustment,
            DROP COLUMN IF EXISTS price_leading_narrative,
            DROP COLUMN IF EXISTS narrative_leading_price,
            DROP COLUMN IF EXISTS crowd_reversal_signal,
            DROP COLUMN IF EXISTS adjusted_signal_score
    """)
    op.execute("DROP INDEX IF EXISTS idx_mlreg_production")
    op.execute("DROP INDEX IF EXISTS idx_mlreg_method_horizon")
    op.execute("DROP TABLE IF EXISTS ml_model_registry")
    op.execute("DROP INDEX IF EXISTS idx_exp_status")
    op.execute("DROP INDEX IF EXISTS idx_exp_name_started")
    op.execute("DROP TABLE IF EXISTS experiment_runs")
