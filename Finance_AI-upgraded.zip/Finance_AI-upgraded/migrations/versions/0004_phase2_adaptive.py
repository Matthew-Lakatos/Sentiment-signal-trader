"""Add Phase 2 columns: online learning state, position lifecycle, drift health.

Revision ID: 0004
Depends-on:  0003
"""
from alembic import op

revision      = "0004"
down_revision = "0003"


def upgrade() -> None:
    # ── §20 Multi-horizon signal scores ────────────────────────────────────
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS signal_score_t1   REAL
                CHECK (signal_score_t1  IS NULL OR signal_score_t1  BETWEEN -1 AND 1),
            ADD COLUMN IF NOT EXISTS signal_score_t5   REAL
                CHECK (signal_score_t5  IS NULL OR signal_score_t5  BETWEEN -1 AND 1),
            ADD COLUMN IF NOT EXISTS signal_score_t20  REAL
                CHECK (signal_score_t20 IS NULL OR signal_score_t20 BETWEEN -1 AND 1),
            ADD COLUMN IF NOT EXISTS dominant_horizon  TEXT,
            ADD COLUMN IF NOT EXISTS horizon_confidence_t1  REAL,
            ADD COLUMN IF NOT EXISTS horizon_confidence_t5  REAL,
            ADD COLUMN IF NOT EXISTS horizon_confidence_t20 REAL
    """)

    # ── §7 Online learning metadata ─────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS online_learner_snapshots (
            snapshot_id   UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            saved_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            n_updates     INT         NOT NULL,
            forgetting    REAL        NOT NULL,
            features      TEXT[]      NOT NULL,
            weights_json  JSONB       NOT NULL,
            drift_healthy BOOLEAN     NOT NULL DEFAULT TRUE,
            notes         TEXT
        )
    """)

    # ── §18 Drift monitor health log ────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS drift_health_log (
            log_id        UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            logged_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            rolling_ic    REAL,
            rolling_sharpe REAL,
            rolling_hit_rate REAL,
            gate_open     BOOLEAN     NOT NULL,
            consecutive_bad INT       NOT NULL DEFAULT 0,
            consecutive_good INT      NOT NULL DEFAULT 0,
            n_windows     INT         NOT NULL DEFAULT 0,
            market_regime TEXT        NOT NULL DEFAULT 'NEUTRAL',
            alerts_json   JSONB,
            summary       TEXT
        )
    """)
    op.execute("""
        SELECT create_hypertable(
            'drift_health_log', 'logged_at',
            if_not_exists => TRUE
        )
    """)

    # ── §13 Position lifecycle log ──────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS position_lifecycle (
            lifecycle_id   UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            ticker         TEXT        NOT NULL,
            direction      TEXT        NOT NULL,
            state          TEXT        NOT NULL,
            notional       REAL        NOT NULL,
            conviction     REAL,
            opened_at      TIMESTAMPTZ NOT NULL,
            updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            event_ids      TEXT[]      NOT NULL DEFAULT '{}',
            state_history  JSONB,
            unrealised_pnl REAL        DEFAULT 0.0
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_plc_ticker_state
            ON position_lifecycle (ticker, state, updated_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_plc_updated_at
            ON position_lifecycle (updated_at DESC)
    """)

    # ── Multi-horizon index ─────────────────────────────────────────────────
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_signal_t1
            ON scraped_events (signal_score_t1 DESC NULLS LAST)
            WHERE NOT is_duplicate AND signal_score_t1 IS NOT NULL
    """)

    # ── Continuous aggregate: daily drift health ────────────────────────────
    op.execute("""
        CREATE MATERIALIZED VIEW IF NOT EXISTS daily_drift_health
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 day', logged_at) AS bucket,
            AVG(rolling_ic)                 AS avg_ic,
            AVG(rolling_sharpe)             AS avg_sharpe,
            AVG(rolling_hit_rate)           AS avg_hit_rate,
            BOOL_AND(gate_open)             AS gate_always_open,
            MAX(consecutive_bad)            AS max_consecutive_bad,
            COUNT(*)                        AS n_checks
        FROM drift_health_log
        GROUP BY 1
    """)


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS daily_drift_health")
    op.execute("DROP INDEX IF EXISTS idx_se_signal_t1")
    op.execute("DROP INDEX IF EXISTS idx_plc_updated_at")
    op.execute("DROP INDEX IF EXISTS idx_plc_ticker_state")
    op.execute("DROP TABLE IF EXISTS position_lifecycle")
    op.execute("DROP TABLE IF EXISTS drift_health_log")
    op.execute("DROP TABLE IF EXISTS online_learner_snapshots")
    op.execute("""
        ALTER TABLE scraped_events
            DROP COLUMN IF EXISTS signal_score_t1,
            DROP COLUMN IF EXISTS signal_score_t5,
            DROP COLUMN IF EXISTS signal_score_t20,
            DROP COLUMN IF EXISTS dominant_horizon,
            DROP COLUMN IF EXISTS horizon_confidence_t1,
            DROP COLUMN IF EXISTS horizon_confidence_t5,
            DROP COLUMN IF EXISTS horizon_confidence_t20
    """)
