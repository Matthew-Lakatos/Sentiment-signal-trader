"""
Migration 0010: Financial feature columns on scraped_events.

Adds all Phase 2 financial feature fields:
  - Price features: momentum (1m/3m/12m), volatility, beta, 52w, dollar vol
  - Fundamental: P/E, FCF yield, revenue growth, ROE, debt/equity,
                 FINRA short vol ratio, value/quality/fragility scores
  - Earnings: EPS SUE, beat rate, revision momentum, implied move,
              analyst price target upside
  - Macro: FRED HY spread, US Treasury 10Y, yield curve, CBOE VIX term,
           ECB EUR/USD, macro stress/growth scores
  - Signal conditioning: financial_signal_mult
  - Realised returns: 1d, 5d, 20d (filled retrospectively for calibration)

Also creates:
  - financial_feature_cache — per-ticker feature snapshots with TTL
  - macro_feature_snapshots — global macro snapshots from FRED/ECB/Treasury/CBOE
  - earnings_surprise_cache — per-ticker EPS surprise history

Revision ID: 0010
Depends-on:  0009
"""
from alembic import op

revision      = "0010"
down_revision = "0009"


def upgrade() -> None:

    # ── Price feature columns ────────────────────────────────────────────────
    price_cols = [
        ("price_momentum_1m",    "REAL"),
        ("price_momentum_3m",    "REAL"),
        ("price_momentum_6m",    "REAL"),
        ("price_momentum_12m",   "REAL"),
        ("price_vol_10d",        "REAL"),
        ("price_vol_30d",        "REAL"),
        ("price_vol_regime",     "REAL"),
        ("price_week52_pct",     "REAL"),
        ("price_to_sma50",       "REAL"),
        ("price_rsi_14",         "REAL"),
        ("price_beta_30d",       "REAL"),
        ("price_dollar_vol_log", "REAL"),
    ]

    # ── Fundamental feature columns ───────────────────────────────────────────
    fund_cols = [
        ("fund_pe_ratio",        "REAL"),
        ("fund_forward_pe",      "REAL"),
        ("fund_pb_ratio",        "REAL"),
        ("fund_ev_ebitda",       "REAL"),
        ("fund_fcf_yield",       "REAL"),
        ("fund_ps_ratio",        "REAL"),
        ("fund_revenue_growth",  "REAL"),
        ("fund_earnings_growth", "REAL"),
        ("fund_gross_margin",    "REAL"),
        ("fund_operating_margin","REAL"),
        ("fund_roe",             "REAL"),
        ("fund_roa",             "REAL"),
        ("fund_debt_to_equity",  "REAL"),
        ("fund_current_ratio",   "REAL"),
        ("fund_interest_coverage","REAL"),
        ("fund_short_ratio",     "REAL"),
        ("fund_short_pct_float", "REAL"),
        ("fund_finra_short_vol", "REAL"),   # FINRA REGSHO short vol ratio
        ("fund_value_score",     "REAL"),
        ("fund_quality_score",   "REAL"),
        ("fund_fragility_score", "REAL"),
    ]

    # ── Earnings/surprise feature columns ─────────────────────────────────────
    earn_cols = [
        ("earn_eps_surprise_pct",   "REAL"),
        ("earn_eps_sue",            "REAL"),   # standardised unexpected earnings
        ("earn_beat_rate",          "REAL"),
        ("earn_surprise_momentum",  "REAL"),
        ("earn_revision_momentum",  "REAL"),
        ("earn_pt_upside",          "REAL"),   # analyst price target upside
        ("earn_n_analysts",         "INT"),
        ("earn_implied_move",       "REAL"),   # CBOE ATM straddle / spot
        ("earn_actual_vs_implied",  "REAL"),
        ("earn_next_er_days",       "REAL"),
        ("earn_last_earnings_date", "TEXT"),
    ]

    # ── Macro feature columns (FRED + ECB + Treasury + CBOE) ─────────────────
    macro_cols = [
        ("macro_unemployment",      "REAL"),
        ("macro_cpi_yoy",           "REAL"),
        ("macro_initial_claims",    "REAL"),
        ("macro_hy_spread",         "REAL"),   # FRED HY OAS spread
        ("macro_ig_spread",         "REAL"),   # FRED IG OAS spread
        ("macro_breakeven_5y",      "REAL"),   # FRED 5Y breakeven inflation
        ("macro_tsy_3m",            "REAL"),   # US Treasury 3M (direct)
        ("macro_tsy_2y",            "REAL"),
        ("macro_tsy_10y",           "REAL"),
        ("macro_tsy_30y",           "REAL"),
        ("macro_tsy_spread_10_2",   "REAL"),   # yield curve 10Y-2Y
        ("macro_tsy_spread_10_3m",  "REAL"),   # yield curve 10Y-3M
        ("macro_vix9d",             "REAL"),   # CBOE VIX 9-day
        ("macro_vix3m",             "REAL"),   # CBOE VIX 3-month
        ("macro_vix_term_slope",    "REAL"),   # VIX3M - VIX
        ("macro_vix_term_score",    "REAL"),   # [0,1] stress from term structure
        ("macro_eurusd",            "REAL"),   # ECB EUR/USD
        ("macro_euribor_3m",        "REAL"),   # ECB 3M EURIBOR
        ("macro_bund_10y",          "REAL"),   # ECB German 10Y Bund
        ("macro_ita_spread",        "REAL"),   # ECB Italy-Germany spread
        ("macro_stress_score",      "REAL"),
        ("macro_growth_score",      "REAL"),
        ("macro_global_regime",     "TEXT"),
    ]

    # ── Signal conditioning + realised returns ────────────────────────────────
    signal_cols = [
        ("financial_signal_mult",   "REAL"),   # [0.3, 1.5] conditioning factor
        ("eps_surprise_sue",        "REAL"),   # duplicate on ScrapedEvent for easy query
        ("realised_return_1d",      "REAL"),
        ("realised_return_5d",      "REAL"),
        ("realised_return_20d",     "REAL"),
    ]

    all_new_cols = price_cols + fund_cols + earn_cols + macro_cols + signal_cols

    for col_name, col_type in all_new_cols:
        try:
            op.execute(
                f"ALTER TABLE scraped_events ADD COLUMN {col_name} {col_type}"
            )
        except Exception:
            pass   # column already exists — idempotent

    # ── Indexes on new columns ────────────────────────────────────────────────
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_ev_realised_1d
            ON scraped_events (realised_return_1d)
            WHERE realised_return_1d IS NOT NULL
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_ev_eps_sue
            ON scraped_events (earn_eps_sue, scraped_at DESC)
            WHERE earn_eps_sue IS NOT NULL
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_ev_financial_mult
            ON scraped_events (financial_signal_mult, scraped_at DESC)
            WHERE financial_signal_mult IS NOT NULL
    """)

    # ── Per-ticker financial feature cache ────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS financial_feature_cache (
            ticker          TEXT        NOT NULL,
            feature_type    TEXT        NOT NULL,   -- price|fundamental|earnings|macro
            fetched_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            ttl_hours       REAL        NOT NULL DEFAULT 24,
            features_json   TEXT        NOT NULL,
            is_stale        BOOLEAN     NOT NULL DEFAULT FALSE,
            PRIMARY KEY (ticker, feature_type)
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_ffc_ticker ON financial_feature_cache (ticker)")

    # ── Global macro snapshot store ───────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS macro_feature_snapshots (
            id              BIGSERIAL   PRIMARY KEY,
            fetched_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            -- FRED
            fred_unemployment    REAL,
            fred_cpi_yoy         REAL,
            fred_initial_claims  REAL,
            fred_hy_spread       REAL,
            fred_ig_spread       REAL,
            fred_breakeven_5y    REAL,
            fred_ted_spread      REAL,
            -- US Treasury (direct from Treasury.gov)
            tsy_3m               REAL,
            tsy_2y               REAL,
            tsy_5y               REAL,
            tsy_10y              REAL,
            tsy_30y              REAL,
            tsy_10y_2y_spread    REAL,
            tsy_10y_3m_spread    REAL,
            -- CBOE VIX term structure
            cboe_vix9d           REAL,
            cboe_vix             REAL,
            cboe_vix3m           REAL,
            cboe_vix6m           REAL,
            cboe_vix_term_slope  REAL,
            cboe_vix_term_score  REAL,
            -- ECB SDW
            ecb_eurusd           REAL,
            ecb_euribor_3m       REAL,
            ecb_de_bund_10y      REAL,
            ecb_spread_ita_de    REAL,
            -- Composite
            macro_stress_score   REAL,
            macro_growth_score   REAL,
            global_risk_regime   TEXT,
            sources_ok_json      TEXT,
            is_stale             BOOLEAN NOT NULL DEFAULT FALSE
        )
    """)
    op.execute("""
        SELECT create_hypertable(
            'macro_feature_snapshots', 'fetched_at', if_not_exists => TRUE
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_mfs_fetched ON macro_feature_snapshots (fetched_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_mfs_regime ON macro_feature_snapshots (global_risk_regime, fetched_at DESC)")

    # ── Per-ticker EPS surprise history cache ─────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS earnings_surprise_cache (
            ticker              TEXT        NOT NULL,
            fiscal_quarter      TEXT        NOT NULL,   -- e.g. "2025-Q1"
            reported_date       TEXT,
            eps_estimate        REAL,
            eps_actual          REAL,
            eps_surprise_pct    REAL,
            sue_score           REAL,
            implied_move_pct    REAL,
            revision_momentum   REAL,
            price_target_upside REAL,
            n_analysts          INT,
            fetched_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY (ticker, fiscal_quarter)
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_esc_ticker ON earnings_surprise_cache (ticker, fetched_at DESC)")
    op.execute("CREATE INDEX IF NOT EXISTS idx_esc_sue ON earnings_surprise_cache (sue_score DESC) WHERE sue_score IS NOT NULL")

    # ── FINRA short interest history ──────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS finra_short_history (
            ticker          TEXT    NOT NULL,
            trade_date      TEXT    NOT NULL,
            short_vol       REAL,
            total_vol       REAL,
            short_vol_ratio REAL
                CHECK (short_vol_ratio IS NULL OR short_vol_ratio BETWEEN 0 AND 1),
            PRIMARY KEY (ticker, trade_date)
        )
    """)
    op.execute("CREATE INDEX IF NOT EXISTS idx_fsh_ticker ON finra_short_history (ticker, trade_date DESC)")


def downgrade() -> None:
    for tbl in [
        "finra_short_history", "earnings_surprise_cache",
        "macro_feature_snapshots", "financial_feature_cache",
    ]:
        op.execute(f"DROP TABLE IF EXISTS {tbl} CASCADE")

    # Note: ALTER TABLE DROP COLUMN is not easily reversible;
    # we skip column removal in downgrade to preserve data safety.
    op.execute("DROP INDEX IF EXISTS idx_ev_realised_1d")
    op.execute("DROP INDEX IF EXISTS idx_ev_eps_sue")
    op.execute("DROP INDEX IF EXISTS idx_ev_financial_mult")
