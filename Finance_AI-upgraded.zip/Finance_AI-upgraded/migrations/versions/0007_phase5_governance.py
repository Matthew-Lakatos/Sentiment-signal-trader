"""Add Phase 5 tables: kill switch events, governance snapshots, liquidity snapshots, positioning snapshots.

Revision ID: 0007
Depends-on:  0006
"""
from alembic import op

revision      = "0007"
down_revision = "0006"


def upgrade() -> None:

    # ── §23 Kill-switch event log ───────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS kill_switch_events (
            id          BIGSERIAL   PRIMARY KEY,
            from_state  TEXT        NOT NULL,
            to_state    TEXT        NOT NULL,
            trigger     TEXT        NOT NULL,
            reason      TEXT        NOT NULL,
            timestamp   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            operator    TEXT
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_ks_timestamp
            ON kill_switch_events (timestamp DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_ks_trigger
            ON kill_switch_events (trigger, timestamp DESC)
    """)

    # ── §16 Governance confidence snapshots ────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS governance_snapshots (
            id                     BIGSERIAL   PRIMARY KEY,
            computed_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            governance_confidence  REAL        NOT NULL
                CHECK (governance_confidence BETWEEN 0 AND 1),
            mode                   TEXT        NOT NULL,
            recommended_size_scalar REAL       NOT NULL,
            model_health_score     REAL,
            market_regime_score    REAL,
            liquidity_score        REAL,
            positioning_score      REAL,
            warnings               TEXT[]      NOT NULL DEFAULT '{}',
            kill_switch_state      TEXT        NOT NULL DEFAULT 'ACTIVE'
        )
    """)
    op.execute("""
        SELECT create_hypertable(
            'governance_snapshots', 'computed_at',
            if_not_exists => TRUE
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_gov_computed_at
            ON governance_snapshots (computed_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_gov_mode
            ON governance_snapshots (mode, computed_at DESC)
    """)

    # ── §4 Liquidity snapshots ──────────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS liquidity_snapshots (
            id                     BIGSERIAL   PRIMARY KEY,
            fetched_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            liquidity_stress_index REAL
                CHECK (liquidity_stress_index IS NULL OR liquidity_stress_index BETWEEN 0 AND 1),
            execution_fragility    REAL
                CHECK (execution_fragility IS NULL OR execution_fragility BETWEEN 0 AND 1),
            spread_instability     REAL
                CHECK (spread_instability IS NULL OR spread_instability BETWEEN 0 AND 1),
            structural_fragility   REAL
                CHECK (structural_fragility IS NULL OR structural_fragility BETWEEN 0 AND 1),
            regime                 TEXT        NOT NULL DEFAULT 'UNKNOWN',
            amihud_score           REAL,
            hl_spread_score        REAL,
            vol_ratio              REAL,
            correlation_score      REAL,
            volume_anomaly         REAL,
            is_stale               BOOLEAN     NOT NULL DEFAULT TRUE
        )
    """)
    op.execute("""
        SELECT create_hypertable(
            'liquidity_snapshots', 'fetched_at',
            if_not_exists => TRUE
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_liq_fetched_at
            ON liquidity_snapshots (fetched_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_liq_regime
            ON liquidity_snapshots (regime, fetched_at DESC)
    """)

    # ── §2 Positioning snapshots ────────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS positioning_snapshots (
            id                     BIGSERIAL   PRIMARY KEY,
            ticker                 TEXT        NOT NULL,
            fetched_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            crowding_score         REAL
                CHECK (crowding_score IS NULL OR crowding_score BETWEEN 0 AND 1),
            squeeze_probability    REAL
                CHECK (squeeze_probability IS NULL OR squeeze_probability BETWEEN 0 AND 1),
            positioning_imbalance  REAL
                CHECK (positioning_imbalance IS NULL OR positioning_imbalance BETWEEN -1 AND 1),
            forced_flow_prob       REAL
                CHECK (forced_flow_prob IS NULL OR forced_flow_prob BETWEEN 0 AND 1),
            fragility_estimate     REAL
                CHECK (fragility_estimate IS NULL OR fragility_estimate BETWEEN 0 AND 1),
            signal_direction       TEXT        NOT NULL DEFAULT 'NEUTRAL',
            short_pct_float        REAL,
            days_to_cover          REAL,
            put_call_ratio         REAL,
            iv_skew                REAL,
            is_stale               BOOLEAN     NOT NULL DEFAULT TRUE
        )
    """)
    op.execute("""
        SELECT create_hypertable(
            'positioning_snapshots', 'fetched_at',
            if_not_exists => TRUE
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_pos_ticker_time
            ON positioning_snapshots (ticker, fetched_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_pos_direction
            ON positioning_snapshots (signal_direction, fetched_at DESC)
            WHERE signal_direction != 'NEUTRAL'
    """)

    # ── Throttle state audit log ────────────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS throttle_state_log (
            id                     BIGSERIAL   PRIMARY KEY,
            recorded_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            mode                   TEXT        NOT NULL,
            size_scalar            REAL        NOT NULL,
            governance_confidence  REAL        NOT NULL,
            max_positions          INT         NOT NULL,
            signal_min_score       REAL        NOT NULL,
            new_positions_ok       BOOLEAN     NOT NULL,
            message                TEXT,
            warnings               TEXT[]      NOT NULL DEFAULT '{}'
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_throttle_recorded_at
            ON throttle_state_log (recorded_at DESC)
    """)


def downgrade() -> None:
    op.execute("DROP TABLE IF EXISTS throttle_state_log CASCADE")
    op.execute("DROP TABLE IF EXISTS positioning_snapshots CASCADE")
    op.execute("DROP TABLE IF EXISTS liquidity_snapshots CASCADE")
    op.execute("DROP TABLE IF EXISTS governance_snapshots CASCADE")
    op.execute("DROP TABLE IF EXISTS kill_switch_events CASCADE")
