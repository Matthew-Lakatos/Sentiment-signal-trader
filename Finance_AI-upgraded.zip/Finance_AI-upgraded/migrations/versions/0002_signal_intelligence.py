"""Add signal intelligence columns: event_type, novelty, signal score.

Revision ID: 0002
Depends-on:  0001
"""
from alembic import op

revision      = "0002"
down_revision = "0001"


def upgrade() -> None:
    # Event classifier fields
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS event_type        TEXT    NOT NULL DEFAULT 'unknown',
            ADD COLUMN IF NOT EXISTS event_confidence  REAL    NOT NULL DEFAULT 0.0
                CHECK (event_confidence BETWEEN 0 AND 1)
    """)

    # Novelty scoring
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS novelty_score  REAL NOT NULL DEFAULT 0.5
                CHECK (novelty_score BETWEEN 0 AND 1),
            ADD COLUMN IF NOT EXISTS novelty_label  TEXT NOT NULL DEFAULT 'PARTIAL'
    """)

    # Composite alpha signal
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS signal_score      REAL NOT NULL DEFAULT 0.0
                CHECK (signal_score BETWEEN -1 AND 1),
            ADD COLUMN IF NOT EXISTS signal_direction  TEXT NOT NULL DEFAULT 'NEUTRAL',
            ADD COLUMN IF NOT EXISTS signal_tier       TEXT NOT NULL DEFAULT 'NOISE'
    """)

    # Extracted numerical values
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS dollar_value  DOUBLE PRECISION,
            ADD COLUMN IF NOT EXISTS pct_change    REAL
    """)

    # Indexes for signal ranking queries
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_event_type
            ON scraped_events (event_type, scraped_at DESC)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_signal_tier
            ON scraped_events (signal_tier, signal_score DESC)
            WHERE NOT is_duplicate
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_novelty
            ON scraped_events (novelty_score DESC)
            WHERE NOT is_duplicate
    """)

    # Continuous aggregate: signal roll-up by event type (hourly)
    op.execute("""
        CREATE MATERIALIZED VIEW IF NOT EXISTS hourly_signals
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 hour', scraped_at)  AS bucket,
            source_domain,
            event_type,
            signal_direction,
            COUNT(*)                           AS event_count,
            AVG(signal_score)                  AS avg_signal,
            AVG(novelty_score)                 AS avg_novelty,
            AVG(materiality_score)             AS avg_materiality
        FROM   scraped_events
        WHERE  NOT is_duplicate
        GROUP  BY 1, 2, 3, 4
    """)


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS hourly_signals")
    op.execute("DROP INDEX IF EXISTS idx_se_novelty")
    op.execute("DROP INDEX IF EXISTS idx_se_signal_tier")
    op.execute("DROP INDEX IF EXISTS idx_se_event_type")
    op.execute("""
        ALTER TABLE scraped_events
            DROP COLUMN IF EXISTS event_type,
            DROP COLUMN IF EXISTS event_confidence,
            DROP COLUMN IF EXISTS novelty_score,
            DROP COLUMN IF EXISTS novelty_label,
            DROP COLUMN IF EXISTS signal_score,
            DROP COLUMN IF EXISTS signal_direction,
            DROP COLUMN IF EXISTS signal_tier,
            DROP COLUMN IF EXISTS dollar_value,
            DROP COLUMN IF EXISTS pct_change
    """)
