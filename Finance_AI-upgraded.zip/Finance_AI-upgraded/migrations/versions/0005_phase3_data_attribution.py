"""Add Phase 3 columns: data connector caches, PnL attribution, narrative dynamics.

Revision ID: 0005
Depends-on:  0004
"""
from alembic import op

revision      = "0005"
down_revision = "0004"


def upgrade() -> None:
    # ── §22 Data connector result cache ────────────────────────────────────
    op.execute("""
        CREATE TABLE IF NOT EXISTS macro_snapshots (
            snapshot_id   UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            fetched_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            source        TEXT        NOT NULL DEFAULT 'FRED',
            fed_funds_rate         REAL,
            cpi_yoy                REAL,
            pce_yoy                REAL,
            unemployment_rate      REAL,
            gdp_growth             REAL,
            yield_10y              REAL,
            yield_2y               REAL,
            yield_3m               REAL,
            yield_curve_10y2y      REAL,
            yield_curve_10y3m      REAL,
            m2_growth              REAL,
            credit_spread_hy       REAL,
            credit_spread_ig       REAL,
            consumer_conf          REAL,
            industrial_prod        REAL,
            missing_series         TEXT[] NOT NULL DEFAULT '{}'
        )
    """)
    op.execute("""
        SELECT create_hypertable(
            'macro_snapshots', 'fetched_at', if_not_exists => TRUE
        )
    """)

    op.execute("""
        CREATE TABLE IF NOT EXISTS sec_filings_cache (
            filing_id     UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            cached_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            entity_name   TEXT        NOT NULL,
            cik           TEXT,
            form_type     TEXT        NOT NULL,
            filed_at      DATE,
            period        TEXT,
            filing_url    TEXT        NOT NULL,
            accession     TEXT        NOT NULL UNIQUE,
            search_query  TEXT
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_sec_entity_form
            ON sec_filings_cache (entity_name, form_type, filed_at DESC)
    """)

    op.execute("""
        CREATE TABLE IF NOT EXISTS options_snapshots (
            snapshot_id    UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            fetched_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            ticker         TEXT        NOT NULL,
            put_call_ratio REAL,
            iv_30d         REAL,
            iv_skew        REAL,
            max_pain       REAL,
            iv_term_slope  REAL,
            call_vol_surge BOOLEAN     NOT NULL DEFAULT FALSE,
            put_vol_surge  BOOLEAN     NOT NULL DEFAULT FALSE,
            expiry_used    TEXT
        )
    """)
    op.execute("""
        SELECT create_hypertable(
            'options_snapshots', 'fetched_at', if_not_exists => TRUE
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_options_ticker
            ON options_snapshots (ticker, fetched_at DESC)
    """)

    # ── §16 PnL attribution columns on scraped_events ──────────────────────
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS fwd_ret_1d    REAL,
            ADD COLUMN IF NOT EXISTS fwd_ret_5d    REAL,
            ADD COLUMN IF NOT EXISTS fwd_ret_20d   REAL,
            ADD COLUMN IF NOT EXISTS slippage_bps  REAL,
            ADD COLUMN IF NOT EXISTS tc_rt_bps     REAL,
            ADD COLUMN IF NOT EXISTS kg_signal_score REAL
                CHECK (kg_signal_score IS NULL OR kg_signal_score BETWEEN -1 AND 1)
    """)

    # PnL attribution results table (per-event breakdown)
    op.execute("""
        CREATE TABLE IF NOT EXISTS pnl_attribution (
            attr_id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
            event_id         UUID        NOT NULL,
            computed_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            horizon          SMALLINT    NOT NULL DEFAULT 1,
            fwd_ret          REAL        NOT NULL,
            strategy_pnl     REAL        NOT NULL,
            net_pnl          REAL        NOT NULL,
            sentiment_pnl    REAL,
            novelty_pnl      REAL,
            surprise_pnl     REAL,
            regime_pnl       REAL,
            kg_pnl           REAL,
            factor_pnl       REAL,
            execution_drag   REAL,
            tc_drag          REAL,
            residual         REAL,
            market_regime    TEXT        NOT NULL DEFAULT 'NEUTRAL'
        )
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_pnl_event_id
            ON pnl_attribution (event_id, horizon)
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_pnl_computed_at
            ON pnl_attribution (computed_at DESC)
    """)

    # ── §3 Narrative dynamics columns on scraped_events ────────────────────
    op.execute("""
        ALTER TABLE scraped_events
            ADD COLUMN IF NOT EXISTS attention_velocity    REAL,
            ADD COLUMN IF NOT EXISTS propagation_rate      REAL,
            ADD COLUMN IF NOT EXISTS is_saturated          BOOLEAN NOT NULL DEFAULT FALSE,
            ADD COLUMN IF NOT EXISTS freshness_score       REAL
                CHECK (freshness_score IS NULL OR freshness_score BETWEEN 0 AND 1),
            ADD COLUMN IF NOT EXISTS narrative_momentum    REAL
                CHECK (narrative_momentum IS NULL OR narrative_momentum BETWEEN -1 AND 1),
            ADD COLUMN IF NOT EXISTS decay_weight          REAL
                CHECK (decay_weight IS NULL OR decay_weight BETWEEN 0 AND 1),
            ADD COLUMN IF NOT EXISTS hours_since_first     REAL
    """)

    # ── Indexes for Phase 3 query patterns ─────────────────────────────────
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_freshness
            ON scraped_events (freshness_score DESC NULLS LAST)
            WHERE NOT is_duplicate AND freshness_score IS NOT NULL
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_saturated
            ON scraped_events (is_saturated, scraped_at DESC)
            WHERE NOT is_duplicate
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_momentum
            ON scraped_events (narrative_momentum DESC NULLS LAST)
            WHERE NOT is_duplicate AND narrative_momentum IS NOT NULL
    """)
    op.execute("""
        CREATE INDEX IF NOT EXISTS idx_se_fwd_ret
            ON scraped_events (fwd_ret_1d DESC NULLS LAST)
            WHERE NOT is_duplicate AND fwd_ret_1d IS NOT NULL
    """)

    # ── Continuous aggregate: daily narrative health ────────────────────────
    op.execute("""
        CREATE MATERIALIZED VIEW IF NOT EXISTS daily_narrative_health
        WITH (timescaledb.continuous) AS
        SELECT
            time_bucket('1 day', scraped_at) AS bucket,
            AVG(freshness_score)             AS avg_freshness,
            AVG(narrative_momentum)          AS avg_momentum,
            AVG(attention_velocity)          AS avg_velocity,
            SUM(CASE WHEN is_saturated THEN 1 ELSE 0 END) AS saturated_count,
            COUNT(*)                         AS event_count
        FROM scraped_events
        WHERE NOT is_duplicate
        GROUP BY 1
    """)


def downgrade() -> None:
    op.execute("DROP MATERIALIZED VIEW IF EXISTS daily_narrative_health")
    for idx in [
        "idx_se_fwd_ret", "idx_se_momentum", "idx_se_saturated",
        "idx_se_freshness", "idx_pnl_computed_at", "idx_pnl_event_id",
        "idx_options_ticker", "idx_sec_entity_form",
    ]:
        op.execute(f"DROP INDEX IF EXISTS {idx}")
    op.execute("DROP TABLE IF EXISTS pnl_attribution")
    op.execute("DROP TABLE IF EXISTS options_snapshots")
    op.execute("DROP TABLE IF EXISTS sec_filings_cache")
    op.execute("DROP TABLE IF EXISTS macro_snapshots")
    op.execute("""
        ALTER TABLE scraped_events
            DROP COLUMN IF EXISTS fwd_ret_1d,
            DROP COLUMN IF EXISTS fwd_ret_5d,
            DROP COLUMN IF EXISTS fwd_ret_20d,
            DROP COLUMN IF EXISTS slippage_bps,
            DROP COLUMN IF EXISTS tc_rt_bps,
            DROP COLUMN IF EXISTS kg_signal_score,
            DROP COLUMN IF EXISTS attention_velocity,
            DROP COLUMN IF EXISTS propagation_rate,
            DROP COLUMN IF EXISTS is_saturated,
            DROP COLUMN IF EXISTS freshness_score,
            DROP COLUMN IF EXISTS narrative_momentum,
            DROP COLUMN IF EXISTS decay_weight,
            DROP COLUMN IF EXISTS hours_since_first
    """)
