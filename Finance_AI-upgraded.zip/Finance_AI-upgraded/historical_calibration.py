"""
historical_calibration.py — Bootstrap calibration from historical event data.

Without realised returns the signal model runs with uncalibrated weights.
This module provides a calibration bootstrap that:

1. Fetches stored events with their signal scores from the DB
2. Downloads historical price data for the target entities
3. Computes realised T+1, T+5, T+20 returns for each event
4. Runs the calibration suite (Ridge + LGBM + Ensemble) to fit weights
5. Persists weights back to the DB and to a JSON file
6. Emits a CalibrationReport with IC, Sharpe, and per-feature attribution

Can be run as a script:
    python historical_calibration.py --days 90 --horizon 1 --method ensemble

Or imported:
    from historical_calibration import run_calibration
    report = asyncio.run(run_calibration(pool, days=90))
"""
from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Feature columns used for calibration
# ---------------------------------------------------------------------------

FEATURE_COLS = [
    "sentiment_score",
    "materiality_score",
    "novelty_score",
    "credibility_score",
    "surprise_score",
    "propaganda_score",
    "event_confidence",
    "guidance_revision_score",
]

HORIZON_MAP = {1: "realised_return_1d", 5: "realised_return_5d", 20: "realised_return_20d"}


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

@dataclass
class CalibrationReport:
    method:       str
    horizon:      int
    n_events:     int
    n_with_returns: int
    ic:           float
    ic_t_stat:    float
    sharpe:       float
    weights:      dict[str, float]
    feature_ics:  dict[str, float]
    calibrated_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    notes:        list[str] = field(default_factory=list)

    def summary(self) -> str:
        top = sorted(self.weights.items(), key=lambda x: abs(x[1]), reverse=True)[:4]
        return (
            f"Calibration[{self.method} T+{self.horizon}]: "
            f"n={self.n_with_returns}  IC={self.ic:.4f}  "
            f"t={self.ic_t_stat:.2f}  Sharpe={self.sharpe:.2f}  "
            f"top_weights={dict(top)}"
        )


# ---------------------------------------------------------------------------
# Price return fetcher
# ---------------------------------------------------------------------------

def _fetch_returns_sync(
    ticker: str,
    event_dates: list[str],
    horizons: list[int] = [1, 5, 20],
) -> dict[str, dict[int, Optional[float]]]:
    """
    Fetch close-to-close returns for ticker after each event_date.
    Returns {date_str: {horizon: return}} .
    """
    try:
        import yfinance as yf
        import pandas as pd

        if not event_dates:
            return {}

        # Download enough history
        min_date = min(event_dates)
        start    = (datetime.strptime(min_date, "%Y-%m-%d") - timedelta(days=5)).strftime("%Y-%m-%d")
        end      = (datetime.now(timezone.utc) + timedelta(days=max(horizons) + 3)).strftime("%Y-%m-%d")

        df = yf.download(ticker, start=start, end=end, progress=False, auto_adjust=True)
        if df.empty:
            return {}

        closes = df["Close"].dropna()
        dates  = [str(d.date()) for d in closes.index]
        prices = {d: float(p) for d, p in zip(dates, closes.values)}

        result: dict[str, dict[int, Optional[float]]] = {}
        for event_date in event_dates:
            result[event_date] = {}
            # Find the trading-day close on or after event_date
            sorted_dates = sorted(d for d in prices if d >= event_date)
            if not sorted_dates:
                for h in horizons:
                    result[event_date][h] = None
                continue

            base_date  = sorted_dates[0]
            base_price = prices[base_date]

            for h in horizons:
                future_dates = sorted(d for d in prices if d > base_date)
                if len(future_dates) >= h:
                    fut_date  = future_dates[h - 1]
                    fut_price = prices[fut_date]
                    result[event_date][h] = (fut_price / base_price) - 1.0
                else:
                    result[event_date][h] = None

        return result

    except Exception as exc:
        logger.debug("Return fetch failed for %s: %s", ticker, exc)
        return {}


# ---------------------------------------------------------------------------
# DB fetch
# ---------------------------------------------------------------------------

async def _fetch_events(pool, days: int) -> list[dict]:
    """Pull recent events with signal scores from the DB."""
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    rows = await pool.fetch(f"""
        SELECT
            id, scraped_at, targets, signal_score,
            sentiment_score, materiality_score, novelty_score,
            credibility_score, surprise_score, propaganda_score,
            event_confidence, guidance_revision_score,
            realised_return_1d, realised_return_5d, realised_return_20d
        FROM scraped_events
        WHERE scraped_at >= $1
          AND signal_score IS NOT NULL
          AND NOT is_duplicate
        ORDER BY scraped_at ASC
    """, since)
    return [dict(r) for r in rows]


async def _update_returns(pool, event_id: int, returns: dict[int, Optional[float]]) -> None:
    """Write realised returns back to the event row."""
    await pool.execute("""
        UPDATE scraped_events SET
            realised_return_1d  = COALESCE($2, realised_return_1d),
            realised_return_5d  = COALESCE($3, realised_return_5d),
            realised_return_20d = COALESCE($4, realised_return_20d)
        WHERE id = $1
    """, event_id, returns.get(1), returns.get(5), returns.get(20))


# ---------------------------------------------------------------------------
# Core calibration logic
# ---------------------------------------------------------------------------

def _calibrate_ridge(X: np.ndarray, y: np.ndarray, feature_names: list[str]) -> dict[str, float]:
    from sklearn.linear_model import RidgeCV
    from sklearn.preprocessing import StandardScaler

    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    model = RidgeCV(alphas=[0.1, 1.0, 10.0, 100.0], cv=5)
    model.fit(Xs, y)
    raw = dict(zip(feature_names, model.coef_))
    total = sum(abs(v) for v in raw.values()) or 1.0
    return {k: round(v / total, 6) for k, v in raw.items()}


def _calibrate_lgbm(X: np.ndarray, y: np.ndarray, feature_names: list[str]) -> dict[str, float]:
    try:
        import lightgbm as lgb
        model = lgb.LGBMRegressor(n_estimators=200, learning_rate=0.05, random_state=42, verbose=-1)
        model.fit(X, y)
        imps = dict(zip(feature_names, model.feature_importances_))
        total = sum(imps.values()) or 1.0
        return {k: round(v / total, 6) for k, v in imps.items()}
    except ImportError:
        logger.warning("LightGBM not installed — using Ridge fallback")
        return _calibrate_ridge(X, y, feature_names)


def _compute_feature_ics(X: np.ndarray, y: np.ndarray, feature_names: list[str]) -> dict[str, float]:
    from scipy.stats import spearmanr
    ics = {}
    for i, name in enumerate(feature_names):
        col = X[:, i]
        mask = np.isfinite(col) & np.isfinite(y)
        if mask.sum() < 10:
            ics[name] = 0.0
            continue
        rho, _ = spearmanr(col[mask], y[mask])
        ics[name] = round(float(rho), 4)
    return ics


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

async def run_calibration(
    pool,
    days:     int = 90,
    horizon:  int = 1,
    method:   str = "ensemble",
    min_events: int = 50,
    persist:  bool = True,
) -> CalibrationReport:
    """
    Full calibration pipeline:
    1. Fetch stored events
    2. Resolve missing returns via yfinance
    3. Fit model weights
    4. Persist weights
    """
    target_col = HORIZON_MAP.get(horizon, "realised_return_1d")
    notes: list[str] = []

    logger.info("Starting calibration: days=%d horizon=T+%d method=%s", days, horizon, method)

    # ── 1. Fetch events from DB ──────────────────────────────────────────────
    events = await _fetch_events(pool, days)
    logger.info("Fetched %d events from DB", len(events))

    if len(events) < min_events:
        notes.append(f"insufficient_data: {len(events)} < {min_events}")
        logger.warning("Not enough events (%d) for reliable calibration", len(events))

    # ── 2. Fetch missing realised returns ────────────────────────────────────
    loop = asyncio.get_running_loop()

    # Group events by ticker
    ticker_events: dict[str, list[dict]] = {}
    for ev in events:
        if ev.get(target_col) is not None:
            continue   # already have return
        targets = ev.get("targets") or []
        if not targets:
            continue
        ticker = targets[0] if isinstance(targets[0], str) else targets[0].get("ticker", "")
        if ticker:
            ticker_events.setdefault(ticker, []).append(ev)

    # Fetch returns concurrently by ticker
    if ticker_events:
        logger.info("Fetching returns for %d tickers", len(ticker_events))
        sem = asyncio.Semaphore(5)

        async def _fetch_and_update(ticker: str, evs: list[dict]) -> None:
            async with sem:
                event_dates = [
                    ev["scraped_at"][:10] if isinstance(ev["scraped_at"], str)
                    else ev["scraped_at"].strftime("%Y-%m-%d")
                    for ev in evs
                ]
                ret_map = await loop.run_in_executor(
                    None, _fetch_returns_sync, ticker, event_dates, [1, 5, 20]
                )
                for ev in evs:
                    dt = ev["scraped_at"][:10] if isinstance(ev["scraped_at"], str) else ev["scraped_at"].strftime("%Y-%m-%d")
                    returns = ret_map.get(dt, {})
                    if any(v is not None for v in returns.values()):
                        ev[target_col] = returns.get(horizon)
                        await _update_returns(pool, ev["id"], returns)

        await asyncio.gather(*[_fetch_and_update(t, evs) for t, evs in ticker_events.items()])

    # ── 3. Build feature matrix ──────────────────────────────────────────────
    usable_features = [f for f in FEATURE_COLS if any(ev.get(f) is not None for ev in events)]
    rows_X = []
    rows_y = []

    for ev in events:
        y_val = ev.get(target_col)
        if y_val is None:
            continue
        x_row = [float(ev.get(f) or 0.0) for f in usable_features]
        rows_X.append(x_row)
        rows_y.append(float(y_val))

    n_with_returns = len(rows_y)
    logger.info("Calibration sample: %d events with returns", n_with_returns)

    if n_with_returns < max(10, min_events // 3):
        notes.append("too_few_returns: using default weights")
        return CalibrationReport(
            method=method, horizon=horizon,
            n_events=len(events), n_with_returns=n_with_returns,
            ic=0.0, ic_t_stat=0.0, sharpe=0.0,
            weights={f: 1.0/len(usable_features) for f in usable_features},
            feature_ics={}, notes=notes,
        )

    X = np.array(rows_X, dtype=float)
    y = np.array(rows_y, dtype=float)

    # Winsorise returns at ±10% to reduce outlier influence
    y = np.clip(y, -0.10, 0.10)

    # ── 4. Compute IC ────────────────────────────────────────────────────────
    from scipy.stats import spearmanr
    composite = X @ np.ones(X.shape[1]) / X.shape[1]
    ic_full, _ = spearmanr(composite, y)
    ic_t = float(ic_full * np.sqrt(n_with_returns - 2) / np.sqrt(1 - ic_full**2 + 1e-9))

    feature_ics = _compute_feature_ics(X, y, usable_features)

    # ── 5. Fit weights ───────────────────────────────────────────────────────
    if method == "lgbm":
        weights = _calibrate_lgbm(X, y, usable_features)
    elif method == "ensemble":
        w_ridge = _calibrate_ridge(X, y, usable_features)
        w_lgbm  = _calibrate_lgbm(X, y, usable_features)
        weights = {f: round((w_ridge.get(f, 0) + w_lgbm.get(f, 0)) / 2, 6) for f in usable_features}
    else:
        weights = _calibrate_ridge(X, y, usable_features)

    # ── 6. Compute Sharpe on fitted predictions ──────────────────────────────
    w_vec  = np.array([weights.get(f, 0.0) for f in usable_features])
    preds  = X @ w_vec
    sharpe = float(np.mean(y * np.sign(preds)) / (np.std(y) + 1e-9) * np.sqrt(252))

    report = CalibrationReport(
        method          = method,
        horizon         = horizon,
        n_events        = len(events),
        n_with_returns  = n_with_returns,
        ic              = round(float(ic_full), 5),
        ic_t_stat       = round(ic_t, 3),
        sharpe          = round(sharpe, 3),
        weights         = weights,
        feature_ics     = feature_ics,
        notes           = notes,
    )

    logger.info(report.summary())

    # ── 7. Persist weights ───────────────────────────────────────────────────
    if persist and n_with_returns >= min_events // 3:
        weights_path = f"calibration_weights_T{horizon}.json"
        with open(weights_path, "w") as f:
            json.dump({
                "weights":        weights,
                "feature_ics":    feature_ics,
                "ic":             report.ic,
                "sharpe":         report.sharpe,
                "n_events":       n_with_returns,
                "calibrated_at":  report.calibrated_at.isoformat(),
                "method":         method,
                "horizon":        horizon,
            }, f, indent=2)
        logger.info("Weights persisted to %s", weights_path)

    return report


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    parser = argparse.ArgumentParser(description="Run historical signal calibration")
    parser.add_argument("--days",    type=int, default=90,       help="Look-back window (days)")
    parser.add_argument("--horizon", type=int, default=1,        help="Return horizon in trading days")
    parser.add_argument("--method",  default="ensemble",         help="ridge|lgbm|ensemble")
    parser.add_argument("--dsn",     default=os.environ.get("POSTGRES_DSN", ""), help="DB connection string")
    args = parser.parse_args()

    if not args.dsn:
        print("Set POSTGRES_DSN or pass --dsn")
        sys.exit(1)

    async def _main():
        import asyncpg
        pool = await asyncpg.create_pool(args.dsn, min_size=2, max_size=5)
        report = await run_calibration(pool, days=args.days, horizon=args.horizon, method=args.method)
        print(report.summary())
        print(json.dumps(report.weights, indent=2))

    asyncio.run(_main())
