"""Tests for alert rule logic (no delivery, no DB)."""
import pytest
from alert_engine import (
    rule_narrative_spike,
    rule_sentiment_shift,
    rule_high_propaganda,
    rule_critical_materiality,
    AlertPayload,
)


def test_narrative_spike_detected():
    alert = rule_narrative_spike(current=100, history=[10, 11, 9, 10, 12], domain="test.com")
    assert alert is not None
    assert alert.alert_type == "NARRATIVE_SPIKE"
    assert alert.severity == "HIGH"


def test_narrative_spike_not_triggered_on_normal_volume():
    alert = rule_narrative_spike(current=12, history=[10, 11, 9, 10, 12], domain="test.com")
    assert alert is None


def test_narrative_spike_needs_history():
    alert = rule_narrative_spike(current=999, history=[1], domain="test.com")
    assert alert is None


def test_sentiment_shift_high():
    alert = rule_sentiment_shift(current=0.8, previous=-0.3, domain="test.com")
    assert alert is not None
    assert alert.severity in ("HIGH", "CRITICAL")


def test_sentiment_shift_no_previous():
    alert = rule_sentiment_shift(current=0.8, previous=None, domain="test.com")
    assert alert is None


def test_sentiment_shift_small_delta():
    alert = rule_sentiment_shift(current=0.1, previous=0.05, domain="test.com")
    assert alert is None


def test_propaganda_critical():
    alert = rule_high_propaganda(score=0.9, domain="test.com")
    assert alert is not None
    assert alert.severity == "CRITICAL"


def test_propaganda_below_threshold():
    alert = rule_high_propaganda(score=0.5, domain="test.com")
    assert alert is None


def test_critical_materiality_fires():
    alert = rule_critical_materiality("CRITICAL", "Fed raises rates 100bps", "test.com")
    assert alert is not None
    assert alert.alert_type == "CRITICAL_EVENT"


def test_high_tier_does_not_fire_critical_rule():
    alert = rule_critical_materiality("HIGH", "Some headline", "test.com")
    assert alert is None
