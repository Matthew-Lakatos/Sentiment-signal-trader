"""
test_phase4.py — Phase 4 integration tests.

Covers all three sections implemented in Phase 4:
    §19 ml_calibration.py        — Bayesian Ridge, LightGBM, XGBoost, Ensemble
    §23 experiment_tracker.py    — run tracking, JSON log, manifests, snapshots
    §21 contradiction_detector.py— disagreement, price lead/lag, crowd reversal
"""
from __future__ import annotations

import json
import math
import os
import random
import tempfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

import pytest


# ─────────────────────────────────────────────────────────────────────────────
# Shared generators
# ─────────────────────────────────────────────────────────────────────────────

def _make_events(n: int = 80, seed: int = 42, ic: float = 0.25) -> list[dict]:
    rng = random.Random(seed)
    evs = []
    for i in range(n):
        score = rng.uniform(-0.8, 0.8)
        ret   = score * ic + rng.gauss(0, 0.5)
        label = "POSITIVE" if score > 0.1 else ("NEGATIVE" if score < -0.1 else "NEUTRAL")
        evs.append({
            "event_id":           f"e{i:04d}",
            "sentiment_label":    label,
            "sentiment_score":    abs(score),
            "materiality_score":  abs(score) * 0.7,
            "novelty_score":      rng.uniform(0.2, 0.9),
            "credibility_score":  rng.uniform(0.4, 0.9),
            "signal_score":       score,
            "surprise_score":     rng.uniform(-0.3, 0.3),
            "fwd_ret_1d":         ret,
            "fwd_ret":            ret,
        })
    return evs


def _make_xy(n: int = 80, seed: int = 42, ic: float = 0.25):
    """Return (X, y, feature_names) numpy arrays for direct ML testing."""
    import numpy as np
    from calibration import _build_feature_matrix
    events = _make_events(n, seed, ic)
    X, y   = _build_feature_matrix(events, with_interactions=False)
    from calibration import FEATURE_NAMES
    return X, y, FEATURE_NAMES


# ─────────────────────────────────────────────────────────────────────────────
# §19 — ml_calibration
# ─────────────────────────────────────────────────────────────────────────────

from ml_calibration import (
    _bayesian_calibrate,
    _lgbm_calibrate,
    _xgboost_calibrate,
    _ensemble_calibrate,
    is_ml_method,
    dispatch,
    ML_METHODS,
)


class TestIsMLMethod:
    def test_bayesian_is_ml(self):
        assert is_ml_method("bayesian") is True

    def test_lgbm_is_ml(self):
        assert is_ml_method("lgbm") is True

    def test_ensemble_is_ml(self):
        assert is_ml_method("ensemble") is True

    def test_ridge_is_not_ml(self):
        assert is_ml_method("ridge") is False

    def test_unknown_is_not_ml(self):
        assert is_ml_method("nonexistent") is False

    def test_all_registered_methods(self):
        assert set(ML_METHODS.keys()) == {"bayesian", "lgbm", "xgboost", "ensemble"}


class TestBayesianCalibrate:
    def test_returns_weights_dict(self):
        X, y, fnames = _make_xy(60)
        result = _bayesian_calibrate(X, y, feature_names=fnames)
        assert isinstance(result["weights"], dict)
        assert set(result["weights"].keys()) == set(fnames)

    def test_weights_sum_to_one(self):
        X, y, fnames = _make_xy(60)
        result = _bayesian_calibrate(X, y, feature_names=fnames)
        # Bayesian Ridge may produce negative weights (feature is inversely predictive).
        # The abs-normalisation contract is: sum(|w|) = 1.0, not sum(w) = 1.0.
        assert abs(sum(abs(v) for v in result["weights"].values()) - 1.0) < 1e-3

    def test_r_squared_finite(self):
        X, y, fnames = _make_xy(60)
        result = _bayesian_calibrate(X, y, feature_names=fnames)
        assert math.isfinite(result["r_squared"])

    def test_ic_in_range(self):
        X, y, fnames = _make_xy(80, ic=0.5)
        result = _bayesian_calibrate(X, y, feature_names=fnames)
        assert -1.0 <= result["_ic"] <= 1.0

    def test_notes_contains_lambda(self):
        X, y, fnames = _make_xy(60)
        result = _bayesian_calibrate(X, y, feature_names=fnames)
        notes  = json.loads(result["_notes"])
        assert "lambda_" in notes
        assert "alpha_"  in notes

    def test_notes_contains_uncertainty(self):
        X, y, fnames = _make_xy(60)
        result = _bayesian_calibrate(X, y, feature_names=fnames)
        notes  = json.loads(result["_notes"])
        assert "uncertainty" in notes
        assert all(f in notes["uncertainty"] for f in fnames)

    def test_dispatch_bayesian(self):
        X, y, fnames = _make_xy(60)
        result = dispatch("bayesian", X, y, feature_names=fnames)
        assert "weights" in result


class TestLGBMCalibrate:
    def test_falls_back_on_import_error(self, monkeypatch):
        """If lightgbm is not installed, must fall back to ridge gracefully."""
        import builtins, sys

        original_import = builtins.__import__
        def mock_import(name, *args, **kwargs):
            if name == "lightgbm":
                raise ImportError("No module named 'lightgbm'")
            return original_import(name, *args, **kwargs)

        monkeypatch.setattr(builtins, "__import__", mock_import)
        # Remove cached lgbm module if present
        sys.modules.pop("lightgbm", None)

        X, y, fnames = _make_xy(60)
        # Should not raise — falls back to ridge
        result = _lgbm_calibrate(X, y, feature_names=fnames)
        assert isinstance(result["weights"], dict)

    def test_weights_present(self):
        X, y, fnames = _make_xy(80)
        result = _lgbm_calibrate(X, y, feature_names=fnames)
        assert isinstance(result["weights"], dict)
        assert len(result["weights"]) == len(fnames)

    def test_ic_in_range(self):
        X, y, fnames = _make_xy(80, ic=0.5)
        result = _lgbm_calibrate(X, y, feature_names=fnames)
        assert -1.0 <= result["_ic"] <= 1.0

    def test_notes_model_lgbm(self):
        X, y, fnames = _make_xy(80)
        result = _lgbm_calibrate(X, y, feature_names=fnames)
        notes  = json.loads(result["_notes"])
        # Either lgbm ran (notes has "model": "lgbm") or fell back (no "model" key)
        assert "model" in notes

    def test_dispatch_lgbm(self):
        X, y, fnames = _make_xy(60)
        result = dispatch("lgbm", X, y, feature_names=fnames)
        assert "weights" in result


class TestXGBoostCalibrate:
    def test_falls_back_on_import_error(self, monkeypatch):
        import builtins, sys
        original = builtins.__import__
        def mock_import(name, *args, **kwargs):
            if name == "xgboost":
                raise ImportError("No module named 'xgboost'")
            return original(name, *args, **kwargs)
        monkeypatch.setattr(builtins, "__import__", mock_import)
        sys.modules.pop("xgboost", None)

        X, y, fnames = _make_xy(60)
        result = _xgboost_calibrate(X, y, feature_names=fnames)
        assert isinstance(result["weights"], dict)

    def test_weights_present(self):
        X, y, fnames = _make_xy(80)
        result = _xgboost_calibrate(X, y, feature_names=fnames)
        assert isinstance(result["weights"], dict)

    def test_dispatch_xgboost(self):
        X, y, fnames = _make_xy(60)
        result = dispatch("xgboost", X, y, feature_names=fnames)
        assert "weights" in result


class TestEnsembleCalibrate:
    def test_returns_weights(self):
        X, y, fnames = _make_xy(80)
        result = _ensemble_calibrate(X, y, feature_names=fnames)
        assert isinstance(result["weights"], dict)
        assert set(result["weights"].keys()) == set(fnames)

    def test_weights_sum_to_one(self):
        X, y, fnames = _make_xy(80)
        result = _ensemble_calibrate(X, y, feature_names=fnames)
        assert abs(sum(result["weights"].values()) - 1.0) < 1e-4

    def test_r_squared_finite(self):
        X, y, fnames = _make_xy(80)
        result = _ensemble_calibrate(X, y, feature_names=fnames)
        assert math.isfinite(result["r_squared"])

    def test_ic_in_range(self):
        X, y, fnames = _make_xy(80, ic=0.5)
        result = _ensemble_calibrate(X, y, feature_names=fnames)
        assert -1.0 <= result["_ic"] <= 1.0

    def test_notes_contains_components(self):
        X, y, fnames = _make_xy(80)
        result = _ensemble_calibrate(X, y, feature_names=fnames)
        notes  = json.loads(result["_notes"])
        assert "components" in notes
        assert "ridge" in notes["components"]

    def test_custom_blend_weights(self):
        X, y, fnames = _make_xy(80)
        result_equal  = _ensemble_calibrate(X, y, fnames, ridge_weight=0.34, lgbm_weight=0.33, bayes_weight=0.33)
        result_bayes  = _ensemble_calibrate(X, y, fnames, ridge_weight=0.10, lgbm_weight=0.10, bayes_weight=0.80)
        # Both should produce valid weights
        for r in (result_equal, result_bayes):
            assert abs(sum(r["weights"].values()) - 1.0) < 1e-4

    def test_dispatch_ensemble(self):
        X, y, fnames = _make_xy(60)
        result = dispatch("ensemble", X, y, feature_names=fnames)
        assert "weights" in result


class TestDispatch:
    def test_unknown_method_raises(self):
        X, y, fnames = _make_xy(30)
        with pytest.raises(ValueError, match="Unknown ML method"):
            dispatch("xyz_unknown", X, y, feature_names=fnames)

    def test_all_registered_methods_work(self):
        X, y, fnames = _make_xy(60)
        for method in ML_METHODS:
            result = dispatch(method, X, y, feature_names=fnames)
            assert "weights" in result, f"method={method} missing weights"
            assert isinstance(result["weights"], dict)


class TestCalibrateIntegration:
    """Tests for calibrate() extended with ML methods via calibration.py patch."""

    def test_bayesian_method_via_calibrate(self):
        from calibration import calibrate
        events = _make_events(60)
        result = calibrate(events, horizon=1, method="bayesian")
        assert result.method == "bayesian"
        assert -1.0 <= result.ic <= 1.0
        assert isinstance(result.weights, dict)

    def test_ensemble_method_via_calibrate(self):
        from calibration import calibrate
        events = _make_events(80)
        result = calibrate(events, horizon=1, method="ensemble")
        assert result.method == "ensemble"
        assert abs(sum(result.weights.values()) - 1.0) < 1e-4

    def test_ml_methods_produce_same_interface_as_ridge(self):
        from calibration import calibrate, CalibrationResult
        events = _make_events(80)
        r_ridge = calibrate(events, method="ridge")
        r_bayes = calibrate(events, method="bayesian")

        for r in (r_ridge, r_bayes):
            assert isinstance(r, CalibrationResult)
            assert hasattr(r, "weights")
            assert hasattr(r, "ic")
            assert hasattr(r, "ic_oos")
            assert hasattr(r, "n_samples")

    def test_ridge_method_still_works(self):
        """Existing ridge method must be unaffected by the patch."""
        from calibration import calibrate
        events = _make_events(80)
        result = calibrate(events, method="ridge")
        assert result.method == "ridge"
        assert result.ic is not None


# ─────────────────────────────────────────────────────────────────────────────
# §23 — experiment_tracker
# ─────────────────────────────────────────────────────────────────────────────

from experiment_tracker import ExperimentTracker, ExperimentRun, tracker


class TestExperimentRun:
    def test_default_run_id_is_uuid(self):
        import uuid
        run = ExperimentRun()
        assert isinstance(run.run_id, str)
        uuid.UUID(run.run_id)   # raises if not valid UUID

    def test_log_metric(self):
        run = ExperimentRun()
        run.log_metric("ic", 0.12)
        assert run.metrics["ic"] == 0.12

    def test_log_metrics_batch(self):
        run = ExperimentRun()
        run.log_metrics({"ic": 0.12, "sharpe": 0.8, "n": 100})
        assert run.metrics["ic"] == 0.12
        assert run.metrics["sharpe"] == 0.8

    def test_log_param(self):
        run = ExperimentRun()
        run.log_param("method", "lgbm")
        assert run.params["method"] == "lgbm"

    def test_set_tag(self):
        run = ExperimentRun()
        run.set_tag("dataset_version", "v2")
        assert run.tags["dataset_version"] == "v2"

    def test_log_artifact_creates_file(self):
        run = ExperimentRun()
        with tempfile.TemporaryDirectory() as d:
            path = run.log_artifact("weights", {"a": 0.5}, artifact_dir=Path(d))
            assert Path(path).exists()
            with open(path) as f:
                data = json.load(f)
            assert data["a"] == 0.5

    def test_artifact_path_recorded(self):
        run = ExperimentRun()
        with tempfile.TemporaryDirectory() as d:
            run.log_artifact("model", {"x": 1}, artifact_dir=Path(d))
            assert len(run.artifact_paths) == 1

    def test_manifest_contains_all_keys(self):
        run = ExperimentRun(experiment_name="test_exp")
        run.log_metric("ic", 0.1)
        run.log_param("method", "ridge")
        m = run.manifest()
        for key in ["run_id", "experiment_name", "params", "metrics",
                    "tags", "dataset_hash", "artifact_paths", "status"]:
            assert key in m

    def test_manifest_is_json_serialisable(self):
        run = ExperimentRun()
        run.log_metric("ic", 0.1)
        m = run.manifest()
        json.dumps(m)   # should not raise


class TestExperimentTracker:
    def _make_tracker(self, tmp_path):
        log_path  = tmp_path / "runs.jsonl"
        art_dir   = tmp_path / "artifacts"
        return ExperimentTracker(log_path=log_path, artifact_dir=art_dir)

    def test_start_run_context_manager(self, tmp_path):
        t = self._make_tracker(tmp_path)
        with t.start_run("test_exp", params={"method": "ridge"}) as run:
            run.log_metric("ic", 0.08)
        assert run.status == "completed"
        assert run.ended_at is not None

    def test_run_appended_to_log(self, tmp_path):
        t = self._make_tracker(tmp_path)
        log_path = tmp_path / "runs.jsonl"

        with t.start_run("test_exp") as run:
            run.log_metric("ic", 0.05)

        assert log_path.exists()
        with open(log_path) as f:
            lines = [l for l in f if l.strip()]
        assert len(lines) == 1
        obj = json.loads(lines[0])
        assert obj["experiment_name"] == "test_exp"

    def test_multiple_runs_all_logged(self, tmp_path):
        t = self._make_tracker(tmp_path)
        log_path = tmp_path / "runs.jsonl"

        for i in range(3):
            with t.start_run("test_exp") as run:
                run.log_metric("ic", 0.01 * i)

        runs = t.list_runs("test_exp")
        assert len(runs) == 3

    def test_list_runs_filtered_by_experiment(self, tmp_path):
        t = self._make_tracker(tmp_path)
        with t.start_run("exp_a") as r: r.log_metric("ic", 0.1)
        with t.start_run("exp_b") as r: r.log_metric("ic", 0.2)

        runs_a = t.list_runs("exp_a")
        runs_b = t.list_runs("exp_b")
        assert len(runs_a) == 1
        assert len(runs_b) == 1
        assert runs_a[0]["experiment_name"] == "exp_a"

    def test_list_runs_empty_when_no_log(self, tmp_path):
        t = self._make_tracker(tmp_path)
        assert t.list_runs("nonexistent") == []

    def test_best_run_returns_correct_run(self, tmp_path):
        t = self._make_tracker(tmp_path)
        ics = [0.05, 0.12, 0.08]
        for ic in ics:
            with t.start_run("calibration") as r:
                r.log_metric("ic_oos", ic)

        best = t.best_run("calibration", metric="ic_oos")
        assert best is not None
        assert abs(best["metrics"]["ic_oos"] - 0.12) < 1e-6

    def test_best_run_none_when_no_runs(self, tmp_path):
        t = self._make_tracker(tmp_path)
        assert t.best_run("nonexistent") is None

    def test_failed_run_status(self, tmp_path):
        t = self._make_tracker(tmp_path)
        try:
            with t.start_run("test_exp") as run:
                raise ValueError("deliberate failure")
        except ValueError:
            pass
        assert run.status == "failed"
        assert run.error == "deliberate failure"

    def test_failed_run_logged(self, tmp_path):
        t = self._make_tracker(tmp_path)
        try:
            with t.start_run("test_exp"):
                raise RuntimeError("boom")
        except RuntimeError:
            pass
        runs = t.list_runs("test_exp")
        assert len(runs) == 1
        assert runs[0]["status"] == "failed"

    def test_run_duration_recorded(self, tmp_path):
        t = self._make_tracker(tmp_path)
        with t.start_run("test_exp") as run:
            pass
        assert run.duration_seconds is not None
        assert run.duration_seconds >= 0.0

    def test_dataset_snapshot_returns_hash(self, tmp_path):
        t = self._make_tracker(tmp_path)
        events = _make_events(20)
        h = t.snapshot_dataset(events, name="test_ds")
        assert isinstance(h, str)
        assert len(h) == 64   # SHA-256 hex

    def test_dataset_snapshot_stable(self, tmp_path):
        t = self._make_tracker(tmp_path)
        events = _make_events(20)
        h1 = t.snapshot_dataset(events, name="ds1")
        h2 = t.snapshot_dataset(events, name="ds1")
        assert h1 == h2

    def test_dataset_snapshot_different_data_different_hash(self, tmp_path):
        t = self._make_tracker(tmp_path)
        h1 = t.snapshot_dataset(_make_events(20, seed=1))
        h2 = t.snapshot_dataset(_make_events(20, seed=2))
        assert h1 != h2

    def test_params_logged_in_run(self, tmp_path):
        t = self._make_tracker(tmp_path)
        with t.start_run("test", params={"method": "lgbm", "horizon": 5}) as run:
            pass
        runs = t.list_runs("test")
        assert runs[0]["params"]["method"] == "lgbm"
        assert runs[0]["params"]["horizon"] == 5

    def test_module_singleton_exists(self):
        assert tracker is not None
        assert isinstance(tracker, ExperimentTracker)


class TestLogCalibrationResult:
    def test_logs_ic_and_weights(self, tmp_path):
        from experiment_tracker import log_calibration_result
        from calibration import calibrate

        t   = ExperimentTracker(
            log_path    = tmp_path / "runs.jsonl",
            artifact_dir= tmp_path / "artifacts",
        )
        events = _make_events(60)
        result = calibrate(events, method="ridge")

        with t.start_run("test_cal") as run:
            log_calibration_result(run, result)

        assert "ic" in run.metrics
        assert "n_samples" in run.metrics
        assert len(run.artifact_paths) >= 1


# ─────────────────────────────────────────────────────────────────────────────
# §21 — contradiction_detector
# ─────────────────────────────────────────────────────────────────────────────

from contradiction_detector import (
    ContradictionDetector, ContradictionResult,
    disagreement_score_from_sentiments, is_crowded,
)


class TestDisagreementScore:
    def test_identical_sentiments_zero_disagreement(self):
        score = disagreement_score_from_sentiments([0.5, 0.5, 0.5])
        assert score == 0.0

    def test_opposite_sentiments_high_disagreement(self):
        score = disagreement_score_from_sentiments([1.0, -1.0, 1.0, -1.0])
        assert score > 0.5

    def test_single_sentiment_zero_disagreement(self):
        assert disagreement_score_from_sentiments([0.5]) == 0.0

    def test_empty_zero_disagreement(self):
        assert disagreement_score_from_sentiments([]) == 0.0

    def test_score_bounded_0_1(self):
        for seed in range(10):
            rng   = random.Random(seed)
            sents = [rng.uniform(-1, 1) for _ in range(10)]
            score = disagreement_score_from_sentiments(sents)
            assert 0.0 <= score <= 1.0

    def test_moderate_disagreement_mid_range(self):
        sents = [0.8, 0.6, 0.4, 0.2, -0.2]
        score = disagreement_score_from_sentiments(sents)
        assert 0.1 < score < 0.9


class TestIsCrowded:
    def test_all_same_direction_crowded(self):
        dirs = ["POS", "POS", "POS", "POS"]  # 4 recent + 1 current = 5
        count, crowded = is_crowded(dirs, "POS", threshold=5)
        assert crowded is True
        assert count == 5

    def test_not_enough_consecutive(self):
        dirs = ["POS", "POS", "NEG", "POS"]
        count, crowded = is_crowded(dirs, "POS", threshold=5)
        assert crowded is False
        assert count == 3  # current + 2 before the NEG break

    def test_single_article_not_crowded(self):
        count, crowded = is_crowded([], "POS", threshold=5)
        assert crowded is False
        assert count == 1

    def test_opposite_direction_breaks_streak(self):
        dirs = ["NEG", "POS", "POS"]
        count, crowded = is_crowded(dirs, "POS", threshold=3)
        # current + "POS" + "POS" = 3, then "NEG" breaks
        assert count == 3
        assert crowded is True

    def test_neutral_breaks_streak(self):
        dirs = ["NEU", "POS", "POS"]
        count, crowded = is_crowded(dirs, "POS", threshold=3)
        assert count == 1   # only current; NEU breaks immediately

    def test_custom_threshold(self):
        dirs = ["POS", "POS"]
        _, crowded_2 = is_crowded(dirs, "POS", threshold=3)
        _, crowded_4 = is_crowded(dirs, "POS", threshold=4)
        assert crowded_2 is True   # 3 >= 3
        assert crowded_4 is False  # 3 < 4


class TestContradictionDetectorNoPool:
    """All tests use pool=None — no DB required."""

    @pytest.mark.asyncio
    async def test_returns_result_no_pool(self):
        d      = ContradictionDetector(pool=None)
        result = await d.analyse(
            entity="NVIDIA", ticker=None,
            sentiment_score=0.7, signal_score=0.6,
            scraped_at=datetime.now(timezone.utc),
        )
        assert isinstance(result, ContradictionResult)

    @pytest.mark.asyncio
    async def test_no_contradictions_without_data(self):
        d      = ContradictionDetector(pool=None)
        result = await d.analyse(
            entity="AAPL", ticker=None,
            sentiment_score=0.5, signal_score=0.5,
            scraped_at=datetime.now(timezone.utc),
        )
        # No DB, no price data → no contradictions detected
        assert result.is_contradicting is False
        assert result.signal_adjustment == 1.0

    @pytest.mark.asyncio
    async def test_adjustment_reasons_empty_without_data(self):
        d      = ContradictionDetector(pool=None)
        result = await d.analyse(
            entity="MSFT", ticker=None,
            sentiment_score=0.6, signal_score=0.5,
            scraped_at=datetime.now(timezone.utc),
        )
        assert result.adjustment_reasons == []

    @pytest.mark.asyncio
    async def test_ticker_resolved_from_map(self):
        d = ContradictionDetector(
            pool=None,
            ticker_map={"nvidia": "NVDA"},
        )
        result = await d.analyse(
            entity="NVIDIA", ticker=None,
            sentiment_score=0.5, signal_score=0.5,
            scraped_at=datetime.now(timezone.utc),
        )
        # Ticker resolution from map should not raise
        assert isinstance(result, ContradictionResult)

    @pytest.mark.asyncio
    async def test_all_fields_have_valid_types(self):
        d      = ContradictionDetector(pool=None)
        result = await d.analyse(
            entity="TSLA", ticker=None,
            sentiment_score=0.4, signal_score=0.4,
            scraped_at=datetime.now(timezone.utc),
        )
        assert isinstance(result.disagreement_score, float)
        assert isinstance(result.consecutive_same_direction, int)
        assert isinstance(result.crowd_consensus_reversal, bool)
        assert isinstance(result.price_leading_narrative, bool)
        assert isinstance(result.narrative_leading_price, bool)
        assert isinstance(result.is_contradicting, bool)
        assert isinstance(result.signal_adjustment, float)
        assert isinstance(result.adjustment_reasons, list)


class TestSignalAdjustmentCompute:
    """Test _compute_adjustment logic directly."""

    def _result(self, **kwargs) -> ContradictionResult:
        r = ContradictionResult()
        for k, v in kwargs.items():
            setattr(r, k, v)
        return r

    def test_price_leading_reduces_adjustment(self):
        r = self._result(
            price_leading_narrative=True,
            price_return_pre=0.03,
        )
        r = ContradictionDetector._compute_adjustment(r, signal_score=0.6)
        assert r.signal_adjustment < 1.0
        assert "price_already_moved" in r.adjustment_reasons[0]

    def test_narrative_leading_boosts_adjustment(self):
        r = self._result(narrative_leading_price=True)
        r = ContradictionDetector._compute_adjustment(r, signal_score=0.6)
        assert r.signal_adjustment > 1.0
        assert "genuine_alpha_window" in r.adjustment_reasons

    def test_crowd_reversal_reduces_adjustment(self):
        r = self._result(
            crowd_consensus_reversal=True,
            consecutive_same_direction=6,
        )
        r = ContradictionDetector._compute_adjustment(r, signal_score=0.7)
        assert r.signal_adjustment < 0.6
        assert any("crowd_consensus" in reason for reason in r.adjustment_reasons)

    def test_high_disagreement_reduces_adjustment(self):
        r = self._result(disagreement_score=0.8)
        r = ContradictionDetector._compute_adjustment(r, signal_score=0.5)
        assert r.signal_adjustment < 1.0
        assert any("disagreement" in reason for reason in r.adjustment_reasons)

    def test_adjustment_clamped_to_0_1_to_1_5(self):
        # Worst case: price leading + crowd reversal → multiply 0.3 × 0.4 = 0.12
        r = self._result(
            price_leading_narrative=True,
            price_return_pre=0.05,
            crowd_consensus_reversal=True,
            consecutive_same_direction=8,
        )
        r = ContradictionDetector._compute_adjustment(r, signal_score=0.6)
        assert r.signal_adjustment >= 0.10
        assert r.signal_adjustment <= 1.50

    def test_no_flags_adjustment_is_1(self):
        r = ContradictionResult()
        r = ContradictionDetector._compute_adjustment(r, signal_score=0.5)
        assert r.signal_adjustment == 1.0
        assert r.is_contradicting is False
        assert r.adjustment_reasons == []

    def test_multiple_flags_compound(self):
        r = self._result(
            price_leading_narrative=True,
            price_return_pre=0.03,
            disagreement_score=0.9,
        )
        r = ContradictionDetector._compute_adjustment(r, signal_score=0.6)
        # 0.3 (price) × 0.7 (disagreement) = 0.21
        assert r.signal_adjustment < 0.30
        assert len(r.adjustment_reasons) == 2

    def test_is_contradicting_true_when_reasons_present(self):
        r = self._result(narrative_leading_price=True)
        r = ContradictionDetector._compute_adjustment(r, signal_score=0.5)
        assert r.is_contradicting is True


# ─────────────────────────────────────────────────────────────────────────────
# Integration: Phase 4 pipeline end-to-end
# ─────────────────────────────────────────────────────────────────────────────

class TestPhase4Integration:
    """Simulate a Phase 4 research workflow."""

    def test_ml_calibration_into_experiment_tracker(self, tmp_path):
        from calibration import calibrate
        from experiment_tracker import ExperimentTracker, log_calibration_result

        t = ExperimentTracker(
            log_path    = tmp_path / "runs.jsonl",
            artifact_dir= tmp_path / "artifacts",
        )
        events = _make_events(80, ic=0.30, seed=42)
        hash_  = t.snapshot_dataset(events, name="phase4_test")

        for method in ["ridge", "bayesian"]:
            with t.start_run(
                "phase4_calibration",
                params={"method": method, "horizon": 1},
                dataset_hash=hash_,
            ) as run:
                result = calibrate(events, method=method, horizon=1)
                log_calibration_result(run, result)

        runs = t.list_runs("phase4_calibration")
        assert len(runs) == 2

        best = t.best_run("phase4_calibration", metric="ic")
        assert best is not None
        assert best["params"]["method"] in ("ridge", "bayesian")

    @pytest.mark.asyncio
    async def test_contradiction_gating_pipeline(self):
        """Contradiction detector adjusts signals before they enter the portfolio."""
        detector = ContradictionDetector(pool=None)
        events   = _make_events(5, seed=99)
        adjusted_scores = []

        for ev in events:
            result = await detector.analyse(
                entity          = "NVIDIA",
                ticker          = None,
                sentiment_score = float(ev["signal_score"]),
                signal_score    = float(ev["signal_score"]),
                scraped_at      = datetime.now(timezone.utc),
            )
            adjusted = ev["signal_score"] * result.signal_adjustment
            adjusted_scores.append(adjusted)

        # Without DB/price data, adjustments should all be 1.0 → identical
        assert all(
            abs(adj - ev["signal_score"]) < 1e-6
            for adj, ev in zip(adjusted_scores, events)
        )

    def test_full_phase4_workflow(self, tmp_path):
        """ML calibration → experiment tracking → disagreement detection."""
        from calibration import calibrate
        from experiment_tracker import ExperimentTracker, log_calibration_result

        t      = ExperimentTracker(tmp_path / "runs.jsonl", tmp_path / "art")
        events = _make_events(80, ic=0.25, seed=7)

        with t.start_run("full_workflow", params={"method": "ensemble"}) as run:
            result = calibrate(events, method="ensemble")
            log_calibration_result(run, result)
            # Disagreement check
            sents = [float(ev["signal_score"]) for ev in events[:10]]
            d_score = disagreement_score_from_sentiments(sents)
            run.log_metric("disagreement_score", d_score)
            run.set_tag("phase", "4")

        runs = t.list_runs("full_workflow")
        assert len(runs) == 1
        obj = runs[0]
        assert "ic" in obj["metrics"]
        assert "disagreement_score" in obj["metrics"]
        assert obj["tags"].get("phase") == "4"
        assert obj["status"] == "completed"
