"""Integration-style tests for the FastAPI app (no DB, no network)."""
import pytest
from fastapi.testclient import TestClient
from unittest.mock import AsyncMock, patch

from config import settings

# Override API key so tests can authenticate
settings.api_key = "test-key"

from api import app

client = TestClient(app, raise_server_exceptions=False)


def auth():
    return {"X-API-Key": "test-key"}


def test_root():
    r = client.get("/")
    assert r.status_code == 200
    assert r.json()["status"] == "running"


def test_health():
    with patch("api.get_pool") as mock_pool:
        mock_conn = AsyncMock()
        mock_conn.fetchval = AsyncMock(return_value=1)
        mock_pool.return_value = mock_conn
        r = client.get("/health")
    assert r.status_code in (200, 503)


def test_results_requires_auth():
    r = client.get("/results")
    assert r.status_code == 403


def test_analyze_requires_auth():
    r = client.post("/analyze", json={"urls": ["https://example.com"]})
    assert r.status_code == 403


def test_analyze_blocks_private_url():
    with patch("api.run_pipeline", new_callable=AsyncMock):
        r = client.post(
            "/analyze",
            json={"urls": ["http://169.254.169.254/latest/meta-data"]},
            headers=auth(),
        )
    assert r.status_code == 400


def test_job_not_found():
    r = client.get("/jobs/nonexistent-id", headers=auth())
    assert r.status_code == 404


def test_wrong_api_key():
    r = client.get("/results", headers={"X-API-Key": "wrong"})
    assert r.status_code == 403
