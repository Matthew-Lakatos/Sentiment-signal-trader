"""
test_round3.py — tests for round-3 additions.

Covers:
    calibration.py   — compute_orthogonality (VIF + corr matrix)
    regime.py        — build_regime_index, classify_regimes, run_regime_split
    horizon.py       — optimise_horizon, apply_horizon_weights
    capacity.py      — CapacityAnalyser, SecondOrderAlpha (sync path)

All tests are pure-Python (no DB, no network).
"""
from __future__ import annotations

import math
import random
from datetime import datetime, timezone, timedelta

import pandas as pd
import numpy as np
import pytest


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

def _now():
    return datetime.now(timezone.utc)


def _make_price_df(n_days: int = 120, seed: int = 42, trend: float = 0.0002) -> pd.DataFrame:
    """Synthetic OHLCV — trend controls bull/bear."""
    rng   = random.Random(seed)
    dates = pd.date_range(end=datetime.now().date(), periods=n_days, freq="B")
    px    = [100.0]
    for _ in range(n_days - 1):
        px.append(px[-1] * (1 + trend + rng.gauss(0, 0.012)))
    df = pd.DataFrame({
        "Open":   [p * 0.998 for p in px],
        "High":   [p * 1.010 for p in px],
        "Low":    [p * 0.990 for p in px],
        "Close":  px,
        "Volume": [int(2e6 * rng.uniform(0.5, 2.0)) for _ in px],
    }, index=pd.to_datetime(dates).normalize())
    return df


def _make_events(n: int = 80, seed: int = 99) -> list[dict]:
    rng  = random.Random(seed)
    base = _now() - timedelta(days=60)
    evs  = []
    for i in range(n):
        score = rng.uniform(-0.8, 0.8)
        noise = rng.gauss(0, 0.4)
        ret   = score * 0.25 + noise
        label = "POSITIVE" if score > 0.1 else ("NEGATIVE" if score < -0.1 else "NEUTRAL")
        evs.append({
            "event_id":         f"e{i:04d}",
            "scraped_at":       (base + timedelta(hours=i * 6)).isoformat(),
            "sentiment_label":  label,
            "sentiment_score":  abs(score),
            "materiality_score": abs(score) * 0.7 + rng.uniform(0, 0.2),
            "novelty_score":    rng.uniform(0.2, 0.95),
            "credibility_score": rng.uniform(0.4, 0.9),
            "signal_score":     score,
            "signal_direction": "BULLISH" if score > 0 else "BEARISH",
            "signal_tier":      "STRONG" if abs(score) > 0.5 else "MODERATE",
            "event_type":       rng.choice(["earnings", "macro", "contract", "analysis"]),
            "fwd_ret_1d":       ret,
            "fwd_ret_2d":       ret * 1.2 + rng.gauss(0, 0.2),
            "fwd_ret_3d":       ret * 1.4 + rng.gauss(0, 0.3),
            "fwd_ret_5d":       ret * 1.8 + rng.gauss(0, 0.5),
            "fwd_ret_7d":       ret * 2.1 + rng.gauss(0, 0.7),
            "fwd_ret_10d":      ret * 2.5 + rng.gauss(0, 1.0),
        })
    return evs


# ===========================================================================
# calibration.py — orthogonality (VIF + corr matrix)
# ===========================================================================

class TestOrthogonality:

    def _X(self, n: int = 100, correlated: bool = False) -> np.ndarray:
        rng = np.random.default_rng(7)
        X   = rng.standard_normal((n, 4))
        if correlated:
            # Make feature 1 strongly correlated with feature 0
            X[:, 1] = X[:, 0] * 0.9 + rng.standard_normal(n) * 0.2
        return X

    def test_orthogonal_features_low_vif(self):
        from calibration import compute_orthogonality
        X    = self._X(correlated=False)
        orth = compute_orthogonality(X)
        vifs = orth["vif"]
        # Independent features should have VIF close to 1
        for f, v in vifs.items():
            assert math.isfinite(v), f"{f} VIF is not finite"
            assert v < 5.0, f"{f} VIF={v:.2f} unexpectedly high for independent features"

    def test_correlated_features_high_vif(self):
        from calibration import compute_orthogonality
        X    = self._X(correlated=True)
        orth = compute_orthogonality(X)
        vifs = list(orth["vif"].values())
        # At least one feature should be flagged with elevated VIF
        assert max(v for v in vifs if math.isfinite(v)) > 1.5

    def test_corr_matrix_diagonal_is_one(self):
        from calibration import compute_orthogonality, FEATURE_NAMES
        X    = self._X()
        orth = compute_orthogonality(X)
        for f in FEATURE_NAMES:
            assert abs(orth["corr_matrix"][f][f] - 1.0) < 1e-6

    def test_corr_matrix_symmetric(self):
        from calibration import compute_orthogonality, FEATURE_NAMES
        X    = self._X()
        orth = compute_orthogonality(X)
        for i, f in enumerate(FEATURE_NAMES):
            for j, g in enumerate(FEATURE_NAMES):
                r_fg = orth["corr_matrix"][f][g]
                r_gf = orth["corr_matrix"][g][f]
                assert abs(r_fg - r_gf) < 1e-6

    def test_high_correlation_triggers_warning(self):
        from calibration import compute_orthogonality
        X    = self._X(correlated=True)
        orth = compute_orthogonality(X)
        # Should warn about sentiment↔materiality correlation
        assert len(orth["corr_warnings"]) >= 1

    def test_vif_warning_on_collinear(self):
        from calibration import compute_orthogonality
        X = self._X(correlated=True)
        orth = compute_orthogonality(X)
        # May or may not trigger VIF > 5 depending on exact correlation
        assert isinstance(orth["vif_warnings"], list)

    def test_calibrate_includes_orthogonality(self):
        from calibration import calibrate
        events = _make_events(80)
        result = calibrate(events, horizon=1, method="ridge")
        assert result.corr_matrix is not None
        assert result.vif is not None
        assert isinstance(result.corr_warnings, list)
        assert isinstance(result.vif_warnings, list)

    def test_orthogonality_report_is_string(self):
        from calibration import calibrate
        result = calibrate(_make_events(60), horizon=1, method="ridge")
        report = result.orthogonality_report()
        assert isinstance(report, str)
        assert "VIF" in report

    def test_independent_features_no_vif_warnings(self):
        from calibration import compute_orthogonality
        rng = np.random.default_rng(42)
        X   = rng.standard_normal((200, 4))   # truly independent
        orth = compute_orthogonality(X)
        # With truly independent features VIF should stay well below 5
        assert all(v < 4.0 for v in orth["vif"].values() if math.isfinite(v))


# ===========================================================================
# regime.py
# ===========================================================================

class TestRegime:

    def test_build_regime_index_columns(self):
        from regime import build_regime_index
        df  = _make_price_df(120)
        idx = build_regime_index(df)
        assert "vol_regime"   in idx.columns
        assert "trend_regime" in idx.columns
        assert "rolling_vol"  in idx.columns
        assert "rolling_ret"  in idx.columns

    def test_vol_regimes_are_valid_labels(self):
        from regime import build_regime_index
        df     = _make_price_df(120)
        idx    = build_regime_index(df)
        valid  = {"LOW", "MEDIUM", "HIGH", "SPIKE", "UNKNOWN"}
        labels = set(idx["vol_regime"].dropna().unique())
        assert labels.issubset(valid)

    def test_trend_regimes_are_valid_labels(self):
        from regime import build_regime_index
        df    = _make_price_df(120)
        idx   = build_regime_index(df)
        valid = {"BULL", "NEUTRAL", "BEAR", "UNKNOWN"}
        labels = set(idx["trend_regime"].dropna().unique())
        assert labels.issubset(valid)

    def test_bull_trend_on_rising_prices(self):
        from regime import build_regime_index, _trend_label
        df  = _make_price_df(120, trend=0.005)   # strong bull
        idx = build_regime_index(df)
        # Last row should be BULL
        last = idx["trend_regime"].dropna().iloc[-1]
        assert last == "BULL"

    def test_bear_trend_on_falling_prices(self):
        from regime import build_regime_index
        df  = _make_price_df(120, trend=-0.005)   # strong bear
        idx = build_regime_index(df)
        last = idx["trend_regime"].dropna().iloc[-1]
        assert last == "BEAR"

    def test_classify_regimes_attaches_fields(self):
        from regime import classify_regimes
        df     = _make_price_df(120)
        events = _make_events(20)
        result = classify_regimes(events, df)
        for ev in result:
            assert "vol_regime"   in ev
            assert "trend_regime" in ev

    def test_classify_regimes_unknown_on_no_match(self):
        from regime import classify_regimes
        df    = _make_price_df(30)   # only 30 days
        # Event far in the past — no price data
        ev    = {"scraped_at": "2010-01-01T00:00:00", "signal_score": 0.5}
        result = classify_regimes([ev], df)
        assert result[0]["vol_regime"] == "UNKNOWN"

    def test_run_regime_split_returns_report(self):
        from regime import classify_regimes, run_regime_split
        df     = _make_price_df(120)
        events = _make_events(60)
        labelled = classify_regimes(events, df)
        report   = run_regime_split(labelled, horizon=1)
        assert isinstance(report.overall_ic, float)
        assert len(report.vol_cuts)   >= 1
        assert len(report.trend_cuts) >= 1

    def test_regime_report_summary_is_string(self):
        from regime import classify_regimes, run_regime_split
        df     = _make_price_df(120)
        events = _make_events(60)
        labelled = classify_regimes(events, df)
        report   = run_regime_split(labelled, horizon=1)
        summary  = report.summary()
        assert isinstance(summary, str)
        assert "REGIME" in summary

    def test_regime_to_dict(self):
        from regime import classify_regimes, run_regime_split
        df     = _make_price_df(120)
        events = _make_events(60)
        labelled = classify_regimes(events, df)
        report   = run_regime_split(labelled, horizon=1)
        d = report.to_dict()
        assert "vol_cuts"    in d
        assert "trend_cuts"  in d
        assert "overall_ic"  in d

    def test_spike_regime_on_high_vol(self):
        from regime import build_regime_index, _vol_label
        # Simulate extreme volatility
        assert _vol_label(0.35) == "SPIKE"
        assert _vol_label(0.05) == "LOW"
        assert _vol_label(0.14) == "MEDIUM"
        assert _vol_label(0.24) == "HIGH"


# ===========================================================================
# horizon.py
# ===========================================================================

class TestHorizon:

    def test_optimise_returns_result(self):
        from horizon import optimise_horizon
        events = _make_events(80)
        result = optimise_horizon(events, horizons=[1, 3, 5])
        assert result.best_horizon in [1, 3, 5]
        assert result.n_events > 0

    def test_ic_curve_has_all_horizons(self):
        from horizon import optimise_horizon
        horizons = [1, 2, 3, 5]
        events   = _make_events(80)
        result   = optimise_horizon(events, horizons=horizons)
        for h in horizons:
            assert h in result.ic_curve
            assert h in result.sharpe_curve

    def test_by_event_type_populated(self):
        from horizon import optimise_horizon
        events = _make_events(100)
        result = optimise_horizon(events, horizons=[1, 3, 5])
        # At least one event type should be present (events have 4 types)
        assert len(result.by_event_type) >= 1
        for h in result.by_event_type.values():
            assert h in [1, 3, 5]

    def test_by_tier_populated(self):
        from horizon import optimise_horizon
        events = _make_events(100)
        result = optimise_horizon(events, horizons=[1, 3, 5])
        assert len(result.by_tier) >= 1

    def test_summary_is_string(self):
        from horizon import optimise_horizon
        events = _make_events(60)
        result = optimise_horizon(events, horizons=[1, 3, 5])
        s = result.summary()
        assert isinstance(s, str)
        assert "HORIZON" in s
        assert "best" in s.lower()

    def test_to_dict(self):
        from horizon import optimise_horizon
        events = _make_events(60)
        result = optimise_horizon(events, horizons=[1, 3, 5])
        d = result.to_dict()
        assert "best_horizon"  in d
        assert "ic_curve"      in d
        assert "by_event_type" in d

    def test_insufficient_data_returns_default(self):
        from horizon import optimise_horizon
        # Only 2 events — should still return without crashing
        events = _make_events(2)
        result = optimise_horizon(events, horizons=[1, 3])
        assert result.best_horizon in [1, 3]

    def test_apply_horizon_weights_shorter_decay(self):
        from horizon import optimise_horizon, apply_horizon_weights
        events = _make_events(80)
        result = optimise_horizon(events, horizons=[1, 3, 5, 7])
        # Longer horizon should apply a decay
        aw1 = apply_horizon_weights(0.6, "earnings", result)
        aw7 = apply_horizon_weights(0.6, "macro",    result)
        # decay for horizon ≥ 1 means adjusted_score ≤ original
        assert aw1["adjusted_score"] <= 0.6 + 1e-6
        assert aw7["adjusted_score"] <= 0.6 + 1e-6

    def test_apply_horizon_weights_returns_dict(self):
        from horizon import optimise_horizon, apply_horizon_weights
        events = _make_events(60)
        result = optimise_horizon(events, horizons=[1, 3])
        aw = apply_horizon_weights(0.5, "analysis", result)
        assert "recommended_horizon" in aw
        assert "adjusted_score"      in aw
        assert "horizon_decay"       in aw
        assert 0.0 <= aw["horizon_decay"] <= 1.0

    def test_best_horizon_is_int(self):
        from horizon import optimise_horizon
        events = _make_events(80)
        result = optimise_horizon(events)
        assert isinstance(result.best_horizon, int)


# ===========================================================================
# capacity.py
# ===========================================================================

class TestCapacity:

    def _make_orders(self, n: int = 10, notional: float = 5_000.0) -> list[dict]:
        rng = random.Random(42)
        return [
            {
                "notional":  notional * rng.uniform(0.5, 1.5),
                "direction": rng.choice(["LONG", "SHORT"]),
                "ticker":    f"T{i}",
            }
            for i in range(n)
        ]

    def test_report_fields_present(self):
        from capacity import CapacityAnalyser
        orders = self._make_orders(10)
        cap    = CapacityAnalyser(avg_daily_volume=2_000_000, avg_price=150.0)
        rpt    = cap.report(orders, signal_alpha_bps=30, trading_days_in_window=21)
        assert "avg_notional_per_trade" in rpt.to_dict()
        assert "trades_per_day"         in rpt.to_dict()
        assert "capacity_ceiling_usd"   in rpt.to_dict()
        assert "estimated_impact_bps"   in rpt.to_dict()

    def test_empty_orders_returns_report(self):
        from capacity import CapacityAnalyser
        cap = CapacityAnalyser()
        rpt = cap.report([], signal_alpha_bps=30)
        assert rpt.avg_notional_per_trade == 0.0
        assert "No orders" in rpt.warnings[0]

    def test_high_pct_adv_triggers_warning(self):
        from capacity import CapacityAnalyser
        # 1 share of a tiny ADV stock → 100% ADV
        orders = [{"notional": 500_000.0, "direction": "LONG"}]
        cap    = CapacityAnalyser(avg_daily_volume=1_000, avg_price=100.0)
        rpt    = cap.report(orders)
        assert any("ADV" in w for w in rpt.warnings)

    def test_impact_increases_with_trade_size(self):
        from capacity import CapacityAnalyser
        cap    = CapacityAnalyser(avg_daily_volume=1_000_000, avg_price=100.0)
        small  = cap._impact_bps(10_000)
        large  = cap._impact_bps(500_000)
        assert large > small

    def test_capacity_ceiling_decreases_with_higher_eta(self):
        """Higher ADV → higher ceiling."""
        from capacity import CapacityAnalyser
        cap_small = CapacityAnalyser(avg_daily_volume=100_000,   avg_price=50.0)
        cap_large = CapacityAnalyser(avg_daily_volume=10_000_000, avg_price=50.0)
        ceil_small = cap_small._capacity_ceiling(30)
        ceil_large = cap_large._capacity_ceiling(30)
        assert ceil_large > ceil_small

    def test_summary_is_string(self):
        from capacity import CapacityAnalyser
        orders = self._make_orders(5)
        cap    = CapacityAnalyser()
        rpt    = cap.report(orders)
        s      = rpt.summary()
        assert isinstance(s, str)
        assert "CAPACITY" in s

    def test_impact_zero_when_adv_zero(self):
        from capacity import CapacityAnalyser
        cap = CapacityAnalyser(avg_daily_volume=0, avg_price=100.0)
        assert cap._impact_bps(10_000) == 0.0

    def test_trades_per_day(self):
        from capacity import CapacityAnalyser
        orders = self._make_orders(21)  # exactly 21 orders over 21 trading days
        cap    = CapacityAnalyser()
        rpt    = cap.report(orders, trading_days_in_window=21)
        assert abs(rpt.trades_per_day - 1.0) < 0.01

    def test_second_order_alpha_sync(self):
        from capacity import SecondOrderAlpha
        soa = SecondOrderAlpha(pool=None)
        peers = [
            {"entity": "AMD",   "propagated_sentiment": 0.8, "topic_bridge": "semiconductors", "hops": 2},
            {"entity": "INTC",  "propagated_sentiment": 0.6, "topic_bridge": "semiconductors", "hops": 2},
            {"entity": "QCOM",  "propagated_sentiment": 0.1, "topic_bridge": "chips",          "hops": 2},
        ]
        # Use low min_score so QCOM is included despite small KG sentiment
        signals = soa.propagate_sync(peers, base_score=0.7, min_score=0.01)
        assert len(signals) >= 2
        amd_sig = next(s for s in signals if s["entity"] == "AMD")
        intc_sig = next(s for s in signals if s["entity"] == "INTC")
        # AMD has higher KG sentiment than INTC → higher secondary score
        assert abs(amd_sig["secondary_score"]) >= abs(intc_sig["secondary_score"])

    def test_second_order_contra_signal_discounted(self):
        """Peer with opposite KG sentiment to primary should be discounted."""
        from capacity import SecondOrderAlpha
        soa = SecondOrderAlpha(pool=None)
        peers = [
            {"entity": "PEER_A", "propagated_sentiment":  0.8, "topic_bridge": "topic", "hops": 2},
            {"entity": "PEER_B", "propagated_sentiment": -0.8, "topic_bridge": "topic", "hops": 2},
        ]
        signals = soa.propagate_sync(peers, base_score=0.6, min_score=0.01)
        a = next((s for s in signals if s["entity"] == "PEER_A"), None)
        b = next((s for s in signals if s["entity"] == "PEER_B"), None)
        if a and b:
            assert abs(a["secondary_score"]) > abs(b["secondary_score"])

    def test_second_order_min_score_filter(self):
        from capacity import SecondOrderAlpha
        soa = SecondOrderAlpha(pool=None)
        peers = [
            {"entity": "TINY", "propagated_sentiment": 0.05, "topic_bridge": "topic", "hops": 2},
        ]
        signals = soa.propagate_sync(peers, base_score=0.5, min_score=0.20)
        # 0.5 × 0.45 × 0.05 ≈ 0.011 < 0.20 → filtered out
        assert len(signals) == 0

    def test_second_order_no_pool_returns_empty(self):
        """Without a pool, propagate() should return [] gracefully (sync path)."""
        from capacity import SecondOrderAlpha
        soa = SecondOrderAlpha(pool=None)
        # Sync path with empty peers
        result = soa.propagate_sync([], base_score=0.5)
        assert result == []
