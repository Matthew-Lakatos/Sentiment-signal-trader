"""Tests for Pydantic event schema validation."""
import pytest
from events import ScrapedEvent


def make_event(**kwargs):
    base = dict(
        url="https://example.com/article",
        source_domain="example.com",
        raw_text_hash="a" * 64,
        summary="Test summary",
        sentiment_label="POSITIVE",
        sentiment_score=0.8,
    )
    base.update(kwargs)
    return ScrapedEvent(**base)


def test_valid_event():
    ev = make_event()
    assert ev.sentiment_label == "POSITIVE"
    assert ev.sentiment_score == 0.8


def test_sentiment_normalised_to_upper():
    ev = make_event(sentiment_label="positive")
    assert ev.sentiment_label == "POSITIVE"


def test_invalid_sentiment_raises():
    with pytest.raises(Exception):
        make_event(sentiment_label="BULLISH")


def test_score_clamped():
    ev = make_event(credibility_score=1.5)
    assert ev.credibility_score == 1.0
    ev2 = make_event(propaganda_score=-0.1)
    assert ev2.propaganda_score == 0.0


def test_hash_text():
    h = ScrapedEvent.hash_text("hello world")
    assert len(h) == 64
    assert h == ScrapedEvent.hash_text("hello world")
    assert h != ScrapedEvent.hash_text("different text")


def test_uncertain_sentiment_allowed():
    ev = make_event(sentiment_label="UNCERTAIN")
    assert ev.sentiment_label == "UNCERTAIN"
