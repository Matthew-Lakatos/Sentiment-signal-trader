"""
test_phase2.py — Phase 2 integration tests.

Covers all four sections implemented in Phase 2:
    §7  online_learning.py     — RLS update, forgetting, drift detection, persistence
    §13 position_lifecycle.py  — state machine transitions, scaling, invalidation
    §18 drift_monitor.py       — rolling IC/Sharpe gate, auto-disable/recover
    §20 multi_horizon.py       — three learners, confidence blending, affinity
"""
from __future__ import annotations

import json
import math
import random
import tempfile
import os
from datetime import datetime, timezone, timedelta
from typing import Optional

import pytest


# ─────────────────────────────────────────────────────────────────────────────
# Shared generators
# ─────────────────────────────────────────────────────────────────────────────

def _make_events(n: int = 80, seed: int = 42, ic: float = 0.25) -> list[dict]:
    """Generate synthetic events with known IC for testing."""
    rng  = random.Random(seed)
    base = datetime.now(timezone.utc) - timedelta(days=30)
    evs  = []
    for i in range(n):
        score = rng.uniform(-0.8, 0.8)
        noise = rng.gauss(0, 0.5)
        ret   = score * ic + noise
        label = "POSITIVE" if score > 0.1 else ("NEGATIVE" if score < -0.1 else "NEUTRAL")
        evs.append({
            "event_id":          f"e{i:04d}",
            "scraped_at":        (base + timedelta(hours=i * 3)).isoformat(),
            "sentiment_label":   label,
            "sentiment_score":   abs(score),
            "materiality_score": abs(score) * 0.7 + rng.uniform(0, 0.2),
            "novelty_score":     rng.uniform(0.2, 0.9),
            "credibility_score": rng.uniform(0.4, 0.9),
            "signal_score":      score,
            "signal_direction":  "BULLISH" if score > 0 else "BEARISH",
            "event_type":        rng.choice(["earnings", "macro", "contract", "analysis"]),
            "surprise_score":    rng.uniform(-0.3, 0.3),
            "fwd_ret_1d":        ret,
            "fwd_ret_5d":        ret * 1.5 + rng.gauss(0, 0.4),
            "fwd_ret_20d":       ret * 2.0 + rng.gauss(0, 0.8),
        })
    return evs


# ─────────────────────────────────────────────────────────────────────────────
# §7 — online_learning
# ─────────────────────────────────────────────────────────────────────────────

from online_learning import OnlineLearner, _event_to_features, _ONLINE_FEATURES


class TestOnlineLearnerInit:
    def test_features_stored(self):
        ol = OnlineLearner(["a", "b", "c"])
        assert ol.features == ["a", "b", "c"]
        assert ol.p == 3

    def test_initial_weights_equal(self):
        ol = OnlineLearner(["a", "b"])
        # Before MIN_SAMPLES_TO_USE updates → equal weights, sum exactly 1.0
        w = ol.weights
        assert abs(sum(w.values()) - 1.0) < 1e-6
        assert abs(w["a"] - w["b"]) < 2e-4   # equal within rounding tolerance

    def test_n_updates_zero(self):
        ol = OnlineLearner(["x"])
        assert ol.n_updates == 0

    def test_forgetting_stored(self):
        ol = OnlineLearner(["x"], forgetting=0.95)
        assert ol.forgetting == 0.95


class TestOnlineLearnerUpdate:
    def test_single_update_increments_counter(self):
        ol = OnlineLearner(["sentiment", "materiality"])
        ol.update({"sentiment": 0.5, "materiality": 0.3}, y=0.02)
        assert ol.n_updates == 1

    def test_non_finite_y_skipped(self):
        ol = OnlineLearner(["sentiment"])
        ol.update({"sentiment": 0.5}, y=float("nan"))
        ol.update({"sentiment": 0.5}, y=float("inf"))
        assert ol.n_updates == 0

    def test_batch_update_returns_count(self):
        ol     = OnlineLearner(_ONLINE_FEATURES)
        events = _make_events(30)
        n      = ol.update_batch(events, horizon=1)
        assert n == 30
        assert ol.n_updates == 30

    def test_weights_change_after_training(self):
        ol = OnlineLearner(_ONLINE_FEATURES)
        events = _make_events(50)
        ol.update_batch(events, horizon=1)
        # Weights should no longer be exactly equal after training
        vals = list(ol.weights.values())
        assert not all(abs(v - vals[0]) < 1e-6 for v in vals)

    def test_weights_sum_to_one(self):
        ol = OnlineLearner(_ONLINE_FEATURES)
        ol.update_batch(_make_events(50))
        assert abs(sum(ol.weights.values()) - 1.0) < 1e-5

    def test_weights_non_negative(self):
        ol = OnlineLearner(_ONLINE_FEATURES)
        ol.update_batch(_make_events(50))
        assert all(v >= 0 for v in ol.weights.values())

    def test_history_grows(self):
        ol = OnlineLearner(["a"])
        for _ in range(5):
            ol.update({"a": 0.5}, 0.01)
        assert len(ol._weight_history) == 5

    def test_history_capped_at_history_len(self):
        ol = OnlineLearner(["a"], history_len=10)
        for _ in range(20):
            ol.update({"a": 0.5}, 0.01)
        assert len(ol._weight_history) <= 10

    def test_missing_features_default_zero(self):
        ol = OnlineLearner(["a", "b"])
        # Update with only 'a' provided — 'b' should default to 0
        ol.update({"a": 0.5}, 0.01)
        assert ol.n_updates == 1


class TestOnlineLearnerForgetting:
    def test_lower_forgetting_adapts_faster(self):
        """A learner with lower λ should diverge more from equal weights faster."""
        events_pos = _make_events(30, ic=0.6, seed=1)
        ol_fast = OnlineLearner(_ONLINE_FEATURES, forgetting=0.80)
        ol_slow = OnlineLearner(_ONLINE_FEATURES, forgetting=0.99)
        ol_fast.update_batch(events_pos)
        ol_slow.update_batch(events_pos)
        # Fast learner should have more extreme weight imbalance
        fast_max = max(ol_fast.weights.values())
        slow_max = max(ol_slow.weights.values())
        eq_w = 1.0 / len(_ONLINE_FEATURES)
        assert (fast_max - eq_w) >= (slow_max - eq_w) - 1e-4


class TestOnlineLearnerDrift:
    def test_drift_report_returns_all_features(self):
        ol = OnlineLearner(_ONLINE_FEATURES)
        ol.update_batch(_make_events(30))
        report = ol.drift_report()
        feat_names = [fd.name for fd in report.features]
        for f in _ONLINE_FEATURES:
            assert f in feat_names

    def test_drift_report_healthy_with_stable_data(self):
        ol = OnlineLearner(_ONLINE_FEATURES, forgetting=0.99)
        # Feed stable signal with low variance
        events = _make_events(60, ic=0.3, seed=99)
        ol.update_batch(events)
        report = ol.drift_report(stale_hours=999)   # suppress stale check
        # With stable data and no time constraint, should generally be healthy
        # (allowing for statistical variance in synthetic data)
        assert report.n_updates == 60

    def test_drift_report_n_updates_correct(self):
        ol = OnlineLearner(["a"])
        for _ in range(7):
            ol.update({"a": 0.3}, 0.01)
        report = ol.drift_report()
        assert report.n_updates == 7

    def test_stale_flag_when_no_recent_update(self):
        ol = OnlineLearner(["a"])
        ol.update({"a": 0.5}, 0.01)
        # Stale check with 0-hour threshold → always stale
        report = ol.drift_report(stale_hours=0.0)
        assert all(fd.is_stale for fd in report.features)


class TestOnlineLearnerPersistence:
    def test_save_load_roundtrip(self):
        ol = OnlineLearner(_ONLINE_FEATURES, forgetting=0.95)
        ol.update_batch(_make_events(30))
        orig_weights = ol.weights
        orig_n       = ol.n_updates

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            ol.save(path)
            ol2 = OnlineLearner.load(path)
            assert ol2.n_updates == orig_n
            assert ol2.features  == ol.features
            assert ol2.forgetting == ol.forgetting
            for feat in _ONLINE_FEATURES:
                assert abs(ol2.weights[feat] - orig_weights[feat]) < 1e-6
        finally:
            os.unlink(path)

    def test_reset_clears_state(self):
        ol = OnlineLearner(["a"])
        for _ in range(10):
            ol.update({"a": 0.5}, 0.01)
        ol.reset()
        assert ol.n_updates == 0
        assert ol._weight_history == []

    def test_fallback_weights_before_min_samples(self):
        ol = OnlineLearner(["a", "b", "c"])
        # 3 updates < MIN_SAMPLES_TO_USE (10)
        for _ in range(3):
            ol.update({"a": 0.5, "b": 0.3, "c": 0.1}, 0.01)
        w = ol.weights
        # All equal
        assert all(abs(v - 1/3) < 1e-4 for v in w.values())


class TestEventToFeatures:
    def test_positive_label_positive_sentiment(self):
        ev = {"sentiment_label": "POSITIVE", "sentiment_score": 0.8,
              "materiality_score": 0.5, "novelty_score": 0.6,
              "credibility_score": 0.7, "surprise_score": 0.2}
        x = _event_to_features(ev)
        assert x["sentiment"] > 0

    def test_negative_label_negative_sentiment(self):
        ev = {"sentiment_label": "NEGATIVE", "sentiment_score": 0.8,
              "materiality_score": 0.5, "novelty_score": 0.6,
              "credibility_score": 0.7}
        x = _event_to_features(ev)
        assert x["sentiment"] < 0

    def test_neutral_label_zero_sentiment(self):
        ev = {"sentiment_label": "NEUTRAL", "sentiment_score": 0.8,
              "materiality_score": 0.5, "novelty_score": 0.6,
              "credibility_score": 0.7}
        x = _event_to_features(ev)
        assert x["sentiment"] == 0.0

    def test_interaction_terms_computed(self):
        ev = {"sentiment_label": "POSITIVE", "sentiment_score": 0.5,
              "materiality_score": 0.4, "novelty_score": 0.6,
              "credibility_score": 0.8}
        x = _event_to_features(ev)
        assert abs(x["sent_x_novelty"] - 0.5 * 0.6) < 1e-6
        assert abs(x["mat_x_credibility"] - 0.4 * 0.8) < 1e-6

    def test_missing_fields_default_sensibly(self):
        x = _event_to_features({})
        assert x["sentiment"] == 0.0
        assert x["materiality"] == 0.0
        assert x["novelty"] == 0.5
        assert x["credibility"] == 0.5
        assert x["surprise"] == 0.0


# ─────────────────────────────────────────────────────────────────────────────
# §13 — position_lifecycle
# ─────────────────────────────────────────────────────────────────────────────

from position_lifecycle import (
    PositionManager, PositionConfig, PositionState,
    Position, LifecycleOrder,
)


class TestPositionOpen:
    def test_open_creates_position(self):
        mgr = PositionManager()
        pos = mgr.open("AAPL", signal_score=0.65, direction="BULLISH", event_id="e1")
        assert pos.ticker   == "AAPL"
        assert pos.state    == PositionState.OPEN
        assert pos.direction == "BULLISH"

    def test_open_generates_buy_order(self):
        mgr = PositionManager()
        mgr.open("AAPL", signal_score=0.65, direction="BULLISH", event_id="e1")
        orders = mgr.pending_orders()
        assert len(orders) == 1
        assert orders[0].side == "BUY"
        assert orders[0].notional > 0

    def test_short_generates_sell_order(self):
        mgr = PositionManager()
        mgr.open("TSLA", signal_score=-0.5, direction="BEARISH", event_id="e1")
        orders = mgr.pending_orders()
        assert orders[0].side == "SELL"

    def test_initial_notional_fraction(self):
        cfg = PositionConfig(max_position=20_000, initial_fraction=0.5)
        mgr = PositionManager(cfg)
        pos = mgr.open("AAPL", 0.7, "BULLISH", "e1")
        assert abs(pos.notional - 10_000) < 1e-6

    def test_open_on_existing_routes_to_on_new_signal(self):
        mgr = PositionManager()
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        # Second open call on same ticker → routes to on_new_signal
        pos = mgr.open("AAPL", 0.60, "BULLISH", "e2")
        assert pos.ticker == "AAPL"
        assert "e2" in pos.event_ids


class TestPositionScaleIn:
    def test_reinforcing_signal_triggers_scale_in(self):
        cfg = PositionConfig(scale_in_threshold=0.20)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.on_new_signal("AAPL", 0.50, "BULLISH", "e2")
        assert pos.state == PositionState.SCALE_IN

    def test_scale_in_increases_notional(self):
        cfg = PositionConfig(max_position=20_000, initial_fraction=0.5,
                             scale_step_fraction=0.25, scale_in_threshold=0.10)
        mgr = PositionManager(cfg)
        pos = mgr.open("AAPL", 0.65, "BULLISH", "e1")
        initial = pos.notional
        mgr.on_new_signal("AAPL", 0.55, "BULLISH", "e2")
        assert pos.notional > initial

    def test_scale_in_capped_at_max_position(self):
        cfg = PositionConfig(max_position=10_000, initial_fraction=0.90,
                             scale_step_fraction=0.50, scale_in_threshold=0.10)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.8, "BULLISH", "e1")
        mgr.on_new_signal("AAPL", 0.8, "BULLISH", "e2")
        pos = mgr.get_position("AAPL")
        assert pos.notional <= cfg.max_position

    def test_weak_reinforcing_signal_no_scale_in(self):
        cfg = PositionConfig(scale_in_threshold=0.40)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        mgr.mark_executed()
        pos = mgr.on_new_signal("AAPL", 0.10, "BULLISH", "e2")
        # Score 0.10 < threshold 0.40 → no SCALE_IN
        assert pos.state != PositionState.SCALE_IN


class TestPositionInvalidation:
    def test_opposing_strong_signal_invalidates(self):
        cfg = PositionConfig(invalidation_threshold=0.30)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.on_new_signal("AAPL", -0.70, "BEARISH", "e2")
        assert pos.state == PositionState.INVALIDATED

    def test_invalidation_generates_closing_order(self):
        mgr = PositionManager()
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        mgr.mark_executed()
        mgr.on_new_signal("AAPL", -0.80, "BEARISH", "e2")
        orders = mgr.pending_orders()
        closing = [o for o in orders if o.state == PositionState.INVALIDATED]
        assert len(closing) == 1
        assert closing[0].side == "SELL"  # close long

    def test_invalidation_zeroes_notional(self):
        mgr = PositionManager()
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.on_new_signal("AAPL", -0.80, "BEARISH", "e2")
        assert pos.notional == 0.0

    def test_weak_opposing_signal_does_not_invalidate(self):
        cfg = PositionConfig(invalidation_threshold=0.50)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.on_new_signal("AAPL", -0.20, "BEARISH", "e2")
        assert pos.state != PositionState.INVALIDATED

    def test_invalidated_position_is_terminal(self):
        mgr = PositionManager()
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.on_new_signal("AAPL", -0.80, "BEARISH", "e2")
        assert pos.is_terminal()


class TestPositionTick:
    def test_stop_loss_exits_position(self):
        cfg = PositionConfig(stop_loss=-0.03, max_position=10_000,
                             initial_fraction=1.0)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.get_position("AAPL")
        pos.state = PositionState.HOLD
        mgr.tick({"AAPL": -350})  # -350 on 10k = -3.5% < -3%
        assert pos.state == PositionState.EXIT
        assert pos.notional == 0.0

    def test_profit_target_reduces_position(self):
        cfg = PositionConfig(profit_target=0.05, max_position=10_000,
                             initial_fraction=1.0, reduce_fraction=0.50)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.get_position("AAPL")
        pos.state = PositionState.HOLD
        mgr.tick({"AAPL": 600})  # +600 on 10k = +6% > +5%
        assert pos.state == PositionState.REDUCE
        assert pos.notional < 10_000

    def test_open_settles_to_hold_on_tick(self):
        mgr = PositionManager()
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.get_position("AAPL")
        assert pos.state == PositionState.OPEN
        mgr.tick()
        assert pos.state == PositionState.HOLD

    def test_max_total_days_exits(self):
        cfg = PositionConfig(max_total_days=5, max_position=10_000,
                             initial_fraction=1.0)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.get_position("AAPL")
        pos.state = PositionState.HOLD
        # Manually age the position
        pos.opened_at = datetime.now(timezone.utc) - timedelta(days=6)
        mgr.tick()
        assert pos.state == PositionState.EXIT

    def test_terminal_positions_skip_tick(self):
        mgr = PositionManager()
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        pos = mgr.get_position("AAPL")
        pos.state = PositionState.EXIT
        mgr.tick({"AAPL": -99999})   # should not affect EXIT position
        assert pos.state == PositionState.EXIT


class TestPositionMarkExecuted:
    def test_mark_executed_clears_orders(self):
        mgr = PositionManager()
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        assert len(mgr.pending_orders()) == 1
        mgr.mark_executed()
        assert len(mgr.pending_orders()) == 0


class TestPositionSummary:
    def test_summary_counts_open(self):
        mgr = PositionManager()
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        mgr.open("TSLA", 0.55, "BEARISH", "e2")
        s = mgr.summary()
        assert s["open_positions"] == 2

    def test_summary_notional(self):
        cfg = PositionConfig(max_position=10_000, initial_fraction=1.0)
        mgr = PositionManager(cfg)
        mgr.open("AAPL", 0.65, "BULLISH", "e1")
        mgr.open("TSLA", 0.55, "BEARISH", "e2")
        s = mgr.summary()
        assert abs(s["total_notional"] - 20_000) < 1e-3


# ─────────────────────────────────────────────────────────────────────────────
# §18 — drift_monitor
# ─────────────────────────────────────────────────────────────────────────────

from drift_monitor import DriftMonitor, _spearman, _sharpe


class TestSpearmanHelper:
    def test_perfect_positive_correlation(self):
        xs = [1.0, 2.0, 3.0, 4.0, 5.0]
        ic = _spearman(xs, xs)
        assert abs(ic - 1.0) < 1e-6

    def test_perfect_negative_correlation(self):
        xs = [1.0, 2.0, 3.0, 4.0, 5.0]
        ys = [5.0, 4.0, 3.0, 2.0, 1.0]
        ic = _spearman(xs, ys)
        assert abs(ic + 1.0) < 1e-6

    def test_uncorrelated_near_zero(self):
        rng = random.Random(0)
        xs  = [rng.random() for _ in range(200)]
        ys  = [rng.random() for _ in range(200)]
        ic  = _spearman(xs, ys)
        assert abs(ic) < 0.2

    def test_too_few_points(self):
        assert math.isnan(_spearman([1.0], [1.0]))
        assert math.isnan(_spearman([], []))


class TestSharpeHelper:
    def test_positive_signal_positive_return_positive_sharpe(self):
        # Use varied (not constant) returns so std > 0
        rng  = random.Random(1)
        sigs = [0.5 + rng.gauss(0, 0.05) for _ in range(50)]
        rets = [0.02 + rng.gauss(0, 0.005) for _ in range(50)]
        sh   = _sharpe(sigs, rets)
        assert sh > 0

    def test_degenerate_returns_give_nan(self):
        # All-identical strategy returns → std = 0 → nan
        sh = _sharpe([0.5] * 50, [0.02] * 50)
        assert math.isnan(sh)

    def test_mixed_gives_lower_sharpe(self):
        sigs_good = [0.5] * 50
        rets_good = [0.02] * 50
        sigs_bad  = [0.5] * 25 + [-0.5] * 25
        rets_bad  = [0.02] * 25 + [0.02] * 25
        sh_good   = _sharpe(sigs_good, rets_good)
        sh_bad    = _sharpe(sigs_bad,  rets_bad)
        assert sh_good > sh_bad


class TestDriftMonitorBasic:
    def test_gate_open_initially(self):
        dm = DriftMonitor()
        assert dm.gate_open() is True

    def test_ingest_empty_list(self):
        dm = DriftMonitor()
        result = dm.ingest([])
        assert result == []

    def test_ingest_returns_empty_before_window_fills(self):
        dm = DriftMonitor(window_size=50)
        events = _make_events(10)
        result = dm.ingest(events)
        assert result == []

    def test_window_computed_at_window_size(self):
        dm = DriftMonitor(window_size=20)
        events = _make_events(20)
        result = dm.ingest(events)
        assert len(result) == 1
        assert result[0].n_events == 20

    def test_two_windows_computed_from_40_events(self):
        dm = DriftMonitor(window_size=20)
        result = dm.ingest(_make_events(40))
        assert len(result) == 2

    def test_ic_positive_with_strong_signal(self):
        dm     = DriftMonitor(window_size=20)
        events = _make_events(20, ic=0.80, seed=7)
        ws     = dm.ingest(events)
        assert len(ws) == 1
        assert ws[0].ic > 0

    def test_ic_roughly_zero_with_noise_signal(self):
        rng    = random.Random(13)
        events = [
            {"signal_score": rng.uniform(-1,1),
             "signal_direction": "BULLISH",
             "fwd_ret_1d": rng.gauss(0, 1)}
            for _ in range(40)
        ]
        dm  = DriftMonitor(window_size=20)
        wss = dm.ingest(events)
        assert len(wss) == 2
        # Mean IC across two windows should be near zero for pure noise
        mean_ic = sum(ws.ic for ws in wss) / 2
        assert abs(mean_ic) < 0.35


class TestDriftMonitorGate:
    def test_gate_closes_after_consecutive_bad_windows(self):
        # ic_disable_threshold=0.90 ensures gate closes for any realistic IC value
        dm = DriftMonitor(
            window_size=10,
            ic_disable_threshold=0.90,
            ic_disable_lookback=1,
        )
        rng    = random.Random(42)
        events = [{"signal_score": rng.gauss(0, 0.5), "signal_direction": "NEUTRAL",
                   "fwd_ret_1d": rng.gauss(0, 1.0)} for _ in range(10)]
        dm.ingest(events)
        assert dm.gate_open() is False

    def test_gate_reopens_after_recovery(self):
        # Use extreme thresholds: disable_threshold=0.90 so any typical IC closes gate,
        # recover_threshold=-0.99 so any non-terrible IC reopens it.
        # This makes the test deterministic regardless of random IC variance.
        dm = DriftMonitor(
            window_size=10,
            ic_disable_threshold=0.90,    # closes gate for almost any realistic IC
            ic_disable_lookback=1,
            ic_recover_threshold=-0.99,   # reopens gate if IC > -0.99 (essentially always)
            ic_recover_lookback=1,
        )
        rng = random.Random(42)
        noise = [{"signal_score": rng.gauss(0, 0.5), "signal_direction": "NEUTRAL",
                  "fwd_ret_1d": rng.gauss(0, 1.0)} for _ in range(10)]
        dm.ingest(noise)
        assert dm.gate_open() is False

        rng2  = random.Random(7)
        # Near-perfect signal → very high IC → well above -0.99
        good  = [{"signal_score": s, "signal_direction": "BULLISH",
                  "fwd_ret_1d": s * 0.99}
                 for s in [rng2.uniform(-1, 1) for _ in range(10)]]
        dm.ingest(good)
        assert dm.gate_open() is True

    def test_reset_clears_gate(self):
        dm = DriftMonitor(window_size=10, ic_disable_threshold=0.90,
                          ic_disable_lookback=1)
        rng    = random.Random(42)
        events = [{"signal_score": rng.gauss(0, 0.5), "signal_direction": "NEUTRAL",
                   "fwd_ret_1d": rng.gauss(0, 1.0)} for _ in range(10)]
        dm.ingest(events)
        dm.reset()
        assert dm.gate_open() is True
        assert len(dm.window_history) == 0


class TestDriftMonitorHealthReport:
    def test_healthy_report_no_alerts(self):
        dm = DriftMonitor()
        report = dm.health_report()
        assert isinstance(report.is_healthy, bool)
        assert isinstance(report.gate_open, bool)
        assert isinstance(report.alerts, list)

    def test_gate_closed_appears_in_alerts(self):
        dm = DriftMonitor(window_size=10, ic_disable_threshold=0.90,
                          ic_disable_lookback=1)
        rng    = random.Random(42)
        events = [{"signal_score": rng.gauss(0, 0.5), "signal_direction": "NEUTRAL",
                   "fwd_ret_1d": rng.gauss(0, 1.0)} for _ in range(10)]
        dm.ingest(events)
        report = dm.health_report()
        gate_alerts = [a for a in report.alerts if "GATE_CLOSED" in a]
        assert len(gate_alerts) == 1

    def test_set_regime(self):
        dm = DriftMonitor()
        dm.set_regime("RISK_OFF")
        report = dm.health_report(regime_mismatch=True)
        assert report.current_regime == "RISK_OFF"
        regime_alerts = [a for a in report.alerts if "REGIME_MISMATCH" in a]
        assert len(regime_alerts) == 1

    def test_ingest_one_convenience(self):
        dm = DriftMonitor(window_size=5)
        for _ in range(5):
            dm.ingest_one(0.5, "BULLISH", 0.02)
        assert len(dm.window_history) == 1


# ─────────────────────────────────────────────────────────────────────────────
# §20 — multi_horizon
# ─────────────────────────────────────────────────────────────────────────────

from multi_horizon import (
    MultiHorizonModel, HorizonScoreResult, HORIZONS,
    _EVENT_TYPE_AFFINITY, _spearman_list,
)


class TestSpearmanList:
    def test_perfect_correlation(self):
        xs = [1.0, 2.0, 3.0, 4.0, 5.0]
        assert abs(_spearman_list(xs, xs) - 1.0) < 1e-6

    def test_too_few_points(self):
        assert math.isnan(_spearman_list([1.0, 2.0], [1.0, 2.0]))


class TestMultiHorizonInit:
    def test_three_learners(self):
        mhm = MultiHorizonModel()
        assert set(mhm._learners.keys()) == {"T1", "T5", "T20"}

    def test_summary_structure(self):
        mhm = MultiHorizonModel()
        s = mhm.summary()
        for hk in HORIZONS:
            assert hk in s
            assert "n_updates" in s[hk]
            assert "ic_mean"   in s[hk]
            assert "confidence" in s[hk]


class TestMultiHorizonUpdate:
    def test_update_batch_all_horizons(self):
        mhm    = MultiHorizonModel()
        events = _make_events(30)
        result = mhm.update_batch(events)
        for hk in HORIZONS:
            assert hk in result
            assert result[hk] > 0

    def test_n_updates_increments(self):
        mhm    = MultiHorizonModel()
        events = _make_events(20)
        mhm.update_batch(events)
        for hk in HORIZONS:
            assert mhm._learners[hk].n_updates == 20

    def test_reset_clears_state(self):
        mhm = MultiHorizonModel()
        mhm.update_batch(_make_events(20))
        mhm.reset()
        for hk in HORIZONS:
            assert mhm._learners[hk].n_updates == 0


class TestMultiHorizonScore:
    def test_score_returns_result(self):
        mhm    = MultiHorizonModel()
        event  = _make_events(1)[0]
        result = mhm.score(event)
        assert isinstance(result, HorizonScoreResult)

    def test_blended_score_bounded(self):
        mhm    = MultiHorizonModel()
        mhm.update_batch(_make_events(30))
        for ev in _make_events(10):
            result = mhm.score(ev)
            assert -1.0 <= result.blended_score <= 1.0

    def test_all_horizon_keys_present(self):
        mhm    = MultiHorizonModel()
        result = mhm.score(_make_events(1)[0])
        assert set(result.by_horizon.keys())   == set(HORIZONS.keys())
        assert set(result.confidences.keys())  == set(HORIZONS.keys())
        assert set(result.weights_used.keys()) == set(HORIZONS.keys())

    def test_weights_sum_to_one(self):
        mhm    = MultiHorizonModel()
        result = mhm.score(_make_events(1)[0])
        assert abs(sum(result.weights_used.values()) - 1.0) < 1e-6

    def test_n_updates_in_result(self):
        mhm    = MultiHorizonModel()
        mhm.update_batch(_make_events(15))
        result = mhm.score(_make_events(1)[0])
        for hk in HORIZONS:
            assert result.n_updates[hk] == 15

    def test_equal_weights_before_training(self):
        """Before any updates, weights should be equal (equal confidence=0)."""
        mhm    = MultiHorizonModel()
        result = mhm.score(_make_events(1)[0])
        w      = list(result.weights_used.values())
        # Sum must be exactly 1.0 and all weights approximately equal
        assert abs(sum(w) - 1.0) < 1e-6
        expected = 1.0 / len(HORIZONS)
        assert all(abs(wi - expected) < 2e-4 for wi in w)


class TestMultiHorizonAffinity:
    def test_earnings_affinity_t1(self):
        assert _EVENT_TYPE_AFFINITY.get("earnings") == "T1"

    def test_macro_affinity_t20(self):
        assert _EVENT_TYPE_AFFINITY.get("macro") == "T20"

    def test_regulation_affinity_t20(self):
        assert _EVENT_TYPE_AFFINITY.get("regulation") == "T20"

    def test_affinity_boosts_dominant_horizon(self):
        """After training, the affinity horizon should get boosted weight."""
        mhm    = MultiHorizonModel()
        # Feed enough data to build non-zero confidence
        events = _make_events(60, ic=0.4)
        mhm.update_batch(events)
        # Force non-trivial IC trackers
        for hk in HORIZONS:
            mhm._ic_trackers[hk].push(0.15)

        earnings_event = {**_make_events(1)[0], "event_type": "earnings"}
        macro_event    = {**_make_events(1)[0], "event_type": "macro"}

        res_earn = mhm.score(earnings_event)
        res_macro = mhm.score(macro_event)

        # Earnings → T1 should have higher weight than in macro
        assert res_earn.weights_used["T1"] >= res_macro.weights_used["T1"] - 1e-4
        # Macro → T20 should have higher weight than in earnings
        assert res_macro.weights_used["T20"] >= res_earn.weights_used["T20"] - 1e-4

    def test_dominant_horizon_is_highest_weight(self):
        mhm    = MultiHorizonModel()
        result = mhm.score(_make_events(1)[0])
        dominant = result.dominant_horizon
        assert result.weights_used[dominant] == max(result.weights_used.values())

    def test_event_type_affinity_recorded_in_result(self):
        mhm    = MultiHorizonModel()
        event  = {**_make_events(1)[0], "event_type": "regulation"}
        result = mhm.score(event)
        assert result.event_type_affinity == "T20"

    def test_unknown_event_type_affinity(self):
        mhm    = MultiHorizonModel()
        event  = {**_make_events(1)[0], "event_type": "unknown"}
        result = mhm.score(event)
        # unknown → T5 (default)
        assert result.event_type_affinity == "T5"


class TestMultiHorizonICTracker:
    def test_confidence_zero_before_data(self):
        from multi_horizon import _ICTracker
        t = _ICTracker()
        assert t.confidence == 0.0

    def test_confidence_nonzero_after_push(self):
        from multi_horizon import _ICTracker
        t = _ICTracker()
        t.push(0.15)
        assert t.confidence > 0

    def test_high_std_reduces_confidence(self):
        from multi_horizon import _ICTracker
        t_stable   = _ICTracker()
        t_volatile = _ICTracker()
        for _ in range(10):
            t_stable.push(0.15)
        for v in [0.5, -0.4, 0.6, -0.5, 0.7]:
            t_volatile.push(v)
        assert t_stable.confidence >= t_volatile.confidence


# ─────────────────────────────────────────────────────────────────────────────
# Integration: Phase 2 pipeline end-to-end
# ─────────────────────────────────────────────────────────────────────────────

class TestPhase2Integration:
    """Simulate a realistic update-then-score pipeline across all four modules."""

    def test_full_cycle(self):
        rng    = random.Random(42)
        events = _make_events(80, ic=0.30, seed=42)

        # 1. Online learner trains on historical events
        learner = OnlineLearner(_ONLINE_FEATURES, forgetting=0.97)
        n = learner.update_batch(events, horizon=1)
        assert n == 80

        # 2. Multi-horizon model trains
        mhm = MultiHorizonModel()
        mhm.update_batch(events)

        # 3. Drift monitor evaluates IC health
        dm = DriftMonitor(window_size=40)
        dm.ingest(events)
        report = dm.health_report()
        # With IC=0.30 the gate should remain open
        assert dm.gate_open() is True

        # 4. Position manager handles live signals
        mgr     = PositionManager()
        new_evs = _make_events(5, ic=0.30, seed=99)

        for ev in new_evs:
            if dm.gate_open():
                result  = mhm.score(ev)
                ticker  = f"TICKER_{ev['event_id']}"
                direction = "BULLISH" if result.blended_score > 0 else "BEARISH"
                mgr.open(ticker, result.blended_score, direction, ev["event_id"])

        s = mgr.summary()
        assert s["open_positions"] == 5

        # 5. Tick advances positions to HOLD
        mgr.mark_executed()
        mgr.tick()
        for pos in mgr._positions.values():
            assert pos.state == PositionState.HOLD

        # 6. Learner weights evolved from uniform
        w = learner.weights
        assert abs(sum(w.values()) - 1.0) < 1e-5

    def test_gate_closed_skips_positions(self):
        """When the drift monitor closes the gate, no new positions should open."""
        dm = DriftMonitor(window_size=10, ic_disable_threshold=0.90,
                          ic_disable_lookback=1)
        rng   = random.Random(42)
        noise = [{"signal_score": rng.gauss(0, 0.5), "signal_direction": "NEUTRAL",
                  "fwd_ret_1d": rng.gauss(0, 1.0)} for _ in range(10)]
        dm.ingest(noise)
        assert dm.gate_open() is False

        mgr    = PositionManager()
        events = _make_events(3, ic=0.50, seed=55)

        opened = 0
        for ev in events:
            if dm.gate_open():
                mgr.open("TICKER", 0.6, "BULLISH", ev["event_id"])
                opened += 1

        assert opened == 0
        assert mgr.summary()["open_positions"] == 0
