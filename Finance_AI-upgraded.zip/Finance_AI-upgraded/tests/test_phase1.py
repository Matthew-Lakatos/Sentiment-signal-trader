"""
test_phase1.py — Phase 1 integration tests.

Covers all four sections implemented in Phase 1:
    §9  market_state.py          — VIX/yield/regime classification + signal conditioning
    §2  expectation_model.py     — guidance revision scoring + surprise z-score
    §11 factor_model.py          — sector classification + batch neutralisation
    §10 cross_section.py         — global + sector-relative percentile ranking

All tests are pure-Python (no DB, no network, no yfinance).
"""
from __future__ import annotations

import math
import random
from datetime import datetime, timezone, timedelta

import pytest

# ─────────────────────────────────────────────────────────────────────────────
# §9 — market_state
# ─────────────────────────────────────────────────────────────────────────────

from market_state import (
    _classify_vix, _classify_yield_curve, _classify_risk,
    _is_earnings_season, _fallback, MarketState,
)


class TestVixClassification:
    def test_low(self):
        assert _classify_vix(10.0) == "LOW"

    def test_elevated(self):
        assert _classify_vix(18.0) == "ELEVATED"

    def test_high(self):
        assert _classify_vix(28.0) == "HIGH"

    def test_spike(self):
        assert _classify_vix(40.0) == "SPIKE"

    def test_boundary_elevated(self):
        assert _classify_vix(15.0) == "ELEVATED"   # exactly at LOW boundary


class TestYieldCurveClassification:
    def test_normal(self):
        assert _classify_yield_curve(0.012) == "NORMAL"

    def test_flat(self):
        assert _classify_yield_curve(0.003) == "FLAT"

    def test_inverted(self):
        assert _classify_yield_curve(-0.008) == "INVERTED"

    def test_exactly_flat(self):
        assert _classify_yield_curve(0.0) == "FLAT"


class TestRiskRegime:
    def test_risk_on(self):
        assert _classify_risk(vix=14.0, slope=0.010, spy_ret=0.03) == "RISK_ON"

    def test_risk_off_high_vix(self):
        assert _classify_risk(vix=35.0, slope=0.005, spy_ret=0.01) == "RISK_OFF"

    def test_risk_off_inverted(self):
        assert _classify_risk(vix=20.0, slope=-0.012, spy_ret=0.01) == "RISK_OFF"

    def test_risk_off_negative_spy(self):
        assert _classify_risk(vix=20.0, slope=0.005, spy_ret=-0.08) == "RISK_OFF"

    def test_neutral(self):
        assert _classify_risk(vix=22.0, slope=0.003, spy_ret=0.005) == "NEUTRAL"


class TestEarningsSeason:
    def test_q1_season(self):
        from datetime import date
        assert _is_earnings_season(date(2025, 4, 20)) is True

    def test_q4_season(self):
        from datetime import date
        assert _is_earnings_season(date(2025, 1, 25)) is True

    def test_off_season(self):
        from datetime import date
        assert _is_earnings_season(date(2025, 3, 15)) is False

    def test_q3_season(self):
        from datetime import date
        assert _is_earnings_season(date(2025, 7, 20)) is True


class TestFallbackState:
    def test_fallback_is_stale(self):
        s = _fallback()
        assert s.is_stale is True

    def test_fallback_neutral_regime(self):
        s = _fallback()
        assert s.risk_regime == "NEUTRAL"

    def test_fallback_sensible_vix(self):
        s = _fallback()
        assert 10.0 <= s.vix <= 30.0


class TestMarketStateSignalConditioning:
    """Test that compute_signal correctly applies regime multipliers."""

    def _signal(self, market_state=None):
        from signal_ranker import compute_signal
        return compute_signal(
            sentiment_label   = "POSITIVE",
            sentiment_score   = 0.80,
            materiality_score = 0.70,
            novelty_score     = 0.90,
            credibility_score = 0.80,
            materiality_tier  = "HIGH",
            event_type        = "earnings",
            market_state      = market_state,
        )

    def test_no_market_state_positive(self):
        sig = self._signal(None)
        assert sig.score > 0

    def test_risk_off_suppresses_signal(self):
        from market_state import MarketState
        ms_off = MarketState(
            vix=32.0, vix_regime="HIGH",
            risk_regime="RISK_OFF",
            yield_curve_state="INVERTED",
            yield_slope=-0.008,
            earnings_season=False,
            is_stale=False,
        )
        sig_base  = self._signal(None)
        sig_risky = self._signal(ms_off)
        # RISK_OFF (0.6) × INVERTED (0.85) = 0.51 multiplier → must be smaller
        assert sig_risky.score < sig_base.score

    def test_vix_spike_suppresses_signal(self):
        from market_state import MarketState
        ms_spike = MarketState(vix=45.0, vix_regime="SPIKE", is_stale=False)
        sig_base  = self._signal(None)
        sig_spike = self._signal(ms_spike)
        assert sig_spike.score < sig_base.score

    def test_risk_on_boosts_signal(self):
        from market_state import MarketState
        ms_on = MarketState(
            vix=12.0, vix_regime="LOW",
            risk_regime="RISK_ON",
            yield_curve_state="NORMAL",
            yield_slope=0.015,
            is_stale=False,
        )
        sig_base = self._signal(None)
        sig_on   = self._signal(ms_on)
        assert sig_on.score > sig_base.score

    def test_earnings_season_boost_for_earnings_event(self):
        from market_state import MarketState
        ms_earn = MarketState(
            vix=18.0, vix_regime="ELEVATED",
            risk_regime="NEUTRAL",
            earnings_season=True,
            is_stale=False,
        )
        sig_neutral = self._signal(None)
        sig_earn    = self._signal(ms_earn)
        # NEUTRAL regime but earnings_season boost → score should be higher
        assert sig_earn.score > sig_neutral.score

    def test_components_include_regime_keys(self):
        from market_state import MarketState
        ms = MarketState(is_stale=False)
        sig = self._signal(ms)
        assert "market_regime" in sig.components
        assert "market_regime_mult" in sig.components


# ─────────────────────────────────────────────────────────────────────────────
# §2 — expectation_model
# ─────────────────────────────────────────────────────────────────────────────

from expectation_model import detect_guidance_revision, GuidanceRevision


class TestGuidanceRevision:
    def test_positive_raise_guidance(self):
        text = "Apple raised guidance for the full year, exceeding analyst estimates."
        r = detect_guidance_revision(text)
        assert r.score > 0
        assert r.pos_hits >= 1

    def test_negative_lowered_guidance(self):
        text = "Microsoft lowered its full-year outlook citing weaker cloud demand."
        r = detect_guidance_revision(text)
        assert r.score < 0
        assert r.neg_hits >= 1

    def test_neutral_reaffirmed(self):
        text = "The company reaffirmed guidance and said results were in-line with expectations."
        r = detect_guidance_revision(text)
        # Neutral/reaffirmed guidance should dampen the score toward zero
        assert -0.3 <= r.score <= 0.3

    def test_no_guidance_language(self):
        text = "Sunny weather expected across the region this weekend."
        r = detect_guidance_revision(text)
        assert r.score == 0.0
        assert r.pos_hits == 0
        assert r.neg_hits == 0

    def test_profit_warning(self):
        text = "The retailer issued a profit warning ahead of earnings season."
        r = detect_guidance_revision(text)
        assert r.score < 0

    def test_score_clamped(self):
        # Pile on many positive phrases — score must stay within [-1, 1]
        text = (
            "raised guidance exceeded analyst estimates beat estimates "
            "above consensus upside surprise record revenue ahead of estimates "
            "strong-than-expected results positive guidance"
        )
        r = detect_guidance_revision(text)
        assert -1.0 <= r.score <= 1.0

    def test_mixed_cancels_out(self):
        text = "Raised guidance but also warned of weaker-than-expected margins."
        r = detect_guidance_revision(text)
        # Should be less extreme than pure positive
        r_pure = detect_guidance_revision("Raised guidance, beat analyst estimates, record revenue.")
        assert abs(r.score) < r_pure.score

    def test_phrases_found_populated(self):
        text = "Beat estimates and raised guidance for the full year."
        r = detect_guidance_revision(text)
        assert len(r.phrases_found) > 0


class TestComputeSurprise:
    """Tests for compute_surprise that use pool=None (is_estimate=True path)."""

    @pytest.mark.asyncio
    async def test_returns_none_without_targets(self):
        from expectation_model import compute_surprise
        result = await compute_surprise(
            pool=None, targets=[],
            current_sentiment_label="POSITIVE", current_sentiment_score=0.8,
            text="Apple beat estimates.",
        )
        assert result is None

    @pytest.mark.asyncio
    async def test_returns_result_with_targets_no_pool(self):
        from expectation_model import compute_surprise
        result = await compute_surprise(
            pool=None, targets=["Apple"],
            current_sentiment_label="POSITIVE", current_sentiment_score=0.8,
            text="Apple raised guidance and beat analyst estimates.",
        )
        assert result is not None
        assert result.is_estimate is True       # no DB → no prior history
        assert result.n_prior_events == 0
        assert -1.0 <= result.surprise_score <= 1.0

    @pytest.mark.asyncio
    async def test_guidance_dominates_when_no_prior(self):
        """With no prior history, surprise_score is driven purely by guidance."""
        from expectation_model import compute_surprise
        pos = await compute_surprise(
            pool=None, targets=["Tesla"],
            current_sentiment_label="POSITIVE", current_sentiment_score=0.9,
            text="Tesla raised full-year guidance, exceeded estimates.",
        )
        neg = await compute_surprise(
            pool=None, targets=["Tesla"],
            current_sentiment_label="NEGATIVE", current_sentiment_score=0.9,
            text="Tesla issued a profit warning and cut guidance.",
        )
        assert pos.surprise_score > 0
        assert neg.surprise_score < 0
        assert pos.surprise_score > neg.surprise_score

    @pytest.mark.asyncio
    async def test_neutral_label_dampens_score(self):
        from expectation_model import compute_surprise
        result = await compute_surprise(
            pool=None, targets=["Ford"],
            current_sentiment_label="NEUTRAL", current_sentiment_score=0.1,
            text="Ford reaffirmed guidance, results in-line with expectations.",
        )
        assert result is not None
        assert abs(result.surprise_score) < 0.3

    @pytest.mark.asyncio
    async def test_score_bounded(self):
        from expectation_model import compute_surprise
        # Maximally positive text
        result = await compute_surprise(
            pool=None, targets=["NVIDIA"],
            current_sentiment_label="POSITIVE", current_sentiment_score=1.0,
            text=(
                "NVIDIA raised guidance, beat estimates, exceeded expectations, "
                "record revenue, above consensus, upside surprise, strong-than-expected."
            ),
        )
        assert result is not None
        assert -1.0 <= result.surprise_score <= 1.0


# ─────────────────────────────────────────────────────────────────────────────
# §11 — factor_model
# ─────────────────────────────────────────────────────────────────────────────

from factor_model import classify_entity_sector, neutralise_batch, ENTITY_SECTOR


class TestSectorClassification:
    def test_exact_match(self):
        assert classify_entity_sector(["nvidia"], []) == "technology"

    def test_partial_match(self):
        assert classify_entity_sector(["nvidia corporation"], []) == "technology"

    def test_financials(self):
        assert classify_entity_sector(["jpmorgan"], []) == "financials"

    def test_topic_fallback(self):
        assert classify_entity_sector([], ["finance"]) == "financials"

    def test_unknown_entity(self):
        assert classify_entity_sector(["xyzcorp123"], []) == "unknown"

    def test_unknown_with_known_topic(self):
        assert classify_entity_sector(["xyzcorp123"], ["energy"]) == "energy"

    def test_case_insensitive(self):
        assert classify_entity_sector(["APPLE"], []) == "technology"

    def test_entity_takes_priority_over_topic(self):
        # Apple is technology even if topic says finance
        assert classify_entity_sector(["apple"], ["finance"]) == "technology"

    def test_multiple_entities_first_wins(self):
        sector = classify_entity_sector(["nvidia", "jpmorgan"], [])
        assert sector == "technology"


class TestNeutraliseBatch:
    def _make_events(self, scores: list[float], sector: str) -> list[dict]:
        return [
            {
                "signal_score":  s,
                "targets":       [],
                "topics":        [],
                "primary_sector": sector,
            }
            for s in scores
        ]

    def test_empty_batch(self):
        assert neutralise_batch([]) == []

    def test_sector_median_removed(self):
        # All events in same sector with identical score → sector residual = 0
        events = self._make_events([0.5, 0.5, 0.5], "technology")
        for ev in events:
            ev["targets"] = ["nvidia"]
        neutralise_batch(events)
        # Residual after removing sector median of 0.5 should be ≈ 0
        for ev in events:
            # Market mean also 0.5 → factor_neutral ≈ 0 - β × 0.5
            # With β=0.30: expected ≈ -0.15 (market discount on uniform signal)
            assert ev["factor_neutral_score"] is not None

    def test_outlier_positive_after_neutralisation(self):
        """An event with signal +0.9 in a sector where median is 0.1 should
        have a positive factor_neutral_score."""
        events = [
            {"signal_score": 0.1, "targets": [], "topics": [], "primary_sector": "technology"},
            {"signal_score": 0.1, "targets": [], "topics": [], "primary_sector": "technology"},
            {"signal_score": 0.9, "targets": [], "topics": [], "primary_sector": "technology"},
        ]
        neutralise_batch(events)
        outlier = events[2]
        others  = events[:2]
        assert outlier["factor_neutral_score"] > others[0]["factor_neutral_score"]

    def test_clamped_to_minus_one_one(self):
        events = [
            {"signal_score": 1.0, "targets": [], "topics": [], "primary_sector": "technology"},
            {"signal_score": -1.0, "targets": [], "topics": [], "primary_sector": "technology"},
        ]
        neutralise_batch(events)
        for ev in events:
            assert -1.0 <= ev["factor_neutral_score"] <= 1.0

    def test_cross_sector_isolation(self):
        """Events in different sectors are neutralised within their own sector."""
        events = [
            {"signal_score": 0.8, "targets": [], "topics": [], "primary_sector": "technology"},
            {"signal_score": 0.8, "targets": [], "topics": [], "primary_sector": "financials"},
        ]
        neutralise_batch(events)
        # Both events are the sole representative of their sector →
        # sector_median = their own score → sector_residual ≈ 0
        # factor_neutral should reflect only the market-beta adjustment
        for ev in events:
            assert ev["factor_neutral_score"] is not None
            # |factor_neutral| should be small (close to zero)
            assert abs(ev["factor_neutral_score"]) < 0.5

    def test_market_mean_key_added(self):
        events = [
            {"signal_score": 0.3, "targets": [], "topics": [], "primary_sector": "energy"},
        ]
        neutralise_batch(events)
        assert "_market_mean" in events[0]

    def test_returns_same_list(self):
        events = [{"signal_score": 0.5, "targets": [], "topics": [], "primary_sector": "energy"}]
        result = neutralise_batch(events)
        assert result is events


# ─────────────────────────────────────────────────────────────────────────────
# §10 — cross_section
# ─────────────────────────────────────────────────────────────────────────────

from cross_section import rank_batch, _percentile_rank, CS_MIN_BATCH


class TestPercentileRank:
    def test_single_element(self):
        assert _percentile_rank([5.0]) == [0.5]

    def test_two_elements_ascending(self):
        ranks = _percentile_rank([1.0, 2.0])
        assert ranks[0] < ranks[1]

    def test_two_elements_highest_is_one(self):
        ranks = _percentile_rank([1.0, 2.0])
        assert ranks[1] == 1.0

    def test_two_elements_lowest_is_zero(self):
        ranks = _percentile_rank([1.0, 2.0])
        assert ranks[0] == 0.0

    def test_ties_averaged(self):
        ranks = _percentile_rank([5.0, 5.0])
        assert ranks[0] == ranks[1] == 0.5

    def test_all_same_value(self):
        ranks = _percentile_rank([3.0, 3.0, 3.0])
        assert all(r == 0.5 for r in ranks)

    def test_monotone_ascending(self):
        vals  = [0.1, 0.3, 0.5, 0.8, 1.0]
        ranks = _percentile_rank(vals)
        for i in range(len(ranks) - 1):
            assert ranks[i] < ranks[i + 1]

    def test_empty(self):
        assert _percentile_rank([]) == []


class TestRankBatch:
    def _events(self, scores: list[float], sector: str = "technology") -> list[dict]:
        return [
            {"factor_neutral_score": s, "primary_sector": sector}
            for s in scores
        ]

    def test_empty_batch(self):
        assert rank_batch([]) == []

    def test_single_event_neutral(self):
        events = self._events([0.5])
        rank_batch(events)
        assert events[0]["cs_percentile"]        == 0.5
        assert events[0]["cs_sector_percentile"] == 0.5
        assert events[0]["cs_score"]             == 0.0

    def test_top_event_cs_score_one(self):
        events = self._events([0.1, 0.5, 0.9])
        rank_batch(events)
        cs_scores = [ev["cs_score"] for ev in events]
        assert max(cs_scores) == 1.0

    def test_bottom_event_cs_score_minus_one(self):
        events = self._events([0.1, 0.5, 0.9])
        rank_batch(events)
        cs_scores = [ev["cs_score"] for ev in events]
        assert min(cs_scores) == -1.0

    def test_cs_score_range(self):
        rng    = random.Random(0)
        events = self._events([rng.uniform(-1, 1) for _ in range(20)])
        rank_batch(events)
        for ev in events:
            assert -1.0 <= ev["cs_score"]             <= 1.0
            assert  0.0 <= ev["cs_percentile"]        <= 1.0
            assert  0.0 <= ev["cs_sector_percentile"] <= 1.0

    def test_sector_percentile_independent_of_global(self):
        """Sector rank is computed within sector, not globally."""
        events = [
            {"factor_neutral_score": 0.9, "primary_sector": "technology"},
            {"factor_neutral_score": 0.8, "primary_sector": "technology"},
            {"factor_neutral_score": 0.1, "primary_sector": "financials"},
            {"factor_neutral_score": 0.05, "primary_sector": "financials"},
        ]
        rank_batch(events)
        # Top tech event should have cs_sector_percentile = 1.0 within tech
        tech_events = [ev for ev in events if ev["primary_sector"] == "technology"]
        assert max(ev["cs_sector_percentile"] for ev in tech_events) == 1.0
        # Bottom financials should have cs_sector_percentile = 0.0 within fins
        fin_events = [ev for ev in events if ev["primary_sector"] == "financials"]
        assert min(ev["cs_sector_percentile"] for ev in fin_events) == 0.0

    def test_single_sector_event_gets_neutral_sector_rank(self):
        """Only event in its sector → cs_sector_percentile = 0.5 (honest unknown)."""
        events = [
            {"factor_neutral_score": 0.8, "primary_sector": "utilities"},
            {"factor_neutral_score": 0.5, "primary_sector": "technology"},
            {"factor_neutral_score": 0.3, "primary_sector": "technology"},
        ]
        rank_batch(events)
        utilities_ev = next(ev for ev in events if ev["primary_sector"] == "utilities")
        assert utilities_ev["cs_sector_percentile"] == 0.5

    def test_returns_same_list(self):
        events = self._events([0.5, 0.3])
        result = rank_batch(events)
        assert result is events


# ─────────────────────────────────────────────────────────────────────────────
# Integration: signal_ranker with surprise_score
# ─────────────────────────────────────────────────────────────────────────────

class TestSignalRankerSurpriseIntegration:
    def _sig(self, surprise: float | None):
        from signal_ranker import compute_signal
        return compute_signal(
            sentiment_label   = "POSITIVE",
            sentiment_score   = 0.75,
            materiality_score = 0.60,
            novelty_score     = 0.70,
            credibility_score = 0.70,
            event_type        = "earnings",
            surprise_score    = surprise,
        )

    def test_positive_surprise_boosts_signal(self):
        sig_no_surprise  = self._sig(None)
        sig_pos_surprise = self._sig(0.8)
        assert sig_pos_surprise.score > sig_no_surprise.score

    def test_negative_surprise_reduces_signal(self):
        sig_no_surprise  = self._sig(None)
        sig_neg_surprise = self._sig(-0.8)
        assert sig_neg_surprise.score < sig_no_surprise.score

    def test_surprise_component_in_components(self):
        sig = self._sig(0.5)
        assert "surprise_contrib" in sig.components

    def test_no_surprise_contrib_is_zero(self):
        sig = self._sig(None)
        assert sig.components["surprise_contrib"] == 0.0

    def test_score_still_clamped_with_max_surprise(self):
        sig = self._sig(1.0)
        assert -1.0 <= sig.score <= 1.0

    def test_backward_compat_existing_call_signature(self):
        """Original 8-argument call with no Phase 1 kwargs must still work."""
        from signal_ranker import compute_signal
        sig = compute_signal(
            sentiment_label   = "POSITIVE",
            sentiment_score   = 0.85,
            materiality_score = 0.70,
            novelty_score     = 0.90,
            credibility_score = 0.80,
            materiality_tier  = "CRITICAL",
            event_type        = "earnings",
        )
        assert sig.score > 0
        assert sig.direction == "BULLISH"
        assert sig.rank_tier in ("STRONG", "MODERATE")


# ─────────────────────────────────────────────────────────────────────────────
# Integration: full Phase 1 batch pipeline (factor + CS + signal)
# ─────────────────────────────────────────────────────────────────────────────

class TestPhase1BatchPipeline:
    """End-to-end batch: neutralise → rank → verify signal enrichment."""

    def _make_batch(self, n: int = 10, seed: int = 7) -> list[dict]:
        rng = random.Random(seed)
        sectors = ["technology", "financials", "healthcare", "energy"]
        events  = []
        for i in range(n):
            score  = rng.uniform(-0.8, 0.8)
            sector = rng.choice(sectors)
            events.append({
                "signal_score":  score,
                "targets":       [],
                "topics":        [],
                "primary_sector": sector,
            })
        return events

    def test_all_fields_populated_after_pipeline(self):
        events = self._make_batch(10)
        neutralise_batch(events)
        rank_batch(events)
        for ev in events:
            assert "factor_neutral_score"  in ev
            assert "cs_score"              in ev
            assert "cs_percentile"         in ev
            assert "cs_sector_percentile"  in ev
            assert ev["factor_neutral_score"] is not None

    def test_cs_score_monotone_with_factor_neutral(self):
        """Globally, higher factor_neutral_score → higher cs_score."""
        events = self._make_batch(20)
        neutralise_batch(events)
        rank_batch(events)
        pairs = [(ev["factor_neutral_score"], ev["cs_score"]) for ev in events]
        pairs.sort(key=lambda x: x[0])
        cs_scores = [p[1] for p in pairs]
        # Not strictly monotone due to ties, but sorted fn_scores should
        # produce non-decreasing cs_scores
        for i in range(len(cs_scores) - 1):
            assert cs_scores[i] <= cs_scores[i + 1] + 1e-9

    def test_large_batch_all_bounded(self):
        events = self._make_batch(100, seed=42)
        neutralise_batch(events)
        rank_batch(events)
        for ev in events:
            assert -1.0 <= ev["factor_neutral_score"] <= 1.0
            assert -1.0 <= ev["cs_score"]             <= 1.0
            assert  0.0 <= ev["cs_percentile"]        <= 1.0
