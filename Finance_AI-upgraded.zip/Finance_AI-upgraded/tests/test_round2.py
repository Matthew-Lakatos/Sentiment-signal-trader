"""
test_round2.py — tests for the 6 new modules added in round 2.

Covers:
    calibration.py   — weight learning via ridge / rank_ic / grid
    benchmark.py     — baseline comparison
    execution.py     — delay enforcement, slippage, leakage detection
    signal_filter.py — threshold / tier / novelty / staleness gates
    portfolio.py     — position sizing, overlap resolution, conflict cancellation
    robustness.py    — walk-forward IC stability, bootstrap CI

All tests are pure-Python (no DB, no network).
"""
from __future__ import annotations

import math
import random
from datetime import datetime, timezone, timedelta

import pandas as pd
import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _now():
    return datetime.now(timezone.utc)


def _make_events(n: int, seed: int = 42) -> list[dict]:
    """Synthetic scored events with known signal-return relationship."""
    rng = random.Random(seed)
    events = []
    base   = _now() - timedelta(days=30)
    for i in range(n):
        # Inject a weak real signal: positive score → positive return
        score = rng.uniform(-0.8, 0.8)
        noise = rng.gauss(0, 0.5)
        ret   = score * 0.3 + noise          # IC ≈ 0.3 * corr(score, score+noise)

        label = "POSITIVE" if score > 0.1 else ("NEGATIVE" if score < -0.1 else "NEUTRAL")
        mat   = abs(score) * 0.8 + rng.uniform(0, 0.2)
        nov   = rng.uniform(0.2, 0.9)
        cred  = rng.uniform(0.4, 0.9)

        events.append({
            "event_id":         f"evt-{i:04d}",
            "scraped_at":       (base + timedelta(hours=i * 4)).isoformat(),
            "sentiment_label":  label,
            "sentiment_score":  abs(score),
            "materiality_score": mat,
            "materiality_tier": "HIGH" if mat > 0.5 else "MEDIUM",
            "novelty_score":    nov,
            "credibility_score": cred,
            "signal_score":     score,
            "signal_direction": label.replace("NEUTRAL", "NEUTRAL"),
            "signal_tier":      "STRONG" if abs(score) > 0.5 else "MODERATE",
            "event_type":       rng.choice(["earnings", "macro", "contract", "analysis"]),
            "event_confidence": rng.uniform(0.5, 0.95),
            "fwd_ret_1d":       ret,
            "fwd_ret_3d":       ret * 1.5 + rng.gauss(0, 0.3),
            "fwd_ret_5d":       ret * 2.0 + rng.gauss(0, 0.5),
        })
    return events


def _make_price_df(n_days: int = 60, seed: int = 99) -> pd.DataFrame:
    """Synthetic OHLCV price data."""
    rng     = random.Random(seed)
    dates   = pd.date_range(end=datetime.now().date(), periods=n_days, freq="B")
    prices  = [100.0]
    for _ in range(n_days - 1):
        prices.append(prices[-1] * (1 + rng.gauss(0, 0.01)))
    df = pd.DataFrame({
        "Open":   [p * 0.998 for p in prices],
        "High":   [p * 1.010 for p in prices],
        "Low":    [p * 0.990 for p in prices],
        "Close":  prices,
        "Volume": [int(1e6 * rng.uniform(0.5, 2.0)) for _ in prices],
    }, index=dates)
    df.index = pd.to_datetime(df.index).normalize()
    return df


# ===========================================================================
# calibration.py
# ===========================================================================

class TestCalibration:

    def test_ridge_returns_result(self):
        from calibration import calibrate
        events = _make_events(80)
        result = calibrate(events, horizon=1, method="ridge")
        assert set(result.weights) == {"sentiment", "materiality", "novelty", "credibility"}
        assert all(math.isfinite(v) for v in result.weights.values())

    def test_weights_sum_to_one(self):
        from calibration import calibrate
        events = _make_events(80)
        result = calibrate(events, horizon=1, method="ridge")
        total  = sum(abs(v) for v in result.weights.values())
        assert abs(total - 1.0) < 0.02

    def test_rank_ic_method(self):
        from calibration import calibrate
        events = _make_events(80)
        result = calibrate(events, horizon=1, method="rank_ic")
        assert result.method == "rank_ic"
        assert math.isfinite(result.ic)

    def test_grid_method(self):
        from calibration import calibrate
        events = _make_events(120)
        result = calibrate(events, horizon=1, method="grid")
        assert result.ic_oos is not None

    def test_calibrate_detects_weak_ic(self):
        """With random events (no signal), IC should be near 0."""
        from calibration import calibrate
        rng = random.Random(7)
        events = []
        for i in range(80):
            events.append({
                "sentiment_label": "NEUTRAL", "sentiment_score": rng.random(),
                "materiality_score": rng.random(), "novelty_score": rng.random(),
                "credibility_score": rng.random(), "signal_score": rng.uniform(-1, 1),
                "fwd_ret_1d": rng.gauss(0, 1),
                "scraped_at": (_now() - timedelta(hours=i)).isoformat(),
            })
        result = calibrate(events, horizon=1, method="ridge")
        assert abs(result.ic) < 0.25   # noise, not a strong IC

    def test_save_and_load(self, tmp_path):
        from calibration import calibrate, load_weights
        events = _make_events(60)
        result = calibrate(events, horizon=1, method="ridge")
        path   = str(tmp_path / "weights.json")
        result.save(path)
        loaded = load_weights(path)
        assert set(loaded) == {"sentiment", "materiality", "novelty", "credibility"}

    def test_apply_calibrated_weights(self):
        from calibration import apply_calibrated_weights
        weights = {"sentiment": 0.3, "materiality": 0.4, "novelty": 0.2, "credibility": 0.1}
        score   = apply_calibrated_weights(
            weights, "POSITIVE", 0.8, 0.7, 0.6, 0.9
        )
        assert -1.0 <= score <= 1.0
        assert score > 0   # positive sentiment → positive score

    def test_negative_sentiment_negative_score(self):
        from calibration import apply_calibrated_weights
        weights = {"sentiment": 0.4, "materiality": 0.3, "novelty": 0.2, "credibility": 0.1}
        score   = apply_calibrated_weights(
            weights, "NEGATIVE", 0.9, 0.6, 0.5, 0.7
        )
        assert score < 0


# ===========================================================================
# benchmark.py
# ===========================================================================

class TestBenchmark:

    def test_run_benchmark_returns_report(self):
        from benchmark import run_benchmark
        events = _make_events(80)
        report = run_benchmark(events, horizon=1)
        assert report.composite is not None
        assert report.sentiment_only is not None
        assert report.random_ is not None

    def test_composite_beats_random_on_real_signal(self):
        """With an injected signal, composite should have higher IC than random baseline."""
        from benchmark import run_benchmark
        events = _make_events(200, seed=1)
        report = run_benchmark(events, horizon=1)
        # Allow a small tolerance — may not always hold with small samples
        assert report.composite.ic > report.random_.ic - 0.10

    def test_random_baseline_ic_near_zero(self):
        from benchmark import run_benchmark
        events = _make_events(200)
        report = run_benchmark(events, horizon=1)
        assert abs(report.random_.ic) < 0.20   # should not be strongly correlated

    def test_no_price_joins_raises(self):
        from benchmark import run_benchmark
        events = [{"signal_score": 0.5, "sentiment_label": "POSITIVE",
                   "sentiment_score": 0.8}]  # no fwd_ret_1d
        with pytest.raises(ValueError):
            run_benchmark(events, horizon=1)

    def test_summary_is_string(self):
        from benchmark import run_benchmark
        events = _make_events(60)
        report = run_benchmark(events, horizon=1)
        summary = report.summary()
        assert isinstance(summary, str)
        assert "IC" in summary

    def test_beats_method(self):
        from benchmark import BaselineResult
        a = BaselineResult("a", ic=0.05, hit_rate=0.55, sharpe=1.0, mean_ret=0.1, n=100)
        b = BaselineResult("b", ic=0.02, hit_rate=0.52, sharpe=0.5, mean_ret=0.05, n=100)
        assert a.beats(b)
        assert not b.beats(a)

    def test_red_flag_sharpe(self):
        from benchmark import run_benchmark
        # Inject artificially high returns to trigger red flag check
        events = _make_events(80)
        for ev in events:
            ev["fwd_ret_1d"] = abs(ev["signal_score"]) * 5.0  # unrealistic
        report = run_benchmark(events, horizon=1)
        assert report.composite.sharpe != 0   # at least computed


# ===========================================================================
# execution.py
# ===========================================================================

class TestExecution:

    def test_simulate_fill_returns_trade(self):
        from execution import ExecutionEngine
        price_df = _make_price_df(60)
        engine   = ExecutionEngine(delay_minutes=15, slippage_bps=10)
        ts       = _now() - timedelta(days=5)
        trade    = engine.simulate_fill(ts, price_df, direction="LONG", horizon=1)
        assert trade is not None
        assert trade.fill_price > 0

    def test_slippage_increases_buy_price(self):
        from execution import apply_slippage
        price  = 100.0
        filled = apply_slippage(price, "LONG", slippage_bps=20)
        assert filled > price

    def test_slippage_decreases_sell_price(self):
        from execution import apply_slippage
        price  = 100.0
        filled = apply_slippage(price, "SHORT", slippage_bps=20)
        assert filled < price

    def test_leakage_detected_same_time(self):
        from execution import check_leakage
        ts = _now()
        assert check_leakage(ts, ts, delay_minutes=15) is True

    def test_leakage_not_detected_with_proper_delay(self):
        from execution import check_leakage
        event_ts = _now() - timedelta(minutes=30)
        fill_ts  = _now()
        assert check_leakage(event_ts, fill_ts, delay_minutes=15) is False

    def test_next_market_open_skips_weekend(self):
        from execution import next_market_open
        # A Saturday
        sat = datetime(2025, 5, 3, 20, 0)
        nxt = next_market_open(sat)
        assert nxt.weekday() < 5   # must be a weekday

    def test_audit_events(self):
        from execution import ExecutionEngine
        price_df = _make_price_df(60)
        engine   = ExecutionEngine(delay_minutes=15)
        # Scrape events after NYSE close (21:00 UTC ≈ 17:00 ET) so
        # next_market_open always returns NEXT calendar day → no same-bar leakage
        events = []
        for i in range(1, 6):
            ts = (_now() - timedelta(days=i)).replace(hour=21, minute=0,
                                                       second=0, microsecond=0)
            events.append({
                "scraped_at":      ts.isoformat(),
                "sentiment_label": "POSITIVE",
            })
        report = engine.audit_events(events, price_df)
        assert "leakage_count" in report
        assert "n_trades" in report
        # After-close events should fill at next-day open → no leakage
        assert report["leakage_count"] == 0

    def test_fill_price_uses_open_by_default(self):
        from execution import ExecutionEngine
        price_df = _make_price_df(60)
        engine   = ExecutionEngine(use_open=True)
        ts       = _now() - timedelta(days=10)
        trade    = engine.simulate_fill(ts, price_df, "LONG", horizon=1)
        if trade:
            # Fill at Open + slippage → should be close to open price
            assert trade.fill_price > 0


# ===========================================================================
# signal_filter.py
# ===========================================================================

class TestSignalFilter:

    def _events(self, n=20):
        return _make_events(n)

    def test_default_filter_returns_subset(self):
        from signal_filter import SignalFilter, FilterConfig
        events = self._events(40)
        cfg    = FilterConfig(min_score=0.20)
        filt   = SignalFilter(cfg)
        passed = filt.apply(events)
        assert len(passed) <= len(events)
        assert all(abs(ev["signal_score"]) >= 0.20 for ev in passed)

    def test_threshold_zero_passes_all(self):
        from signal_filter import SignalFilter, FilterConfig
        events = self._events(20)
        cfg    = FilterConfig(
            min_score=0.0, allowed_tiers=[],
            min_novelty=0.0, min_materiality=0.0,
            min_credibility=0.0, max_age_hours=0,
            blocked_types=[],
        )
        filt   = SignalFilter(cfg)
        passed = filt.apply(events)
        assert len(passed) == len(events)

    def test_top_pct(self):
        from signal_filter import SignalFilter, FilterConfig
        events = self._events(40)
        cfg    = FilterConfig(min_score=0.0, allowed_tiers=[], top_pct=0.25,
                              min_novelty=0.0, min_materiality=0.0,
                              min_credibility=0.0, max_age_hours=0, blocked_types=[])
        filt   = SignalFilter(cfg)
        passed = filt.apply(events)
        expected = max(1, math.ceil(40 * 0.25))
        assert len(passed) == expected

    def test_staleness_gate_rejects_old(self):
        from signal_filter import SignalFilter, FilterConfig
        events = _make_events(10)
        # Make all events 100 hours old
        for ev in events:
            ev["scraped_at"] = (_now() - timedelta(hours=100)).isoformat()
        cfg    = FilterConfig(min_score=0.0, allowed_tiers=[], max_age_hours=48,
                              min_novelty=0.0, min_materiality=0.0, min_credibility=0.0,
                              blocked_types=[])
        filt   = SignalFilter(cfg)
        passed = filt.apply(events)
        assert len(passed) == 0

    def test_blocked_type_rejected(self):
        from signal_filter import SignalFilter, FilterConfig
        events = _make_events(20)
        for ev in events:
            ev["event_type"] = "rumor"
        cfg    = FilterConfig(min_score=0.0, allowed_tiers=[], blocked_types=["rumor"],
                              min_novelty=0.0, min_materiality=0.0, min_credibility=0.0,
                              max_age_hours=0)
        filt   = SignalFilter(cfg)
        passed = filt.apply(events)
        assert len(passed) == 0

    def test_report_contains_metrics(self):
        from signal_filter import SignalFilter, FilterConfig
        events = self._events(30)
        filt   = SignalFilter(FilterConfig(min_score=0.20))
        passed = filt.apply(events)
        rpt    = filt.report(events, passed)
        assert "pass_rate" in rpt
        assert "rejection_reasons" in rpt
        assert rpt["total_events"] == len(events)


# ===========================================================================
# portfolio.py
# ===========================================================================

class TestPortfolio:

    def _events(self, n=10, ticker="AAPL"):
        evs = _make_events(n)
        for ev in evs:
            ev["ticker"] = ticker
        return evs

    def test_orders_generated(self):
        from portfolio import PortfolioLayer, PortfolioConfig
        events = self._events(5)
        layer  = PortfolioLayer(PortfolioConfig())
        layer.ingest(events)
        # With overlap=AVERAGE across same ticker, get 1 order
        assert len(layer.orders()) <= 1

    def test_prop_sizing(self):
        from portfolio import PortfolioLayer, PortfolioConfig
        events = [_make_events(1)[0]]
        events[0]["ticker"] = "TEST"
        events[0]["signal_score"] = 0.6
        cfg   = PortfolioConfig(max_position=10_000, sizing="PROP", overlap="STRONGEST")
        layer = PortfolioLayer(cfg)
        layer.ingest(events)
        orders = layer.orders()
        if orders:
            assert orders[0].notional == pytest.approx(6000.0, rel=0.01)

    def test_fixed_sizing(self):
        from portfolio import PortfolioLayer, PortfolioConfig
        events = [_make_events(1)[0]]
        events[0]["ticker"] = "FIXED"
        events[0]["signal_score"] = 0.3
        cfg   = PortfolioConfig(max_position=5_000, sizing="FIXED", overlap="STRONGEST")
        layer = PortfolioLayer(cfg)
        layer.ingest(events)
        orders = layer.orders()
        if orders:
            assert orders[0].notional == pytest.approx(5000.0, rel=0.01)

    def test_conflict_cancellation(self):
        from portfolio import PortfolioLayer, PortfolioConfig
        bull = {**_make_events(1)[0], "ticker": "CONFLICTED",
                "signal_score": 0.5, "signal_direction": "BULLISH"}
        bear = {**_make_events(1)[0], "ticker": "CONFLICTED",
                "signal_score": -0.5, "signal_direction": "BEARISH"}
        cfg   = PortfolioConfig(cancel_conflicts=True, overlap="AVERAGE")
        layer = PortfolioLayer(cfg)
        layer.ingest([bull, bear])
        assert len(layer.orders()) == 0

    def test_no_conflict_cancellation(self):
        from portfolio import PortfolioLayer, PortfolioConfig
        bull = {**_make_events(1)[0], "ticker": "KEEP",
                "signal_score": 0.7, "signal_direction": "BULLISH"}
        bear = {**_make_events(1)[0], "ticker": "KEEP",
                "signal_score": -0.3, "signal_direction": "BEARISH"}
        cfg   = PortfolioConfig(cancel_conflicts=False, overlap="AVERAGE")
        layer = PortfolioLayer(cfg)
        layer.ingest([bull, bear])
        assert len(layer.orders()) >= 0   # depends on average score vs min threshold

    def test_kelly_sizing_nonnegative(self):
        from portfolio import kelly_notional
        notional = kelly_notional(0.5, 0.55, 0.3, 100_000, 0.25)
        assert notional >= 0

    def test_report_structure(self):
        from portfolio import PortfolioLayer, PortfolioConfig
        events = _make_events(15)
        for ev in events:
            ev["ticker"] = f"T{int(abs(ev['signal_score']) * 10)}"
        layer = PortfolioLayer(PortfolioConfig())
        layer.ingest(events)
        rpt = layer.report()
        assert "n_orders" in rpt
        assert "gross_exposure" in rpt
        assert "utilisation_pct" in rpt

    def test_overlap_stack_capped_at_one(self):
        from portfolio import SignalGroup
        group = SignalGroup(ticker="X", signals=[
            {"signal_score": 0.9, "signal_direction": "BULLISH"},
            {"signal_score": 0.8, "signal_direction": "BULLISH"},
        ])
        resolved = group.resolved_score("STACK")
        assert resolved <= 1.0

    def test_overlap_average(self):
        from portfolio import SignalGroup
        group = SignalGroup(ticker="X", signals=[
            {"signal_score": 0.4, "signal_direction": "BULLISH"},
            {"signal_score": 0.6, "signal_direction": "BULLISH"},
        ])
        assert group.resolved_score("AVERAGE") == pytest.approx(0.5, abs=0.001)

    def test_overlap_strongest(self):
        from portfolio import SignalGroup
        group = SignalGroup(ticker="X", signals=[
            {"signal_score": 0.3},
            {"signal_score": 0.8},
            {"signal_score": 0.5},
        ])
        assert group.resolved_score("STRONGEST") == pytest.approx(0.8, abs=0.001)


# ===========================================================================
# robustness.py
# ===========================================================================

class TestRobustness:

    def test_run_returns_report(self):
        from robustness import run_robustness_suite
        events = _make_events(100)
        report = run_robustness_suite(events, horizon=1, n_windows=4, n_boot=50)
        assert math.isfinite(report.overall_ic)
        assert len(report.walk_forward_windows) == 4

    def test_bootstrap_ci_ordered(self):
        from robustness import run_robustness_suite
        events = _make_events(120)
        report = run_robustness_suite(events, horizon=1, n_windows=3, n_boot=100)
        b = report.bootstrap_ic
        assert b["ci_low"] <= b["mean"] <= b["ci_high"]

    def test_threshold_sensitivity_rows(self):
        from robustness import run_robustness_suite
        events = _make_events(100)
        report = run_robustness_suite(events, horizon=1, thresholds=[0.1, 0.3])
        assert len(report.threshold_sensitivity) == 2

    def test_event_type_cuts_present(self):
        from robustness import run_robustness_suite
        events = _make_events(80)
        report = run_robustness_suite(events, horizon=1, n_windows=3, n_boot=50)
        assert len(report.event_type_cuts) >= 1

    def test_summary_is_string(self):
        from robustness import run_robustness_suite
        events = _make_events(80)
        report = run_robustness_suite(events, horizon=1, n_windows=3, n_boot=50)
        s = report.summary()
        assert "ROBUSTNESS" in s
        assert "IC" in s

    def test_save(self, tmp_path):
        from robustness import run_robustness_suite
        events = _make_events(60)
        report = run_robustness_suite(events, horizon=1, n_windows=3, n_boot=30)
        path   = str(tmp_path / "robust.json")
        report.save(path)
        import json, os
        assert os.path.exists(path)
        with open(path) as f:
            d = json.load(f)
        assert "overall_ic" in d

    def test_random_signal_is_not_robust(self):
        """Purely random signals should not be marked robust."""
        from robustness import run_robustness_suite
        rng = random.Random(55)
        events = []
        base = _now() - timedelta(days=20)
        for i in range(120):
            s = rng.uniform(-1, 1)
            r = rng.gauss(0, 1)
            events.append({
                "signal_score": s, "sentiment_label": "NEUTRAL",
                "sentiment_score": abs(s), "materiality_score": rng.random(),
                "novelty_score": rng.random(), "credibility_score": rng.random(),
                "event_type": "unknown",
                "scraped_at": (base + timedelta(hours=i * 4)).isoformat(),
                "fwd_ret_1d": r, "fwd_ret_3d": r, "fwd_ret_5d": r,
            })
        report = run_robustness_suite(events, horizon=1, n_windows=5, n_boot=100)
        # Random signal may or may not be flagged robust; key check is it runs cleanly
        assert isinstance(report.is_robust, bool)
