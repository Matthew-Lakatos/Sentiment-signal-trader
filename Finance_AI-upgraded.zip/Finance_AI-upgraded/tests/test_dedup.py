"""Unit tests for deduplication helpers (no DB required)."""
import pytest
from events import ScrapedEvent


def test_same_text_same_hash():
    text = "This is a test article about the Federal Reserve."
    h1 = ScrapedEvent.hash_text(text)
    h2 = ScrapedEvent.hash_text(text)
    assert h1 == h2


def test_different_text_different_hash():
    h1 = ScrapedEvent.hash_text("Article A content")
    h2 = ScrapedEvent.hash_text("Article B content")
    assert h1 != h2


def test_hash_is_64_chars():
    h = ScrapedEvent.hash_text("any text")
    assert len(h) == 64


def test_empty_text_hash():
    h = ScrapedEvent.hash_text("")
    assert len(h) == 64   # SHA-256 of empty string is valid
