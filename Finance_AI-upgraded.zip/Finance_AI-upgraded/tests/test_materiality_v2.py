"""Tests for Materiality 2.0 (materiality.py)"""
import pytest
from materiality import score_materiality, _largest_dollar_amount, _largest_pct_change


def _base(**kwargs):
    defaults = dict(
        text="",
        keywords=[],
        credibility=0.8,
        sentiment_score=0.0,
    )
    defaults.update(kwargs)
    return score_materiality(**defaults)


# ---- Backward compatibility -----------------------------------------------

def test_v1_signature_still_works():
    """Original 4-arg call must not raise."""
    result = score_materiality(
        "bankruptcy and default", ["bankruptcy"], 0.8, 0.0
    )
    assert result.score > 0
    assert result.tier in ("CRITICAL", "HIGH", "MEDIUM", "LOW")


def test_v1_returns_new_fields_with_defaults():
    result = score_materiality("market crash", [], 0.9, 0.0)
    assert hasattr(result, "entity_boost")
    assert hasattr(result, "dollar_value")
    assert hasattr(result, "event_type")


# ---- Entity boosts --------------------------------------------------------

def test_entity_boost_nvidia():
    without = _base(text="earnings beat estimates")
    with_   = _base(text="nvidia earnings beat estimates")
    assert with_.score > without.score
    assert with_.entity_boost > 0


def test_entity_boost_fed():
    result = _base(text="federal reserve signals interest rate cut")
    assert result.entity_boost > 0
    assert any("entity:federal reserve" in r for r in result.reasons)


def test_entity_boost_capped():
    # Many entities at once should not exceed cap
    text = "apple microsoft nvidia amazon meta tesla alphabet google berkshire"
    result = _base(text=text)
    assert result.entity_boost <= 0.30


# ---- Numerical extraction -------------------------------------------------

def test_dollar_value_extracted():
    result = _base(text="The company signed a $2 billion contract with the government.")
    assert result.dollar_value == pytest.approx(2e9, rel=0.01)
    assert any("dollar_value" in r for r in result.reasons)


def test_pct_change_boost():
    result_high = _base(text="Revenue surged 25% year-over-year, beating all estimates.")
    result_low  = _base(text="Revenue grew 2% year-over-year.")
    assert result_high.score >= result_low.score


# ---- Event type multipliers -----------------------------------------------

def test_earnings_multiplier_higher_than_rumor():
    text     = "company reported strong results"
    keywords = ["earnings"]
    e = score_materiality(text, keywords, 0.8, 0.0, event_type="earnings")
    r = score_materiality(text, keywords, 0.8, 0.0, event_type="rumor")
    assert e.score > r.score


def test_event_type_in_result():
    result = _base(text="acquisition", event_type="contract")
    assert result.event_type == "contract"


# ---- Score bounds ---------------------------------------------------------

def test_score_never_exceeds_one():
    result = score_materiality(
        text="bankruptcy default fraud sec investigation market crash",
        keywords=["bankruptcy", "fraud"],
        credibility=1.0,
        sentiment_score=1.0,
        event_type="regulation",
        entities=["jpmorgan", "goldman sachs"],
    )
    assert result.score <= 1.0


def test_low_credibility_dampens():
    high = _base(text="recession market crash", credibility=0.9)
    low  = _base(text="recession market crash", credibility=0.1)
    assert high.score > low.score


def test_extreme_sentiment_amplifies():
    mild    = _base(text="inflation rate hike", sentiment_score=0.3)
    extreme = _base(text="inflation rate hike", sentiment_score=0.95)
    assert extreme.score >= mild.score
