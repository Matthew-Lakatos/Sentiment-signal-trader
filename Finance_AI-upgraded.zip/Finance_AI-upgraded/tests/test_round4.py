"""
test_round4.py — tests for round-4 additions.

Covers:
    feature_stability.py        — rolling regression + stability scores
    regime_model.py             — per-regime model fitting and conditional scoring
    calibration.py (interactions) — sent×novelty, mat×cred columns
    novelty.py                  — reference_time strict past-only bound
    second_order_validation.py  — compare first vs first+second IC/Sharpe
    overfitting_guard.py        — train/val/test split + single-use test lock
"""
from __future__ import annotations

import math
import os
import random
import tempfile
from datetime import datetime, timezone, timedelta

import numpy as np
import pytest


# ---------------------------------------------------------------------------
# Shared generators
# ---------------------------------------------------------------------------

def _now():
    return datetime.now(timezone.utc)


def _make_events(n: int = 120, seed: int = 42) -> list[dict]:
    rng  = random.Random(seed)
    base = _now() - timedelta(days=60)
    evs  = []
    for i in range(n):
        score = rng.uniform(-0.8, 0.8)
        ret   = score * 0.25 + rng.gauss(0, 0.4)
        label = "POSITIVE" if score > 0.1 else ("NEGATIVE" if score < -0.1 else "NEUTRAL")
        mat   = abs(score) * 0.7 + rng.uniform(0, 0.2)
        nov   = rng.uniform(0.2, 0.9)
        cred  = rng.uniform(0.4, 0.9)
        evs.append({
            "event_id":         f"e{i:04d}",
            "scraped_at":       (base + timedelta(hours=i * 5)).isoformat(),
            "sentiment_label":  label,
            "sentiment_score":  abs(score),
            "materiality_score": mat,
            "novelty_score":    nov,
            "credibility_score": cred,
            "signal_score":     score,
            "signal_direction": "BULLISH" if score > 0 else "BEARISH",
            "signal_tier":      "STRONG" if abs(score) > 0.5 else "MODERATE",
            "event_type":       rng.choice(["earnings", "macro", "contract", "analysis"]),
            "vol_regime":       rng.choice(["LOW", "MEDIUM", "HIGH", "SPIKE"]),
            "trend_regime":     rng.choice(["BULL", "NEUTRAL", "BEAR"]),
            "fwd_ret_1d":       ret,
            "fwd_ret_3d":       ret * 1.3 + rng.gauss(0, 0.3),
            "fwd_ret_5d":       ret * 1.7 + rng.gauss(0, 0.5),
        })
    return evs


# ===========================================================================
# feature_stability.py
# ===========================================================================

class TestFeatureStability:

    def test_returns_report(self):
        from feature_stability import analyse_stability
        events = _make_events(120)
        report = analyse_stability(events, horizon=1, window=40, step=20)
        assert report.n_windows >= 1
        assert len(report.traces) >= 4

    def test_all_base_features_present(self):
        from feature_stability import analyse_stability
        events = _make_events(120)
        report = analyse_stability(events, horizon=1, window=40, step=20,
                                   with_interactions=False)
        for f in ["sentiment", "materiality", "novelty", "credibility"]:
            assert f in report.traces

    def test_interaction_features_present_when_enabled(self):
        from feature_stability import analyse_stability
        events = _make_events(120)
        report = analyse_stability(events, horizon=1, window=40, step=20,
                                   with_interactions=True)
        assert "sent_x_novelty"    in report.traces
        assert "mat_x_credibility" in report.traces

    def test_stability_score_in_range(self):
        from feature_stability import analyse_stability
        events = _make_events(120)
        report = analyse_stability(events, horizon=1, window=40, step=20)
        for f, tr in report.traces.items():
            assert 0.0 <= tr.stability <= 1.0, f"{f} stability out of range"

    def test_sign_flips_nonnegative(self):
        from feature_stability import analyse_stability
        events = _make_events(120)
        report = analyse_stability(events, horizon=1, window=40, step=20)
        for f, tr in report.traces.items():
            assert tr.sign_flips >= 0

    def test_summary_is_string(self):
        from feature_stability import analyse_stability
        events = _make_events(120)
        report = analyse_stability(events, horizon=1, window=40, step=20)
        s = report.summary()
        assert isinstance(s, str)
        assert "STABILITY" in s

    def test_save_to_json(self, tmp_path):
        from feature_stability import analyse_stability
        events = _make_events(120)
        report = analyse_stability(events, horizon=1, window=40, step=20)
        path   = str(tmp_path / "stability.json")
        report.save(path)
        import json
        with open(path) as f:
            d = json.load(f)
        assert "traces" in d

    def test_insufficient_data_returns_empty(self):
        from feature_stability import analyse_stability
        events = _make_events(5)   # fewer than window=60
        report = analyse_stability(events, horizon=1, window=60, step=20)
        assert report.n_windows == 0
        assert "Insufficient data" in report.drift_warnings[0]

    def test_stable_feature_appears_in_stable_list(self):
        """Generate a feature with perfectly stable coefficient and check it's classified stable."""
        from feature_stability import _stability_score
        stable_coefs = [0.5] * 10   # constant → perfect stability
        s = _stability_score(stable_coefs)
        assert s > 0.7

    def test_drifting_feature_appears_in_unstable(self):
        from feature_stability import _stability_score
        # Alternating sign → many flips → low stability
        flip_coefs = [0.5, -0.5] * 6
        s = _stability_score(flip_coefs)
        assert s < 0.5

    def test_rolling_windows_increase_with_more_data(self):
        from feature_stability import analyse_stability
        small = analyse_stability(_make_events(80),  horizon=1, window=30, step=10)
        large = analyse_stability(_make_events(200), horizon=1, window=30, step=10)
        assert large.n_windows >= small.n_windows


# ===========================================================================
# regime_model.py
# ===========================================================================

class TestRegimeModel:

    def test_fit_returns_model_set(self):
        from regime_model import fit_regime_models
        events = _make_events(120)
        ms     = fit_regime_models(events, horizon=1)
        assert ms.global_ is not None
        assert len(ms.models) >= 1

    def test_global_fallback_always_present(self):
        from regime_model import fit_regime_models
        events = _make_events(120)
        ms     = fit_regime_models(events, horizon=1)
        assert ms.global_.is_fallback is True

    def test_score_returns_dict_with_alpha(self):
        from regime_model import fit_regime_models
        events = _make_events(120)
        ms     = fit_regime_models(events, horizon=1)
        ev     = events[0]
        result = ms.score(ev, vol_regime="MEDIUM", trend_regime="BULL")
        assert "alpha"      in result
        assert "regime_key" in result
        assert -1.0 <= result["alpha"] <= 1.0

    def test_score_unknown_regime_uses_fallback(self):
        from regime_model import fit_regime_models
        events = _make_events(120)
        ms     = fit_regime_models(events, horizon=1)
        ev     = events[0]
        result = ms.score(ev, vol_regime="UNKNOWN", trend_regime="UNKNOWN")
        assert "alpha" in result

    def test_score_differs_by_regime(self):
        """High-vol and low-vol models should differ (unless data is tiny)."""
        from regime_model import fit_regime_models, MIN_REGIME_SAMPLES
        # Make events clearly labelled
        rng  = random.Random(7)
        evs  = _make_events(200, seed=7)
        # Force 100 events into HIGH_VOL and 100 into NORMAL
        for i, ev in enumerate(evs):
            ev["vol_regime"]   = "HIGH"   if i < 100 else "LOW"
            ev["trend_regime"] = "BULL"

        ms = fit_regime_models(evs, horizon=1)
        hv = ms.models.get("HIGH_VOL_BULL")
        nv = ms.models.get("NORMAL_BULL")
        if hv and nv and not hv.is_fallback and not nv.is_fallback:
            # Weights should differ between regimes
            assert hv.weights != nv.weights or hv.intercept != nv.intercept

    def test_save_and_load(self, tmp_path):
        from regime_model import fit_regime_models, RegimeModelSet
        events = _make_events(120)
        ms     = fit_regime_models(events, horizon=1)
        path   = str(tmp_path / "regime_models.json")
        ms.save(path)
        loaded = RegimeModelSet.load(path)
        assert loaded.horizon == ms.horizon
        assert set(loaded.models.keys()) == set(ms.models.keys())

    def test_regime_model_score_is_signed(self):
        from regime_model import RegimeModel
        # Pure sentiment model: only sentiment weight, zero intercept + others
        m = RegimeModel(
            regime_key="test",
            weights={"sentiment": 1.0, "materiality": 0.0, "novelty": 0.0, "credibility": 0.0},
            intercept=0.0, n_samples=50, ic=0.05,
        )
        pos = m.score("POSITIVE", 0.8, 0.0, 0.0, 0.0)
        neg = m.score("NEGATIVE", 0.8, 0.0, 0.0, 0.0)
        assert pos > 0
        assert neg < 0

    def test_available_regimes_excludes_fallback_global(self):
        from regime_model import fit_regime_models
        events = _make_events(200)
        ms     = fit_regime_models(events, horizon=1)
        available = ms.available_regimes()
        # All listed regimes should not be globally flagged as fallback
        # (though some may be data-fallbacks)
        assert isinstance(available, list)

    def test_report_is_string(self):
        from regime_model import fit_regime_models
        events = _make_events(120)
        ms     = fit_regime_models(events, horizon=1)
        s = ms.report()
        assert isinstance(s, str)
        assert "REGIME" in s


# ===========================================================================
# calibration.py — interaction terms
# ===========================================================================

class TestInteractionTerms:

    def test_with_interactions_returns_extra_weights(self):
        from calibration import calibrate, FEATURE_NAMES_WITH_INTERACTIONS
        events = _make_events(100)
        result = calibrate(events, horizon=1, method="ridge", with_interactions=True)
        for f in FEATURE_NAMES_WITH_INTERACTIONS:
            assert f in result.weights, f"Missing weight for {f}"

    def test_without_interactions_returns_base_weights_only(self):
        from calibration import calibrate, FEATURE_NAMES
        events = _make_events(100)
        result = calibrate(events, horizon=1, method="ridge", with_interactions=False)
        assert set(result.weights.keys()) == set(FEATURE_NAMES)

    def test_interactions_flag_stored_in_result(self):
        from calibration import calibrate
        events = _make_events(80)
        r_no   = calibrate(events, horizon=1, with_interactions=False)
        r_yes  = calibrate(events, horizon=1, with_interactions=True)
        assert r_no.with_interactions  is False
        assert r_yes.with_interactions is True

    def test_interactions_ic_not_dramatically_worse(self):
        """Adding interactions should not catastrophically reduce IC."""
        from calibration import calibrate
        events  = _make_events(100)
        r_no    = calibrate(events, horizon=1, method="ridge", with_interactions=False)
        r_yes   = calibrate(events, horizon=1, method="ridge", with_interactions=True)
        # With interactions may have slightly different IC — should not be >0.10 worse
        assert r_yes.ic >= r_no.ic - 0.10

    def test_apply_weights_with_interaction_columns(self):
        from calibration import apply_calibrated_weights
        weights = {
            "sentiment": 0.3, "materiality": 0.3, "novelty": 0.2, "credibility": 0.1,
            "sent_x_novelty": 0.05, "mat_x_credibility": 0.05,
        }
        score = apply_calibrated_weights(weights, "POSITIVE", 0.8, 0.7, 0.6, 0.9)
        assert -1.0 <= score <= 1.0
        assert score > 0   # positive sentiment → positive score

    def test_interaction_terms_have_finite_vif(self):
        from calibration import calibrate
        events = _make_events(100)
        result = calibrate(events, horizon=1, with_interactions=True)
        if result.vif:
            for f, v in result.vif.items():
                assert math.isfinite(v) or v == float("nan"), f"{f} VIF is invalid"


# ===========================================================================
# novelty.py — reference_time strict past bound
# ===========================================================================

class TestNoveltyLeakageGuard:
    """
    These tests validate the reference_time parameter added to compute_novelty_score.
    We test the pure-Python helpers since the DB calls require asyncpg.
    """

    def test_narrative_novelty_uses_timestamp_decay(self):
        """Older clusters should contribute less to novelty suppression."""
        from novelty import narrative_novelty
        import time

        emb      = [1.0, 0.0, 0.0]
        centroid = [1.0, 0.0, 0.0]   # identical → very similar

        now      = time.time()
        recent   = now - 3600        # 1h old
        old      = now - 86400 * 5   # 5 days old

        nov_recent = narrative_novelty(emb, [centroid], [recent])
        nov_old    = narrative_novelty(emb, [centroid], [old])

        # Older clusters should suppress novelty less → higher novelty score for old
        assert nov_old > nov_recent

    def test_empty_clusters_returns_max_novelty(self):
        from novelty import narrative_novelty
        emb = [1.0, 0.0, 0.0]
        nov = narrative_novelty(emb, [], [])
        assert nov == 1.0

    def test_identical_embedding_low_novelty(self):
        """An embedding identical to a very recent cluster should have low novelty."""
        import time
        from novelty import narrative_novelty

        emb      = [0.6, 0.8, 0.0]
        centroid = [0.6, 0.8, 0.0]
        now      = time.time()

        nov = narrative_novelty(emb, [centroid], [now])
        assert nov < 0.5   # recent identical story → low novelty

    def test_novelty_label_mapping(self):
        from novelty import novelty_label
        assert novelty_label(0.90) == "NOVEL"
        assert novelty_label(0.60) == "PARTIAL"
        assert novelty_label(0.35) == "REPEATED"
        assert novelty_label(0.10) == "DUPLICATE"

    def test_reference_time_parameter_accepted(self):
        """Verify compute_novelty_score signature accepts reference_time (no DB call needed)."""
        import inspect
        from novelty import compute_novelty_score
        sig = inspect.signature(compute_novelty_score)
        assert "reference_time" in sig.parameters


# ===========================================================================
# second_order_validation.py
# ===========================================================================

class TestSecondOrderValidation:

    def _make_soa_events(self, n: int, seed: int = 77) -> tuple[list[dict], list[dict]]:
        """Return (first_order_events, second_order_events) pairs."""
        rng  = random.Random(seed)
        base = _now() - timedelta(days=30)
        first, second = [], []
        for i in range(n):
            score   = rng.uniform(-0.6, 0.6)
            ret     = score * 0.3 + rng.gauss(0, 0.4)
            eid     = f"e{i:04d}"
            label   = "POSITIVE" if score > 0 else "NEGATIVE"
            first.append({
                "event_id":        eid,
                "scraped_at":      (base + timedelta(hours=i * 6)).isoformat(),
                "signal_score":    score,
                "sentiment_label": label,
                "sentiment_score": abs(score),
                "materiality_score": abs(score) * 0.7,
                "novelty_score":   0.6,
                "credibility_score": 0.7,
                "fwd_ret_1d":      ret,
                "fwd_ret_3d":      ret * 1.2 + rng.gauss(0, 0.3),
            })
            # Second-order: correlated with first (so blending may help)
            second.append({
                "entity":           f"PEER_{i}",
                "secondary_score":  score * 0.4 + rng.gauss(0, 0.1),
                "source_event_id":  eid,
                "kg_sentiment":     score * 0.5,
            })
        return first, second

    def test_validate_returns_result(self):
        from second_order_validation import validate_second_order
        first, second = self._make_soa_events(80)
        result = validate_second_order(first, second, blend_lambda=0.3, horizon=1)
        assert hasattr(result, "keep")
        assert hasattr(result, "ic_first")
        assert hasattr(result, "ic_combined")

    def test_keep_is_bool(self):
        from second_order_validation import validate_second_order
        first, second = self._make_soa_events(80)
        result = validate_second_order(first, second)
        assert isinstance(result.keep, bool)

    def test_recommended_lambda_zero_when_discarded(self):
        from second_order_validation import validate_second_order
        first, second = self._make_soa_events(80)
        # Use a noisy second-order (random) that should hurt
        rng = random.Random(99)
        for s in second:
            s["secondary_score"] = rng.gauss(0, 1.0)   # pure noise
        result = validate_second_order(first, second, blend_lambda=0.5, horizon=1)
        if not result.keep:
            assert result.recommended_lambda == 0.0

    def test_blend_returns_first_when_discarded(self):
        from second_order_validation import SecondOrderValidationResult
        result = SecondOrderValidationResult(
            horizon=1, blend_lambda=0.3,
            ic_first=0.05, sharpe_first=0.8, ic_std_first=0.02,
            ic_combined=0.01, sharpe_combined=0.5, ic_std_combined=0.05,
            keep=False, ic_lift=-0.04, recommended_lambda=0.0,
        )
        blended = result.blend(0.6, 0.3)
        assert blended == pytest.approx(0.6, abs=1e-4)

    def test_blend_applies_lambda_when_kept(self):
        from second_order_validation import SecondOrderValidationResult
        result = SecondOrderValidationResult(
            horizon=1, blend_lambda=0.3,
            ic_first=0.05, sharpe_first=0.9, ic_std_first=0.02,
            ic_combined=0.06, sharpe_combined=1.0, ic_std_combined=0.02,
            keep=True, ic_lift=0.01, recommended_lambda=0.3,
        )
        blended = result.blend(0.6, 0.4)
        expected = (1 - 0.3) * 0.6 + 0.3 * 0.4
        assert blended == pytest.approx(expected, abs=1e-4)

    def test_ic_lift_computed(self):
        from second_order_validation import validate_second_order
        first, second = self._make_soa_events(80)
        result = validate_second_order(first, second, horizon=1)
        assert math.isfinite(result.ic_lift)
        assert result.ic_lift == pytest.approx(result.ic_combined - result.ic_first, abs=0.001)

    def test_insufficient_events_returns_null(self):
        from second_order_validation import validate_second_order
        first, second = self._make_soa_events(5)  # too few
        result = validate_second_order(first, second)
        assert result.keep is False
        assert "Insufficient" in result.notes

    def test_summary_is_string(self):
        from second_order_validation import validate_second_order
        first, second = self._make_soa_events(80)
        result = validate_second_order(first, second)
        s = result.summary()
        assert isinstance(s, str)
        assert "SECOND-ORDER" in s


# ===========================================================================
# overfitting_guard.py
# ===========================================================================

class TestOverfittingGuard:

    def test_data_splitter_sizes(self):
        from overfitting_guard import DataSplitter
        events = _make_events(100)
        sp     = DataSplitter(events, train=0.6, val=0.2, test=0.2)
        tr, va, te = sp.split()
        assert len(tr) == 60
        assert len(va) == 20
        assert len(te) == 20

    def test_split_is_time_ordered(self):
        from overfitting_guard import DataSplitter
        events = _make_events(100)
        sp     = DataSplitter(events, 0.6, 0.2, 0.2)
        tr, va, te = sp.split()
        # Last train event should be before first val event
        if tr and va:
            assert str(tr[-1]["scraped_at"]) <= str(va[0]["scraped_at"])
        if va and te:
            assert str(va[-1]["scraped_at"]) <= str(te[0]["scraped_at"])

    def test_split_sizes_sum_to_total(self):
        from overfitting_guard import DataSplitter
        events = _make_events(150)
        sp     = DataSplitter(events, 0.6, 0.2, 0.2)
        tr, va, te = sp.split()
        assert len(tr) + len(va) + len(te) == len(events)

    def test_evaluate_on_val_returns_result(self):
        from overfitting_guard import DataSplitter, OverfittingGuard
        events = _make_events(100)
        sp     = DataSplitter(events)
        _, va, _  = sp.split()
        weights   = {"sentiment": 0.3, "materiality": 0.35, "novelty": 0.2, "credibility": 0.15}
        guard     = OverfittingGuard("test_val", lock_dir=tempfile.gettempdir())
        result    = guard.evaluate_on_val(va, weights, horizon=1)
        assert hasattr(result, "ic")
        assert hasattr(result, "sharpe")

    def test_evaluate_on_test_single_use(self, tmp_path):
        from overfitting_guard import DataSplitter, OverfittingGuard
        events  = _make_events(100)
        sp      = DataSplitter(events)
        _, _, te = sp.split()
        weights  = {"sentiment": 0.3, "materiality": 0.35, "novelty": 0.2, "credibility": 0.15}

        guard = OverfittingGuard(f"test_single_{id(tmp_path)}", lock_dir=str(tmp_path))
        result = guard.evaluate_on_test(te, weights, horizon=1)
        assert result.split_name == "test"

        # Second call must raise
        with pytest.raises(RuntimeError, match="already been evaluated"):
            guard.evaluate_on_test(te, weights, horizon=1)

    def test_evaluate_on_val_can_be_called_multiple_times(self, tmp_path):
        from overfitting_guard import DataSplitter, OverfittingGuard
        events  = _make_events(100)
        sp      = DataSplitter(events)
        _, va, _  = sp.split()
        weights   = {"sentiment": 0.3, "materiality": 0.35, "novelty": 0.2, "credibility": 0.15}
        guard     = OverfittingGuard("test_val_multi", lock_dir=str(tmp_path))
        # Should not raise on multiple calls
        for _ in range(3):
            guard.evaluate_on_val(va, weights, horizon=1)

    def test_red_flags_triggered_on_high_ic(self):
        from overfitting_guard import _eval_split
        # Inject events where signal perfectly predicts return → IC ≈ 1.0
        rng = random.Random(5)
        evs = []
        for i in range(50):
            s = rng.choice([-0.8, 0.8])
            evs.append({
                "sentiment_label": "POSITIVE" if s > 0 else "NEGATIVE",
                "sentiment_score": abs(s),
                "materiality_score": 0.8, "novelty_score": 0.7,
                "credibility_score": 0.9,
                "signal_score": s,
                "fwd_ret_1d": s * 5.0,  # perfect prediction, high Sharpe
            })
        from calibration import FEATURE_NAMES
        weights = {f: 0.25 for f in FEATURE_NAMES}
        result  = _eval_split(evs, weights, 1, "test")
        assert len(result.red_flags) >= 1

    def test_summary_from_split(self):
        from overfitting_guard import DataSplitter
        events = _make_events(90)
        sp     = DataSplitter(events)
        s      = sp.summary()
        assert "total" in s
        assert s["train"]["n"] > 0

    def test_overfitting_detected_train_much_better_than_test(self, tmp_path):
        """Simulate train IC >> test IC and verify the warning path runs."""
        from overfitting_guard import OverfittingGuard, _eval_split, EvaluationResult
        import math

        # Create a fake guard and mock the evaluation results
        guard = OverfittingGuard(f"ov_test_{id(tmp_path)}", lock_dir=str(tmp_path))

        # We only test the logic path, not the lock (since we'd need real events)
        train_r = EvaluationResult("train", 60, ic=0.15, sharpe=1.2,
                                   hit_rate=0.58, mean_ret=0.1, red_flags=[])
        test_r  = EvaluationResult("test",  20, ic=0.02, sharpe=0.4,
                                   hit_rate=0.51, mean_ret=0.01, red_flags=[])

        # Check the gap detection logic directly
        gap = train_r.ic - test_r.ic
        assert gap > 0.03   # should be flagged as overfitting
