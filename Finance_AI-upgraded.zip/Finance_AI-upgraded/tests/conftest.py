"""
Shared pytest fixtures.
DB-dependent tests are skipped unless POSTGRES_DSN is set in the environment.
"""
import os
import asyncio
import pytest


@pytest.fixture(scope="session")
def event_loop():
    """Shared event loop for async tests."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


def pytest_configure(config):
    config.addinivalue_line("markers", "db: mark test as requiring a live database")


def pytest_runtest_setup(item):
    if "db" in item.keywords:
        if not os.getenv("POSTGRES_DSN"):
            pytest.skip("POSTGRES_DSN not set — skipping DB test")
