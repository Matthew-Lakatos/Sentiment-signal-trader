"""Tests for scraper guards (SSRF, Content-Type, response size)."""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch


def test_private_url_blocked():
    from scraper import _is_private_url
    assert _is_private_url("http://127.0.0.1/secret") is True
    assert _is_private_url("http://192.168.1.1/admin") is True
    assert _is_private_url("http://169.254.169.254/latest/meta-data/") is True


def test_public_url_allowed():
    from scraper import _is_private_url
    assert _is_private_url("https://www.bbc.com/news") is False


def test_backoff_increases_with_attempt():
    """Verify backoff is capped and increases with attempt count."""
    import asyncio
    from unittest.mock import patch

    delays = []
    async def mock_sleep(d):
        delays.append(d)

    async def run():
        with patch("asyncio.sleep", side_effect=mock_sleep):
            from scraper import _backoff
            await _backoff(0)
            await _backoff(3)
            await _backoff(10)

    asyncio.run(run())
    # Max delay for attempt=10 is capped at 30.0
    assert all(d <= 30.0 for d in delays)


def test_robots_is_allowed_public():
    from robots_cache import is_allowed
    # example.com has no robots.txt restriction on /
    result = is_allowed("https://example.com/")
    assert isinstance(result, bool)
