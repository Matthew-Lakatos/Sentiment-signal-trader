"""Tests for event_classifier.py"""
import pytest
from event_classifier import (
    classify,
    extract_numerical_value,
    extract_percentage_change,
    EVENT_TYPES,
)


def test_earnings_classification():
    text = "Apple reported record quarterly earnings, with EPS beating consensus by 12%."
    result = classify(text)
    assert result.event_type == "earnings"
    assert result.confidence > 0.3
    assert result.match_count >= 1


def test_macro_classification():
    text = "The Federal Reserve raised interest rates by 25 basis points, citing persistent inflation."
    result = classify(text)
    assert result.event_type == "macro"
    assert result.confidence > 0.4


def test_contract_classification():
    text = "Lockheed Martin was awarded a $5 billion defense contract by the US government."
    result = classify(text)
    assert result.event_type == "contract"
    assert result.dollar_value == pytest.approx(5e9, rel=0.01)


def test_regulation_classification():
    text = "The SEC launched an investigation into the company for alleged securities fraud."
    result = classify(text)
    assert result.event_type == "regulation"


def test_rumor_classification():
    text = "Sources say the company is considering a merger, according to people familiar with the matter."
    result = classify(text)
    assert result.event_type == "rumor"


def test_analysis_classification():
    text = "Goldman Sachs analyst upgraded the stock to Buy, raising the price target to $200."
    result = classify(text)
    assert result.event_type == "analysis"


def test_geopolitical_classification():
    # "sanctions" overlaps with regulation; use a text with multiple geopolitical signals
    text = "NATO allies responded to the trade war with new tariffs after the election result."
    result = classify(text)
    assert result.event_type == "geopolitical"


def test_unknown_on_empty():
    result = classify("")
    assert result.event_type == "unknown"
    assert result.confidence == 0.0


def test_all_event_types_valid():
    for et in EVENT_TYPES:
        assert isinstance(et, str)


def test_extract_numerical_value_billion():
    usd = extract_numerical_value("The deal is worth $3.5 billion")
    assert usd == pytest.approx(3.5e9, rel=0.01)


def test_extract_numerical_value_million():
    usd = extract_numerical_value("A $750 million contract was signed")
    assert usd == pytest.approx(7.5e8, rel=0.01)


def test_extract_numerical_value_none():
    usd = extract_numerical_value("No monetary value mentioned here")
    assert usd is None


def test_extract_percentage():
    pct = extract_percentage_change("Revenue grew 18.5% year-over-year")
    assert pct == pytest.approx(18.5, rel=0.01)


def test_extract_percentage_none():
    pct = extract_percentage_change("No percentages in this text")
    assert pct is None
