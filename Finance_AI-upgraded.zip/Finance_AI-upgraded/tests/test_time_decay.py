"""Tests for time_decay.py"""
import pytest
from datetime import datetime, timezone, timedelta
from time_decay import time_decay_multiplier, recency_score


def _now():
    return datetime.now(timezone.utc)


def test_fresh_event_near_one():
    sat = _now() - timedelta(minutes=5)
    mult = time_decay_multiplier(sat, "CRITICAL")
    assert mult > 0.9


def test_breaking_news_boost():
    sat = _now() - timedelta(minutes=30)
    mult = time_decay_multiplier(sat, "CRITICAL")
    assert mult >= 1.0   # should be boosted above 1


def test_old_event_decayed():
    sat = _now() - timedelta(days=7)
    mult = time_decay_multiplier(sat, "LOW")
    assert mult < 0.5


def test_critical_decays_faster_than_low():
    sat = _now() - timedelta(hours=24)
    mult_crit = time_decay_multiplier(sat, "CRITICAL")
    mult_low  = time_decay_multiplier(sat, "LOW")
    assert mult_crit < mult_low


def test_multiplier_positive():
    for tier in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        sat = _now() - timedelta(hours=100)
        assert time_decay_multiplier(sat, tier) > 0


def test_recency_score_range():
    for hours in [0, 1, 12, 48, 168]:
        sat = _now() - timedelta(hours=hours)
        s = recency_score(sat)
        assert 0.0 <= s <= 1.0


def test_recency_score_monotone():
    scores = [
        recency_score(_now() - timedelta(hours=h))
        for h in [0, 6, 24, 72, 168]
    ]
    for i in range(len(scores) - 1):
        assert scores[i] >= scores[i + 1]


def test_naive_datetime_handled():
    sat = datetime.utcnow()  # naive
    mult = time_decay_multiplier(sat, "MEDIUM")
    assert mult > 0
