"""Tests for materiality scoring engine."""
import pytest
from materiality import score_materiality, MaterialityResult


def test_low_score_generic_text():
    r = score_materiality("The weather is nice today", [], 0.5, 0.0)
    assert r.tier == "LOW"
    assert r.score < 0.2


def test_critical_keywords_high_credibility():
    r = score_materiality(
        "Federal Reserve announces emergency rate hike amid market crash",
        ["federal reserve", "market crash"],
        credibility=0.95,
        sentiment_score=-0.9,
    )
    assert r.tier in ("CRITICAL", "HIGH")
    assert r.score > 0.4


def test_credibility_dampens_score():
    high = score_materiality("bankruptcy merger acquisition", [], 1.0, 0.0)
    low  = score_materiality("bankruptcy merger acquisition", [], 0.1, 0.0)
    assert high.score > low.score


def test_extreme_sentiment_amplifies():
    base    = score_materiality("recession inflation gdp", [], 0.7, 0.0)
    extreme = score_materiality("recession inflation gdp", [], 0.7, -0.95)
    assert extreme.score >= base.score


def test_tiers_exhaustive():
    r = score_materiality("bankruptcy federal reserve", [], 1.0, -1.0)
    assert r.tier in ("CRITICAL", "HIGH", "MEDIUM", "LOW")


def test_score_clamped_to_unit():
    r = score_materiality(
        " ".join(["bankruptcy federal reserve recession"] * 20), [], 1.0, -1.0
    )
    assert 0.0 <= r.score <= 1.0


def test_reasons_populated():
    r = score_materiality("federal reserve rate hike", ["federal reserve"], 0.9, 0.0)
    assert any("federal reserve" in reason for reason in r.reasons)
