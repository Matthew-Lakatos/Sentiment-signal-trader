"""Tests for source health logic (pure functions, no DB)."""
import pytest
from unittest.mock import AsyncMock, MagicMock


def test_domain_of():
    from source_health import domain_of
    assert domain_of("https://www.example.com/path?q=1") == "www.example.com"
    assert domain_of("http://reuters.com") == "reuters.com"


@pytest.mark.asyncio
async def test_record_success_resets_fails():
    pool = AsyncMock()
    pool.execute = AsyncMock()
    from source_health import record_success
    await record_success(pool, "example.com")
    pool.execute.assert_called_once()
    call_sql = pool.execute.call_args[0][0]
    assert "consecutive_fails = 0" in call_sql


@pytest.mark.asyncio
async def test_is_dead_returns_false_for_unknown():
    pool = AsyncMock()
    pool.fetchrow = AsyncMock(return_value=None)
    from source_health import is_dead
    result = await is_dead(pool, "unknown.com")
    assert result is False
