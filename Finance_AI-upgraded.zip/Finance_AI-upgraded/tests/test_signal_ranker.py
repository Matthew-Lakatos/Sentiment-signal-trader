"""Tests for signal_ranker.py"""
import pytest
from datetime import datetime, timezone, timedelta
from signal_ranker import compute_signal, rank_signals, SignalResult


def _now():
    return datetime.now(timezone.utc)


def test_bullish_signal():
    sig = compute_signal(
        sentiment_label="POSITIVE",
        sentiment_score=0.85,
        materiality_score=0.70,
        novelty_score=0.90,
        credibility_score=0.80,
        materiality_tier="CRITICAL",
        event_type="earnings",
        scraped_at=_now(),
    )
    assert sig.score > 0
    assert sig.direction == "BULLISH"
    assert sig.rank_tier in ("STRONG", "MODERATE")


def test_bearish_signal():
    sig = compute_signal(
        sentiment_label="NEGATIVE",
        sentiment_score=0.80,
        materiality_score=0.65,
        novelty_score=0.85,
        credibility_score=0.75,
        materiality_tier="HIGH",
        event_type="regulation",
        scraped_at=_now(),
    )
    # sentiment_contrib is negative; direction reflects overall bias
    assert sig.direction == "BEARISH"
    assert sig.components["sentiment_contrib"] < 0


def test_neutral_signal_low_materiality():
    sig = compute_signal(
        sentiment_label="NEUTRAL",
        sentiment_score=0.10,
        materiality_score=0.05,
        novelty_score=0.30,
        credibility_score=0.50,
        materiality_tier="LOW",
        event_type="analysis",
    )
    assert sig.rank_tier in ("WEAK", "NOISE")


def test_rumor_discounted():
    sig_rumor = compute_signal(
        sentiment_label="POSITIVE", sentiment_score=0.8,
        materiality_score=0.5, novelty_score=0.7,
        credibility_score=0.6, event_type="rumor",
    )
    sig_earnings = compute_signal(
        sentiment_label="POSITIVE", sentiment_score=0.8,
        materiality_score=0.5, novelty_score=0.7,
        credibility_score=0.6, event_type="earnings",
    )
    assert abs(sig_rumor.score) < abs(sig_earnings.score)


def test_breaking_news_boost():
    just_now  = _now()
    yesterday = _now() - timedelta(hours=36)
    sig_new = compute_signal(
        "POSITIVE", 0.7, 0.6, 0.8, 0.7, "HIGH", "macro", scraped_at=just_now
    )
    sig_old = compute_signal(
        "POSITIVE", 0.7, 0.6, 0.8, 0.7, "HIGH", "macro", scraped_at=yesterday
    )
    assert sig_new.score > sig_old.score


def test_score_clamped():
    sig = compute_signal(
        sentiment_label="POSITIVE", sentiment_score=1.0,
        materiality_score=1.0, novelty_score=1.0,
        credibility_score=1.0, event_type="earnings",
    )
    assert -1.0 <= sig.score <= 1.0


def test_components_present():
    sig = compute_signal("NEUTRAL", 0.5, 0.5, 0.5, 0.5)
    assert "sentiment_contrib" in sig.components
    assert "materiality_contrib" in sig.components
    assert "novelty_contrib" in sig.components
    assert "credibility_contrib" in sig.components
    assert "time_decay" in sig.components


def test_rank_signals_sorted():
    events = [
        {"sentiment_label": "NEGATIVE", "sentiment_score": 0.9,
         "materiality_score": 0.8, "novelty_score": 0.9,
         "credibility_score": 0.8, "materiality_tier": "CRITICAL",
         "event_type": "regulation", "scraped_at": _now().isoformat()},
        {"sentiment_label": "NEUTRAL", "sentiment_score": 0.1,
         "materiality_score": 0.1, "novelty_score": 0.2,
         "credibility_score": 0.5, "materiality_tier": "LOW",
         "event_type": "unknown", "scraped_at": _now().isoformat()},
    ]
    ranked = rank_signals(events)
    assert len(ranked) == 2
    assert abs(ranked[0]["signal"]["score"]) >= abs(ranked[1]["signal"]["score"])
