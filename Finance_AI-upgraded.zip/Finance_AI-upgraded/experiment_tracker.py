"""
experiment_tracker.py — §23 Research Infrastructure & Experiment Tracking.

Provides reproducible, versioned tracking of every calibration run, backtest,
and signal evaluation without requiring any external services.

Two backends
------------
1. MLflow (preferred)
   If mlflow is installed and MLFLOW_TRACKING_URI is set, all experiments
   are logged to the MLflow server.  Params, metrics, artifacts, and
   dataset hashes are stored in the run.

2. JSON file (fallback — always works, zero dependencies)
   If MLflow is unavailable, each run is appended to a JSONL file at
   EXPERIMENT_LOG_PATH (default: experiments/runs.jsonl).
   The format is one JSON object per line, readable by pandas, jq, etc.

Core concepts
-------------
ExperimentRun:
   A single calibration or backtest execution.  Contains:
   - run_id         UUID (stable across MLflow and JSON backends)
   - experiment_name  e.g. "signal_calibration" or "backtest_walk_forward"
   - params         dict of hyperparameters (method, horizon, alpha, etc.)
   - metrics        dict of results (ic, ic_oos, sharpe, hit_rate, etc.)
   - tags           free-form metadata (git_commit, dataset_version, etc.)
   - artifact_paths files logged (weights.json, feature_matrix.npy, etc.)
   - dataset_hash   SHA-256 of the training data (for reproducibility)

Reproducible manifests
-----------------------
manifest() returns a dict that fully describes a run:
   {
     run_id, experiment_name, params, metrics,
     dataset_hash, started_at, ended_at, duration_seconds,
     tags, artifact_paths
   }
This can be saved as a JSON file alongside the model weights so the
exact conditions of any result can be reproduced.

Dataset snapshotting
--------------------
snapshot_dataset(events) serialises the event list to a JSONL file in
the artifacts directory and returns its hash.  This hash is stored in
every run that uses the dataset, enabling exact reproducibility.

Usage
-----
    from experiment_tracker import tracker, ExperimentRun

    with tracker.start_run("signal_calibration", params={"method": "lgbm", "horizon": 5}) as run:
        result = calibrate(events, method="lgbm", horizon=5)
        run.log_metrics({"ic": result.ic, "ic_oos": result.ic_oos})
        run.log_artifact("weights.json", result.weights)

    # Save manifest for reproducibility
    with open("run_manifest.json", "w") as f:
        json.dump(run.manifest(), f, indent=2)

    # Query past runs
    runs = tracker.list_runs("signal_calibration")
    best = max(runs, key=lambda r: r["metrics"].get("ic_oos", -999))
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Generator, Optional

from config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

_DEFAULT_LOG_PATH  = Path("experiments/runs.jsonl")
_DEFAULT_ART_DIR   = Path("experiments/artifacts")
_MLFLOW_AVAILABLE  = False

try:
    import mlflow
    _MLFLOW_AVAILABLE = True
except ImportError:
    pass


# ---------------------------------------------------------------------------
# ExperimentRun
# ---------------------------------------------------------------------------

@dataclass
class ExperimentRun:
    """Tracks a single experiment run (calibration, backtest, etc.)."""
    run_id:          str = field(default_factory=lambda: str(uuid.uuid4()))
    experiment_name: str = "default"
    params:          dict = field(default_factory=dict)
    metrics:         dict = field(default_factory=dict)
    tags:            dict = field(default_factory=dict)
    artifact_paths:  list[str] = field(default_factory=list)
    dataset_hash:    Optional[str] = None
    started_at:      Optional[str] = None
    ended_at:        Optional[str] = None
    duration_seconds:Optional[float] = None
    status:          str = "running"   # running | completed | failed
    error:           Optional[str] = None

    # Internal: MLflow run object (not serialised)
    _mlflow_run: Any = field(default=None, repr=False, compare=False)

    def log_metric(self, key: str, value: float) -> None:
        self.metrics[key] = value
        if self._mlflow_run and _MLFLOW_AVAILABLE:
            try:
                mlflow.log_metric(key, value)
            except Exception:
                pass

    def log_metrics(self, d: dict) -> None:
        for k, v in d.items():
            self.log_metric(k, v)

    def log_param(self, key: str, value: Any) -> None:
        self.params[key] = value
        if self._mlflow_run and _MLFLOW_AVAILABLE:
            try:
                mlflow.log_param(key, str(value))
            except Exception:
                pass

    def log_params(self, d: dict) -> None:
        for k, v in d.items():
            self.log_param(k, v)

    def set_tag(self, key: str, value: str) -> None:
        self.tags[key] = value
        if self._mlflow_run and _MLFLOW_AVAILABLE:
            try:
                mlflow.set_tag(key, value)
            except Exception:
                pass

    def log_artifact(self, name: str, data: Any, artifact_dir: Optional[Path] = None) -> str:
        """
        Serialise data to a JSON file in the artifacts directory and record the path.
        Returns the file path.
        """
        art_dir = artifact_dir or _DEFAULT_ART_DIR
        art_dir.mkdir(parents=True, exist_ok=True)
        path = art_dir / f"{self.run_id[:8]}_{name}"

        if not str(path).endswith(".json"):
            path = Path(str(path) + ".json")

        with open(path, "w") as f:
            json.dump(data, f, indent=2, default=str)

        self.artifact_paths.append(str(path))

        if self._mlflow_run and _MLFLOW_AVAILABLE:
            try:
                mlflow.log_artifact(str(path))
            except Exception:
                pass

        return str(path)

    def manifest(self) -> dict:
        """Return a fully reproducible run manifest dict."""
        return {
            "run_id":          self.run_id,
            "experiment_name": self.experiment_name,
            "status":          self.status,
            "params":          self.params,
            "metrics":         self.metrics,
            "tags":            self.tags,
            "dataset_hash":    self.dataset_hash,
            "artifact_paths":  self.artifact_paths,
            "started_at":      self.started_at,
            "ended_at":        self.ended_at,
            "duration_seconds":self.duration_seconds,
            "error":           self.error,
        }


# ---------------------------------------------------------------------------
# ExperimentTracker
# ---------------------------------------------------------------------------

class ExperimentTracker:
    """
    Central experiment tracker with MLflow + JSON dual-backend.

    Use as a context manager via start_run(), or create ExperimentRun
    objects directly for manual tracking.
    """

    def __init__(
        self,
        log_path:      Optional[Path] = None,
        artifact_dir:  Optional[Path] = None,
        mlflow_uri:    Optional[str]  = None,
    ):
        self._log_path     = log_path     or _DEFAULT_LOG_PATH
        self._artifact_dir = artifact_dir or _DEFAULT_ART_DIR
        self._mlflow_uri   = mlflow_uri   or getattr(settings, "mlflow_tracking_uri", "") or ""
        self._active_run:  Optional[ExperimentRun] = None

        # Initialise MLflow if available and configured
        if _MLFLOW_AVAILABLE and self._mlflow_uri:
            try:
                mlflow.set_tracking_uri(self._mlflow_uri)
                logger.info("MLflow tracking URI: %s", self._mlflow_uri)
            except Exception as exc:
                logger.warning("MLflow init failed: %s — using JSON fallback", exc)

    @contextmanager
    def start_run(
        self,
        experiment_name: str,
        params:          Optional[dict] = None,
        tags:            Optional[dict] = None,
        dataset_hash:    Optional[str]  = None,
    ) -> Generator[ExperimentRun, None, None]:
        """
        Context manager for a single experiment run.

            with tracker.start_run("calibration", params={...}) as run:
                run.log_metrics({...})
                run.log_artifact("weights.json", data)
        """
        run = ExperimentRun(
            experiment_name = experiment_name,
            params          = dict(params or {}),
            tags            = dict(tags or {}),
            dataset_hash    = dataset_hash,
            started_at      = datetime.now(timezone.utc).isoformat(),
        )
        self._active_run = run

        # Add standard tags
        run.set_tag("python_version", _python_version())
        run.set_tag("host",           os.uname().nodename)
        git_commit = _git_commit()
        if git_commit:
            run.set_tag("git_commit", git_commit)

        # MLflow start
        mlflow_run = None
        if _MLFLOW_AVAILABLE and self._mlflow_uri:
            try:
                mlflow.set_experiment(experiment_name)
                mlflow_run = mlflow.start_run(run_name=run.run_id[:8])
                run._mlflow_run = mlflow_run
                for k, v in run.params.items():
                    mlflow.log_param(k, str(v))
            except Exception as exc:
                logger.warning("MLflow start_run failed: %s", exc)

        t_start = time.monotonic()

        try:
            yield run
            run.status = "completed"
        except Exception as exc:
            run.status = "failed"
            run.error  = str(exc)
            logger.error("ExperimentRun %s failed: %s", run.run_id[:8], exc)
            raise
        finally:
            run.ended_at        = datetime.now(timezone.utc).isoformat()
            run.duration_seconds = round(time.monotonic() - t_start, 3)

            # Persist to JSON log
            self._append_to_log(run)

            # MLflow end
            if mlflow_run and _MLFLOW_AVAILABLE:
                try:
                    mlflow.end_run(status="FINISHED" if run.status == "completed" else "FAILED")
                except Exception:
                    pass

            self._active_run = None

    def _append_to_log(self, run: ExperimentRun) -> None:
        """Append run manifest to the JSONL log file."""
        try:
            self._log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._log_path, "a") as f:
                f.write(json.dumps(run.manifest(), default=str) + "\n")
        except Exception as exc:
            logger.error("Failed to write experiment log: %s", exc)

    def list_runs(
        self,
        experiment_name: Optional[str] = None,
        limit:           int = 100,
    ) -> list[dict]:
        """
        Load and return past runs from the JSONL log, newest first.
        Optionally filter by experiment_name.
        """
        if not self._log_path.exists():
            return []

        results = []
        try:
            with open(self._log_path) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                        if experiment_name and obj.get("experiment_name") != experiment_name:
                            continue
                        results.append(obj)
                    except json.JSONDecodeError:
                        pass
        except Exception as exc:
            logger.warning("Failed to read experiment log: %s", exc)
            return []

        results.sort(key=lambda r: r.get("started_at", ""), reverse=True)
        return results[:limit]

    def best_run(
        self,
        experiment_name: str,
        metric:          str = "ic_oos",
        higher_is_better: bool = True,
    ) -> Optional[dict]:
        """Return the run with the best value of a given metric."""
        runs = self.list_runs(experiment_name)
        valid = [r for r in runs if r.get("metrics", {}).get(metric) is not None]
        if not valid:
            return None
        key_fn = lambda r: r["metrics"][metric]
        return max(valid, key=key_fn) if higher_is_better else min(valid, key=key_fn)

    def snapshot_dataset(
        self,
        events:          list[dict],
        name:            str = "training_data",
    ) -> str:
        """
        Serialise the event list to a JSONL artifact and return its SHA-256 hash.
        The hash is stable for the same dataset regardless of ordering.
        """
        art_dir  = self._artifact_dir
        art_dir.mkdir(parents=True, exist_ok=True)

        # Stable hash: sort by event_id before serialising
        sorted_events = sorted(events, key=lambda e: str(e.get("event_id", "")))
        payload       = json.dumps(sorted_events, sort_keys=True, default=str).encode()
        hash_hex      = hashlib.sha256(payload).hexdigest()

        path = art_dir / f"dataset_{name}_{hash_hex[:12]}.jsonl"
        if not path.exists():
            with open(path, "w") as f:
                for ev in sorted_events:
                    f.write(json.dumps(ev, default=str) + "\n")
            logger.info("Dataset snapshot: %s  (n=%d  hash=%s)", path, len(events), hash_hex[:12])
        else:
            logger.debug("Dataset snapshot already exists: %s", path)

        return hash_hex


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _python_version() -> str:
    import sys
    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"


def _git_commit() -> Optional[str]:
    """Return the current git commit hash, or None if git is unavailable."""
    try:
        import subprocess
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, timeout=3,
        )
        return result.stdout.strip() or None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Integration with calibration.py
# ---------------------------------------------------------------------------

def log_calibration_result(
    run:    ExperimentRun,
    result,                  # CalibrationResult
    prefix: str = "",
) -> None:
    """
    Convenience function to log a CalibrationResult into an ExperimentRun.
    """
    p = f"{prefix}." if prefix else ""
    run.log_metrics({
        f"{p}ic":            result.ic,
        f"{p}ic_oos":        result.ic_oos or 0.0,
        f"{p}n_samples":     result.n_samples,
        f"{p}r_squared":     result.r_squared or 0.0,
    })
    run.log_params({
        f"{p}method":        result.method,
        f"{p}horizon":       result.horizon,
        f"{p}interactions":  result.with_interactions,
    })
    run.log_artifact(f"{p}weights.json", result.weights)
    if result.notes:
        run.set_tag(f"{p}notes", result.notes[:250])


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

tracker = ExperimentTracker()
