"""
url_queue.py — PostgreSQL-backed persistent URL queue.
Crash-safe: discovered URLs survive process restarts.
"""
from __future__ import annotations
from asyncpg.pool import Pool


async def enqueue_urls(pool: Pool, urls: list[str]) -> None:
    """Add URLs to the crawl queue (idempotent)."""
    if not urls:
        return
    await pool.executemany("""
        INSERT INTO crawl_queue (url)
        VALUES ($1)
        ON CONFLICT (url) DO NOTHING
    """, [(u,) for u in urls])


async def dequeue_batch(pool: Pool, batch_size: int = 50) -> list[str]:
    """Atomically claim a batch of uncrawled URLs."""
    rows = await pool.fetch("""
        UPDATE crawl_queue
        SET    crawled = TRUE, crawled_at = NOW()
        WHERE  url IN (
            SELECT url FROM crawl_queue
            WHERE  NOT crawled
            ORDER  BY added_at
            LIMIT  $1
            FOR UPDATE SKIP LOCKED
        )
        RETURNING url
    """, batch_size)
    return [r["url"] for r in rows]


async def queue_size(pool: Pool) -> int:
    row = await pool.fetchrow("SELECT COUNT(*) FROM crawl_queue WHERE NOT crawled")
    return row[0] if row else 0
