"""
risk_throttle.py — §17 Risk-Throttling Engine.

Translates governance_confidence into concrete operational constraints.
Every sizing and exposure decision in the portfolio layer should pass
through this module before execution.

Architecture
------------
The throttle is a stateful object that:
  1. Ingests a GovernanceReport on each pipeline run.
  2. Applies hysteresis so the system doesn't flip between modes
     on every small confidence wiggle (requires N consecutive cycles
     at the new level before committing to a mode change).
  3. Exposes the current ThrottleState to the portfolio layer and
     any other caller that needs to know the current risk stance.

ThrottleState
-------------
  mode              str    — FULL | CAUTIOUS | REDUCED | DEFENSIVE | SUSPENDED
  size_scalar       float  — multiply all position notionals by this (0–1)
  max_positions     int    — maximum simultaneous open positions
  max_gross_exp     float  — maximum gross exposure as fraction of AUM
  signal_min_score  float  — minimum signal score to open a new position
  new_positions_ok  bool   — whether opening NEW positions is allowed
  message           str    — human-readable explanation of current stance

Hysteresis
----------
Tightening (confidence falls) is IMMEDIATE — safety first.
Loosening  (confidence rises) requires GOV_HYSTERESIS_CYCLES consecutive
positive cycles before the mode upgrades (default: 3).

This prevents whipsawing the portfolio during short-lived data glitches.

Usage
-----
    from governance_engine import GovernanceEngine
    from risk_throttle import RiskThrottle

    gov      = GovernanceEngine(...)
    throttle = RiskThrottle()

    report = await gov.assess(market_state=ms)
    state  = throttle.update(report)

    # In the portfolio layer:
    if not state.new_positions_ok:
        return []   # no new trades

    sized_orders = [
        Order(notional = raw_notional * state.size_scalar, ...)
        for raw_notional in raw_notionals
        if signal_score >= state.signal_min_score
    ][:state.max_positions]
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from governance_engine import GovernanceReport

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Mode definitions
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ModeConfig:
    mode:             str
    size_scalar:      float  # multiply all notionals by this
    max_positions:    int    # absolute cap on simultaneous positions
    max_gross_exp:    float  # max gross exposure (fraction of AUM)
    signal_min_score: float  # minimum signal score to open a position
    new_positions_ok: bool   # whether to allow any new entries


_MODE_CONFIGS: dict[str, ModeConfig] = {
    "FULL": ModeConfig(
        mode             = "FULL",
        size_scalar      = 1.00,
        max_positions    = 20,
        max_gross_exp    = 1.00,
        signal_min_score = 0.40,
        new_positions_ok = True,
    ),
    "CAUTIOUS": ModeConfig(
        mode             = "CAUTIOUS",
        size_scalar      = 0.75,
        max_positions    = 15,
        max_gross_exp    = 0.75,
        signal_min_score = 0.50,
        new_positions_ok = True,
    ),
    "REDUCED": ModeConfig(
        mode             = "REDUCED",
        size_scalar      = 0.50,
        max_positions    = 10,
        max_gross_exp    = 0.50,
        signal_min_score = 0.60,
        new_positions_ok = True,
    ),
    "DEFENSIVE": ModeConfig(
        mode             = "DEFENSIVE",
        size_scalar      = 0.25,
        max_positions    = 5,
        max_gross_exp    = 0.25,
        signal_min_score = 0.75,
        new_positions_ok = True,
    ),
    "SUSPENDED": ModeConfig(
        mode             = "SUSPENDED",
        size_scalar      = 0.00,
        max_positions    = 0,
        max_gross_exp    = 0.00,
        signal_min_score = 1.00,
        new_positions_ok = False,
    ),
}

# Mode severity order (higher index = more restrictive)
_MODE_ORDER = ["FULL", "CAUTIOUS", "REDUCED", "DEFENSIVE", "SUSPENDED"]


def _float_env(key: str, default: float) -> float:
    try:
        return float(os.environ[key])
    except (KeyError, ValueError):
        return default


def _int_env(key: str, default: int) -> int:
    try:
        return int(os.environ[key])
    except (KeyError, ValueError):
        return default


_HYSTERESIS_CYCLES = _int_env("GOV_HYSTERESIS_CYCLES", 3)


# ---------------------------------------------------------------------------
# ThrottleState
# ---------------------------------------------------------------------------

@dataclass
class ThrottleState:
    mode:             str
    size_scalar:      float
    max_positions:    int
    max_gross_exp:    float
    signal_min_score: float
    new_positions_ok: bool
    governance_confidence: float
    message:          str
    warnings:         list[str]
    updated_at:       datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @classmethod
    def from_config(
        cls,
        cfg:                    ModeConfig,
        governance_confidence:  float,
        message:                str,
        warnings:               list[str],
    ) -> "ThrottleState":
        return cls(
            mode                  = cfg.mode,
            size_scalar           = cfg.size_scalar,
            max_positions         = cfg.max_positions,
            max_gross_exp         = cfg.max_gross_exp,
            signal_min_score      = cfg.signal_min_score,
            new_positions_ok      = cfg.new_positions_ok,
            governance_confidence = governance_confidence,
            message               = message,
            warnings              = warnings,
        )

    def apply_to_notional(self, raw_notional: float) -> float:
        """Scale a raw position notional by the current size scalar."""
        return raw_notional * self.size_scalar

    def filter_signals(self, signals: list[dict]) -> list[dict]:
        """
        Filter and cap a list of signal dicts by current throttle state.
        Expects each dict to have 'signal_score' and optionally 'signal_tier'.
        """
        if not self.new_positions_ok:
            return []
        passing = [s for s in signals if s.get("signal_score", 0.0) >= self.signal_min_score]
        # Sort by score descending; cap at max_positions
        passing.sort(key=lambda s: s.get("signal_score", 0.0), reverse=True)
        return passing[: self.max_positions]

    def summary(self) -> str:
        return (
            f"ThrottleState(mode={self.mode}, confidence={self.governance_confidence:.3f}, "
            f"scalar={self.size_scalar:.2f}, max_pos={self.max_positions}, "
            f"min_score={self.signal_min_score:.2f}, new_ok={self.new_positions_ok})"
        )


# ---------------------------------------------------------------------------
# RiskThrottle
# ---------------------------------------------------------------------------

class RiskThrottle:
    """
    Stateful risk throttle with hysteresis, minimum dwell times,
    instability memory, and asymmetric breach penalties.

    #5 Minimum dwell times: once the system enters a mode, it must stay
    there for at least N cycles regardless of confidence improvement.
    Prevents mode-flapping on noisy governance signals.

    #6 Memory + decay: the throttle remembers past instability episodes
    and applies a decaying penalty even after conditions improve.
    Models how a human PM would behave: cautious for a while after a scare.
    """

    # Minimum cycles to dwell in each mode before loosening
    _MIN_DWELL: dict[str, int] = {
        "FULL":      1,    # can tighten any time
        "CAUTIOUS":  2,
        "REDUCED":   3,
        "DEFENSIVE": 4,
        "SUSPENDED": 0,    # recovery managed by kill-switch cooldown
    }

    def __init__(self, hysteresis_cycles: int = _HYSTERESIS_CYCLES) -> None:
        self._hysteresis_cycles  = hysteresis_cycles
        self._current_mode: str  = "FULL"
        self._pending_mode: Optional[str] = None
        self._pending_count: int = 0
        self._last_report:   Optional[GovernanceReport] = None
        self._state:         Optional[ThrottleState] = None

        # #5 Dwell tracking
        self._mode_entered_cycle: int = 0
        self._cycle_count:        int = 0
        self._dwell_cycles_in_mode: int = 0

        # #6 Instability memory: exponentially decaying penalty
        # Accumulated when confidence drops; decays each cycle
        self._instability_memory:  float = 0.0
        self._memory_decay_rate:   float = 0.85     # per cycle
        self._memory_charge_rate:  float = 0.20     # per breach cycle
        self._memory_max:          float = 0.40     # max penalty on size_scalar

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    def update(self, report: GovernanceReport) -> ThrottleState:
        """
        Ingest a GovernanceReport and return the resulting ThrottleState.
        Applies hysteresis, minimum dwell times, and instability memory.
        """
        self._last_report  = report
        self._cycle_count += 1
        new_mode           = report.mode

        current_severity = _MODE_ORDER.index(self._current_mode)
        new_severity     = _MODE_ORDER.index(new_mode)

        # #6 Update instability memory
        if new_severity > current_severity or (
            report.governance_confidence < 0.60
        ):
            # Charging: bad cycle → add to memory
            self._instability_memory = min(
                self._memory_max,
                self._instability_memory + self._memory_charge_rate
            )
        else:
            # Decaying: good cycle → memory fades
            self._instability_memory *= self._memory_decay_rate

        mode_changed = False

        if new_severity > current_severity:
            # Tightening — immediate; reset dwell
            self._current_mode       = new_mode
            self._pending_mode       = None
            self._pending_count      = 0
            self._dwell_cycles_in_mode = 0
            mode_changed = True
            reason = f"Tightened immediately: confidence={report.governance_confidence:.3f}"
            logger.warning(
                "Risk throttle TIGHTENED: %s → %s (confidence=%.3f, warnings=%s)",
                _MODE_ORDER[current_severity], new_mode,
                report.governance_confidence, report.warnings,
            )

        elif new_severity < current_severity:
            # #5 Check minimum dwell before allowing loosening
            self._dwell_cycles_in_mode += 1
            min_dwell = self._MIN_DWELL.get(self._current_mode, 1)

            if self._dwell_cycles_in_mode < min_dwell:
                reason = (
                    f"Min dwell not met for {self._current_mode} "
                    f"({self._dwell_cycles_in_mode}/{min_dwell} cycles)"
                )
                logger.debug(reason)
            else:
                # Hysteresis: require N consecutive clean cycles
                if self._pending_mode == new_mode:
                    self._pending_count += 1
                else:
                    self._pending_mode  = new_mode
                    self._pending_count = 1

                if self._pending_count >= self._hysteresis_cycles:
                    prev_mode               = self._current_mode
                    self._current_mode      = new_mode
                    self._pending_mode      = None
                    self._pending_count     = 0
                    self._dwell_cycles_in_mode = 0
                    mode_changed            = True
                    reason = (
                        f"Loosened after {self._hysteresis_cycles} cycles + dwell: "
                        f"confidence={report.governance_confidence:.3f}"
                    )
                    logger.info("Risk throttle LOOSENED: %s → %s", prev_mode, new_mode)
                else:
                    reason = (
                        f"Holding {self._current_mode} (pending {new_mode}: "
                        f"{self._pending_count}/{self._hysteresis_cycles} cycles)"
                    )
        else:
            self._dwell_cycles_in_mode += 1
            self._pending_mode  = None
            self._pending_count = 0
            reason = f"Stable at {self._current_mode} (confidence={report.governance_confidence:.3f})"

        cfg = _MODE_CONFIGS[self._current_mode]

        # #6 Apply instability memory penalty to size_scalar
        memory_discount = self._instability_memory   # [0, memory_max]
        effective_scalar = max(0.0, cfg.size_scalar * (1.0 - memory_discount))
        if memory_discount > 0.05:
            reason += f" | memory_discount={memory_discount:.2f}"

        state = ThrottleState(
            mode                  = cfg.mode,
            size_scalar           = round(effective_scalar, 4),
            max_positions         = cfg.max_positions,
            max_gross_exp         = cfg.max_gross_exp,
            signal_min_score      = cfg.signal_min_score,
            new_positions_ok      = cfg.new_positions_ok,
            governance_confidence = report.governance_confidence,
            message               = reason,
            warnings              = report.warnings,
        )
        self._state = state

        logger.info("ThrottleState: %s  memory=%.3f", state.summary(), self._instability_memory)
        return state

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def current_mode(self) -> str:
        return self._current_mode

    @property
    def state(self) -> Optional[ThrottleState]:
        return self._state

    def is_deployable(self) -> bool:
        """True if opening new positions is currently allowed."""
        return self._current_mode != "SUSPENDED"

    def force_mode(self, mode: str, reason: str = "manual override") -> ThrottleState:
        """
        Override the current mode directly (e.g. from kill-switch or operator).
        Bypasses hysteresis.
        """
        if mode not in _MODE_CONFIGS:
            raise ValueError(f"Unknown mode: {mode}. Valid: {list(_MODE_CONFIGS)}")
        prev = self._current_mode
        self._current_mode  = mode
        self._pending_mode  = None
        self._pending_count = 0
        cfg   = _MODE_CONFIGS[mode]
        state = ThrottleState.from_config(
            cfg                   = cfg,
            governance_confidence = self._last_report.governance_confidence if self._last_report else 0.0,
            message               = f"FORCED: {reason} (was {prev})",
            warnings              = [f"manual_override: {reason}"],
        )
        self._state = state
        logger.warning("Risk throttle FORCED to %s: %s", mode, reason)
        return state

    def reset(self) -> None:
        """Reset to default state (FULL). Use with caution."""
        self._current_mode  = "FULL"
        self._pending_mode  = None
        self._pending_count = 0
        self._state         = None
        logger.info("Risk throttle reset to FULL")


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_throttle: Optional[RiskThrottle] = None


def get_throttle(hysteresis_cycles: int = _HYSTERESIS_CYCLES) -> RiskThrottle:
    global _throttle
    if _throttle is None:
        _throttle = RiskThrottle(hysteresis_cycles=hysteresis_cycles)
    return _throttle
