"""
data_connectors.py — §22 Structured Data Source Connectors.

Three free, high-value data sources:

1. FRED (Federal Reserve Economic Data) — macro indicators
   - Requires FRED_API_KEY (free at https://fred.stlouisfed.org/docs/api/api_key.html)
   - Fetches CPI, unemployment, fed funds rate, yield curve, VIX, etc.
   - Results cached for FRED_CACHE_TTL_SECONDS (default 3600)

2. SEC EDGAR Full-Text Search — corporate filings
   - No API key required; uses the public EFTS endpoint
   - Searches 8-K, 10-K, 10-Q, S-1, proxy statements by keyword
   - Returns structured filing metadata (company, CIK, date, form, URL)
   - Rate-limited to 10 requests/second per SEC fair-use policy

3. Options Chain (yfinance) — market-implied sentiment
   - IV (implied volatility), put/call ratio, max-pain price
   - Returns OptionsSnapshot dataclass per ticker
   - Cached for OPTIONS_CACHE_TTL_SECONDS (default 900)

All connectors return typed dataclasses and degrade gracefully:
- Missing API key → returns None + logs warning
- Network error → returns None + logs warning
- Stale cache → returns cached value + sets is_stale=True

Usage
-----
    from data_connectors import fred, edgar, options

    # FRED
    macro = await fred.get_macro_snapshot()
    print(macro.fed_funds_rate, macro.cpi_yoy, macro.unemployment_rate)

    # SEC EDGAR
    filings = await edgar.search("NVIDIA earnings guidance", form_types=["8-K"], limit=5)
    for f in filings:
        print(f.company_name, f.filed_at, f.filing_url)

    # Options
    snap = await options.get_snapshot("AAPL")
    print(snap.put_call_ratio, snap.iv_30d, snap.max_pain)
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

from config import settings

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
# §22-A  FRED Connector
# ─────────────────────────────────────────────────────────────────────────────

_FRED_BASE = "https://api.stlouisfed.org/fred/series/observations"

# Key macro series and their FRED IDs
_FRED_SERIES: dict[str, str] = {
    "fed_funds_rate":    "FEDFUNDS",
    "cpi_yoy":           "CPIAUCSL",       # CPI (need to compute YoY ourselves)
    "unemployment_rate": "UNRATE",
    "gdp_growth":        "A191RL1Q225SBEA",# Real GDP growth QoQ annualised
    "yield_10y":         "GS10",           # 10-year Treasury
    "yield_2y":          "GS2",            # 2-year Treasury
    "yield_3m":          "TB3MS",          # 3-month Treasury bill
    "m2_growth":         "M2SL",
    "pce_yoy":           "PCEPI",          # PCE inflation (Fed's preferred)
    "industrial_prod":   "INDPRO",
    "retail_sales":      "RSAFS",
    "housing_starts":    "HOUST",
    "consumer_conf":     "UMCSENT",        # U of Michigan consumer sentiment
    "credit_spread_hy":  "BAMLH0A0HYM2",  # HY spread (OAS)
    "credit_spread_ig":  "BAMLC0A0CM",    # IG spread (OAS)
}


@dataclass
class MacroSnapshot:
    """Latest reading of key FRED macro indicators."""
    fed_funds_rate:    Optional[float] = None   # %
    cpi_yoy:           Optional[float] = None   # % year-over-year
    pce_yoy:           Optional[float] = None   # % year-over-year
    unemployment_rate: Optional[float] = None   # %
    gdp_growth:        Optional[float] = None   # % annualised
    yield_10y:         Optional[float] = None   # %
    yield_2y:          Optional[float] = None   # %
    yield_3m:          Optional[float] = None   # %
    yield_curve_10y2y: Optional[float] = None   # 10Y − 2Y spread
    yield_curve_10y3m: Optional[float] = None   # 10Y − 3M spread
    m2_growth:         Optional[float] = None   # % YoY
    industrial_prod:   Optional[float] = None   # index level
    retail_sales:      Optional[float] = None   # millions USD
    housing_starts:    Optional[float] = None   # thousands, annualised
    consumer_conf:     Optional[float] = None   # index
    credit_spread_hy:  Optional[float] = None   # bps
    credit_spread_ig:  Optional[float] = None   # bps
    fetched_at:        datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_stale:          bool = True
    missing_series:    list[str] = field(default_factory=list)


class FREDConnector:
    """
    Fetches macro indicators from the FRED API.
    Requires FRED_API_KEY environment variable.
    """

    def __init__(self):
        self._cache: Optional[tuple[float, MacroSnapshot]] = None
        self._lock  = asyncio.Lock()

    def _api_key(self) -> Optional[str]:
        key = getattr(settings, "fred_api_key", None) or ""
        return key.strip() or None

    async def get_macro_snapshot(
        self,
        force_refresh: bool = False,
    ) -> Optional[MacroSnapshot]:
        """
        Return the latest macro snapshot. Returns None if no API key is configured.
        Results are cached for FRED_CACHE_TTL_SECONDS.
        """
        api_key = self._api_key()
        if not api_key:
            logger.debug("FRED_API_KEY not configured — skipping macro snapshot")
            return None

        ttl = float(getattr(settings, "fred_cache_ttl_seconds", 3600))

        async with self._lock:
            now = time.monotonic()
            if not force_refresh and self._cache:
                expires, cached = self._cache
                if now < expires:
                    return cached

            snap = await self._fetch(api_key)
            self._cache = (now + ttl, snap)
            return snap

    async def _fetch(self, api_key: str) -> MacroSnapshot:
        try:
            import aiohttp
        except ImportError:
            logger.warning("aiohttp not installed — cannot fetch FRED data")
            return MacroSnapshot(is_stale=True)

        raw: dict[str, Optional[float]] = {}
        missing: list[str] = []

        async with aiohttp.ClientSession() as session:
            for field_name, series_id in _FRED_SERIES.items():
                try:
                    params = {
                        "series_id":       series_id,
                        "api_key":         api_key,
                        "file_type":       "json",
                        "sort_order":      "desc",
                        "limit":           "13",   # 13 months for YoY
                        "observation_start": (
                            datetime.now(timezone.utc) - timedelta(days=400)
                        ).strftime("%Y-%m-%d"),
                    }
                    async with session.get(
                        _FRED_BASE, params=params, timeout=aiohttp.ClientTimeout(total=10)
                    ) as resp:
                        if resp.status != 200:
                            missing.append(field_name)
                            continue
                        data = await resp.json()
                        obs  = [
                            o for o in data.get("observations", [])
                            if o.get("value") not in (".", "")
                        ]
                        if not obs:
                            missing.append(field_name)
                            continue
                        # Most recent observation
                        latest = float(obs[0]["value"])
                        # YoY for CPI and PCE
                        if field_name in ("cpi_yoy", "pce_yoy", "m2_growth") and len(obs) >= 13:
                            year_ago = float(obs[12]["value"])
                            raw[field_name] = round((latest / year_ago - 1) * 100, 2)
                        else:
                            raw[field_name] = round(latest, 4)

                except Exception as exc:
                    logger.debug("FRED series %s failed: %s", series_id, exc)
                    missing.append(field_name)

        # Derived fields
        y10 = raw.get("yield_10y")
        y2  = raw.get("yield_2y")
        y3m = raw.get("yield_3m")
        curve_10y2y = round(y10 - y2,  4) if y10 is not None and y2  is not None else None
        curve_10y3m = round(y10 - y3m, 4) if y10 is not None and y3m is not None else None

        logger.info(
            "FRED snapshot fetched: %d series OK, %d missing",
            len(_FRED_SERIES) - len(missing), len(missing),
        )
        return MacroSnapshot(
            fed_funds_rate    = raw.get("fed_funds_rate"),
            cpi_yoy           = raw.get("cpi_yoy"),
            pce_yoy           = raw.get("pce_yoy"),
            unemployment_rate = raw.get("unemployment_rate"),
            gdp_growth        = raw.get("gdp_growth"),
            yield_10y         = y10,
            yield_2y          = y2,
            yield_3m          = y3m,
            yield_curve_10y2y = curve_10y2y,
            yield_curve_10y3m = curve_10y3m,
            m2_growth         = raw.get("m2_growth"),
            industrial_prod   = raw.get("industrial_prod"),
            retail_sales      = raw.get("retail_sales"),
            housing_starts    = raw.get("housing_starts"),
            consumer_conf     = raw.get("consumer_conf"),
            credit_spread_hy  = raw.get("credit_spread_hy"),
            credit_spread_ig  = raw.get("credit_spread_ig"),
            fetched_at        = datetime.now(timezone.utc),
            is_stale          = False,
            missing_series    = missing,
        )


# ─────────────────────────────────────────────────────────────────────────────
# §22-B  SEC EDGAR Full-Text Search Connector
# ─────────────────────────────────────────────────────────────────────────────

_EDGAR_EFTS  = "https://efts.sec.gov/LATEST/search-index?q={query}&dateRange=custom&startdt={start}&enddt={end}&forms={forms}&hits.hits._source=period_of_report,file_date,form_type,entity_name,file_num,period_of_report&hits.hits.total=true&hits.hits.highlight=false"
_EDGAR_FULL  = "https://efts.sec.gov/LATEST/search-index?q={query}&forms={forms}&hits.hits.total=true"
_EDGAR_UA    = "Finance-AI-Research-Bot contact@example.com"   # SEC requires User-Agent


@dataclass
class SECFiling:
    entity_name:  str
    cik:          str
    form_type:    str
    filed_at:     str         # ISO date string
    period:       str         # reporting period
    filing_url:   str
    accession:    str


class EDGARConnector:
    """
    Searches SEC EDGAR full-text search (no API key required).
    Rate-limited to 10 requests/second per SEC fair-use policy.
    """

    _last_request_time: float = 0.0
    _min_interval: float = 0.11   # ~9 req/s (below 10/s limit)

    async def search(
        self,
        query:      str,
        form_types: Optional[list[str]] = None,
        days_back:  int = 30,
        limit:      int = 10,
    ) -> list[SECFiling]:
        """
        Full-text search across SEC filings.

        Parameters
        ----------
        query       Keywords to search (e.g. "guidance revenue miss")
        form_types  Filing types to filter: ["8-K", "10-K", "10-Q", "S-1"]
                    Defaults to 8-K (material event disclosures)
        days_back   Look back this many days from today
        limit       Maximum number of filings to return
        """
        if form_types is None:
            form_types = ["8-K"]

        try:
            import aiohttp
        except ImportError:
            logger.warning("aiohttp not installed — cannot search EDGAR")
            return []

        # Rate limit
        now = time.monotonic()
        wait = self._min_interval - (now - self.__class__._last_request_time)
        if wait > 0:
            await asyncio.sleep(wait)
        self.__class__._last_request_time = time.monotonic()

        start_date = (datetime.now(timezone.utc) - timedelta(days=days_back)).strftime("%Y-%m-%d")
        end_date   = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        forms_str  = ",".join(form_types)

        # Build EFTS query URL
        import urllib.parse
        q_enc = urllib.parse.quote_plus(query)
        url   = (
            f"https://efts.sec.gov/LATEST/search-index"
            f"?q={q_enc}"
            f"&dateRange=custom&startdt={start_date}&enddt={end_date}"
            f"&forms={forms_str}"
            f"&hits.hits.total=true"
        )

        try:
            async with aiohttp.ClientSession(headers={"User-Agent": _EDGAR_UA}) as session:
                async with session.get(url, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                    if resp.status != 200:
                        logger.warning("EDGAR search returned HTTP %d", resp.status)
                        return []
                    data = await resp.json(content_type=None)
        except Exception as exc:
            logger.warning("EDGAR search failed: %s", exc)
            return []

        hits = data.get("hits", {}).get("hits", [])
        results: list[SECFiling] = []

        for hit in hits[:limit]:
            src = hit.get("_source", {})
            entity   = src.get("entity_name", "") or src.get("display_names", [""])[0]
            cik      = src.get("ciks", [""])[0] if src.get("ciks") else ""
            form     = src.get("form_type", "")
            filed    = src.get("file_date", "")
            period   = src.get("period_of_report", "")
            acc      = hit.get("_id", "")

            # Build direct filing URL
            acc_fmt = acc.replace("-", "")
            filing_url = f"https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK={cik}&type={form}&dateb=&owner=include&count=10"
            if acc:
                filing_url = f"https://www.sec.gov/Archives/edgar/data/{cik}/{acc_fmt}/{acc}-index.htm"

            results.append(SECFiling(
                entity_name = entity,
                cik         = cik,
                form_type   = form,
                filed_at    = filed,
                period      = period,
                filing_url  = filing_url,
                accession   = acc,
            ))

        logger.info(
            "EDGAR search '%s' (forms=%s, days=%d): %d results",
            query[:50], forms_str, days_back, len(results),
        )
        return results

    async def get_recent_8k(
        self,
        company_name: str,
        days_back: int = 14,
        limit: int = 5,
    ) -> list[SECFiling]:
        """Convenience: fetch recent 8-K filings for a specific company."""
        return await self.search(
            query      = company_name,
            form_types = ["8-K"],
            days_back  = days_back,
            limit      = limit,
        )


# ─────────────────────────────────────────────────────────────────────────────
# §22-C  Options Chain Connector (yfinance)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class OptionsSnapshot:
    """Market-implied sentiment indicators from the options chain."""
    ticker:         str
    # Sentiment indicators
    put_call_ratio: Optional[float] = None   # OI-weighted; >1 = bearish skew
    iv_30d:         Optional[float] = None   # 30-day ATM implied volatility (%)
    iv_skew:        Optional[float] = None   # 25-delta put IV − call IV (skew)
    max_pain:       Optional[float] = None   # price at which most options expire worthless
    # Term structure
    iv_term_slope:  Optional[float] = None   # front_iv - back_iv (contango vs backwardation)
    # Volume signals
    call_vol_surge: bool = False             # call volume > 2× avg open interest
    put_vol_surge:  bool = False             # put  volume > 2× avg open interest
    # Metadata
    fetched_at:     datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_stale:       bool = True
    expiry_used:    str = ""                 # expiry date used for IV calculation


class OptionsConnector:
    """Fetches options chain data using yfinance."""

    def __init__(self):
        self._cache: dict[str, tuple[float, OptionsSnapshot]] = {}
        self._lock = asyncio.Lock()

    async def get_snapshot(
        self,
        ticker:        str,
        force_refresh: bool = False,
    ) -> Optional[OptionsSnapshot]:
        """
        Return an OptionsSnapshot for the given ticker.
        Returns None if yfinance is unavailable or no options data exists.
        """
        ttl = float(getattr(settings, "options_cache_ttl_seconds", 900))

        async with self._lock:
            now = time.monotonic()
            if not force_refresh and ticker in self._cache:
                expires, cached = self._cache[ticker]
                if now < expires:
                    return cached

            loop = asyncio.get_running_loop()
            try:
                snap = await loop.run_in_executor(None, self._fetch_sync, ticker)
            except Exception as exc:
                logger.warning("Options fetch failed for %s: %s", ticker, exc)
                snap = OptionsSnapshot(ticker=ticker, is_stale=True)

            self._cache[ticker] = (now + ttl, snap)
            return snap

    def _fetch_sync(self, ticker: str) -> OptionsSnapshot:
        try:
            import yfinance as yf
        except ImportError:
            logger.warning("yfinance not installed — cannot fetch options")
            return OptionsSnapshot(ticker=ticker, is_stale=True)

        try:
            obj      = yf.Ticker(ticker)
            expiries = obj.options
            if not expiries:
                return OptionsSnapshot(ticker=ticker, is_stale=True)

            # Use the nearest expiry ≥ 20 days out for a clean 30-day IV proxy
            from datetime import date
            today     = date.today()
            target    = today + timedelta(days=20)
            usable    = [e for e in expiries
                         if datetime.strptime(e, "%Y-%m-%d").date() >= target]
            expiry    = usable[0] if usable else expiries[0]

            chain  = obj.option_chain(expiry)
            calls  = chain.calls
            puts   = chain.puts

            if calls.empty or puts.empty:
                return OptionsSnapshot(ticker=ticker, is_stale=True)

            # Put/call ratio (open-interest weighted)
            call_oi = float(calls["openInterest"].sum())
            put_oi  = float(puts["openInterest"].sum())
            pc_ratio = round(put_oi / call_oi, 4) if call_oi > 0 else None

            # ATM IV proxy: find option closest to current price
            current_price = obj.info.get("regularMarketPrice") or obj.info.get("currentPrice")
            if current_price:
                atm_calls = calls.iloc[(calls["strike"] - current_price).abs().argsort()[:1]]
                atm_puts  = puts.iloc[(puts["strike"]  - current_price).abs().argsort()[:1]]
                atm_call_iv = float(atm_calls["impliedVolatility"].iloc[0]) if not atm_calls.empty else None
                atm_put_iv  = float(atm_puts["impliedVolatility"].iloc[0])  if not atm_puts.empty  else None
                iv_30d = round(((atm_call_iv or 0) + (atm_put_iv or 0)) / 2 * 100, 2) if atm_call_iv and atm_put_iv else None
                iv_skew = round((atm_put_iv - atm_call_iv) * 100, 2) if atm_put_iv and atm_call_iv else None
            else:
                iv_30d = iv_skew = current_price = None

            # Max pain: price where total $ value of expiring options is minimised
            max_pain = self._compute_max_pain(calls, puts)

            # Volume surge: current vol > 2× avg OI
            call_vol = float(calls["volume"].sum())
            put_vol  = float(puts["volume"].sum())
            call_surge = call_vol > 2 * call_oi if call_oi > 0 else False
            put_surge  = put_vol  > 2 * put_oi  if put_oi  > 0 else False

            # IV term structure slope (front vs back month)
            iv_term_slope = None
            if len(usable) >= 2:
                try:
                    back_chain  = obj.option_chain(usable[1])
                    if current_price and not back_chain.calls.empty:
                        bc_atm   = back_chain.calls.iloc[
                            (back_chain.calls["strike"] - current_price).abs().argsort()[:1]
                        ]
                        back_iv  = float(bc_atm["impliedVolatility"].iloc[0]) * 100
                        if iv_30d:
                            iv_term_slope = round(iv_30d - back_iv, 2)
                except Exception:
                    pass

            logger.info(
                "Options snapshot %s: P/C=%.2f  IV30d=%.1f%%  MaxPain=%.2f",
                ticker,
                pc_ratio or 0,
                iv_30d or 0,
                max_pain or 0,
            )
            return OptionsSnapshot(
                ticker         = ticker,
                put_call_ratio = pc_ratio,
                iv_30d         = iv_30d,
                iv_skew        = iv_skew,
                max_pain       = max_pain,
                iv_term_slope  = iv_term_slope,
                call_vol_surge = call_surge,
                put_vol_surge  = put_surge,
                fetched_at     = datetime.now(timezone.utc),
                is_stale       = False,
                expiry_used    = expiry,
            )

        except Exception as exc:
            logger.warning("Options chain processing failed for %s: %s", ticker, exc)
            return OptionsSnapshot(ticker=ticker, is_stale=True)

    @staticmethod
    def _compute_max_pain(calls, puts) -> Optional[float]:
        """
        Max pain = strike price where total intrinsic value of open
        interest (ITM options) across all strikes is minimised.
        """
        try:
            import numpy as np
            strikes = sorted(set(calls["strike"].tolist() + puts["strike"].tolist()))
            if not strikes:
                return None

            call_oi_map = dict(zip(calls["strike"], calls["openInterest"].fillna(0)))
            put_oi_map  = dict(zip(puts["strike"],  puts["openInterest"].fillna(0)))

            total_pain = []
            for s in strikes:
                call_pain = sum(max(0, s - k) * call_oi_map.get(k, 0) for k in strikes)
                put_pain  = sum(max(0, k - s) * put_oi_map.get(k, 0)  for k in strikes)
                total_pain.append(call_pain + put_pain)

            min_idx = int(total_pain.index(min(total_pain)))
            return float(strikes[min_idx])
        except Exception:
            return None


# ─────────────────────────────────────────────────────────────────────────────
# Module-level singletons
# ─────────────────────────────────────────────────────────────────────────────

fred    = FREDConnector()
edgar   = EDGARConnector()
options = OptionsConnector()
