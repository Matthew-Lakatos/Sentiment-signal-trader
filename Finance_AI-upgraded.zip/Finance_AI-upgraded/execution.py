"""
execution.py — realistic trade execution modelling for backtesting.

Problems this solves
--------------------
1. Look-ahead leakage:  events scraped at 14:32 must NOT use same-day close;
                        they must use next-day open (or later).
2. Slippage modelling:  fill price = reference_price × (1 ± slippage_bps/10000)
3. Market hours:        NYSE 09:30–16:00 ET; events outside hours shift to next open.
4. Execution delay:     configurable minimum delay between event and fill (default 15 min).
5. Timestamp audit:     flags events where the scraped_at is AFTER the price used
                        (a definitive sign of leakage).

Usage (inside backtest)
-----------------------
    from execution import ExecutionEngine, TradeRecord

    engine = ExecutionEngine(delay_minutes=15, slippage_bps=10)
    trade  = engine.simulate_fill(
        event_ts   = scraped_at,
        price_df   = price_df,
        direction  = "LONG",    # or "SHORT"
        notional   = 10_000,
    )
    if trade.leakage_flag:
        logger.warning("Leakage detected for event %s", event_id)
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone, time as dtime
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# NYSE market hours (Eastern Time, naive — price data is typically tz-naive)
# ---------------------------------------------------------------------------

_MARKET_OPEN_ET  = dtime(9, 30)
_MARKET_CLOSE_ET = dtime(16, 0)

# US market holidays (incomplete — extend as needed)
_US_HOLIDAYS_2024_2026: set[str] = {
    "2024-01-01", "2024-01-15", "2024-02-19", "2024-03-29",
    "2024-05-27", "2024-06-19", "2024-07-04", "2024-09-02",
    "2024-11-28", "2024-12-25",
    "2025-01-01", "2025-01-20", "2025-02-17", "2025-04-18",
    "2025-05-26", "2025-06-19", "2025-07-04", "2025-09-01",
    "2025-11-27", "2025-12-25",
    "2026-01-01", "2026-01-19", "2026-02-16", "2026-04-03",
    "2026-05-25", "2026-06-19", "2026-07-03", "2026-09-07",
    "2026-11-26", "2026-12-25",
}


def is_market_day(dt: datetime) -> bool:
    """True if dt falls on a trading day (Mon–Fri, not a US holiday)."""
    return dt.weekday() < 5 and dt.strftime("%Y-%m-%d") not in _US_HOLIDAYS_2024_2026


def next_market_open(dt: datetime) -> datetime:
    """
    Return the next NYSE open after dt.
    If dt is before market open on a trading day, return today's open.
    If dt is after market close, return next trading day's open.
    """
    # Strip timezone for arithmetic (price data is tz-naive)
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None) - timedelta(hours=4)  # rough ET

    candidate = dt.replace(hour=9, minute=30, second=0, microsecond=0)
    if dt.time() >= _MARKET_CLOSE_ET or not is_market_day(dt):
        # Move to next calendar day then find a market day
        candidate = candidate + timedelta(days=1)

    while not is_market_day(candidate):
        candidate += timedelta(days=1)

    return candidate


# ---------------------------------------------------------------------------
# Slippage model
# ---------------------------------------------------------------------------

def apply_slippage(price: float, direction: str, slippage_bps: float) -> float:
    """
    Apply half-spread slippage.
    LONG  → buy  at price × (1 + bps/10000)
    SHORT → sell at price × (1 - bps/10000)
    """
    factor = slippage_bps / 10_000.0
    if direction.upper() == "LONG":
        return price * (1.0 + factor)
    return price * (1.0 - factor)


# ---------------------------------------------------------------------------
# Leakage detector
# ---------------------------------------------------------------------------

def check_leakage(event_ts: datetime, fill_ts: datetime, delay_minutes: int) -> bool:
    """
    Return True (leakage flag) if fill_ts is within delay_minutes of event_ts,
    or if fill_ts is somehow BEFORE event_ts.
    """
    if fill_ts <= event_ts:
        return True  # definitive look-ahead
    lag = (fill_ts - event_ts).total_seconds() / 60.0
    return lag < delay_minutes


# ---------------------------------------------------------------------------
# Trade record
# ---------------------------------------------------------------------------

@dataclass
class TradeRecord:
    event_ts:      datetime
    fill_ts:       datetime
    fill_price:    float
    exit_price:    Optional[float]        # None until closed
    direction:     str                    # LONG | SHORT
    notional:      float
    slippage_bps:  float
    delay_minutes: float                  # actual lag in minutes
    return_pct:    Optional[float] = None
    leakage_flag:  bool = False
    notes:         str  = ""

    def pnl(self) -> Optional[float]:
        if self.exit_price is None:
            return None
        raw = (self.exit_price / self.fill_price - 1.0) * 100.0
        return raw if self.direction == "LONG" else -raw


# ---------------------------------------------------------------------------
# Execution engine
# ---------------------------------------------------------------------------

@dataclass
class ExecutionEngine:
    delay_minutes:  float = 15.0   # minimum lag between event and fill
    slippage_bps:   float = 10.0   # basis points of half-spread
    use_open:       bool  = True   # fill at open of next bar (safer) vs close

    def simulate_fill(
        self,
        event_ts:  datetime,
        price_df:  pd.DataFrame,
        direction: str = "LONG",
        notional:  float = 10_000.0,
        horizon:   int = 1,
    ) -> Optional[TradeRecord]:
        """
        Simulate a realistic fill given an event timestamp and price data.

        Parameters
        ----------
        event_ts    UTC datetime the article was scraped
        price_df    DataFrame with DatetimeIndex (tz-naive) and OHLCV columns
        direction   LONG or SHORT
        notional    dollar position size
        horizon     hold period in trading days (for exit price)

        Returns None if no valid fill date exists in price_df.
        """
        # Determine fill date: next market open >= event_ts + delay
        earliest_fill = event_ts + timedelta(minutes=self.delay_minutes)
        fill_date     = next_market_open(earliest_fill)
        fill_date_str = fill_date.strftime("%Y-%m-%d")

        # Find fill price in price_df
        idx = pd.Timestamp(fill_date_str)
        if idx not in price_df.index:
            # Find nearest future date in price_df
            future = price_df.index[price_df.index >= idx]
            if future.empty:
                logger.debug("No fill date found for event at %s", event_ts)
                return None
            idx = future[0]

        row        = price_df.loc[idx]
        ref_price  = float(row["Open"] if self.use_open else row["Close"])
        fill_price = apply_slippage(ref_price, direction, self.slippage_bps)

        fill_ts    = pd.Timestamp(idx).to_pydatetime()
        actual_lag = (fill_ts - event_ts.replace(tzinfo=None)).total_seconds() / 60.0

        # Exit price at horizon
        exit_price  = None
        return_pct  = None
        future_bars = price_df.index[price_df.index > idx]
        if len(future_bars) >= horizon:
            exit_idx   = future_bars[horizon - 1]
            exit_row   = price_df.loc[exit_idx]
            exit_ref   = float(exit_row["Close"])
            exit_price = apply_slippage(exit_ref, "SHORT" if direction == "LONG" else "LONG",
                                        self.slippage_bps)
            raw        = (exit_price / fill_price - 1.0) * 100.0
            return_pct = raw if direction == "LONG" else -raw

        leakage = check_leakage(
            event_ts.replace(tzinfo=None) if event_ts.tzinfo else event_ts,
            fill_ts,
            int(self.delay_minutes),
        )

        notes = []
        if leakage:
            notes.append("LEAKAGE_FLAG")
        if not is_market_day(fill_ts):
            notes.append("NON_TRADING_DAY")

        return TradeRecord(
            event_ts      = event_ts,
            fill_ts       = fill_ts,
            fill_price    = round(fill_price, 4),
            exit_price    = round(exit_price, 4) if exit_price else None,
            direction     = direction,
            notional      = notional,
            slippage_bps  = self.slippage_bps,
            delay_minutes = round(actual_lag, 1),
            return_pct    = round(return_pct, 4) if return_pct is not None else None,
            leakage_flag  = leakage,
            notes         = "; ".join(notes),
        )

    def audit_events(self, events: list[dict], price_df: pd.DataFrame) -> dict:
        """
        Run leakage audit across a batch of events.
        Returns summary statistics.
        """
        total      = len(events)
        leakage    = 0
        no_fill    = 0
        trade_rets = []

        for ev in events:
            ts = ev.get("scraped_at")
            if ts is None:
                continue
            if isinstance(ts, str):
                ts = datetime.fromisoformat(ts)

            label  = (ev.get("sentiment_label") or "NEUTRAL").upper()
            direction = "LONG" if label == "POSITIVE" else "SHORT" if label == "NEGATIVE" else "LONG"

            trade = self.simulate_fill(ts, price_df, direction=direction, horizon=1)
            if trade is None:
                no_fill += 1
                continue
            if trade.leakage_flag:
                leakage += 1
            if trade.return_pct is not None:
                trade_rets.append(trade.return_pct)

        return {
            "total_events":    total,
            "no_fill":         no_fill,
            "leakage_count":   leakage,
            "leakage_rate":    round(leakage / max(1, total - no_fill), 4),
            "n_trades":        len(trade_rets),
            "mean_return_pct": round(sum(trade_rets) / len(trade_rets), 4) if trade_rets else None,
            "leakage_clean":   leakage == 0,
        }
