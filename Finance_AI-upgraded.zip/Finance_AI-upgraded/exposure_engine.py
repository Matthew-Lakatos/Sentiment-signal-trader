"""
exposure_engine.py — #17 Exposure + Capital Engine (§22).

Enforces portfolio-level risk constraints that operate independently
of the per-signal throttle. While the throttle scales individual
position sizes, the exposure engine enforces aggregate limits.

Constraints enforced
--------------------
  gross_exposure_limit   : total |long| + |short| as fraction of AUM
  net_exposure_limit     : |long - short| as fraction of AUM
  sector_cap             : max allocation to any single GICS sector
  factor_cap             : max beta-equivalent exposure to any single factor
  single_name_cap        : max allocation to any single ticker
  max_positions          : hard cap on simultaneous open positions

All limits are configurable via env vars and also accept runtime overrides
from the governance throttle.

Usage
-----
    from exposure_engine import ExposureEngine, ExposureCheck

    engine = ExposureEngine(aum=1_000_000)

    # Check before opening a position
    check = engine.check_new_position(
        ticker    = "AAPL",
        direction = "LONG",
        notional  = 50_000,
        sector    = "Technology",
        beta      = 1.2,
    )
    if not check.approved:
        logger.warning("Exposure limit breach: %s", check.violations)

    # Update existing book state
    engine.record_fill(ticker="AAPL", direction="LONG", notional=48_000, sector="Technology", beta=1.2)

    # Get current exposure report
    report = engine.exposure_report()
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)


def _float_env(k: str, default: float) -> float:
    try:
        return float(os.environ[k])
    except (KeyError, ValueError):
        return default


# ---------------------------------------------------------------------------
# Limits
# ---------------------------------------------------------------------------

@dataclass
class ExposureLimits:
    gross_exp_limit:    float = _float_env("EXP_GROSS_LIMIT",   1.00)
    net_exp_limit:      float = _float_env("EXP_NET_LIMIT",      0.50)
    sector_cap:         float = _float_env("EXP_SECTOR_CAP",     0.30)
    single_name_cap:    float = _float_env("EXP_SINGLE_NAME_CAP", 0.10)
    max_positions:      int   = int(_float_env("EXP_MAX_POSITIONS", 20))
    factor_beta_cap:    float = _float_env("EXP_FACTOR_BETA_CAP", 0.40)  # max net beta-equiv exposure


# ---------------------------------------------------------------------------
# Position record
# ---------------------------------------------------------------------------

@dataclass
class PositionRecord:
    ticker:    str
    direction: str    # LONG | SHORT
    notional:  float  # positive always
    sector:    str    = "Unknown"
    beta:      float  = 1.0
    opened_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def signed_notional(self) -> float:
        return self.notional if self.direction == "LONG" else -self.notional


# ---------------------------------------------------------------------------
# Check result
# ---------------------------------------------------------------------------

@dataclass
class ExposureCheck:
    approved:   bool
    violations: list[str]
    warnings:   list[str]
    # What the position size should be trimmed to (if partially approved)
    approved_notional: Optional[float] = None

    @property
    def is_clean(self) -> bool:
        return self.approved and not self.warnings


# ---------------------------------------------------------------------------
# Exposure report
# ---------------------------------------------------------------------------

@dataclass
class ExposureReport:
    gross_exposure:   float   # fraction of AUM
    net_exposure:     float
    long_exposure:    float
    short_exposure:   float
    sector_exposures: dict[str, float]
    net_beta:         float   # portfolio beta to market
    n_positions:      int
    largest_position: Optional[str]
    limit_utilisation: dict[str, float]  # limit_name → fraction used
    computed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def summary(self) -> str:
        return (
            f"Exposure: gross={self.gross_exposure:.1%}  net={self.net_exposure:.1%}  "
            f"beta={self.net_beta:.2f}  n={self.n_positions}  "
            f"utilisation={self.limit_utilisation}"
        )


# ---------------------------------------------------------------------------
# ExposureEngine
# ---------------------------------------------------------------------------

class ExposureEngine:
    """
    Tracks the live portfolio book and enforces aggregate exposure limits.
    """

    def __init__(
        self,
        aum:    float = 1_000_000.0,
        limits: Optional[ExposureLimits] = None,
    ) -> None:
        self._aum     = aum
        self._limits  = limits or ExposureLimits()
        self._book:   dict[str, PositionRecord] = {}

    # ------------------------------------------------------------------
    # Book management
    # ------------------------------------------------------------------

    def record_fill(
        self,
        ticker:    str,
        direction: str,
        notional:  float,
        sector:    str   = "Unknown",
        beta:      float = 1.0,
    ) -> None:
        self._book[ticker] = PositionRecord(
            ticker    = ticker,
            direction = direction,
            notional  = notional,
            sector    = sector,
            beta      = beta,
        )
        logger.info("ExposureEngine: recorded %s %s %.0f", direction, ticker, notional)

    def close_position(self, ticker: str) -> None:
        if ticker in self._book:
            del self._book[ticker]

    # ------------------------------------------------------------------
    # Pre-trade check
    # ------------------------------------------------------------------

    def check_new_position(
        self,
        ticker:    str,
        direction: str,
        notional:  float,
        sector:    str   = "Unknown",
        beta:      float = 1.0,
    ) -> ExposureCheck:
        violations: list[str] = []
        warnings:   list[str] = []
        L = self._limits

        # ── Current state ────────────────────────────────────────────────────
        current_long  = sum(p.notional for p in self._book.values() if p.direction == "LONG")
        current_short = sum(p.notional for p in self._book.values() if p.direction == "SHORT")
        current_gross = (current_long + current_short) / self._aum
        current_net   = (current_long - current_short) / self._aum

        # ── Proposed state ───────────────────────────────────────────────────
        new_long  = current_long  + (notional if direction == "LONG"  else 0)
        new_short = current_short + (notional if direction == "SHORT" else 0)
        new_gross = (new_long + new_short) / self._aum
        new_net   = abs(new_long - new_short) / self._aum

        # ── Checks ──────────────────────────────────────────────────────────
        approved_notional = notional

        # 1. Gross exposure
        if new_gross > L.gross_exp_limit:
            excess  = (new_gross - L.gross_exp_limit) * self._aum
            trimmed = max(0, notional - excess)
            if trimmed <= 0:
                violations.append(f"GROSS_LIMIT: {new_gross:.1%} > {L.gross_exp_limit:.1%}")
                approved_notional = 0
            else:
                warnings.append(f"gross_limit_partial_trim: {notional:.0f} → {trimmed:.0f}")
                approved_notional = min(approved_notional, trimmed)
        elif new_gross > L.gross_exp_limit * 0.90:
            warnings.append(f"gross_limit_approaching: {new_gross:.1%}")

        # 2. Net exposure
        if new_net > L.net_exp_limit:
            violations.append(f"NET_LIMIT: {new_net:.1%} > {L.net_exp_limit:.1%}")
            approved_notional = 0

        # 3. Sector cap
        sector_notional = sum(
            p.notional for p in self._book.values() if p.sector == sector
        ) + notional
        sector_exp = sector_notional / self._aum
        if sector_exp > L.sector_cap:
            trimmed = max(0, (L.sector_cap * self._aum) - (sector_notional - notional))
            if trimmed <= 0:
                violations.append(f"SECTOR_CAP[{sector}]: {sector_exp:.1%} > {L.sector_cap:.1%}")
                approved_notional = 0
            else:
                warnings.append(f"sector_cap_trim[{sector}]: {notional:.0f} → {trimmed:.0f}")
                approved_notional = min(approved_notional, trimmed)

        # 4. Single name cap
        existing = self._book.get(ticker)
        existing_notional = existing.notional if existing else 0.0
        total_name = (existing_notional + notional) / self._aum
        if total_name > L.single_name_cap:
            trimmed = max(0, (L.single_name_cap * self._aum) - existing_notional)
            if trimmed <= 0:
                violations.append(f"SINGLE_NAME_CAP[{ticker}]: {total_name:.1%} > {L.single_name_cap:.1%}")
                approved_notional = 0
            else:
                warnings.append(f"single_name_trim[{ticker}]: {notional:.0f} → {trimmed:.0f}")
                approved_notional = min(approved_notional, trimmed)

        # 5. Max positions
        if ticker not in self._book and len(self._book) >= L.max_positions:
            violations.append(f"MAX_POSITIONS: {len(self._book)} >= {L.max_positions}")
            approved_notional = 0

        # 6. Factor beta cap
        signed_new = notional * beta if direction == "LONG" else -notional * beta
        current_beta_exp = sum(p.signed_notional * p.beta for p in self._book.values()) / self._aum
        new_beta_exp = abs((current_beta_exp * self._aum + signed_new) / self._aum)
        if new_beta_exp > L.factor_beta_cap:
            warnings.append(f"factor_beta_cap_approaching: net_beta_exp={new_beta_exp:.2f}")

        approved = len(violations) == 0 and approved_notional > 0

        if violations:
            logger.warning("Exposure violations for %s: %s", ticker, violations)

        return ExposureCheck(
            approved          = approved,
            violations        = violations,
            warnings          = warnings,
            approved_notional = round(approved_notional, 2) if approved else 0.0,
        )

    # ------------------------------------------------------------------
    # Exposure report
    # ------------------------------------------------------------------

    def exposure_report(self) -> ExposureReport:
        if not self._book:
            return ExposureReport(
                gross_exposure=0, net_exposure=0, long_exposure=0,
                short_exposure=0, sector_exposures={}, net_beta=0,
                n_positions=0, largest_position=None, limit_utilisation={},
            )

        long_n  = sum(p.notional for p in self._book.values() if p.direction == "LONG")
        short_n = sum(p.notional for p in self._book.values() if p.direction == "SHORT")
        gross   = (long_n + short_n) / self._aum
        net     = (long_n - short_n) / self._aum

        sector_exp = {}
        for p in self._book.values():
            sector_exp[p.sector] = sector_exp.get(p.sector, 0.0) + p.notional / self._aum

        net_beta = sum(p.signed_notional * p.beta for p in self._book.values()) / self._aum

        largest = max(self._book, key=lambda t: self._book[t].notional) if self._book else None

        L = self._limits
        utilisation = {
            "gross":       round(gross / L.gross_exp_limit, 3),
            "net":         round(abs(net) / L.net_exp_limit, 3),
            "positions":   round(len(self._book) / L.max_positions, 3),
            "factor_beta": round(abs(net_beta) / L.factor_beta_cap, 3),
        }

        return ExposureReport(
            gross_exposure   = round(gross, 4),
            net_exposure     = round(net,   4),
            long_exposure    = round(long_n / self._aum, 4),
            short_exposure   = round(short_n / self._aum, 4),
            sector_exposures = {k: round(v, 4) for k, v in sector_exp.items()},
            net_beta         = round(net_beta, 4),
            n_positions      = len(self._book),
            largest_position = largest,
            limit_utilisation = utilisation,
        )

    def update_limits_from_throttle(self, throttle_state) -> None:
        """Sync limits with risk throttle state."""
        self._limits.max_positions  = throttle_state.max_positions
        self._limits.gross_exp_limit = throttle_state.max_gross_exp


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_engine: Optional[ExposureEngine] = None


def get_engine(aum: float = 1_000_000.0) -> ExposureEngine:
    global _engine
    if _engine is None:
        _engine = ExposureEngine(aum=aum)
    return _engine
