"""
alt_data_sources.py — Expanded Information Sources.

Adds six alternative data connectors beyond the existing web scraper:

1. SECEdgarConnector      — 8-K / 10-K / earnings filings from SEC EDGAR (free API)
2. RedditSentimentConnector — WSB + investing + stocks subreddit sentiment
3. GoogleTrendsConnector  — search-volume momentum for tickers/topics
4. CongressionalTradeConnector — congressional trading disclosures (quiverquant.com)
5. JobPostingConnector    — hiring velocity signal via SerpAPI/Adzuna (corporate health)
6. PatentConnector        — USPTO patent grant velocity (R&D momentum signal)

All connectors are rate-limited and circuit-breaker protected via alt_data_ratelimit.py.

Usage
-----
    from alt_data_sources import AltDataHub

    hub = AltDataHub()
    events = await hub.fetch_all("AAPL")
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import time
import urllib.request
import urllib.parse
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

from alt_data_ratelimit import rate_limited, get_breaker, get_limiter

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared event type
# ---------------------------------------------------------------------------

@dataclass
class AltDataEvent:
    source:      str            # connector name
    ticker:      str
    title:       str
    url:         str
    text:        str
    published_at: datetime
    category:    str            # SEC_FILING | REDDIT | TRENDS | CONGRESS | JOBS | PATENT
    metadata:    dict = field(default_factory=dict)
    sentiment_hint: Optional[float] = None   # pre-computed if available [-1,1]

    def to_scraper_dict(self) -> dict:
        """Convert to the dict format expected by the NLP pipeline."""
        return {
            "url":          self.url,
            "title":        self.title,
            "text":         self.text,
            "published_at": self.published_at.isoformat(),
            "source":       self.source,
            "category":     self.category,
            "target_entity": self.ticker,
            "metadata":     self.metadata,
        }


# ---------------------------------------------------------------------------
# Cache helpers
# ---------------------------------------------------------------------------

_cache: dict[str, tuple[float, list]] = {}
_CACHE_TTL = 1800  # 30 min


def _cached(key: str) -> Optional[list]:
    if key in _cache:
        exp, data = _cache[key]
        if time.monotonic() < exp:
            return data
    return None


def _store(key: str, data: list) -> None:
    _cache[key] = (time.monotonic() + _CACHE_TTL, data)


# ---------------------------------------------------------------------------
# 1. SEC EDGAR Connector
# ---------------------------------------------------------------------------

class SECEdgarConnector:
    """
    Pulls recent 8-K (material events), 10-K (annual), and 10-Q (quarterly)
    filings from the SEC EDGAR full-text search API (free, no auth required).

    API: https://efts.sec.gov/LATEST/search-index?q={ticker}&dateRange=custom&...
    """
    BASE = "https://efts.sec.gov/LATEST/search-index"
    HEADERS = {"User-Agent": "FinanceAI research@financeai.dev"}
    FORM_TYPES = ["8-K", "10-K", "10-Q", "SC 13G", "SC 13D", "4"]

    @rate_limited("sec_edgar")
    async def fetch(self, ticker: str, days_back: int = 14) -> list[AltDataEvent]:
        key = f"sec_{ticker}_{days_back}"
        cached = _cached(key)
        if cached is not None:
            return cached

        loop  = asyncio.get_running_loop()
        events = await loop.run_in_executor(None, self._fetch_sync, ticker, days_back)
        _store(key, events)
        return events

    def _fetch_sync(self, ticker: str, days_back: int) -> list[AltDataEvent]:
        try:
            import urllib.request, json
            since = (datetime.now(timezone.utc) - timedelta(days=days_back)).strftime("%Y-%m-%d")
            url   = (
                f"https://efts.sec.gov/LATEST/search-index?q=%22{ticker}%22"
                f"&dateRange=custom&startdt={since}&forms=8-K,10-K,10-Q"
            )
            req  = urllib.request.Request(url, headers=self.HEADERS)
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())

            events = []
            for hit in data.get("hits", {}).get("hits", [])[:10]:
                src  = hit.get("_source", {})
                form = src.get("form_type", "SEC")
                events.append(AltDataEvent(
                    source       = "SEC_EDGAR",
                    ticker       = ticker,
                    title        = f"{ticker} {form}: {src.get('display_names', [''])[0]}",
                    url          = f"https://www.sec.gov/Archives/edgar/data/{src.get('entity_id','')}/{src.get('file_date','')}/",
                    text         = src.get("period_of_report", "") + " " + src.get("display_names", [""])[0],
                    published_at = datetime.fromisoformat(src.get("file_date", "2000-01-01")).replace(tzinfo=timezone.utc),
                    category     = "SEC_FILING",
                    metadata     = {"form_type": form, "cik": src.get("entity_id", "")},
                ))
            logger.info("SEC EDGAR[%s]: %d filings fetched", ticker, len(events))
            return events
        except Exception as exc:
            logger.debug("SEC EDGAR fetch failed for %s: %s", ticker, exc)
            return []


# ---------------------------------------------------------------------------
# 2. Reddit Sentiment Connector
# ---------------------------------------------------------------------------

class RedditSentimentConnector:
    """
    Pulls post titles + scores from finance subreddits.

    Authentication (preferred): PRAW OAuth2 read-only
    https://praw.readthedocs.io
    Set env vars: REDDIT_CLIENT_ID, REDDIT_CLIENT_SECRET, REDDIT_USER_AGENT
    Falls back to unauthenticated public JSON API if credentials absent.

    PRAW gives: higher rate limits (60 req/min vs ~10), authenticated
    access to more subreddit data, and reliable push_shift history.
    """
    SUBREDDITS = ["wallstreetbets", "investing", "stocks", "options", "StockMarket"]
    _CLIENT_ID     = os.environ.get("REDDIT_CLIENT_ID",     "")
    _CLIENT_SECRET = os.environ.get("REDDIT_CLIENT_SECRET", "")
    _USER_AGENT    = os.environ.get("REDDIT_USER_AGENT",    "FinanceAI/1.0 (by u/financeai_bot)")

    def _build_praw_reddit(self):
        """Build authenticated PRAW Reddit instance."""
        import praw
        return praw.Reddit(
            client_id     = self._CLIENT_ID,
            client_secret = self._CLIENT_SECRET,
            user_agent    = self._USER_AGENT,
            read_only     = True,
        )

    def _fetch_praw_sync(self, ticker: str, max_posts: int) -> list[AltDataEvent]:
        """Use PRAW OAuth2 for reliable, higher-rate-limit Reddit access."""
        try:
            reddit = self._build_praw_reddit()
            events = []

            for sub_name in self.SUBREDDITS[:3]:
                subreddit = reddit.subreddit(sub_name)
                for post in subreddit.search(ticker, sort="new", limit=10, time_filter="week"):
                    score        = post.score
                    upvote_ratio = post.upvote_ratio
                    n_comments   = post.num_comments
                    sentiment_h  = round((upvote_ratio - 0.5) * 2.0, 4)
                    created_at   = datetime.fromtimestamp(post.created_utc, tz=timezone.utc)

                    events.append(AltDataEvent(
                        source        = f"reddit_praw_r/{sub_name}",
                        ticker        = ticker,
                        title         = post.title[:500],
                        url           = f"https://reddit.com{post.permalink}",
                        text          = (post.selftext or post.title)[:2000],
                        published_at  = created_at,
                        category      = "REDDIT",
                        metadata      = {
                            "subreddit":    sub_name,
                            "score":        score,
                            "comments":     n_comments,
                            "upvote_ratio": upvote_ratio,
                            "post_id":      post.id,
                            "auth":         "praw_oauth2",
                        },
                        sentiment_hint = sentiment_h,
                    ))
                    if len(events) >= max_posts:
                        break
                if len(events) >= max_posts:
                    break

            return events
        except ImportError:
            logger.debug("praw not installed — falling back to public API")
            return []
        except Exception as exc:
            logger.debug("PRAW fetch failed for %s: %s", ticker, exc)
            return []

    def _fetch_public_sync(self, ticker: str, max_posts: int) -> list[AltDataEvent]:
        """Fallback: unauthenticated Reddit public JSON API."""
        events  = []
        headers = {"User-Agent": self._USER_AGENT}

        for sub in self.SUBREDDITS[:3]:
            url = f"https://www.reddit.com/r/{sub}/search.json?q={ticker}&restrict_sr=1&sort=new&limit=10&t=week"
            try:
                req = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(req, timeout=8) as resp:
                    data = json.loads(resp.read())
            except Exception:
                continue

            for post in data.get("data", {}).get("children", []):
                p = post.get("data", {})
                score        = p.get("score", 0)
                upvote_ratio = p.get("upvote_ratio", 0.5)
                n_comments   = p.get("num_comments", 0)
                sentiment_h  = round((upvote_ratio - 0.5) * 2.0, 4)
                created_at   = datetime.fromtimestamp(p.get("created_utc", 0), tz=timezone.utc)

                events.append(AltDataEvent(
                    source        = f"reddit_public_r/{sub}",
                    ticker        = ticker,
                    title         = p.get("title", ""),
                    url           = f"https://reddit.com{p.get('permalink', '')}",
                    text          = p.get("selftext", "") or p.get("title", ""),
                    published_at  = created_at,
                    category      = "REDDIT",
                    metadata      = {
                        "subreddit":    sub,
                        "score":        score,
                        "comments":     n_comments,
                        "upvote_ratio": upvote_ratio,
                        "auth":         "public_json",
                    },
                    sentiment_hint = sentiment_h,
                ))

            if len(events) >= max_posts:
                break

        return events[:max_posts]

    @rate_limited("reddit")
    async def fetch(self, ticker: str, max_posts: int = 20) -> list[AltDataEvent]:
        key = f"reddit_{ticker}"
        cached = _cached(key)
        if cached is not None:
            return cached

        loop = asyncio.get_running_loop()

        # Use PRAW if credentials are available, else public API
        if self._CLIENT_ID and self._CLIENT_SECRET:
            events = await loop.run_in_executor(None, self._fetch_praw_sync, ticker, max_posts)
        else:
            events = []

        if not events:
            events = await loop.run_in_executor(None, self._fetch_public_sync, ticker, max_posts)

        _store(key, events)
        logger.info("Reddit[%s]: %d posts (auth=%s)", ticker, len(events),
                    "praw" if self._CLIENT_ID else "public")
        return events


class APBusinessConnector:
    """
    Associated Press Business news connector.
    https://apnews.com/hub/business

    Scrapes the AP Business hub for headlines and article summaries.
    AP is a primary wire service and one of the most reliable sources
    for breaking corporate and macro news.
    """
    AP_BIZ_URL   = "https://apnews.com/hub/business"
    AP_RSS_URL   = "https://rsshub.app/apnews/topics/business"   # RSS bridge (no auth)
    AP_JSON_URL  = "https://apnews.com/hub/business?type=json"

    @rate_limited("web_scraper")
    async def fetch(self, max_articles: int = 20) -> list[AltDataEvent]:
        """Fetch latest AP Business articles."""
        key = "ap_business"
        cached = _cached(key)
        if cached is not None:
            return cached

        loop   = asyncio.get_running_loop()
        events = await loop.run_in_executor(None, self._fetch_sync, max_articles)
        _store(key, events)
        return events

    def _fetch_sync(self, max_articles: int) -> list[AltDataEvent]:
        """Fetch AP Business via RSS bridge (most reliable free path)."""
        try:
            # Try RSS bridge first
            headers = {"User-Agent": "FinanceAI/1.0 research@financeai.dev"}
            req = urllib.request.Request(self.AP_RSS_URL, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                content = resp.read().decode("utf-8", errors="replace")

            # Parse RSS/Atom
            events = []
            import re
            items = re.findall(r'<item>(.*?)</item>', content, re.DOTALL)
            if not items:
                items = re.findall(r'<entry>(.*?)</entry>', content, re.DOTALL)

            for item in items[:max_articles]:
                title_m  = re.search(r'<title[^>]*>(.*?)</title>', item, re.DOTALL)
                link_m   = re.search(r'<link[^>]*>(.*?)</link>|<link[^>]*/>', item, re.DOTALL)
                desc_m   = re.search(r'<description[^>]*>(.*?)</description>|<summary[^>]*>(.*?)</summary>', item, re.DOTALL)
                date_m   = re.search(r'<pubDate>(.*?)</pubDate>|<published>(.*?)</published>', item, re.DOTALL)

                title = re.sub(r'<[^>]+>', '', title_m.group(1) if title_m else "").strip()
                if not title:
                    continue

                link = (link_m.group(1) or link_m.group(0) if link_m else self.AP_BIZ_URL).strip()
                desc = re.sub(r'<[^>]+>', '', (desc_m.group(1) or desc_m.group(2) or "") if desc_m else "").strip()

                # Parse date
                try:
                    date_str = (date_m.group(1) or date_m.group(2) if date_m else "").strip()
                    from email.utils import parsedate_to_datetime
                    pub_dt = parsedate_to_datetime(date_str)
                except Exception:
                    pub_dt = datetime.now(timezone.utc)

                events.append(AltDataEvent(
                    source       = "ap_business",
                    ticker       = "",   # AP articles are market-wide
                    title        = title[:500],
                    url          = link,
                    text         = f"{title}. {desc}"[:2000],
                    published_at = pub_dt,
                    category     = "NEWS",
                    metadata     = {"feed": "rss", "wire": "AP"},
                ))

            logger.info("AP Business: %d articles fetched via RSS", len(events))
            return events

        except Exception as exc:
            logger.debug("AP Business RSS fetch failed: %s", exc)
            return self._fetch_html_fallback(max_articles)

    def _fetch_html_fallback(self, max_articles: int) -> list[AltDataEvent]:
        """Direct HTML scrape of AP Business hub as final fallback."""
        try:
            from lxml import html as lxml_html
            headers = {"User-Agent": "Mozilla/5.0 (compatible; FinanceAI/1.0)"}
            req = urllib.request.Request(self.AP_BIZ_URL, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                content = resp.read()

            tree     = lxml_html.fromstring(content)
            articles = tree.xpath('//div[contains(@class,"FeedCard")]//a[@href]')
            events   = []

            for a in articles[:max_articles]:
                href  = a.get("href", "")
                title = a.text_content().strip()
                if not title or not href:
                    continue
                url = href if href.startswith("http") else f"https://apnews.com{href}"
                events.append(AltDataEvent(
                    source       = "ap_business",
                    ticker       = "",
                    title        = title[:500],
                    url          = url,
                    text         = title,
                    published_at = datetime.now(timezone.utc),
                    category     = "NEWS",
                    metadata     = {"feed": "html", "wire": "AP"},
                ))

            return events
        except Exception as exc:
            logger.debug("AP Business HTML fallback failed: %s", exc)
            return []


# ---------------------------------------------------------------------------
# 3. Google Trends Connector
# ---------------------------------------------------------------------------

class GoogleTrendsConnector:
    """
    Pulls Google search-interest data for a ticker using pytrends.
    Rising search interest → growing retail attention → potential momentum signal.

    pip install pytrends
    """

    @rate_limited("google_trends")
    async def fetch(self, ticker: str) -> list[AltDataEvent]:
        cached = _cached(key)
        if cached is not None:
            return cached

        loop   = asyncio.get_running_loop()
        events = await loop.run_in_executor(None, self._fetch_sync, ticker)
        _store(key, events)
        return events

    def _fetch_sync(self, ticker: str) -> list[AltDataEvent]:
        try:
            from pytrends.request import TrendReq
            pt = TrendReq(hl="en-US", tz=0, timeout=(5, 15))
            pt.build_payload([ticker], timeframe="now 7-d", geo="US")
            df = pt.interest_over_time()
            if df.empty or ticker not in df.columns:
                return []

            series    = df[ticker].values
            mean_val  = float(series[:-7].mean()) if len(series) > 7 else float(series.mean())
            recent    = float(series[-1])
            momentum  = (recent - mean_val) / max(mean_val, 1)   # % change from baseline

            if abs(momentum) < 0.10:   # not noteworthy
                return []

            direction = "rising" if momentum > 0 else "falling"
            return [AltDataEvent(
                source       = "google_trends",
                ticker       = ticker,
                title        = f"{ticker} Google search interest {direction} ({momentum:+.0%})",
                url          = f"https://trends.google.com/trends/explore?q={ticker}",
                text         = (
                    f"Google Trends shows {ticker} search interest is {direction} "
                    f"significantly. Current interest: {recent:.0f}/100, "
                    f"7-day baseline: {mean_val:.0f}/100. "
                    f"Momentum: {momentum:+.0%}."
                ),
                published_at  = datetime.now(timezone.utc),
                category      = "TRENDS",
                metadata      = {
                    "momentum": round(momentum, 4),
                    "current":  round(recent, 1),
                    "baseline": round(mean_val, 1),
                },
                sentiment_hint = min(1.0, max(-1.0, momentum)),
            )]
        except ImportError:
            logger.debug("pytrends not installed — skipping Google Trends")
            return []
        except Exception as exc:
            logger.debug("Google Trends fetch failed for %s: %s", ticker, exc)
            return []


# ---------------------------------------------------------------------------
# 4. Congressional Trading Connector
# ---------------------------------------------------------------------------

class CongressionalTradeConnector:
    """
    Pulls congressional stock trade disclosures from the House Stock Watcher
    and Senate disclosure APIs. Congressional trades have historically
    been a strong alpha signal.

    Data source: https://housestockwatcher.com/api (free, public)
    """
    HOUSE_API = "https://house-stock-watcher-data.s3-us-west-2.amazonaws.com/data/all_transactions.json"

    @rate_limited("congressional_trades")
    async def fetch(self, ticker: str, days_back: int = 90) -> list[AltDataEvent]:
        key = f"congress_{ticker}_{days_back}"
        cached = _cached(key)
        if cached is not None:
            return cached

        loop   = asyncio.get_running_loop()
        events = await loop.run_in_executor(None, self._fetch_sync, ticker, days_back)
        _store(key, events)
        return events

    def _fetch_sync(self, ticker: str, days_back: int) -> list[AltDataEvent]:
        try:
            import urllib.request, json
            cutoff = datetime.now(timezone.utc) - timedelta(days=days_back)

            req = urllib.request.Request(
                self.HOUSE_API,
                headers={"User-Agent": "FinanceAI research@financeai.dev"},
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                all_trades = json.loads(resp.read())

            events = []
            buys = sells = 0
            for trade in all_trades:
                t_ticker = trade.get("ticker", "").upper().strip()
                if t_ticker != ticker.upper():
                    continue
                try:
                    disc_date = datetime.strptime(
                        trade.get("disclosure_date", ""), "%m/%d/%Y"
                    ).replace(tzinfo=timezone.utc)
                except ValueError:
                    continue
                if disc_date < cutoff:
                    continue

                tx_type = trade.get("type", "").lower()
                is_buy  = "purchase" in tx_type
                is_sell = "sale" in tx_type
                if is_buy:
                    buys += 1
                elif is_sell:
                    sells += 1

                rep   = trade.get("representative", "Unknown")
                amt   = trade.get("amount", "unknown amount")
                events.append(AltDataEvent(
                    source       = "congressional_trades",
                    ticker       = ticker,
                    title        = f"Rep. {rep}: {'BUY' if is_buy else 'SELL'} {ticker} ({amt})",
                    url          = "https://housestockwatcher.com",
                    text         = (
                        f"Congressional disclosure: Representative {rep} "
                        f"{'purchased' if is_buy else 'sold'} shares of {ticker} "
                        f"worth approximately {amt} on {disc_date.strftime('%Y-%m-%d')}."
                    ),
                    published_at  = disc_date,
                    category      = "CONGRESS",
                    metadata      = {
                        "rep":      rep,
                        "type":     tx_type,
                        "amount":   amt,
                        "chamber":  "house",
                    },
                    sentiment_hint = 0.6 if is_buy else -0.4,
                ))

            # Aggregate event
            if buys + sells > 0:
                net_sentiment = (buys - sells) / (buys + sells)
                events.insert(0, AltDataEvent(
                    source       = "congressional_trades",
                    ticker       = ticker,
                    title        = f"Congressional net flow {ticker}: {buys} buys, {sells} sells",
                    url          = "https://housestockwatcher.com",
                    text         = (
                        f"Congressional trading summary for {ticker} over the past "
                        f"{days_back} days: {buys} purchase(s), {sells} sale(s). "
                        f"Net sentiment: {'BULLISH' if net_sentiment > 0 else 'BEARISH'}."
                    ),
                    published_at  = datetime.now(timezone.utc),
                    category      = "CONGRESS",
                    metadata      = {"buys": buys, "sells": sells},
                    sentiment_hint = round(net_sentiment, 4),
                ))

            logger.info("CongressTrades[%s]: %d events (%d buys, %d sells)", ticker, len(events), buys, sells)
            return events
        except Exception as exc:
            logger.debug("Congressional trades fetch failed for %s: %s", ticker, exc)
            return []


# ---------------------------------------------------------------------------
# 5. Job Posting Connector
# ---------------------------------------------------------------------------

class JobPostingConnector:
    """
    Estimates hiring velocity as a corporate health signal.
    Uses the Adzuna API (free tier available) or SerpAPI.

    Rising job postings → expansion phase → bullish signal.
    Falling postings   → cost-cutting    → bearish signal.

    Set ADZUNA_APP_ID and ADZUNA_APP_KEY env vars for live data.
    Falls back to LinkedIn job count via public search (no auth).
    """

    @rate_limited("job_postings")
    async def fetch(self, ticker: str, company_name: Optional[str] = None) -> list[AltDataEvent]:
        key = f"jobs_{ticker}"
        cached = _cached(key)
        if cached is not None:
            return cached

        company = company_name or ticker
        loop    = asyncio.get_running_loop()
        events  = await loop.run_in_executor(None, self._fetch_sync, ticker, company)
        _store(key, events)
        return events

    def _fetch_sync(self, ticker: str, company: str) -> list[AltDataEvent]:
        app_id  = os.environ.get("ADZUNA_APP_ID")
        app_key = os.environ.get("ADZUNA_APP_KEY")
        if not app_id or not app_key:
            return self._fallback_linkedin(ticker, company)

        try:
            import urllib.request, json
            url = (
                f"https://api.adzuna.com/v1/api/jobs/us/search/1"
                f"?app_id={app_id}&app_key={app_key}"
                f"&company={company}&results_per_page=1&content-type=application/json"
            )
            with urllib.request.urlopen(url, timeout=10) as resp:
                data  = json.loads(resp.read())
            count = data.get("count", 0)

            return [AltDataEvent(
                source       = "adzuna_jobs",
                ticker       = ticker,
                title        = f"{company} open positions: {count:,}",
                url          = f"https://www.adzuna.com/search?q={company}",
                text         = (
                    f"{company} currently has approximately {count:,} open job postings "
                    f"listed on Adzuna. Job posting volume is a leading indicator of "
                    f"corporate expansion or contraction plans."
                ),
                published_at  = datetime.now(timezone.utc),
                category      = "JOBS",
                metadata      = {"count": count, "company": company},
            )]
        except Exception as exc:
            logger.debug("Adzuna fetch failed for %s: %s", ticker, exc)
            return []

    def _fallback_linkedin(self, ticker: str, company: str) -> list[AltDataEvent]:
        """Fallback: scrape LinkedIn job count via public search page."""
        try:
            import urllib.request
            url     = f"https://www.linkedin.com/jobs/search/?keywords={company}&f_C="
            headers = {"User-Agent": "Mozilla/5.0 (compatible; FinanceAI/1.0)"}
            req     = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=8) as resp:
                html = resp.read().decode("utf-8", errors="ignore")

            # Extract job count from HTML (LinkedIn includes it in a span)
            import re
            m = re.search(r"([\d,]+)\s+jobs?\s+results?", html, re.IGNORECASE)
            if not m:
                return []
            count = int(m.group(1).replace(",", ""))
            return [AltDataEvent(
                source       = "linkedin_jobs",
                ticker       = ticker,
                title        = f"{company} LinkedIn open roles: {count:,}",
                url          = url,
                text         = f"{company} has approximately {count:,} open positions on LinkedIn.",
                published_at  = datetime.now(timezone.utc),
                category      = "JOBS",
                metadata      = {"count": count},
            )]
        except Exception:
            return []


# ---------------------------------------------------------------------------
# 6. Patent Connector
# ---------------------------------------------------------------------------

class PatentConnector:
    """
    Tracks patent grant velocity via the USPTO Patent Full-Text Database
    API (free, no auth required). Rising patent grants → R&D productivity.

    API: https://developer.uspto.gov/api-catalog/bdss-search
    """
    BASE = "https://developer.uspto.gov/ibd-api/v1/patent/application"

    @rate_limited("uspto_patents")
    async def fetch(self, ticker: str, company_name: Optional[str] = None, days_back: int = 90) -> list[AltDataEvent]:
        key = f"patents_{ticker}_{days_back}"
        cached = _cached(key)
        if cached is not None:
            return cached

        company = company_name or ticker
        loop    = asyncio.get_running_loop()
        events  = await loop.run_in_executor(None, self._fetch_sync, ticker, company, days_back)
        _store(key, events)
        return events

    def _fetch_sync(self, ticker: str, company: str, days_back: int) -> list[AltDataEvent]:
        try:
            import urllib.request, json, urllib.parse
            since = (datetime.now(timezone.utc) - timedelta(days=days_back)).strftime("%Y%m%d")
            params = urllib.parse.urlencode({
                "searchText": f'assignee:"{company}"',
                "start": 0, "rows": 10,
                "dateRangeField": "appFilingDate",
                "dateRangeStart": since,
            })
            url = f"{self.BASE}?{params}"
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "FinanceAI research@financeai.dev"},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data  = json.loads(resp.read())

            total = data.get("response", {}).get("numFound", 0)
            if total == 0:
                return []

            return [AltDataEvent(
                source       = "uspto_patents",
                ticker       = ticker,
                title        = f"{company} filed {total} patent application(s) in last {days_back} days",
                url          = f"https://developer.uspto.gov/api-catalog/bdss-search",
                text         = (
                    f"{company} has filed {total} patent application(s) with the USPTO "
                    f"over the past {days_back} days. Patent velocity is a leading indicator "
                    f"of R&D investment and future product pipeline."
                ),
                published_at  = datetime.now(timezone.utc),
                category      = "PATENT",
                metadata      = {"count": total, "days_back": days_back},
            )]
        except Exception as exc:
            logger.debug("Patent fetch failed for %s: %s", ticker, exc)
            return []


# ---------------------------------------------------------------------------
# AltDataHub — unified interface
# ---------------------------------------------------------------------------

class AltDataHub:
    """
    Single entry point for all alternative data sources.
    Runs all connectors concurrently and returns a merged event list.
    """

    def __init__(
        self,
        enable_sec:           bool = True,
        enable_reddit:        bool = True,
        enable_trends:        bool = True,
        enable_congressional: bool = True,
        enable_jobs:          bool = False,
        enable_patents:       bool = True,
        enable_ap_business:   bool = True,
    ) -> None:
        self.sec           = SECEdgarConnector()           if enable_sec           else None
        self.reddit        = RedditSentimentConnector()    if enable_reddit        else None
        self.trends        = GoogleTrendsConnector()       if enable_trends        else None
        self.congressional = CongressionalTradeConnector() if enable_congressional else None
        self.jobs          = JobPostingConnector()         if enable_jobs          else None
        self.patents       = PatentConnector()             if enable_patents        else None
        self.ap_business   = APBusinessConnector()         if enable_ap_business   else None

    async def fetch_all(
        self,
        ticker:       str,
        company_name: Optional[str] = None,
    ) -> list[AltDataEvent]:
        """Fetch from all enabled connectors concurrently."""
        tasks = []
        if self.sec:           tasks.append(self.sec.fetch(ticker))
        if self.reddit:        tasks.append(self.reddit.fetch(ticker))
        if self.trends:        tasks.append(self.trends.fetch(ticker))
        if self.congressional: tasks.append(self.congressional.fetch(ticker))
        if self.jobs:          tasks.append(self.jobs.fetch(ticker, company_name))
        if self.patents:       tasks.append(self.patents.fetch(ticker, company_name))
        # AP Business is market-wide — fetch once regardless of ticker
        if self.ap_business:   tasks.append(self.ap_business.fetch())

        results = await asyncio.gather(*tasks, return_exceptions=True)

        events: list[AltDataEvent] = []
        for r in results:
            if isinstance(r, Exception):
                logger.debug("AltDataHub connector error: %s", r)
            elif isinstance(r, list):
                events.extend(r)

        logger.info("AltDataHub[%s]: %d events from %d connectors",
                    ticker, len(events), len(tasks))
        return events


# ---------------------------------------------------------------------------
# Extended finance URL seeds (supplement target_profiles.py)
# ---------------------------------------------------------------------------

ALT_DATA_URLS = [
    # SEC EDGAR full-text search
    "https://efts.sec.gov/LATEST/search-index?forms=8-K&dateRange=custom&startdt={today}",
    # Congressional disclosures
    "https://housestockwatcher.com/api",
    "https://efts.sec.gov/LATEST/search-index?forms=10-K",
    # Earnings call transcripts
    "https://www.fool.com/earnings-call-transcripts/",
    "https://seekingalpha.com/earnings/earnings-call-transcripts",
    # Economic calendars
    "https://www.investing.com/economic-calendar/",
    "https://finance.yahoo.com/calendar/earnings",
    # Options flow
    "https://unusualwhales.com/flow",
    # Short interest
    "https://finviz.com/screener.ashx?v=111&f=sh_short_high",
    # Fed communications
    "https://www.federalreserve.gov/newsevents/pressreleases.htm",
    "https://www.federalreserve.gov/monetarypolicy/fomc.htm",
    # Macro data
    "https://fred.stlouisfed.org/graph/fredgraph.csv?id=T10Y2Y",  # yield curve
    "https://fred.stlouisfed.org/graph/fredgraph.csv?id=BAMLH0A0HYM2",  # HY spread
    # Global central banks
    "https://www.ecb.europa.eu/press/pr/date/2025/html/index.en.html",
    "https://www.bankofengland.co.uk/news/speeches",
    # Commodity market intelligence
    "https://www.eia.gov/petroleum/supply/weekly/",
    "https://www.cmegroup.com/markets/energy/crude-oil.html",
    # M&A intelligence
    "https://www.mergermarket.com/",
    "https://www.businesswire.com/news/home/recent",
    "https://www.prnewswire.com/news-releases/news-releases-list.html",
]


def get_extended_urls() -> list[str]:
    """Return the extended URL seed list for the scraper."""
    return ALT_DATA_URLS
