"""
database.py — asyncpg connection pool over PostgreSQL + TimescaleDB.
"""
from __future__ import annotations

import json
import logging
from typing import Optional

import asyncpg
from asyncpg.pool import Pool

from config import settings

logger = logging.getLogger(__name__)

_pool: Optional[Pool] = None


async def get_pool() -> Pool:
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(
            dsn=settings.postgres_dsn,
            min_size=settings.db_pool_min,
            max_size=settings.db_pool_max,
            command_timeout=30,
            server_settings={"application_name": "scraper"},
        )
        logger.info(
            "Database pool initialised (min=%d max=%d)",
            settings.db_pool_min, settings.db_pool_max,
        )
    return _pool


async def close_pool() -> None:
    global _pool
    if _pool:
        await _pool.close()
        _pool = None
        logger.info("Database pool closed")


async def insert_event(pool: Pool, ev) -> None:
    """
    Insert a ScrapedEvent.  Skips embedding column when None.
    All Phase 1 columns included; they default to NULL / 'NEUTRAL'
    when not populated (e.g. single-event runs with no CS ranking).
    """
    emb_str = (
        f"[{','.join(str(x) for x in ev.embedding)}]"
        if ev.embedding else None
    )

    await pool.execute(
        """
        INSERT INTO scraped_events (
            event_id, url, source_domain, scraped_at, http_status,
            raw_text_hash, summary,
            sentiment_label, sentiment_score, sentiment_confident,
            keywords, topics, emotions,
            embedding, embedding_model,
            credibility_score, propaganda_score, propaganda_flags,
            materiality_score, materiality_tier,
            is_duplicate, canonical_event_id,
            event_type, event_confidence,
            novelty_score, novelty_label,
            signal_score, signal_direction, signal_tier,
            dollar_value, pct_change,
            -- Phase 1
            targets,
            primary_sector,
            surprise_score,
            guidance_revision_score,
            factor_neutral_score,
            cs_percentile,
            cs_sector_percentile,
            cs_score,
            market_regime,
            vix_level,
            yield_curve_slope
        ) VALUES (
            $1, $2, $3, $4, $5,
            $6, $7,
            $8, $9, $10,
            $11::text[], $12::text[], $13::jsonb,
            $14::vector, $15,
            $16, $17, $18::text[],
            $19, $20,
            $21, $22,
            $23, $24,
            $25, $26,
            $27, $28, $29,
            $30, $31,
            -- Phase 1
            $32::text[],
            $33,
            $34,
            $35,
            $36,
            $37,
            $38,
            $39,
            $40,
            $41,
            $42
        )
        ON CONFLICT (event_id) DO NOTHING
        """,
        # Original fields
        ev.event_id, ev.url, ev.source_domain, ev.scraped_at, ev.http_status,
        ev.raw_text_hash, ev.summary,
        ev.sentiment_label, ev.sentiment_score, ev.sentiment_confident,
        ev.keywords, ev.topics, json.dumps(ev.emotions),
        emb_str, ev.embedding_model,
        ev.credibility_score, ev.propaganda_score, ev.propaganda_flags,
        ev.materiality_score, ev.materiality_tier,
        ev.is_duplicate, ev.canonical_event_id,
        ev.event_type, ev.event_confidence,
        ev.novelty_score, ev.novelty_label,
        ev.signal_score, ev.signal_direction, ev.signal_tier,
        ev.dollar_value, ev.pct_change,
        # Phase 1
        ev.targets,
        ev.primary_sector,
        ev.surprise_score,
        ev.guidance_revision_score,
        ev.factor_neutral_score,
        ev.cs_percentile,
        ev.cs_sector_percentile,
        ev.cs_score,
        ev.market_regime,
        ev.vix_level,
        ev.yield_curve_slope,
    )
