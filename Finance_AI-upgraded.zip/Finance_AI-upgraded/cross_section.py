"""
cross_section.py — §10 Cross-Sectional Alpha Ranking.

Ranks events by their factor-neutralised alpha relative to the peer
universe rather than rating each event in absolute terms.

Why this matters
----------------
A signal of +0.40 from a tech stock is far less informative if every
other tech stock also has a signal of +0.38 that day.  Cross-sectional
ranking tells you which events represent genuine relative outperformance
within their sector and globally.

Two ranking axes
----------------
1. Sector-relative percentile (cs_sector_percentile)
   Rank of the event's factor_neutral_score within its sector peers.
   1.0 = highest signal in sector, 0.0 = lowest.

2. Global percentile (cs_percentile)
   Rank across all events in the batch regardless of sector.

Cross-sectional score (cs_score)
   Maps global percentile to [-1, 1]: cs_score = 2 × cs_percentile - 1
   +1.0 = top of the batch, -1.0 = bottom.

Minimum batch size
------------------
Ranking with n < 2 events is degenerate.  When fewer than
CS_MIN_BATCH (default 2) events are present the function assigns
cs_percentile = 0.5 and cs_score = 0.0 to all events (honest "no rank"
rather than falsely extreme values).

Usage
-----
    from cross_section import rank_batch

    events = neutralise_batch(events)   # adds factor_neutral_score + primary_sector
    events = rank_batch(events)         # adds cs_percentile, cs_sector_percentile, cs_score
"""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)

# Minimum number of events needed to produce meaningful cross-sectional ranks
CS_MIN_BATCH = 10   # Bug fix: was 2. With n<10, percentile values are {0,0.5,1.0}
                    # which creates falsely extreme conviction. Need ≥10 events
                    # for a meaningful within-batch distribution.

# Rolling reference population for cross-sectional ranking.
# When a scrape cycle produces < CS_MIN_BATCH events, we rank against
# the last CS_ROLLING_N events from prior cycles instead of just the
# current batch. This prevents small-batch percentile collapse.
CS_ROLLING_N    = 500   # size of rolling reference distribution
_rolling_scores: list[float] = []   # module-level ring buffer (score, sector)
_rolling_sectors: list[str]  = []


def _update_rolling(scores: list[float], sectors: list[str]) -> None:
    """Add current batch to the rolling reference distribution."""
    global _rolling_scores, _rolling_sectors
    _rolling_scores  = (_rolling_scores  + scores)[-CS_ROLLING_N:]
    _rolling_sectors = (_rolling_sectors + sectors)[-CS_ROLLING_N:]


# ---------------------------------------------------------------------------
# Percentile rank helper
# ---------------------------------------------------------------------------

def _percentile_rank(values: list[float]) -> list[float]:
    """
    Return fractional percentile ranks in [0, 1] for each value.

    Rank 1.0 → highest value, 0.0 → lowest.
    Ties are broken by averaging their ranks (standard competition ranking).
    """
    n = len(values)
    if n == 0:
        return []
    if n == 1:
        return [0.5]

    # Pair each value with its original index, sort ascending
    indexed = sorted(enumerate(values), key=lambda x: x[1])

    # Assign ranks 0 to n-1 (ascending), then resolve ties by averaging
    ranks   = [0.0] * n
    i       = 0
    while i < n:
        j = i
        # Find end of tie group
        while j + 1 < n and indexed[j + 1][1] == indexed[j][1]:
            j += 1
        avg_rank = (i + j) / 2.0
        for k in range(i, j + 1):
            orig_idx      = indexed[k][0]
            ranks[orig_idx] = avg_rank
        i = j + 1

    # Normalise to [0, 1]: highest value → 1.0
    max_rank = float(n - 1)
    return [round(r / max_rank, 4) for r in ranks]


# ---------------------------------------------------------------------------
# Main ranking function
# ---------------------------------------------------------------------------

def rank_batch(events: list[dict]) -> list[dict]:
    """
    Add cross-sectional rank fields to each event dict in-place.

    Requires each event to have:
        factor_neutral_score   float  (from factor_model.neutralise_batch)
        primary_sector         str    (from factor_model.classify_entity_sector)

    Adds:
        cs_percentile          float  [0, 1]  — global rank within batch
        cs_sector_percentile   float  [0, 1]  — rank within sector
        cs_score               float  [-1, 1] — 2 × cs_percentile - 1
    """
    if not events:
        return events

    n = len(events)
    global_scores = [float(ev.get("factor_neutral_score", 0.0)) for ev in events]
    batch_sectors = [ev.get("primary_sector", "unknown") for ev in events]

    # ── Not enough events for meaningful within-batch ranking ───────────────
    # Bug fix: was CS_MIN_BATCH=2; raised to 10. When batch < 10, rank against
    # rolling reference population from prior cycles to avoid extreme
    # percentile values ({0.0, 0.5, 1.0} from 3-event batches).
    if n < CS_MIN_BATCH:
        if len(_rolling_scores) >= CS_MIN_BATCH:
            # Rank current events against rolling reference + current batch
            ref_scores  = _rolling_scores + global_scores
            ref_sectors = _rolling_sectors + batch_sectors
            # Global rank: position of each current event in the combined pool
            combined_ranks = _percentile_rank(ref_scores)
            # Only take the ranks corresponding to current events (last n)
            current_ranks = combined_ranks[len(_rolling_scores):]
            for ev, grank in zip(events, current_ranks):
                ev["cs_percentile"] = grank
                ev["cs_score"]      = round(2.0 * grank - 1.0, 4)
            # Sector relative: assign 0.5 (no sector peers in tiny batch)
            for ev in events:
                ev["cs_sector_percentile"] = 0.5
        else:
            # No reference population yet — honest neutral assignment
            for ev in events:
                ev["cs_percentile"]        = 0.5
                ev["cs_sector_percentile"] = 0.5
                ev["cs_score"]             = 0.0
        # Still update rolling buffer with these events
        _update_rolling(global_scores, batch_sectors)
        return events

    # ── Global ranking ──────────────────────────────────────────────────────
    global_scores = [float(ev.get("factor_neutral_score", 0.0)) for ev in events]
    global_ranks  = _percentile_rank(global_scores)

    for ev, grank in zip(events, global_ranks):
        ev["cs_percentile"] = grank
        ev["cs_score"]      = round(2.0 * grank - 1.0, 4)

    # ── Sector-relative ranking ─────────────────────────────────────────────
    sector_groups: dict[str, list[int]] = {}
    for idx, ev in enumerate(events):
        sector = ev.get("primary_sector", "unknown")
        sector_groups.setdefault(sector, []).append(idx)

    for sector, indices in sector_groups.items():
        if len(indices) < 2:
            events[indices[0]]["cs_sector_percentile"] = 0.5
            continue
        sector_vals  = [float(events[i].get("factor_neutral_score", 0.0)) for i in indices]
        sector_ranks = _percentile_rank(sector_vals)
        for idx, srank in zip(indices, sector_ranks):
            events[idx]["cs_sector_percentile"] = srank

    # ── Update rolling reference population for future small batches ─────────
    _update_rolling(global_scores, batch_sectors)

    return events
