"""
causal_propagation.py — §8 Causal Propagation Engine.

Upgrades the knowledge graph from co-occurrence edges to causal inference.

The existing knowledge_graph.py stores: (entity, topic, weight)
This module adds: temporal causality, propagation probabilities, and
delayed-impact modelling to extract second-order alpha.

Core insight
------------
"Entity A mentions Topic X" is correlation.
"Entity A mentioning Topic X reliably precedes Entity B moving 3 days later"
is causality — and that's the signal.

What this adds
--------------
1. Temporal edges
   Each KG edge gets a timestamp distribution. We track: how long after
   Entity A's event does Entity B's price typically move?

2. Propagation probability
   P(B moves | A event, topic X) estimated from historical co-occurrences
   with confirmed price moves.

3. Delayed-impact model
   For each (A → X → B) chain: expected impact magnitude and horizon.

4. Scenario trees
   Given a new event for Entity A, generate the most likely propagation
   paths through the graph with probability-weighted impacts.

Usage
-----
    from causal_propagation import CausalPropagationEngine

    engine = CausalPropagationEngine(pool=pool)
    await engine.record_event(entity="NVDA", topic="AI_chips", sentiment=0.8)

    paths = await engine.propagate("NVDA", hops=2)
    for path in paths:
        print(path.target, path.probability, path.expected_impact, path.expected_delay_days)
"""
from __future__ import annotations

import asyncio
import logging
import math
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Propagation path
# ---------------------------------------------------------------------------

@dataclass
class PropagationPath:
    source:              str              # originating entity
    topic:               str              # connecting topic
    target:              str              # downstream entity
    probability:         float            # P(target impacted | source event)
    expected_impact:     float            # expected alpha [−1, 1]
    expected_delay_days: float            # median lag in days
    confidence:          float            # data confidence [0, 1]
    hop_count:           int = 1
    chain:               list[str] = field(default_factory=list)


@dataclass
class CausalEdge:
    source:   str
    topic:    str
    target:   str
    # Observed lags (days) between source and target price moves
    observed_lags:    list[float] = field(default_factory=list)
    # Observed impact magnitudes when propagation occurred
    observed_impacts: list[float] = field(default_factory=list)
    # Count of co-occurrence vs confirmed propagation
    co_occurrence_count:  int = 0
    propagation_count:    int = 0

    @property
    def probability(self) -> float:
        if self.co_occurrence_count == 0:
            return 0.0
        return self.propagation_count / self.co_occurrence_count

    @property
    def expected_delay_days(self) -> float:
        if not self.observed_lags:
            return 2.0
        return float(sum(self.observed_lags) / len(self.observed_lags))

    @property
    def expected_impact(self) -> float:
        if not self.observed_impacts:
            return 0.0
        return float(sum(self.observed_impacts) / len(self.observed_impacts))

    @property
    def confidence(self) -> float:
        """Confidence based on sample size. Reaches 0.9 at 30 observations."""
        return min(0.9, self.co_occurrence_count / 30.0)


# ---------------------------------------------------------------------------
# In-memory edge store with optional DB persistence
# ---------------------------------------------------------------------------

class CausalEdgeStore:
    def __init__(self, pool=None) -> None:
        # (source, topic, target) → CausalEdge
        self._edges: dict[tuple, CausalEdge] = {}
        self._pool  = pool
        self._lock  = asyncio.Lock()

    async def record_co_occurrence(
        self,
        source: str,
        topic:  str,
        target: str,
    ) -> None:
        async with self._lock:
            key = (source, topic, target)
            if key not in self._edges:
                self._edges[key] = CausalEdge(source=source, topic=topic, target=target)
            self._edges[key].co_occurrence_count += 1

    async def record_propagation(
        self,
        source:      str,
        topic:       str,
        target:      str,
        lag_days:    float,
        impact:      float,
    ) -> None:
        """
        Record a confirmed propagation event.
        Call this when a downstream price move is observed after a source event.
        """
        async with self._lock:
            key = (source, topic, target)
            if key not in self._edges:
                self._edges[key] = CausalEdge(source=source, topic=topic, target=target)
            edge = self._edges[key]
            edge.propagation_count += 1
            edge.observed_lags.append(lag_days)
            edge.observed_impacts.append(impact)
            # Bound history
            if len(edge.observed_lags) > 100:
                edge.observed_lags = edge.observed_lags[-100:]
                edge.observed_impacts = edge.observed_impacts[-100:]

    def get_edges_from(self, source: str) -> list[CausalEdge]:
        return [e for (s, _, _), e in self._edges.items() if s == source]

    def get_edges_via_topic(self, topic: str) -> list[CausalEdge]:
        return [e for (_, t, _), e in self._edges.items() if t == topic]

    def all_targets_for(self, source: str, min_probability: float = 0.05) -> list[CausalEdge]:
        return [
            e for e in self.get_edges_from(source)
            if e.probability >= min_probability and e.confidence >= 0.1
        ]


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class CausalPropagationEngine:
    """
    Models causal propagation through the entity-topic knowledge graph.

    Parameters
    ----------
    pool            : asyncpg pool (optional, for persistence)
    min_probability : minimum edge probability to include in paths
    max_hops        : maximum propagation hops (2 = A→topic→B→topic→C)
    """

    def __init__(
        self,
        pool            = None,
        min_probability : float = 0.05,
        max_hops        : int   = 2,
    ) -> None:
        self._store         = CausalEdgeStore(pool=pool)
        self._min_prob      = min_probability
        self._max_hops      = max_hops
        # Recent events for same-cycle co-occurrence detection
        self._recent_events: list[tuple[str, str, float, datetime]] = []  # (entity, topic, sentiment, ts)

    # ------------------------------------------------------------------
    # Ingest
    # ------------------------------------------------------------------

    async def record_event(
        self,
        entity:    str,
        topic:     str,
        sentiment: float,
        ts:        Optional[datetime] = None,
    ) -> None:
        """
        Record that 'entity' was associated with 'topic' at time 'ts'.
        Automatically detects co-occurrences with other recent events.
        """
        ts = ts or datetime.now(timezone.utc)

        # Find other entities recently associated with the same topic
        cutoff = ts - timedelta(days=7)
        same_topic = [
            (e, t, s, event_ts)
            for e, t, s, event_ts in self._recent_events
            if t == topic and event_ts >= cutoff and e != entity
        ]

        for prior_entity, _, _, prior_ts in same_topic:
            # Record bidirectional co-occurrence
            await self._store.record_co_occurrence(prior_entity, topic, entity)
            await self._store.record_co_occurrence(entity, topic, prior_entity)

        # Append to recent events
        self._recent_events.append((entity, topic, sentiment, ts))
        # Bound
        cutoff_bound = ts - timedelta(days=30)
        self._recent_events = [
            r for r in self._recent_events if r[3] >= cutoff_bound
        ]

    async def record_confirmed_propagation(
        self,
        source_entity: str,
        topic:         str,
        target_entity: str,
        lag_days:      float,
        impact:        float,
    ) -> None:
        """
        Call this when you've confirmed a downstream price move.
        This is the ground-truth signal that improves future probability estimates.
        """
        await self._store.record_propagation(source_entity, topic, target_entity, lag_days, impact)

    # ------------------------------------------------------------------
    # Propagate
    # ------------------------------------------------------------------

    async def propagate(
        self,
        source_entity: str,
        hops:          int = 2,
        sentiment:     float = 1.0,
    ) -> list[PropagationPath]:
        """
        Given an event for source_entity, generate the most likely
        downstream propagation paths up to `hops` steps.

        Returns paths sorted by probability × |expected_impact|.
        """
        hops = min(hops, self._max_hops)
        paths: list[PropagationPath] = []

        await self._bfs(
            source     = source_entity,
            sentiment  = sentiment,
            depth      = 0,
            max_depth  = hops,
            visited    = {source_entity},
            chain      = [source_entity],
            paths      = paths,
        )

        # Sort by expected value (probability × |impact|)
        paths.sort(key=lambda p: p.probability * abs(p.expected_impact), reverse=True)
        return paths[:20]  # top 20

    async def _bfs(
        self,
        source:    str,
        sentiment: float,
        depth:     int,
        max_depth: int,
        visited:   set,
        chain:     list[str],
        paths:     list[PropagationPath],
    ) -> None:
        if depth >= max_depth:
            return

        edges = self._store.all_targets_for(source, min_probability=self._min_prob)

        for edge in edges:
            if edge.target in visited:
                continue

            # Attenuate probability with distance
            attenuation = 0.8 ** depth
            effective_prob = edge.probability * attenuation * edge.confidence

            if effective_prob < self._min_prob:
                continue

            # Expected impact: combine edge magnitude with source sentiment direction
            direction = 1.0 if sentiment > 0 else -1.0
            expected_impact = edge.expected_impact * direction * (0.7 ** depth)

            path = PropagationPath(
                source              = chain[0],
                topic               = edge.topic,
                target              = edge.target,
                probability         = round(effective_prob, 4),
                expected_impact     = round(expected_impact, 4),
                expected_delay_days = edge.expected_delay_days + depth * 1.5,
                confidence          = round(edge.confidence, 4),
                hop_count           = depth + 1,
                chain               = list(chain) + [edge.topic, edge.target],
            )
            paths.append(path)

            # Recurse
            await self._bfs(
                source    = edge.target,
                sentiment = sentiment * (0.7 ** (depth + 1)),
                depth     = depth + 1,
                max_depth = max_depth,
                visited   = visited | {edge.target},
                chain     = list(chain) + [edge.topic, edge.target],
                paths     = paths,
            )

    # ------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------

    def edge_summary(self) -> list[dict]:
        """Return all edges with p > 0.1 as a list of dicts."""
        return [
            {
                "source":       e.source,
                "topic":        e.topic,
                "target":       e.target,
                "probability":  round(e.probability, 4),
                "expected_impact": round(e.expected_impact, 4),
                "expected_delay_days": round(e.expected_delay_days, 1),
                "confidence":   round(e.confidence, 4),
                "n_observed":   e.co_occurrence_count,
            }
            for e in self._store._edges.values()
            if e.probability >= 0.10 and e.confidence >= 0.1
        ]
