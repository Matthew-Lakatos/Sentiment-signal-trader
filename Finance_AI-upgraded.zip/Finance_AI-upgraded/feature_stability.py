"""
feature_stability.py — track whether feature importance drifts over time.

Problem
-------
A model calibrated on 6 months of data may have weights that were correct
then but are wrong now.  Sentiment's predictive power may fade as the market
learns to read the same signals.  Materiality may spike during earnings season
and collapse in quiet periods.

This module runs a rolling regression over time-sorted events and tracks:
  1. Rolling coefficient for each feature (does the weight change sign?)
  2. Coefficient variance (is the weight stable or erratic?)
  3. Stability score per feature [0, 1] — 1 = very stable, 0 = drifting
  4. Drift alerts — flag if a coefficient's sign flips or variance is high

Usage
-----
    from feature_stability import analyse_stability, StabilityReport

    report = analyse_stability(events, horizon=1, window=60, step=20)
    print(report.summary())
    report.save("stability.json")
"""
from __future__ import annotations

import json
import logging
import math
from dataclasses import dataclass, field, asdict
from typing import Optional

logger = logging.getLogger(__name__)

# Features tracked (must match calibration.FEATURE_NAMES + interactions)
_ALL_FEATURES = [
    "sentiment", "materiality", "novelty", "credibility",
    "sent_x_novelty", "mat_x_credibility",  # interaction terms
]


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class FeatureTrace:
    """Time series of rolling coefficients for one feature."""
    name:         str
    coefficients: list[float]       # one per window
    window_ids:   list[int]         # 0-indexed window number
    mean:         float
    std:          float
    min_:         float
    max_:         float
    sign_flips:   int               # how many times the sign changes
    stability:    float             # [0, 1] — higher is more stable


@dataclass
class StabilityReport:
    horizon:        int
    window_size:    int
    step_size:      int
    n_windows:      int
    traces:         dict[str, FeatureTrace]  # feature → trace
    stable_features:   list[str]             # stability ≥ 0.70
    unstable_features: list[str]             # stability < 0.40
    drift_warnings:    list[str]

    def summary(self) -> str:
        lines = [
            f"\n{'═'*62}",
            f"  FEATURE STABILITY REPORT  (T+{self.horizon}d)",
            f"  windows={self.n_windows}  size={self.window_size}  step={self.step_size}",
            f"{'═'*62}",
            f"  {'Feature':<22} {'Mean':>7} {'Std':>7} {'Flips':>6} {'Stable':>8}",
            f"{'─'*62}",
        ]
        for feat, tr in self.traces.items():
            flag = "✓" if tr.stability >= 0.70 else ("⚠" if tr.stability >= 0.40 else "✗")
            lines.append(
                f"  {flag} {feat:<20} {tr.mean:>7.4f} {tr.std:>7.4f} "
                f"{tr.sign_flips:>6} {tr.stability:>8.3f}"
            )
        if self.stable_features:
            lines.append(f"\n  ✓ Stable:   {', '.join(self.stable_features)}")
        if self.unstable_features:
            lines.append(f"  ✗ Drifting: {', '.join(self.unstable_features)}")
        for w in self.drift_warnings:
            lines.append(f"  ⚠  {w}")
        lines.append(f"{'═'*62}")
        return "\n".join(lines)

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2, default=str)
        logger.info("Stability report saved → %s", path)

    def to_dict(self) -> dict:
        return {
            "horizon":          self.horizon,
            "n_windows":        self.n_windows,
            "stable_features":  self.stable_features,
            "unstable_features": self.unstable_features,
            "drift_warnings":   self.drift_warnings,
            "traces": {
                f: {
                    "mean": t.mean, "std": t.std,
                    "sign_flips": t.sign_flips, "stability": t.stability,
                    "coefficients": t.coefficients,
                }
                for f, t in self.traces.items()
            },
        }


# ---------------------------------------------------------------------------
# Interaction term builder (shared with calibration.py)
# ---------------------------------------------------------------------------

def add_interactions(X):
    """
    Append two interaction columns to feature matrix X:
        col 4: sentiment × novelty      (signed_sent × nov)
        col 5: materiality × credibility (mat × cred)
    X must have columns [sentiment, materiality, novelty, credibility].
    Returns augmented X with shape (n, 6).
    """
    import numpy as np
    sent_x_nov  = (X[:, 0] * X[:, 2]).reshape(-1, 1)
    mat_x_cred  = (X[:, 1] * X[:, 3]).reshape(-1, 1)
    return np.hstack([X, sent_x_nov, mat_x_cred])


# ---------------------------------------------------------------------------
# Rolling OLS
# ---------------------------------------------------------------------------

def _ols_coefs(X, y):
    """
    Fit OLS on (X, y) and return coefficient vector (no intercept).
    Returns None if rank-deficient.
    """
    import numpy as np
    try:
        beta, _, _, _ = np.linalg.lstsq(X, y, rcond=None)
        return beta
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Stability score computation
# ---------------------------------------------------------------------------

def _stability_score(coefficients: list[float]) -> float:
    """
    Stability ∈ [0, 1].

    Penalises:
      - high coefficient of variation  (std / |mean|)
      - sign flips
    """
    n = len(coefficients)
    if n < 2:
        return 1.0

    mean = sum(coefficients) / n
    std  = math.sqrt(sum((c - mean) ** 2 for c in coefficients) / (n - 1))

    # Coefficient of variation (normalised)
    cv = std / (abs(mean) + 1e-6)
    cv_score = max(0.0, 1.0 - cv)

    # Sign flip penalty
    flips = sum(
        1 for i in range(n - 1)
        if coefficients[i] * coefficients[i + 1] < 0
    )
    flip_penalty = flips / max(1, n - 1)

    return round(max(0.0, min(1.0, 0.6 * cv_score + 0.4 * (1.0 - flip_penalty))), 4)


def _count_sign_flips(coefficients: list[float]) -> int:
    return sum(
        1 for i in range(len(coefficients) - 1)
        if coefficients[i] * coefficients[i + 1] < 0
    )


# ---------------------------------------------------------------------------
# Main API
# ---------------------------------------------------------------------------

def analyse_stability(
    events:      list[dict],
    horizon:     int   = 1,
    window:      int   = 60,    # events per rolling window
    step:        int   = 20,    # events to advance per step
    with_interactions: bool = True,
) -> StabilityReport:
    """
    Run rolling OLS over time-sorted events and track how feature weights change.

    Parameters
    ----------
    events           list of scored+price-joined event dicts (sorted by time)
    horizon          return horizon (1, 3, or 5 days)
    window           number of events per rolling window
    step             stride between windows
    with_interactions include sentiment×novelty and materiality×credibility

    Returns
    -------
    StabilityReport with per-feature traces and stability scores
    """
    import numpy as np

    key = f"fwd_ret_{horizon}d"
    feat_names = list(_ALL_FEATURES) if with_interactions else _ALL_FEATURES[:4]

    # Sort by time and filter to events with price data
    def _ts_key(ev):
        return str(ev.get("scraped_at") or "")

    sorted_evs = sorted(events, key=_ts_key)
    valid = []
    for ev in sorted_evs:
        y_val = ev.get(key)
        if y_val is None or not math.isfinite(float(y_val)):
            continue
        label    = (ev.get("sentiment_label") or "NEUTRAL").upper()
        sent_abs = float(ev.get("sentiment_score") or 0.0)
        sign     = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
        valid.append({
            "x": [
                sign * sent_abs,
                float(ev.get("materiality_score") or 0.0),
                float(ev.get("novelty_score")      or 0.5),
                float(ev.get("credibility_score")  or 0.5),
            ],
            "y": float(y_val),
        })

    if len(valid) < window:
        logger.warning(
            "Stability: only %d valid events, need ≥ %d. Returning empty report.",
            len(valid), window
        )
        return _empty_report(horizon, window, step)

    # Build windowed coefficient traces
    windows_coefs: list[list[float]] = []    # [window_idx][feature_idx]
    w_ids = []
    w_idx = 0

    for start in range(0, len(valid) - window + 1, step):
        chunk = valid[start: start + window]
        X = np.array([r["x"] for r in chunk], dtype=float)
        y = np.array([r["y"] for r in chunk], dtype=float)

        if with_interactions:
            X = add_interactions(X)

        beta = _ols_coefs(X, y)
        if beta is None:
            continue

        windows_coefs.append(list(beta))
        w_ids.append(w_idx)
        w_idx += 1

    if not windows_coefs:
        return _empty_report(horizon, window, step)

    n_windows = len(windows_coefs)
    n_feats   = len(feat_names)

    # Per-feature traces
    traces: dict[str, FeatureTrace] = {}
    drift_warnings: list[str] = []

    for fi, fname in enumerate(feat_names):
        if fi >= len(windows_coefs[0]):
            continue
        coefs = [windows_coefs[wi][fi] for wi in range(n_windows)]

        mean_c  = sum(coefs) / len(coefs)
        std_c   = math.sqrt(sum((c - mean_c) ** 2 for c in coefs) / max(1, len(coefs) - 1))
        flips   = _count_sign_flips(coefs)
        stab    = _stability_score(coefs)

        traces[fname] = FeatureTrace(
            name         = fname,
            coefficients = [round(c, 6) for c in coefs],
            window_ids   = w_ids,
            mean         = round(mean_c, 6),
            std          = round(std_c,  6),
            min_         = round(min(coefs), 6),
            max_         = round(max(coefs), 6),
            sign_flips   = flips,
            stability    = stab,
        )

        if flips >= n_windows // 3:
            drift_warnings.append(
                f"{fname}: sign flipped {flips}× across {n_windows} windows — "
                "feature may be noise-driven"
            )
        if stab < 0.40:
            drift_warnings.append(
                f"{fname}: stability={stab:.3f} < 0.40 — "
                "consider removing or regularising this feature"
            )

    stable   = [f for f, tr in traces.items() if tr.stability >= 0.70]
    unstable = [f for f, tr in traces.items() if tr.stability < 0.40]

    return StabilityReport(
        horizon           = horizon,
        window_size       = window,
        step_size         = step,
        n_windows         = n_windows,
        traces            = traces,
        stable_features   = stable,
        unstable_features = unstable,
        drift_warnings    = drift_warnings,
    )


def _empty_report(horizon: int, window: int, step: int) -> StabilityReport:
    return StabilityReport(
        horizon=horizon, window_size=window, step_size=step,
        n_windows=0, traces={}, stable_features=[],
        unstable_features=[], drift_warnings=["Insufficient data"],
    )
