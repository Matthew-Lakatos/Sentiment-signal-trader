"""
worker.py — long-running scraper worker entry point.
Runs the pipeline on a fixed interval with distributed PG advisory lock.
"""
from __future__ import annotations
import asyncio
import logging
import signal

from config import settings
from database import get_pool, close_pool
from knowledge_graph import init_knowledge_graph
from logging_config import setup_logging
from main import run_pipeline, DEFAULT_URLS
from monitor import start_metrics_server
from scheduler import run_scheduled_pipeline

setup_logging()
logger = logging.getLogger(__name__)

_shutdown = asyncio.Event()


def _handle_signal(sig, frame):
    logger.info("Received signal %s — shutting down gracefully", sig)
    _shutdown.set()


async def main() -> None:
    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT,  _handle_signal)

    pool = await get_pool()
    await init_knowledge_graph(pool)
    start_metrics_server()

    logger.info("Worker started — pipeline interval: %ds", settings.pipeline_interval_seconds)

    # Read URLs from urls.txt if present, otherwise use defaults
    try:
        with open("urls.txt") as f:
            urls = [u.strip() for u in f if u.strip() and not u.startswith("#")]
        logger.info("Loaded %d URLs from urls.txt", len(urls))
    except FileNotFoundError:
        urls = DEFAULT_URLS
        logger.info("urls.txt not found — using %d default URLs", len(urls))

    scheduler_task = asyncio.create_task(
        run_scheduled_pipeline(
            pool,
            lambda: run_pipeline(urls),
            interval_s=settings.pipeline_interval_seconds,
        )
    )

    # Wait for shutdown signal
    await _shutdown.wait()
    scheduler_task.cancel()
    try:
        await scheduler_task
    except asyncio.CancelledError:
        pass

    await close_pool()
    logger.info("Worker stopped cleanly")


if __name__ == "__main__":
    asyncio.run(main())
