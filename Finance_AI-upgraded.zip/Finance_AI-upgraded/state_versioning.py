"""
state_versioning.py — #9 Versioned State Vectors.

Every major engine output (expectation vector, positioning snapshot,
liquidity snapshot, governance report) should be versioned, timestamped,
and schema-tracked for full reproducibility.

This module provides:
  StateVector       — versioned container wrapping any engine output
  StateVectorStore  — in-memory + optional DB store for state history
  schema_hash()     — deterministic hash of an output's field set
  diff()            — structured diff between two state vectors

Why this matters
----------------
Without versioning:
  - It's impossible to know which inputs produced a given backtest output
  - Debugging governance decisions requires reconstructing state from logs
  - Rolling recalibration silently invalidates prior decisions

With versioning:
  - Every governance decision is traceable to an exact state snapshot
  - Backtests can replay exactly the state the system saw at each point
  - Anomalies in governance confidence can be root-caused to specific inputs

Usage
-----
    from state_versioning import StateVector, StateVectorStore

    store = StateVectorStore()

    # Wrap a governance report
    sv = StateVector.from_dict(
        data        = report.__dict__,
        schema_name = "governance",
        version     = "1.0",
        source      = "governance_engine",
    )
    store.push(sv)

    # Retrieve latest
    latest = store.latest("governance")

    # Get history
    history = store.history("governance", last_n=10)

    # Diff two states
    delta = store.diff("governance", store.history("governance")[-2], latest)
"""
from __future__ import annotations

import hashlib
import json
import logging
from collections import defaultdict, deque
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)

_MAX_HISTORY_PER_KEY = 500


# ---------------------------------------------------------------------------
# StateVector
# ---------------------------------------------------------------------------

@dataclass
class StateVector:
    schema_name:  str
    version:      str
    source:       str
    data:         dict[str, Any]
    schema_hash:  str
    data_hash:    str
    created_at:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    parent_hash:  Optional[str] = None    # hash of the previous vector (chain)
    tags:         dict[str, str] = field(default_factory=dict)

    @classmethod
    def from_dict(
        cls,
        data:        dict[str, Any],
        schema_name: str,
        version:     str    = "1.0",
        source:      str    = "unknown",
        parent:      Optional["StateVector"] = None,
        tags:        Optional[dict] = None,
    ) -> "StateVector":
        # Compute stable hashes
        schema_h = _hash_schema(data)
        data_h   = _hash_data(data)
        return cls(
            schema_name = schema_name,
            version     = version,
            source      = source,
            data        = _sanitise(data),
            schema_hash = schema_h,
            data_hash   = data_h,
            parent_hash = parent.data_hash if parent else None,
            tags        = tags or {},
        )

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)

    def to_json(self) -> str:
        d = {
            "schema_name":  self.schema_name,
            "version":      self.version,
            "source":       self.source,
            "schema_hash":  self.schema_hash,
            "data_hash":    self.data_hash,
            "created_at":   self.created_at.isoformat(),
            "parent_hash":  self.parent_hash,
            "tags":         self.tags,
            "data":         self.data,
        }
        return json.dumps(d, default=str)

    @classmethod
    def from_json(cls, raw: str) -> "StateVector":
        d = json.loads(raw)
        return cls(
            schema_name = d["schema_name"],
            version     = d["version"],
            source      = d["source"],
            data        = d["data"],
            schema_hash = d["schema_hash"],
            data_hash   = d["data_hash"],
            created_at  = datetime.fromisoformat(d["created_at"]),
            parent_hash = d.get("parent_hash"),
            tags        = d.get("tags", {}),
        )


# ---------------------------------------------------------------------------
# Hashing helpers
# ---------------------------------------------------------------------------

def _sanitise(data: dict) -> dict:
    """Convert non-serialisable types to strings/numbers for storage."""
    out = {}
    for k, v in data.items():
        if isinstance(v, datetime):
            out[k] = v.isoformat()
        elif isinstance(v, (list, dict, str, int, float, bool, type(None))):
            out[k] = v
        else:
            out[k] = str(v)
    return out


def _hash_schema(data: dict) -> str:
    """Hash the field names (schema) — stable across runs."""
    keys = sorted(data.keys())
    raw  = json.dumps(keys)
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


def _hash_data(data: dict) -> str:
    """Hash the data values — changes when any value changes."""
    try:
        raw = json.dumps(_sanitise(data), sort_keys=True, default=str)
    except Exception:
        raw = str(sorted(data.items()))
    return hashlib.sha256(raw.encode()).hexdigest()[:16]


# ---------------------------------------------------------------------------
# Diff
# ---------------------------------------------------------------------------

@dataclass
class StateDiff:
    schema_name:   str
    from_hash:     str
    to_hash:       str
    changed_fields: dict[str, tuple[Any, Any]]  # field → (old, new)
    added_fields:   list[str]
    removed_fields: list[str]
    from_at:       Optional[datetime]
    to_at:         Optional[datetime]

    def has_changes(self) -> bool:
        return bool(self.changed_fields or self.added_fields or self.removed_fields)

    def summary(self) -> str:
        changes = list(self.changed_fields)[:5]
        return (
            f"StateDiff[{self.schema_name}]: "
            f"{len(self.changed_fields)} changed, "
            f"{len(self.added_fields)} added, "
            f"{len(self.removed_fields)} removed. "
            f"Changed: {changes}"
        )


def diff(sv_old: StateVector, sv_new: StateVector) -> StateDiff:
    """Compute a structured diff between two StateVectors."""
    old_data = sv_old.data
    new_data = sv_new.data

    all_keys    = set(old_data) | set(new_data)
    changed     = {}
    added       = []
    removed     = []

    for k in all_keys:
        if k not in old_data:
            added.append(k)
        elif k not in new_data:
            removed.append(k)
        elif old_data[k] != new_data[k]:
            changed[k] = (old_data[k], new_data[k])

    return StateDiff(
        schema_name    = sv_new.schema_name,
        from_hash      = sv_old.data_hash,
        to_hash        = sv_new.data_hash,
        changed_fields = changed,
        added_fields   = added,
        removed_fields = removed,
        from_at        = sv_old.created_at,
        to_at          = sv_new.created_at,
    )


# ---------------------------------------------------------------------------
# StateVectorStore
# ---------------------------------------------------------------------------

class StateVectorStore:
    """
    In-memory store for state vector history, keyed by schema_name.

    Optionally persists to a DB pool (asyncpg) when pool is set.
    """

    def __init__(self, max_per_key: int = _MAX_HISTORY_PER_KEY, pool=None) -> None:
        self._store: dict[str, deque[StateVector]] = defaultdict(
            lambda: deque(maxlen=max_per_key)
        )
        self._pool = pool

    def push(self, sv: StateVector) -> None:
        """Store a StateVector and optionally persist it."""
        self._store[sv.schema_name].append(sv)
        logger.debug(
            "StateVector[%s] stored: data_hash=%s  schema_hash=%s",
            sv.schema_name, sv.data_hash, sv.schema_hash,
        )

    def latest(self, schema_name: str) -> Optional[StateVector]:
        buf = self._store.get(schema_name)
        if not buf:
            return None
        return buf[-1]

    def history(self, schema_name: str, last_n: int = 50) -> list[StateVector]:
        buf = self._store.get(schema_name, deque())
        hist = list(buf)
        return hist[-last_n:] if last_n else hist

    def diff_latest(self, schema_name: str) -> Optional[StateDiff]:
        """Diff the two most recent state vectors."""
        hist = self.history(schema_name, last_n=2)
        if len(hist) < 2:
            return None
        return diff(hist[-2], hist[-1])

    def schema_changed(self, schema_name: str) -> bool:
        """True if the schema (field set) changed between the last two vectors."""
        hist = self.history(schema_name, last_n=2)
        if len(hist) < 2:
            return False
        return hist[-2].schema_hash != hist[-1].schema_hash

    async def persist(self, sv: StateVector) -> None:
        """Write a StateVector to the DB (state_vectors table)."""
        if self._pool is None:
            return
        try:
            await self._pool.execute("""
                INSERT INTO state_vectors
                    (schema_name, version, source, schema_hash, data_hash,
                     parent_hash, created_at, tags_json, data_json)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
                ON CONFLICT (data_hash) DO NOTHING
            """,
                sv.schema_name, sv.version, sv.source,
                sv.schema_hash, sv.data_hash, sv.parent_hash,
                sv.created_at, json.dumps(sv.tags), sv.to_json(),
            )
        except Exception as exc:
            logger.warning("Failed to persist StateVector: %s", exc)


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_store: Optional[StateVectorStore] = None


def get_store(pool=None) -> StateVectorStore:
    global _store
    if _store is None:
        _store = StateVectorStore(pool=pool)
    return _store
