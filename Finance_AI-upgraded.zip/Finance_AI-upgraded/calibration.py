"""
calibration.py — learn and validate signal weights from realised returns.

Three calibration modes
-----------------------
1. OLS / Ridge regression
   Features: sentiment, materiality, novelty, credibility [+ interactions]
   Target:   forward return at horizon H (T+1, T+3, T+5)
   Output:   fitted weights + R2, t-stats, p-values

2. Rank-IC optimisation (Spearman)
   Maximises IC = rank-corr(signal, return) by gradient-free search.

3. Grid search
   Exhaustively tests weight combinations over a discrete grid.
   Returns the combo with best out-of-sample IC.

Feature orthogonality
---------------------
Before fitting, compute Pearson correlation matrix + VIF per feature.
Flag any feature with VIF > 5 (multicollinearity warning).

Interaction terms (NEW)
-----------------------
  sent_x_novelty     = sentiment × novelty
  mat_x_credibility  = materiality × credibility
Enable via with_interactions=True in calibrate().

Usage
-----
    result = calibrate(events, horizon=1, method="ridge", with_interactions=True)
    print(result.weights)
    print(result.orthogonality_report())
    result.save("weights.json")
"""
from __future__ import annotations

import json
import logging
import math
from dataclasses import dataclass, asdict, field
from typing import Literal, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Feature name lists
# ---------------------------------------------------------------------------

FEATURE_NAMES = ["sentiment", "materiality", "novelty", "credibility"]
FEATURE_NAMES_WITH_INTERACTIONS = [
    "sentiment", "materiality", "novelty", "credibility",
    "sent_x_novelty",       # sentiment × novelty
    "mat_x_credibility",    # materiality × credibility
]


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class CalibrationResult:
    method:            str
    horizon:           int
    weights:           dict[str, float]
    ic:                float
    ic_oos:            Optional[float]
    r_squared:         Optional[float]
    t_stats:           Optional[dict]
    p_values:          Optional[dict]
    n_samples:         int
    notes:             str = ""
    corr_matrix:       Optional[dict] = None
    vif:               Optional[dict] = None
    corr_warnings:     list[str] = field(default_factory=list)
    vif_warnings:      list[str] = field(default_factory=list)
    with_interactions: bool = False

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2)
        logger.info("Calibration result saved → %s", path)

    @classmethod
    def from_file(cls, path: str) -> "CalibrationResult":
        with open(path) as f:
            d = json.load(f)
        return cls(**d)

    def orthogonality_report(self) -> str:
        lines = ["\n  ── Feature Orthogonality ─────────────────────────"]
        if self.corr_matrix:
            feat_list = list(self.corr_matrix.keys())
            lines.append("  Correlation matrix:")
            header = f"  {'':>14}" + "".join(f"{f[:6]:>8}" for f in feat_list)
            lines.append(header)
            for f in feat_list:
                row_vals = "".join(
                    f"{self.corr_matrix[f].get(g, 0.0):>8.3f}" for g in feat_list
                )
                lines.append(f"  {f[:14]:>14}{row_vals}")
        if self.vif:
            lines.append("  VIF per feature:")
            for f, v in self.vif.items():
                flag = " ⚠ HIGH" if v > 5.0 else ("  ⚠ MOD" if v > 2.5 else "  ✓")
                lines.append(f"    {f:<22} VIF={v:.2f}{flag}")
        for w in self.corr_warnings + self.vif_warnings:
            lines.append(f"  ⚠  {w}")
        if not self.corr_warnings and not self.vif_warnings:
            lines.append("  ✓  All features are sufficiently orthogonal")
        return "\n".join(lines)


def load_weights(path: str) -> dict[str, float]:
    with open(path) as f:
        d = json.load(f)
    return d["weights"]


# ---------------------------------------------------------------------------
# Feature matrix builder
# ---------------------------------------------------------------------------

def _build_feature_matrix(
    events: list[dict],
    with_interactions: bool = False,
) -> tuple:
    import numpy as np

    rows_X, rows_y = [], []
    for ev in events:
        y_val = ev.get("fwd_ret")
        if y_val is None or not math.isfinite(float(y_val)):
            continue

        label    = (ev.get("sentiment_label") or "NEUTRAL").upper()
        sent_abs = float(ev.get("sentiment_score") or 0.0)
        sign     = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
        sent     = sign * sent_abs
        mat      = float(ev.get("materiality_score") or 0.0)
        nov      = float(ev.get("novelty_score")      or 0.5)
        cred     = float(ev.get("credibility_score")  or 0.5)

        row = [sent, mat, nov, cred]
        if with_interactions:
            row.append(sent * nov)   # sentiment × novelty
            row.append(mat  * cred)  # materiality × credibility

        rows_X.append(row)
        rows_y.append(float(y_val))

    if len(rows_X) < 10:
        return None, None

    return (
        np.array(rows_X, dtype=float),
        np.array(rows_y, dtype=float),
    )


# ---------------------------------------------------------------------------
# Feature orthogonality diagnostics
# ---------------------------------------------------------------------------

def compute_orthogonality(
    X,
    feature_names: Optional[list[str]] = None,
) -> dict:
    import numpy as np

    n, p  = X.shape
    feats = (feature_names or FEATURE_NAMES)[:p]

    corr = np.corrcoef(X, rowvar=False)
    corr_matrix = {
        f: {g: round(float(corr[i, j]), 4) for j, g in enumerate(feats)}
        for i, f in enumerate(feats)
    }

    corr_warnings = []
    for i in range(p):
        for j in range(i + 1, p):
            r = float(corr[i, j])
            if abs(r) >= 0.60:
                strength = "strong" if abs(r) > 0.75 else "moderate"
                corr_warnings.append(
                    f"{feats[i]}↔{feats[j]} r={r:.3f} — {strength} correlation"
                )

    vif_vals, vif_warnings = {}, []
    for j, feat in enumerate(feats):
        y_aux   = X[:, j]
        X_aux   = np.delete(X, j, axis=1)
        X_aux_b = np.hstack([np.ones((n, 1)), X_aux])
        try:
            beta_aux  = np.linalg.lstsq(X_aux_b, y_aux, rcond=None)[0]
            ss_res    = ((y_aux - X_aux_b @ beta_aux) ** 2).sum()
            ss_tot    = ((y_aux - y_aux.mean()) ** 2).sum()
            r2_aux    = 1.0 - ss_res / max(ss_tot, 1e-12)
            vif       = 1.0 / max(1.0 - r2_aux, 1e-6)
        except Exception:
            vif = float("nan")
        vif_vals[feat] = round(float(vif), 3)
        if math.isfinite(vif) and vif > 5.0:
            vif_warnings.append(
                f"{feat} VIF={vif:.2f} > 5.0 — weights may be unreliable"
            )

    return {
        "corr_matrix":   corr_matrix,
        "vif":           vif_vals,
        "corr_warnings": corr_warnings,
        "vif_warnings":  vif_warnings,
    }


# ---------------------------------------------------------------------------
# Ridge regression
# ---------------------------------------------------------------------------

def _ridge_calibrate(
    X, y,
    alpha:         float = 1.0,
    feature_names: Optional[list[str]] = None,
) -> dict:
    import numpy as np
    fnames = feature_names or FEATURE_NAMES

    n, p  = X.shape
    X_b   = np.hstack([np.ones((n, 1)), X])
    I     = np.eye(p + 1); I[0, 0] = 0.0
    beta  = np.linalg.solve(X_b.T @ X_b + alpha * I, X_b.T @ y)

    y_hat     = X_b @ beta
    ss_res    = ((y - y_hat) ** 2).sum()
    ss_tot    = ((y - y.mean()) ** 2).sum()
    r2        = 1.0 - ss_res / max(ss_tot, 1e-12)

    sigma2   = ss_res / max(n - p - 1, 1)
    var_beta = sigma2 * np.linalg.pinv(X_b.T @ X_b + alpha * I)
    se       = np.sqrt(np.diag(var_beta))
    t_arr    = beta[1:] / np.maximum(se[1:], 1e-12)

    t_stats  = dict(zip(fnames, t_arr.tolist()))
    p_values = dict(zip(fnames, _t_to_p(t_arr, n - p - 1).tolist()))
    raw_w    = {f: float(beta[i + 1]) for i, f in enumerate(fnames)}
    total    = sum(abs(v) for v in raw_w.values()) or 1.0
    weights  = {f: round(v / total, 4) for f, v in raw_w.items()}

    return {
        "weights":   weights,
        "r_squared": round(float(r2), 4),
        "t_stats":   {k: round(v, 4) for k, v in t_stats.items()},
        "p_values":  {k: round(v, 4) for k, v in p_values.items()},
    }


def _t_to_p(t_stats, df: int):
    import numpy as np
    z = np.abs(t_stats)
    p = 2.0 * (1.0 - 0.5 * (1.0 + np.array(
        [math.erf(x / math.sqrt(2)) for x in z.flat]
    ).reshape(z.shape)))
    return np.clip(p, 1e-6, 1.0)


# ---------------------------------------------------------------------------
# Rank-IC optimisation
# ---------------------------------------------------------------------------

def _rank_ic_optimise(
    X, y,
    n_restarts:    int = 8,
    feature_names: Optional[list[str]] = None,
) -> dict:
    import numpy as np
    from scipy.optimize import minimize
    from scipy.stats import spearmanr

    fnames = feature_names or FEATURE_NAMES
    nf     = X.shape[1]

    def neg_ic(w):
        r, _ = spearmanr(X @ w, y)
        return -r if math.isfinite(r) else 0.0

    best_w  = np.ones(nf) / nf
    best_ic = neg_ic(best_w)
    rng     = np.random.default_rng(42)

    for _ in range(n_restarts):
        w0  = rng.dirichlet(np.ones(nf))
        res = minimize(neg_ic, w0, method="Nelder-Mead",
                       options={"maxiter": 2000, "xatol": 1e-6})
        if res.fun < best_ic:
            best_ic, best_w = res.fun, res.x

    w = np.abs(best_w); w /= w.sum() or 1.0
    weights = {f: round(float(w[i]), 4) for i, f in enumerate(fnames)}
    ic, _   = spearmanr(X @ np.array(list(weights.values())), y)

    return {
        "weights":   weights,
        "r_squared": None, "t_stats": None, "p_values": None,
        "_ic":       round(float(ic), 4),
    }


# ---------------------------------------------------------------------------
# Grid search
# ---------------------------------------------------------------------------

_GRID_VALUES = [0.1, 0.2, 0.3, 0.4, 0.5]


def _grid_search(
    X, y,
    oos_frac:      float = 0.3,
    feature_names: Optional[list[str]] = None,
) -> dict:
    import numpy as np
    from scipy.stats import spearmanr
    from itertools import product

    fnames = feature_names or FEATURE_NAMES
    nf     = X.shape[1]
    n      = len(y)
    split  = int(n * (1 - oos_frac))
    X_tr, X_oo = X[:split], X[split:]
    y_tr, y_oo = y[:split], y[split:]

    best_ic, best_w = -999.0, None
    for combo in product(_GRID_VALUES, repeat=nf):
        w = np.array(combo); w /= w.sum()
        if len(X_oo) < 3:
            continue
        ic_oo, _ = spearmanr(X_oo @ w, y_oo)
        if math.isfinite(ic_oo) and ic_oo > best_ic:
            best_ic, best_w = ic_oo, w

    if best_w is None:
        best_w = np.ones(nf) / nf

    weights = {f: round(float(best_w[i]), 4) for i, f in enumerate(fnames)}
    ic_is, _ = spearmanr(X_tr @ best_w, y_tr)

    return {
        "weights":   weights,
        "r_squared": None, "t_stats": None, "p_values": None,
        "_ic":       round(float(ic_is), 4),
        "_ic_oos":   round(float(best_ic), 4),
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def calibrate(
    events:            list[dict],
    horizon:           int     = 1,
    method:            Literal["ridge", "rank_ic", "grid", "bayesian", "lgbm", "xgboost", "ensemble"] = "ridge",
    ridge_alpha:       float   = 1.0,
    oos_frac:          float   = 0.3,
    with_interactions: bool    = False,
) -> CalibrationResult:
    """
    Calibrate signal weights against realised forward returns.

    Parameters
    ----------
    events             list of dicts with signal fields + fwd_ret_{horizon}d
    horizon            1, 3, or 5 (days forward)
    method             "ridge" | "rank_ic" | "grid" | "bayesian" | "lgbm" | "xgboost" | "ensemble"
    ridge_alpha        L2 strength (method="ridge" only)
    oos_frac           fraction held out for OOS evaluation
    with_interactions  if True, include sent×novelty and mat×cred interaction columns
    """
    import numpy as np
    from rolling_ic_fast import rolling_spearman_ic, ic_significance

    fnames    = FEATURE_NAMES_WITH_INTERACTIONS if with_interactions else FEATURE_NAMES
    key       = f"fwd_ret_{horizon}d"
    augmented = [{**ev, "fwd_ret": ev.get(key)} for ev in events]
    X, y      = _build_feature_matrix(augmented, with_interactions=with_interactions)

    if X is None:
        raise ValueError(f"Not enough valid samples (need ≥ 10 with {key})")

    n = len(y)
    logger.info("Calibrating: method=%s horizon=T+%d n=%d interactions=%s",
                method, horizon, n, with_interactions)

    orth = compute_orthogonality(X, feature_names=fnames)

    # ── Route ML methods to ml_calibration.py ──────────────────────────────
    from ml_calibration import is_ml_method, dispatch as ml_dispatch
    if is_ml_method(method):
        out = ml_dispatch(method, X, y, feature_names=fnames)
    elif method == "ridge":
        out = _ridge_calibrate(X, y, alpha=ridge_alpha, feature_names=fnames)
    elif method == "rank_ic":
        out = _rank_ic_optimise(X, y, feature_names=fnames)
    elif method == "grid":
        out = _grid_search(X, y, oos_frac=oos_frac, feature_names=fnames)
    else:
        raise ValueError(f"Unknown method: {method}")

    w_vec = np.array([out["weights"].get(f, 0.0) for f in fnames])

    # ── In-sample IC via fast rolling implementation ─────────────────────
    composite = X @ w_vec
    win       = min(60, n)
    ic_series = rolling_spearman_ic(composite, y, window=win)
    ic_stats  = ic_significance(ic_series)
    ic_is     = ic_stats["mean_ic"]

    ic_oos = out.get("_ic_oos")
    if ic_oos is None and n >= 20:
        split   = int(n * (1 - oos_frac))
        y_oos   = y[split:]
        c_oos   = composite[split:]
        if len(y_oos) >= 5:
            ic_oos_ser = rolling_spearman_ic(c_oos, y_oos, window=min(20, len(y_oos)))
            ic_oos     = float(ic_oos_ser[np.isfinite(ic_oos_ser)].mean()) if np.any(np.isfinite(ic_oos_ser)) else None

    for w in orth["corr_warnings"] + orth["vif_warnings"]:
        logger.warning("Orthogonality: %s", w)

    ml_notes = out.get("_notes", "")
    notes    = ml_notes if ml_notes else (f"ridge_alpha={ridge_alpha}" if method == "ridge" else "")

    return CalibrationResult(
        method             = method,
        horizon            = horizon,
        weights            = out["weights"],
        ic                 = round(float(ic_is), 4) if math.isfinite(ic_is) else 0.0,
        ic_oos             = ic_oos,
        r_squared          = out.get("r_squared"),
        t_stats            = out.get("t_stats"),
        p_values           = out.get("p_values"),
        n_samples          = n,
        notes              = notes,
        corr_matrix        = orth["corr_matrix"],
        vif                = orth["vif"],
        corr_warnings      = orth["corr_warnings"],
        vif_warnings       = orth["vif_warnings"],
        with_interactions  = with_interactions,
    )


def apply_calibrated_weights(
    weights:           dict[str, float],
    sentiment_label:   str,
    sentiment_score:   float,
    materiality_score: float,
    novelty_score:     float,
    credibility_score: float,
) -> float:
    label = (sentiment_label or "NEUTRAL").upper()
    sign  = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
    sent  = sign * max(0.0, min(1.0, sentiment_score))
    mat   = max(0.0, min(1.0, materiality_score))
    nov   = max(0.0, min(1.0, novelty_score))
    cred  = max(0.0, min(1.0, credibility_score))

    raw = (
        weights.get("sentiment",        0.25) * sent
      + weights.get("materiality",      0.35) * mat
      + weights.get("novelty",          0.25) * nov
      + weights.get("credibility",      0.15) * cred
      + weights.get("sent_x_novelty",   0.0)  * (sent * nov)
      + weights.get("mat_x_credibility",0.0)  * (mat  * cred)
    )
    return round(max(-1.0, min(1.0, raw)), 4)
