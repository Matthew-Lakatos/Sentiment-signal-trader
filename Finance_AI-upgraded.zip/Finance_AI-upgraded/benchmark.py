"""
benchmark.py — compare the composite alpha signal against baselines.

Baselines
---------
1. random         — shuffled signal scores (noise floor)
2. sentiment_only — use raw sentiment score with no other features
3. market         — buy-and-hold the underlying index / ticker
4. composite      — the full signal_ranker output (what we built)

For each baseline, compute:
    IC (Spearman rank correlation vs forward return)
    hit_rate (direction correct)
    Sharpe (annualised)
    mean_return

The gap between baselines shows whether each layer of complexity adds value.
If composite ≈ random → the non-sentiment features aren't helping.
If composite ≈ sentiment_only → materiality / novelty aren't adding edge.
"""
from __future__ import annotations

import logging
import math
import random
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class BaselineResult:
    name:         str
    ic:           float
    hit_rate:     float
    sharpe:       float
    mean_ret:     float
    n:            int
    notes:        str = ""

    def beats(self, other: "BaselineResult") -> bool:
        """True if self has higher IC than other."""
        return self.ic > other.ic


@dataclass
class BenchmarkReport:
    composite:      BaselineResult
    random_:        BaselineResult
    sentiment_only: BaselineResult
    market:         Optional[BaselineResult]

    def summary(self) -> str:
        lines = [
            f"\n{'─'*60}",
            f"  BENCHMARK REPORT",
            f"{'─'*60}",
            f"  {'Strategy':<22} {'IC':>7} {'Hit%':>7} {'Sharpe':>8} {'MeanRet%':>10}",
            f"{'─'*60}",
        ]
        for label, res in [
            ("composite",       self.composite),
            ("sentiment_only",  self.sentiment_only),
            ("random",          self.random_),
            ("market (B&H)",    self.market),
        ]:
            if res is None:
                continue
            lines.append(
                f"  {label:<22} {res.ic:>7.4f} {res.hit_rate:>6.1%} "
                f"{res.sharpe:>8.2f} {res.mean_ret:>9.4f}%"
            )
        lines.append(f"{'─'*60}")
        lines += self._verdict()
        return "\n".join(lines)

    def _verdict(self) -> list[str]:
        v = []
        c = self.composite
        s = self.sentiment_only
        r = self.random_

        if c.ic <= r.ic + 0.005:
            v.append("  ⚠  Composite ≈ random — signal adds no value over noise")
        elif c.ic <= s.ic + 0.005:
            v.append("  ⚠  Composite ≈ sentiment-only — mat/novelty/credibility not helping")
        else:
            lift = round((c.ic - s.ic) / max(abs(s.ic), 1e-6) * 100, 1)
            v.append(f"  ✓  Composite beats sentiment-only by {lift:.1f}% IC lift")

        if c.sharpe > 2.0:
            v.append("  🚨 Sharpe > 2.0 — check for look-ahead leakage")
        elif c.sharpe > 1.0:
            v.append("  ✓  Sharpe > 1.0 — strong signal for this asset class")

        if c.hit_rate > 0.65:
            v.append("  🚨 Hit rate > 65% — likely leakage or timestamp misalignment")
        elif c.hit_rate > 0.55:
            v.append("  ✓  Hit rate > 55% — directionally informative")

        return v

    def to_dict(self) -> dict:
        def _r(res):
            if res is None:
                return None
            return {
                "ic": res.ic, "hit_rate": res.hit_rate,
                "sharpe": res.sharpe, "mean_ret": res.mean_ret, "n": res.n,
            }
        return {
            "composite":      _r(self.composite),
            "sentiment_only": _r(self.sentiment_only),
            "random":         _r(self.random_),
            "market":         _r(self.market),
        }


# ---------------------------------------------------------------------------
# Metric helpers
# ---------------------------------------------------------------------------

def _spearman_ic(signals: list[float], returns: list[float]) -> float:
    n = len(signals)
    if n < 3:
        return 0.0
    try:
        from scipy.stats import spearmanr
        r, _ = spearmanr(signals, returns)
        return float(r) if math.isfinite(r) else 0.0
    except ImportError:
        # Fallback: manual rank correlation
        def _rank(lst):
            s = sorted(enumerate(lst), key=lambda x: x[1])
            r = [0.0] * len(lst)
            for rank, (i, _) in enumerate(s):
                r[i] = float(rank)
            return r
        rs = _rank(signals)
        rr = _rank(returns)
        d2 = sum((a - b) ** 2 for a, b in zip(rs, rr))
        return 1.0 - 6.0 * d2 / (n * (n * n - 1))


def _hit_rate(signals: list[float], returns: list[float], threshold: float = 0.05) -> float:
    pairs = [(s, r) for s, r in zip(signals, returns) if abs(s) > threshold]
    if not pairs:
        return 0.5
    hits = sum(1 for s, r in pairs if (s > 0 and r > 0) or (s < 0 and r < 0))
    return round(hits / len(pairs), 4)


def _sharpe(returns: list[float]) -> float:
    n = len(returns)
    if n < 2:
        return 0.0
    mean = sum(returns) / n
    var  = sum((r - mean) ** 2 for r in returns) / (n - 1)
    std  = math.sqrt(var)
    if std < 1e-9:
        return 0.0
    return round(mean / std * math.sqrt(252), 4)


def _mean_ret(returns: list[float]) -> float:
    return round(sum(returns) / len(returns), 6) if returns else 0.0


def _baseline_stats(signals: list[float], returns: list[float], name: str, notes: str = "") -> BaselineResult:
    return BaselineResult(
        name     = name,
        ic       = _spearman_ic(signals, returns),
        hit_rate = _hit_rate(signals, returns),
        sharpe   = _sharpe(returns),
        mean_ret = _mean_ret(returns),
        n        = len(returns),
        notes    = notes,
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_benchmark(
    events:        list[dict],
    ticker:        Optional[str] = None,
    horizon:       int = 1,
    seed:          int = 42,
) -> BenchmarkReport:
    """
    Compare composite signal against baselines.

    Each event dict must have:
        signal_score        — composite alpha output
        sentiment_label     — POSITIVE / NEGATIVE / NEUTRAL
        sentiment_score     — [0, 1]
        fwd_ret_{horizon}d  — forward return % at horizon (may be None)

    Parameters
    ----------
    events      list of scored event dicts (output of backtest.run_backtest)
    ticker      optional ticker for buy-and-hold market baseline
    horizon     return horizon in trading days (1, 3, or 5)
    seed        random seed for the random baseline shuffle
    """
    key = f"fwd_ret_{horizon}d"

    # Filter to events that have a price-joined forward return
    valid = [ev for ev in events if ev.get(key) is not None]
    if not valid:
        raise ValueError(
            f"No events have '{key}' — run backtest with --ticker to join prices first"
        )

    composite_signals = [float(ev["signal_score"]) for ev in valid]
    returns           = [float(ev[key]) for ev in valid]

    # ---- 1. Composite ---------------------------------------------------- #
    composite = _baseline_stats(composite_signals, returns, "composite")

    # ---- 2. Sentiment-only ----------------------------------------------- #
    def _sent_signal(ev: dict) -> float:
        label = (ev.get("sentiment_label") or "NEUTRAL").upper()
        score = float(ev.get("sentiment_score") or 0.0)
        sign  = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
        return sign * score

    sent_signals   = [_sent_signal(ev) for ev in valid]
    sentiment_only = _baseline_stats(sent_signals, returns, "sentiment_only")

    # ---- 3. Random ------------------------------------------------------- #
    rng = random.Random(seed)
    random_signals = composite_signals[:]
    rng.shuffle(random_signals)
    random_ = _baseline_stats(random_signals, returns, "random")

    # ---- 4. Market buy-and-hold ------------------------------------------ #
    market = None
    if ticker and valid:
        # B&H: always long → signal = +1, return = actual return
        bh_returns = returns
        bh_signals = [1.0] * len(bh_returns)
        market = _baseline_stats(bh_signals, bh_returns, f"market:{ticker}")

    return BenchmarkReport(
        composite      = composite,
        random_        = random_,
        sentiment_only = sentiment_only,
        market         = market,
    )


def print_benchmark(report: BenchmarkReport) -> None:
    print(report.summary())
