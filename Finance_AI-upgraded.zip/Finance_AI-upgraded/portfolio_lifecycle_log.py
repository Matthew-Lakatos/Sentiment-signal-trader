"""
portfolio_lifecycle_log.py — #18 Portfolio Lifecycle Logging.

Captures the complete governance state at every position entry and exit.
Required for auditability, debugging, and post-mortem analysis.

Every position now carries:
  entry_reason           : string tag (e.g. "sentiment_HIGH_AAPL_earnings")
  exit_reason            : string tag (e.g. "horizon_reached" | "invalidated")
  governance_confidence_at_entry : float
  throttle_mode_at_entry : str
  kill_switch_state_at_entry : str
  governance_confidence_at_exit : float
  kill_switch_state_at_exit : str

Without this, it's impossible to answer:
  "Why did we open this position when governance was at 0.42?"
  "Did we exit because the signal decayed or because the kill-switch fired?"
  "What fraction of our losses occurred during REDUCED throttle mode?"

Usage
-----
    from portfolio_lifecycle_log import LifecycleLogger, LifecycleEntry

    log = LifecycleLogger(pool=pool)

    entry_id = await log.record_entry(
        event_id              = "evt-123",
        ticker                = "AAPL",
        direction             = "LONG",
        signal_score          = 0.72,
        entry_reason          = "sentiment_HIGH_earnings_beat",
        governance_confidence = 0.85,
        throttle_mode         = "FULL",
        kill_switch_state     = "ACTIVE",
        notional              = 48_000,
    )

    await log.record_exit(
        event_id              = "evt-123",
        exit_reason           = "horizon_reached",
        realised_pct          = 1.4,
        governance_confidence = 0.78,
        kill_switch_state     = "ACTIVE",
    )
"""
from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lifecycle entry
# ---------------------------------------------------------------------------

@dataclass
class LifecycleEntry:
    event_id:    str
    ticker:      str
    direction:   str   # LONG | SHORT

    # Signal context
    signal_score:        float
    signal_tier:         str   = ""
    signal_direction:    str   = ""
    entry_reason:        str   = ""

    # Governance state at entry
    governance_confidence_at_entry: float = 0.0
    governance_uncertainty_at_entry: float = 0.0
    throttle_mode_at_entry:         str   = ""
    kill_switch_state_at_entry:     str   = ""
    liquidity_regime_at_entry:      str   = ""
    market_regime_at_entry:         str   = ""

    # Execution
    notional:           float         = 0.0
    filled_notional:    float         = 0.0
    fill_pct:           float         = 1.0
    fill_price:         Optional[float] = None
    slippage_bps:       float         = 0.0
    size_scalar_applied: float        = 1.0

    # Timing
    opened_at:          datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    # Exit (populated on close)
    exit_reason:                    str            = ""
    realised_pct:                   Optional[float] = None
    realised_pnl:                   Optional[float] = None
    governance_confidence_at_exit:  Optional[float] = None
    governance_uncertainty_at_exit: Optional[float] = None
    kill_switch_state_at_exit:      str             = ""
    liquidity_regime_at_exit:       str             = ""
    closed_at:                      Optional[datetime] = None
    hold_days:                      Optional[float]    = None

    # Flags
    was_kill_switch_open:     bool = True    # kill switch was ACTIVE at entry
    was_above_ic_threshold:   bool = True
    is_shadow_trade:          bool = False   # True if paper/shadow trade

    def close(
        self,
        exit_reason:           str,
        realised_pct:          Optional[float],
        realised_pnl:          Optional[float] = None,
        governance_confidence: Optional[float] = None,
        governance_uncertainty: Optional[float] = None,
        kill_switch_state:     str = "",
        liquidity_regime:      str = "",
    ) -> None:
        now = datetime.now(timezone.utc)
        self.exit_reason                    = exit_reason
        self.realised_pct                   = realised_pct
        self.realised_pnl                   = realised_pnl
        self.governance_confidence_at_exit  = governance_confidence
        self.governance_uncertainty_at_exit = governance_uncertainty
        self.kill_switch_state_at_exit      = kill_switch_state
        self.liquidity_regime_at_exit       = liquidity_regime
        self.closed_at                      = now
        self.hold_days = round((now - self.opened_at).total_seconds() / 86400.0, 2)

    def to_dict(self) -> dict:
        d = asdict(self)
        # Convert datetimes to ISO strings
        for k in ("opened_at", "closed_at"):
            if d[k] is not None:
                d[k] = d[k].isoformat() if hasattr(d[k], "isoformat") else str(d[k])
        return d


# ---------------------------------------------------------------------------
# Lifecycle logger
# ---------------------------------------------------------------------------

class LifecycleLogger:
    """
    Logs position lifecycle events to memory and optionally to DB.

    Provides attribution analytics: breakdown of returns by governance
    mode, kill-switch state, liquidity regime, and throttle mode.
    """

    def __init__(self, pool=None) -> None:
        self._pool   = pool
        self._log:   dict[str, LifecycleEntry] = {}
        self._closed: list[LifecycleEntry]     = []

    # ------------------------------------------------------------------
    # Entry
    # ------------------------------------------------------------------

    async def record_entry(
        self,
        event_id:             str,
        ticker:               str,
        direction:            str,
        signal_score:         float,
        entry_reason:         str   = "",
        governance_confidence: float = 0.0,
        governance_uncertainty: float = 0.0,
        throttle_mode:        str   = "",
        kill_switch_state:    str   = "ACTIVE",
        liquidity_regime:     str   = "",
        market_regime:        str   = "",
        notional:             float = 0.0,
        filled_notional:      float = 0.0,
        fill_pct:             float = 1.0,
        fill_price:           Optional[float] = None,
        slippage_bps:         float = 0.0,
        size_scalar_applied:  float = 1.0,
        signal_tier:          str   = "",
        is_shadow_trade:      bool  = False,
    ) -> LifecycleEntry:
        entry = LifecycleEntry(
            event_id                         = event_id,
            ticker                           = ticker,
            direction                        = direction,
            signal_score                     = signal_score,
            signal_tier                      = signal_tier,
            entry_reason                     = entry_reason,
            governance_confidence_at_entry   = governance_confidence,
            governance_uncertainty_at_entry  = governance_uncertainty,
            throttle_mode_at_entry           = throttle_mode,
            kill_switch_state_at_entry       = kill_switch_state,
            liquidity_regime_at_entry        = liquidity_regime,
            market_regime_at_entry           = market_regime,
            notional                         = notional,
            filled_notional                  = filled_notional,
            fill_pct                         = fill_pct,
            fill_price                       = fill_price,
            slippage_bps                     = slippage_bps,
            size_scalar_applied              = size_scalar_applied,
            was_kill_switch_open             = kill_switch_state == "ACTIVE",
            is_shadow_trade                  = is_shadow_trade,
        )
        self._log[event_id] = entry
        logger.info(
            "Lifecycle ENTRY: %s %s %s  gov=%.2f  mode=%s  reason=%s",
            event_id, direction, ticker, governance_confidence, throttle_mode, entry_reason,
        )
        await self._persist_entry(entry)
        return entry

    # ------------------------------------------------------------------
    # Exit
    # ------------------------------------------------------------------

    async def record_exit(
        self,
        event_id:              str,
        exit_reason:           str,
        realised_pct:          Optional[float] = None,
        realised_pnl:          Optional[float] = None,
        governance_confidence: Optional[float] = None,
        governance_uncertainty: Optional[float] = None,
        kill_switch_state:     str = "",
        liquidity_regime:      str = "",
    ) -> Optional[LifecycleEntry]:
        entry = self._log.pop(event_id, None)
        if entry is None:
            logger.warning("Lifecycle EXIT: event_id %s not found", event_id)
            return None

        entry.close(
            exit_reason            = exit_reason,
            realised_pct           = realised_pct,
            realised_pnl           = realised_pnl,
            governance_confidence  = governance_confidence,
            governance_uncertainty = governance_uncertainty,
            kill_switch_state      = kill_switch_state,
            liquidity_regime       = liquidity_regime,
        )
        self._closed.append(entry)
        logger.info(
            "Lifecycle EXIT: %s %s  ret=%.2f%%  reason=%s  gov_exit=%.2f",
            event_id, entry.ticker,
            realised_pct or 0.0, exit_reason, governance_confidence or 0.0,
        )
        await self._persist_exit(entry)
        return entry

    # ------------------------------------------------------------------
    # Analytics
    # ------------------------------------------------------------------

    def attribution_report(self) -> dict:
        """
        Break down returns by governance mode, kill-switch state, and
        liquidity regime at entry.
        """
        if not self._closed:
            return {"n_closed": 0}

        def _group_avg(closed, key_fn):
            groups: dict[str, list[float]] = {}
            for e in closed:
                k = key_fn(e)
                r = e.realised_pct or 0.0
                groups.setdefault(k, []).append(r)
            return {k: round(sum(v) / len(v), 4) for k, v in groups.items()}

        closed = self._closed
        returns = [e.realised_pct or 0.0 for e in closed]

        return {
            "n_closed":          len(closed),
            "avg_return_pct":    round(sum(returns) / len(returns), 4),
            "win_rate":          round(sum(1 for r in returns if r > 0) / len(returns), 4),
            "by_throttle_mode":  _group_avg(closed, lambda e: e.throttle_mode_at_entry),
            "by_kill_state":     _group_avg(closed, lambda e: e.kill_switch_state_at_entry),
            "by_liquidity":      _group_avg(closed, lambda e: e.liquidity_regime_at_entry),
            "by_market_regime":  _group_avg(closed, lambda e: e.market_regime_at_entry),
            "by_exit_reason":    _group_avg(closed, lambda e: e.exit_reason),
            "shadow_vs_live": {
                "shadow_avg": round(sum(e.realised_pct or 0 for e in closed if e.is_shadow_trade) /
                              max(1, sum(1 for e in closed if e.is_shadow_trade)), 4),
                "live_avg":   round(sum(e.realised_pct or 0 for e in closed if not e.is_shadow_trade) /
                              max(1, sum(1 for e in closed if not e.is_shadow_trade)), 4),
            },
        }

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    async def _persist_entry(self, entry: LifecycleEntry) -> None:
        if self._pool is None:
            return
        try:
            await self._pool.execute("""
                INSERT INTO portfolio_lifecycle
                    (event_id, ticker, direction, signal_score, entry_reason,
                     governance_confidence_at_entry, throttle_mode_at_entry,
                     kill_switch_state_at_entry, liquidity_regime_at_entry,
                     notional, filled_notional, fill_pct, size_scalar_applied,
                     is_shadow_trade, opened_at)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
                ON CONFLICT (event_id) DO NOTHING
            """,
                entry.event_id, entry.ticker, entry.direction, entry.signal_score,
                entry.entry_reason, entry.governance_confidence_at_entry,
                entry.throttle_mode_at_entry, entry.kill_switch_state_at_entry,
                entry.liquidity_regime_at_entry, entry.notional, entry.filled_notional,
                entry.fill_pct, entry.size_scalar_applied, entry.is_shadow_trade,
                entry.opened_at,
            )
        except Exception as exc:
            logger.warning("Failed to persist lifecycle entry: %s", exc)

    async def _persist_exit(self, entry: LifecycleEntry) -> None:
        if self._pool is None:
            return
        try:
            await self._pool.execute("""
                UPDATE portfolio_lifecycle SET
                    exit_reason = $2,
                    realised_pct = $3,
                    realised_pnl = $4,
                    governance_confidence_at_exit = $5,
                    kill_switch_state_at_exit = $6,
                    liquidity_regime_at_exit = $7,
                    closed_at = $8,
                    hold_days = $9
                WHERE event_id = $1
            """,
                entry.event_id, entry.exit_reason, entry.realised_pct, entry.realised_pnl,
                entry.governance_confidence_at_exit, entry.kill_switch_state_at_exit,
                entry.liquidity_regime_at_exit, entry.closed_at, entry.hold_days,
            )
        except Exception as exc:
            logger.warning("Failed to persist lifecycle exit: %s", exc)
