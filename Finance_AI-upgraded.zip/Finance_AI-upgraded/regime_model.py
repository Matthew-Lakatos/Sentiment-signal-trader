"""
regime_model.py — regime-conditional signal models.

Problem
-------
A single global model assumes signal weights are constant across
market conditions.  In practice:
  - Sentiment matters more in low-vol / trending markets
  - Materiality dominates in high-vol / crisis regimes
  - Novelty is more valuable in quiet periods (less noise)

Solution
--------
Fit one Ridge model per regime bucket and dispatch at inference time:

    if regime == "HIGH" or regime == "SPIKE":
        alpha = model_high_vol.score(features)
    else:
        alpha = model_normal.score(features)

If a regime has too few events to calibrate (< MIN_REGIME_SAMPLES),
fall back to the global model.

Usage
-----
    from regime_model import RegimeModelSet, fit_regime_models

    model_set = fit_regime_models(events, horizon=1)
    score = model_set.score(event, vol_regime="HIGH", trend_regime="BULL")

    model_set.save("regime_models.json")
    model_set = RegimeModelSet.load("regime_models.json")
"""
from __future__ import annotations

import json
import logging
import math
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

MIN_REGIME_SAMPLES = 30   # minimum events to fit a regime-specific model
FALLBACK_REGIME    = "GLOBAL"

# Regime consolidation: map fine-grained labels → model buckets
_VOL_BUCKET = {
    "LOW":     "NORMAL",
    "MEDIUM":  "NORMAL",
    "HIGH":    "HIGH_VOL",
    "SPIKE":   "HIGH_VOL",
    "UNKNOWN": "NORMAL",
}
_TREND_BUCKET = {
    "BULL":    "BULL",
    "NEUTRAL": "NEUTRAL",
    "BEAR":    "BEAR",
    "UNKNOWN": "NEUTRAL",
}

# Features (must stay in sync with calibration.FEATURE_NAMES)
_FEATURES = ["sentiment", "materiality", "novelty", "credibility"]


# ---------------------------------------------------------------------------
# Thin model wrapper (serialisable)
# ---------------------------------------------------------------------------

@dataclass
class RegimeModel:
    """
    A fitted linear model for one regime bucket.
    Stores weights and intercept; can score new events.
    """
    regime_key: str
    weights:    dict[str, float]   # feature → coefficient
    intercept:  float
    n_samples:  int
    ic:         float              # in-sample Spearman IC
    is_fallback: bool = False

    def score(
        self,
        sentiment_label:   str,
        sentiment_score:   float,
        materiality_score: float,
        novelty_score:     float,
        credibility_score: float,
    ) -> float:
        """Return signed alpha score ∈ [-1, 1]."""
        label = (sentiment_label or "NEUTRAL").upper()
        sign  = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
        feats = {
            "sentiment":   sign * max(0.0, min(1.0, sentiment_score)),
            "materiality": max(0.0, min(1.0, materiality_score)),
            "novelty":     max(0.0, min(1.0, novelty_score)),
            "credibility": max(0.0, min(1.0, credibility_score)),
        }
        raw = self.intercept + sum(
            self.weights.get(f, 0.0) * v for f, v in feats.items()
        )
        return round(max(-1.0, min(1.0, raw)), 4)

    def to_dict(self) -> dict:
        return {
            "regime_key":  self.regime_key,
            "weights":     self.weights,
            "intercept":   self.intercept,
            "n_samples":   self.n_samples,
            "ic":          self.ic,
            "is_fallback": self.is_fallback,
        }

    @classmethod
    def from_dict(cls, d: dict) -> "RegimeModel":
        return cls(**d)


# ---------------------------------------------------------------------------
# Model set
# ---------------------------------------------------------------------------

@dataclass
class RegimeModelSet:
    """
    Collection of per-regime models + a global fallback.
    """
    horizon:    int
    models:     dict[str, RegimeModel]   # regime_key → model
    global_:    RegimeModel              # fallback

    def _resolve_regime_key(self, vol_regime: str, trend_regime: str) -> str:
        vb = _VOL_BUCKET.get(vol_regime.upper(), "NORMAL")
        tb = _TREND_BUCKET.get(trend_regime.upper(), "NEUTRAL")
        return f"{vb}_{tb}"

    def score(
        self,
        event:        dict,
        vol_regime:   str = "UNKNOWN",
        trend_regime: str = "UNKNOWN",
    ) -> dict:
        """
        Score a single event using the appropriate regime model.

        Returns dict with:
            alpha          — regime-conditional score
            regime_key     — which model was used
            is_fallback    — True if global model was used
        """
        key   = self._resolve_regime_key(vol_regime, trend_regime)
        model = self.models.get(key, self.global_)

        alpha = model.score(
            sentiment_label   = event.get("sentiment_label", "NEUTRAL"),
            sentiment_score   = float(event.get("sentiment_score",   0.0)),
            materiality_score = float(event.get("materiality_score", 0.0)),
            novelty_score     = float(event.get("novelty_score",     0.5)),
            credibility_score = float(event.get("credibility_score", 0.5)),
        )
        return {
            "alpha":       alpha,
            "regime_key":  key,
            "model_ic":    model.ic,
            "is_fallback": model.is_fallback,
        }

    def available_regimes(self) -> list[str]:
        return [k for k in self.models if not self.models[k].is_fallback]

    def report(self) -> str:
        lines = [
            f"\n{'─'*62}",
            f"  REGIME MODEL SET  (T+{self.horizon}d)",
            f"{'─'*62}",
            f"  {'Regime':<24} {'n':>6} {'IC':>8} {'Fallback':>10}",
            f"{'─'*62}",
        ]
        for key, m in sorted(self.models.items()):
            lines.append(
                f"  {key:<24} {m.n_samples:>6} {m.ic:>8.4f} {str(m.is_fallback):>10}"
            )
        lines.append(
            f"  {'GLOBAL (fallback)':<24} {self.global_.n_samples:>6} "
            f"{self.global_.ic:>8.4f}"
        )
        lines.append(f"{'─'*62}")
        return "\n".join(lines)

    def save(self, path: str) -> None:
        d = {
            "horizon": self.horizon,
            "models":  {k: v.to_dict() for k, v in self.models.items()},
            "global":  self.global_.to_dict(),
        }
        with open(path, "w") as f:
            json.dump(d, f, indent=2)
        logger.info("RegimeModelSet saved → %s", path)

    @classmethod
    def load(cls, path: str) -> "RegimeModelSet":
        with open(path) as f:
            d = json.load(f)
        return cls(
            horizon = d["horizon"],
            models  = {k: RegimeModel.from_dict(v) for k, v in d["models"].items()},
            global_ = RegimeModel.from_dict(d["global"]),
        )


# ---------------------------------------------------------------------------
# Fitting
# ---------------------------------------------------------------------------

def _fit_model(events: list[dict], key: str, horizon: int, alpha: float = 1.0) -> RegimeModel:
    """
    Fit a Ridge model on *events* for the given regime key.
    Returns a RegimeModel. Falls back gracefully on tiny samples.
    """
    import numpy as np
    from scipy.stats import spearmanr

    ret_key = f"fwd_ret_{horizon}d"
    rows_X, rows_y = [], []

    for ev in events:
        y = ev.get(ret_key)
        if y is None or not math.isfinite(float(y)):
            continue
        label    = (ev.get("sentiment_label") or "NEUTRAL").upper()
        sent_abs = float(ev.get("sentiment_score") or 0.0)
        sign     = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
        rows_X.append([
            sign * sent_abs,
            float(ev.get("materiality_score") or 0.0),
            float(ev.get("novelty_score")     or 0.5),
            float(ev.get("credibility_score") or 0.5),
        ])
        rows_y.append(float(y))

    n = len(rows_X)
    if n < 5:
        return RegimeModel(
            regime_key  = key,
            weights     = {f: 0.0 for f in _FEATURES},
            intercept   = 0.0,
            n_samples   = n,
            ic          = 0.0,
            is_fallback = True,
        )

    X = np.array(rows_X, dtype=float)
    y = np.array(rows_y, dtype=float)
    n_feat = X.shape[1]

    # Add intercept
    X_b = np.hstack([np.ones((n, 1)), X])
    I   = np.eye(n_feat + 1); I[0, 0] = 0.0
    try:
        beta = np.linalg.solve(X_b.T @ X_b + alpha * I, X_b.T @ y)
    except np.linalg.LinAlgError:
        beta = np.zeros(n_feat + 1)

    # Compute in-sample IC
    y_hat = X_b @ beta
    try:
        ic, _ = spearmanr(y_hat, y)
        ic = float(ic) if math.isfinite(ic) else 0.0
    except Exception:
        ic = 0.0

    weights = {f: round(float(beta[i + 1]), 6) for i, f in enumerate(_FEATURES)}
    return RegimeModel(
        regime_key  = key,
        weights     = weights,
        intercept   = round(float(beta[0]), 6),
        n_samples   = n,
        ic          = round(ic, 4),
        is_fallback = False,
    )


def fit_regime_models(
    events:  list[dict],
    horizon: int   = 1,
    alpha:   float = 1.0,
) -> RegimeModelSet:
    """
    Fit one Ridge model per regime bucket.  Events must have vol_regime and
    trend_regime fields (attach via regime.classify_regimes() first).

    Parameters
    ----------
    events   scored + regime-labelled event dicts
    horizon  return horizon in trading days
    alpha    Ridge regularisation strength

    Returns
    -------
    RegimeModelSet ready for conditional scoring
    """
    # Group events by regime key
    groups: dict[str, list] = {}
    for ev in events:
        vb  = _VOL_BUCKET.get((ev.get("vol_regime")   or "UNKNOWN").upper(), "NORMAL")
        tb  = _TREND_BUCKET.get((ev.get("trend_regime") or "UNKNOWN").upper(), "NEUTRAL")
        key = f"{vb}_{tb}"
        groups.setdefault(key, []).append(ev)

    # Fit per-regime models
    models: dict[str, RegimeModel] = {}
    for key, grp in groups.items():
        if len(grp) >= MIN_REGIME_SAMPLES:
            models[key] = _fit_model(grp, key, horizon, alpha)
            logger.info(
                "Regime model [%s]: n=%d IC=%.4f",
                key, models[key].n_samples, models[key].ic
            )
        else:
            logger.info(
                "Regime [%s]: only %d events (< %d), will use global fallback",
                key, len(grp), MIN_REGIME_SAMPLES
            )

    # Global fallback (all events)
    global_model = _fit_model(events, FALLBACK_REGIME, horizon, alpha)
    global_model.is_fallback = True

    # For regimes with insufficient data, insert fallback-flagged copies
    all_keys = {f"{vb}_{tb}"
                for vb in set(_VOL_BUCKET.values())
                for tb in set(_TREND_BUCKET.values())}
    for key in all_keys:
        if key not in models:
            models[key] = RegimeModel(
                regime_key  = key,
                weights     = global_model.weights,
                intercept   = global_model.intercept,
                n_samples   = 0,
                ic          = global_model.ic,
                is_fallback = True,
            )

    return RegimeModelSet(horizon=horizon, models=models, global_=global_model)
