"""
online_learning.py — §7 Dynamic Online Learning System.

Replaces the static ridge regression in calibration.py with an
adaptive system that continuously updates weights as new realised
returns arrive, with a controlled forgetting mechanism.

Core algorithm: Recursive Least Squares with exponential forgetting
--------------------------------------------------------------------
Given observations (x_t, y_t) arriving one at a time:

    P_t   = (1/λ) × (P_{t-1} − P_{t-1} x_t xₜᵀ P_{t-1} / (λ + xₜᵀ P_{t-1} x_t))
    K_t   = P_t x_t                              (Kalman gain)
    β_t   = β_{t-1} + K_t (y_t − xₜᵀ β_{t-1})  (weight update)

where λ ∈ (0, 1] is the forgetting factor.  λ = 1 → standard least
squares (no forgetting).  λ = 0.95 → observations more than ~20
steps old contribute half the weight of fresh ones.

Why RLS over SGD
----------------
SGD requires tuning a learning rate that interacts poorly with non-
stationary inputs.  RLS adapts its effective learning rate automatically
based on the curvature of the loss surface, making it well-suited to
financial time-series where the signal-to-noise ratio varies over time.

Forgetting factor calibration
------------------------------
A forgetting factor of λ with window W satisfies:
    λ^W ≈ 0.5  →  W = log(2) / log(1/λ)

Practical table:
    λ = 0.99  → effective window ~70  observations
    λ = 0.97  → effective window ~23  observations
    λ = 0.95  → effective window ~14  observations
    λ = 0.90  → effective window ~ 7  observations

Default λ = 0.97 (effective ~23-obs window).  Configurable via
ONLINE_LEARNING_FORGETTING_FACTOR env var / settings.

Feature drift monitoring
------------------------
After each update, coefficient_history stores the full β trace so
that drift_report() can detect:
  - sign flips     (β changes sign between consecutive updates)
  - high variance  (rolling std > DRIFT_STD_THRESHOLD)
  - staleness      (no update in more than STALE_HOURS hours)

Persistence
-----------
OnlineLearner.save(path) / .load(path) — JSON-serialisable state
so weights survive process restarts.

Usage
-----
    from online_learning import OnlineLearner

    learner = OnlineLearner(features=FEATURE_NAMES, forgetting=0.97)
    learner.update(x_dict, y_realised)          # one observation
    learner.update_batch(events_with_fwd_ret)   # batch of observations
    weights = learner.weights                   # current weights dict
    report  = learner.drift_report()            # DriftReport
    learner.save("learner_state.json")
"""
from __future__ import annotations

import json
import logging
import math
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone, timedelta
from typing import Optional

from config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants / thresholds
# ---------------------------------------------------------------------------

DRIFT_STD_THRESHOLD  = 0.12   # rolling σ of a coefficient that triggers alert
DRIFT_FLIP_THRESHOLD = 2       # number of sign flips in history that triggers alert
MIN_SAMPLES_TO_USE   = 10      # learner outputs fallback weights below this count
_RIDGE_INIT_ALPHA    = 1.0     # regularisation used for initial prior covariance


# ---------------------------------------------------------------------------
# DriftReport
# ---------------------------------------------------------------------------

@dataclass
class FeatureDrift:
    name:           str
    current_weight: float
    mean_weight:    float
    std_weight:     float
    sign_flips:     int
    is_drifting:    bool       # True when std or flip count exceeds threshold
    is_stale:       bool       # True when no update in >STALE_HOURS


@dataclass
class DriftReport:
    features:          list[FeatureDrift]
    n_updates:         int
    last_update_ts:    Optional[str]      # ISO-8601
    is_healthy:        bool               # True when no feature is drifting
    stale_hours:       float              # hours since last update
    summary:           str = ""

    def any_drifting(self) -> bool:
        return any(f.is_drifting or f.is_stale for f in self.features)


# ---------------------------------------------------------------------------
# OnlineLearner
# ---------------------------------------------------------------------------

class OnlineLearner:
    """
    Recursive Least Squares with exponential forgetting for online
    signal weight adaptation.

    Parameters
    ----------
    features    : list of feature name strings (must match keys in x_dict)
    forgetting  : λ ∈ (0, 1]  — exponential forgetting factor
    ridge_init  : initial L2 regularisation for the P matrix prior
    history_len : number of past weight vectors to keep for drift analysis
    """

    def __init__(
        self,
        features:    list[str],
        forgetting:  Optional[float] = None,
        ridge_init:  float = _RIDGE_INIT_ALPHA,
        history_len: int   = 200,
    ):
        self.features    = list(features)
        self.p           = len(features)
        self.forgetting  = forgetting if forgetting is not None else float(
            getattr(settings, "online_learning_forgetting_factor", 0.97)
        )
        self.ridge_init  = ridge_init
        self.history_len = history_len

        # RLS state: β (weights), P (inverse covariance proxy)
        self._beta = [0.0] * self.p
        # Initialise P as (1/ridge_init) × I — diffuse prior
        scale = 1.0 / max(ridge_init, 1e-6)
        self._P = [[scale if i == j else 0.0 for j in range(self.p)]
                   for i in range(self.p)]

        self.n_updates  = 0
        self._last_ts   = None     # last update unix timestamp

        # Ring buffer of past weight vectors for drift analysis
        # Each entry: list[float] of length p
        self._weight_history: list[list[float]] = []

        logger.info(
            "OnlineLearner init: features=%s  forgetting=%.3f",
            self.features, self.forgetting,
        )

    # ── Properties ─────────────────────────────────────────────────────────

    @property
    def weights(self) -> dict[str, float]:
        """Current calibrated weights (L1-normalised, positive, sum = 1.0)."""
        if self.n_updates < MIN_SAMPLES_TO_USE:
            abs_vals = [1.0] * self.p          # equal-weight fallback
        else:
            abs_vals = [abs(b) for b in self._beta]

        total  = sum(abs_vals) or 1.0
        normed = [v / total for v in abs_vals]

        # Round to 4 dp then fix the largest element so the sum is exactly 1.0
        # (avoids 0.3333 × 3 = 0.9999 rounding artefacts).
        rounded = [round(v, 4) for v in normed]
        diff    = round(1.0 - sum(rounded), 4)
        if diff != 0.0:
            idx = max(range(self.p), key=lambda i: rounded[i])
            rounded[idx] = round(rounded[idx] + diff, 4)

        return {f: rounded[i] for i, f in enumerate(self.features)}

    @property
    def raw_weights(self) -> dict[str, float]:
        """Raw (signed) β coefficients — used for directional signal."""
        return {f: round(self._beta[i], 6) for i, f in enumerate(self.features)}

    # ── RLS update helpers ──────────────────────────────────────────────────

    def _matvec(self, M: list[list[float]], v: list[float]) -> list[float]:
        """M @ v — pure Python, no numpy dependency at update time."""
        n = len(M)
        return [sum(M[i][j] * v[j] for j in range(n)) for i in range(n)]

    def _dot(self, a: list[float], b: list[float]) -> float:
        return sum(a[i] * b[i] for i in range(len(a)))

    def _outer(self, a: list[float], b: list[float]) -> list[list[float]]:
        return [[a[i] * b[j] for j in range(len(b))] for i in range(len(a))]

    def _matscale(self, M: list[list[float]], s: float) -> list[list[float]]:
        return [[M[i][j] * s for j in range(len(M[i]))] for i in range(len(M))]

    def _matadd(self, A: list[list[float]], B: list[list[float]]) -> list[list[float]]:
        return [[A[i][j] + B[i][j] for j in range(len(A[i]))] for i in range(len(A))]

    # ── Single-observation update ───────────────────────────────────────────

    def _x_vec(self, x_dict: dict) -> list[float]:
        """Extract feature vector from dict, in self.features order."""
        return [float(x_dict.get(f, 0.0)) for f in self.features]

    def update(self, x_dict: dict, y: float) -> None:
        """
        Update weights given one new (feature vector, realised return) pair.

        Parameters
        ----------
        x_dict  : dict mapping feature name → value
        y       : realised forward return for this observation
        """
        if not math.isfinite(y):
            return

        x = self._x_vec(x_dict)
        lam = self.forgetting

        # P_new = (1/λ)(P - P x xᵀ P / (λ + xᵀ P x))
        Px      = self._matvec(self._P, x)
        xTPx    = self._dot(x, Px)
        denom   = lam + xTPx

        if abs(denom) < 1e-12:
            logger.warning("RLS update: near-singular denominator, skipping")
            return

        # Kalman gain K = Px / denom
        K = [px / denom for px in Px]

        # β update: β += K × (y − xᵀ β)
        innovation = y - self._dot(x, self._beta)
        self._beta = [self._beta[i] + K[i] * innovation for i in range(self.p)]

        # P update: P = (P - K xᵀ P) / λ
        KxP = self._outer(K, Px)   # K × (Px)ᵀ = K xᵀ P
        P_new = self._matscale(self._matadd(self._P, self._matscale(KxP, -1.0)), 1.0 / lam)
        self._P = P_new

        self.n_updates += 1
        self._last_ts   = time.time()

        # Store weight snapshot in history ring buffer
        snap = list(self._beta)
        self._weight_history.append(snap)
        if len(self._weight_history) > self.history_len:
            self._weight_history.pop(0)

    # ── Batch update ────────────────────────────────────────────────────────

    def update_batch(
        self,
        events: list[dict],
        horizon: int = 1,
    ) -> int:
        """
        Update from a list of event dicts that already carry realised returns.
        Events without the fwd_ret key are silently skipped.

        Returns the number of successful updates.
        """
        key     = f"fwd_ret_{horizon}d"
        updated = 0
        for ev in events:
            y = ev.get(key) or ev.get("fwd_ret")
            if y is None:
                continue
            x_dict = _event_to_features(ev)
            self.update(x_dict, float(y))
            updated += 1

        if updated:
            logger.info(
                "OnlineLearner: %d observations ingested  n_total=%d  weights=%s",
                updated, self.n_updates,
                {k: round(v, 3) for k, v in self.weights.items()},
            )
        return updated

    # ── Drift analysis ──────────────────────────────────────────────────────

    def drift_report(
        self,
        stale_hours:    float = 24.0,
        window:         int   = 50,
    ) -> DriftReport:
        """
        Analyse coefficient stability over the recent history window.

        A feature is flagged as drifting when:
        - rolling std of its coefficient > DRIFT_STD_THRESHOLD, or
        - the number of sign-flips in the window > DRIFT_FLIP_THRESHOLD
        """
        now_ts  = time.time()
        last_ts = self._last_ts
        stale_h = ((now_ts - last_ts) / 3600.0) if last_ts else float("inf")

        hist = self._weight_history[-window:] if self._weight_history else []
        feature_drifts: list[FeatureDrift] = []

        for i, fname in enumerate(self.features):
            vals = [h[i] for h in hist] if hist else []
            if not vals:
                mean_w = self._beta[i]
                std_w  = 0.0
                flips  = 0
            else:
                mean_w = sum(vals) / len(vals)
                var    = sum((v - mean_w) ** 2 for v in vals) / max(len(vals) - 1, 1)
                std_w  = math.sqrt(var)
                flips  = sum(
                    1 for j in range(1, len(vals))
                    if math.copysign(1, vals[j]) != math.copysign(1, vals[j - 1])
                )

            is_drifting = std_w > DRIFT_STD_THRESHOLD or flips > DRIFT_FLIP_THRESHOLD
            is_stale    = stale_h > stale_hours

            feature_drifts.append(FeatureDrift(
                name           = fname,
                current_weight = round(self._beta[i], 6),
                mean_weight    = round(mean_w, 6),
                std_weight     = round(std_w, 6),
                sign_flips     = flips,
                is_drifting    = is_drifting,
                is_stale       = is_stale,
            ))

        is_healthy = not any(fd.is_drifting or fd.is_stale for fd in feature_drifts)
        last_ts_iso = (
            datetime.fromtimestamp(last_ts, tz=timezone.utc).isoformat()
            if last_ts else None
        )

        drifting = [fd.name for fd in feature_drifts if fd.is_drifting]
        summary  = (
            f"Healthy — {self.n_updates} total updates" if is_healthy
            else f"Drifting features: {drifting}  stale={stale_h:.1f}h"
        )

        return DriftReport(
            features       = feature_drifts,
            n_updates      = self.n_updates,
            last_update_ts = last_ts_iso,
            is_healthy     = is_healthy,
            stale_hours    = round(stale_h, 2),
            summary        = summary,
        )

    # ── Persistence ─────────────────────────────────────────────────────────

    def save(self, path: str) -> None:
        state = {
            "features":       self.features,
            "forgetting":     self.forgetting,
            "ridge_init":     self.ridge_init,
            "history_len":    self.history_len,
            "n_updates":      self.n_updates,
            "beta":           self._beta,
            "P":              self._P,
            "last_ts":        self._last_ts,
            "weight_history": self._weight_history[-100:],  # last 100 for compactness
        }
        with open(path, "w") as fh:
            json.dump(state, fh, indent=2)
        logger.info("OnlineLearner state saved → %s  (n=%d)", path, self.n_updates)

    @classmethod
    def load(cls, path: str) -> "OnlineLearner":
        with open(path) as fh:
            state = json.load(fh)
        obj = cls(
            features   = state["features"],
            forgetting = state["forgetting"],
            ridge_init = state["ridge_init"],
            history_len= state["history_len"],
        )
        obj._beta            = state["beta"]
        obj._P               = state["P"]
        obj.n_updates        = state["n_updates"]
        obj._last_ts         = state.get("last_ts")
        obj._weight_history  = state.get("weight_history", [])
        logger.info("OnlineLearner loaded from %s  (n=%d)", path, obj.n_updates)
        return obj

    def reset(self) -> None:
        """Hard reset — discards all learned weights and history."""
        scale        = 1.0 / max(self.ridge_init, 1e-6)
        self._beta   = [0.0] * self.p
        self._P      = [[scale if i == j else 0.0 for j in range(self.p)]
                        for i in range(self.p)]
        self.n_updates = 0
        self._last_ts  = None
        self._weight_history.clear()
        logger.info("OnlineLearner reset")


# ---------------------------------------------------------------------------
# Event → feature vector helper
# ---------------------------------------------------------------------------

def _event_to_features(ev: dict) -> dict:
    """
    Convert a scraped-event dict to the feature dict expected by OnlineLearner.
    Handles both signed and absolute sentiment representations.
    """
    label    = (ev.get("sentiment_label") or "NEUTRAL").upper()
    sent_abs = float(ev.get("sentiment_score") or 0.0)
    sign     = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
    sent     = sign * sent_abs

    mat  = float(ev.get("materiality_score") or 0.0)
    nov  = float(ev.get("novelty_score")      or 0.5)
    cred = float(ev.get("credibility_score")  or 0.5)
    sur  = float(ev.get("surprise_score")     or 0.0)

    return {
        "sentiment":           sent,
        "materiality":         mat,
        "novelty":             nov,
        "credibility":         cred,
        "sent_x_novelty":      sent * nov,
        "mat_x_credibility":   mat  * cred,
        "surprise":            sur,
    }


# ---------------------------------------------------------------------------
# Module-level singleton (shared across the process)
# ---------------------------------------------------------------------------

from calibration import FEATURE_NAMES_WITH_INTERACTIONS

# Extend base features with the Phase 1 surprise feature
_ONLINE_FEATURES = FEATURE_NAMES_WITH_INTERACTIONS + ["surprise"]

_learner: Optional[OnlineLearner] = None


def get_learner(
    path:       Optional[str]   = None,
    forgetting: Optional[float] = None,
) -> OnlineLearner:
    """
    Return the process-level OnlineLearner singleton.
    If path is given and the file exists, state is loaded from disk.
    """
    global _learner
    if _learner is None:
        if path:
            try:
                _learner = OnlineLearner.load(path)
                return _learner
            except (FileNotFoundError, KeyError, json.JSONDecodeError):
                logger.info("No existing learner state at %s — initialising fresh", path)
        _learner = OnlineLearner(features=_ONLINE_FEATURES, forgetting=forgetting)
    return _learner
