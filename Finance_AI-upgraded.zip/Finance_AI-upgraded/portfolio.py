"""
portfolio.py — position sizing and overlapping signal resolution.

Two open problems this module solves
-------------------------------------
1. Overlapping signals: multiple events hitting the same ticker simultaneously.
   Three resolution strategies:
     - STACK    (sum signals, capped)
     - AVERAGE  (mean of all signals)
     - STRONGEST (take the single highest-confidence signal)

2. Position sizing: translate alpha score to a dollar allocation.
   Three sizing rules:
     - FIXED      fixed notional per signal (e.g. $10 000)
     - PROP        proportional to |score|: notional = score × max_position
     - KELLY       fractional Kelly criterion using hit_rate and mean_ret

Usage
-----
    from portfolio import PortfolioLayer, PortfolioConfig, SignalGroup

    cfg   = PortfolioConfig(
                max_position=25_000,
                sizing="PROP",
                overlap="AVERAGE",
                max_ticker_exposure=50_000,
            )
    layer = PortfolioLayer(cfg)

    # Feed filtered, scored events
    layer.ingest(events)

    orders = layer.orders()      # list of Order ready for execution
    report = layer.report()      # allocation summary
"""
from __future__ import annotations

import logging
import math
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Literal, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

@dataclass
class PortfolioConfig:
    # Position sizing
    max_position:         float = 10_000.0    # max notional per single position
    sizing:               Literal["FIXED", "PROP", "KELLY"] = "PROP"
    total_capital:        float = 100_000.0   # total portfolio capital

    # Overlap resolution
    overlap:              Literal["STACK", "AVERAGE", "STRONGEST"] = "AVERAGE"

    # Risk limits
    max_ticker_exposure:  float = 25_000.0    # max net exposure per ticker
    min_score_to_trade:   float = 0.15        # don't open positions below this

    # Kelly parameters (only used when sizing="KELLY")
    kelly_fraction:       float = 0.25        # fractional Kelly (0.25 = quarter-Kelly)
    default_hit_rate:     float = 0.53        # used when no calibration data available
    default_mean_ret:     float = 0.30        # expected % return per trade

    # Conflict resolution: cancel opposite-direction signals on same ticker?
    cancel_conflicts:     bool = True


# ---------------------------------------------------------------------------
# Domain objects
# ---------------------------------------------------------------------------

@dataclass
class SignalGroup:
    """All signals pointing to the same ticker in the same batch."""
    ticker:   str
    signals:  list[dict] = field(default_factory=list)

    def resolved_score(self, method: str) -> float:
        scores = [float(ev.get("signal_score") or 0.0) for ev in self.signals]
        if not scores:
            return 0.0
        if method == "STACK":
            return max(-1.0, min(1.0, sum(scores)))
        if method == "AVERAGE":
            return sum(scores) / len(scores)
        if method == "STRONGEST":
            return max(scores, key=abs)
        return scores[0]

    def has_conflict(self) -> bool:
        """True if signals have both BULLISH and BEARISH members."""
        directions = set(
            (ev.get("signal_direction") or "NEUTRAL").upper()
            for ev in self.signals
        )
        return "BULLISH" in directions and "BEARISH" in directions

    def dominant_direction(self) -> str:
        pos = sum(1 for ev in self.signals
                  if (ev.get("signal_direction") or "NEUTRAL").upper() == "BULLISH")
        neg = sum(1 for ev in self.signals
                  if (ev.get("signal_direction") or "NEUTRAL").upper() == "BEARISH")
        if pos > neg:
            return "BULLISH"
        if neg > pos:
            return "BEARISH"
        return "NEUTRAL"

    def best_event(self) -> dict:
        return max(self.signals,
                   key=lambda e: abs(float(e.get("signal_score") or 0.0)))


@dataclass
class Order:
    ticker:     str
    direction:  str                # LONG | SHORT
    score:      float              # resolved alpha score
    notional:   float              # dollar size
    n_signals:  int                # number of events driving this order
    conflict:   bool               # True if opposing signals were present
    event_ids:  list[str] = field(default_factory=list)
    notes:      str = ""


# ---------------------------------------------------------------------------
# Kelly sizing helper
# ---------------------------------------------------------------------------

def kelly_notional(
    score:        float,
    hit_rate:     float,
    mean_ret_pct: float,
    capital:      float,
    fraction:     float = 0.25,
) -> float:
    """
    Fractional Kelly position size.

    Kelly fraction = (p × b - q) / b
    where  p = hit_rate
           q = 1 - p
           b = mean_ret / 100  (expressed as a ratio, not %)

    Scaled by |score| to modulate conviction.
    """
    if mean_ret_pct <= 0 or hit_rate <= 0:
        return 0.0
    b = abs(mean_ret_pct) / 100.0
    q = 1.0 - hit_rate
    kelly = (hit_rate * b - q) / b
    kelly = max(0.0, kelly)   # never negative
    return min(capital, capital * kelly * fraction * abs(score))


# ---------------------------------------------------------------------------
# Portfolio layer
# ---------------------------------------------------------------------------

class PortfolioLayer:

    def __init__(self, config: Optional[PortfolioConfig] = None):
        self.cfg    = config or PortfolioConfig()
        self._groups: dict[str, SignalGroup] = {}
        self._orders: list[Order] = []

    def reset(self) -> None:
        self._groups.clear()
        self._orders.clear()

    def ingest(self, events: list[dict]) -> None:
        """
        Group events by ticker and resolve overlapping signals.
        Call this once per batch before calling orders().
        """
        self._groups.clear()
        self._orders.clear()

        for ev in events:
            ticker = self._resolve_ticker(ev)
            if ticker not in self._groups:
                self._groups[ticker] = SignalGroup(ticker=ticker)
            self._groups[ticker].signals.append(ev)

        for ticker, group in self._groups.items():
            order = self._build_order(group)
            if order is not None:
                self._orders.append(order)

    def _resolve_ticker(self, ev: dict) -> str:
        """Extract ticker from event. Falls back to source_domain."""
        # Try explicit ticker field first (populated by target_profiles)
        ticker = ev.get("ticker") or ev.get("primary_ticker")
        if ticker:
            return ticker.upper()
        # Fall back to domain as a proxy group key
        return (ev.get("source_domain") or "UNKNOWN").upper()

    def _build_order(self, group: SignalGroup) -> Optional[Order]:
        conflict = group.has_conflict()

        # Cancel conflicting signals if configured
        if conflict and self.cfg.cancel_conflicts:
            logger.debug("Cancelling conflicting signals for ticker %s", group.ticker)
            return None

        score = group.resolved_score(self.cfg.overlap)
        if abs(score) < self.cfg.min_score_to_trade:
            return None

        direction = "LONG" if score > 0 else "SHORT"

        # Size the position
        notional = self._size(score)
        notional = min(notional, self.cfg.max_ticker_exposure)
        if notional <= 0:
            return None

        return Order(
            ticker    = group.ticker,
            direction = direction,
            score     = round(score, 4),
            notional  = round(notional, 2),
            n_signals = len(group.signals),
            conflict  = conflict,
            event_ids = [
                str(ev.get("event_id") or "")
                for ev in group.signals
            ],
            notes = f"overlap={self.cfg.overlap} n={len(group.signals)}",
        )

    def _size(self, score: float) -> float:
        cfg = self.cfg
        if cfg.sizing == "FIXED":
            return cfg.max_position

        if cfg.sizing == "PROP":
            return cfg.max_position * abs(score)

        if cfg.sizing == "KELLY":
            return kelly_notional(
                score        = score,
                hit_rate     = cfg.default_hit_rate,
                mean_ret_pct = cfg.default_mean_ret,
                capital      = cfg.total_capital,
                fraction     = cfg.kelly_fraction,
            )

        return cfg.max_position * abs(score)

    def orders(self) -> list[Order]:
        """Return all generated orders sorted by |score| desc."""
        return sorted(self._orders, key=lambda o: abs(o.score), reverse=True)

    def report(self) -> dict:
        orders   = self.orders()
        long_exp = sum(o.notional for o in orders if o.direction == "LONG")
        short_exp= sum(o.notional for o in orders if o.direction == "SHORT")
        total_exp= long_exp + short_exp

        return {
            "n_orders":         len(orders),
            "long_exposure":    round(long_exp, 2),
            "short_exposure":   round(short_exp, 2),
            "net_exposure":     round(long_exp - short_exp, 2),
            "gross_exposure":   round(total_exp, 2),
            "utilisation_pct":  round(total_exp / max(1, self.cfg.total_capital) * 100, 2),
            "tickers":          [o.ticker for o in orders],
            "conflicts_cancelled": sum(
                1 for g in self._groups.values()
                if g.has_conflict() and self.cfg.cancel_conflicts
            ),
            "orders": [
                {
                    "ticker":    o.ticker,
                    "direction": o.direction,
                    "score":     o.score,
                    "notional":  o.notional,
                    "n_signals": o.n_signals,
                    "conflict":  o.conflict,
                }
                for o in orders
            ],
        }
