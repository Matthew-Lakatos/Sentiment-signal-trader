"""
earnings_surprise.py — Earnings surprise, revision momentum, and implied move.

Data sources
------------
1. yfinance earnings_history      — historical EPS actual vs estimate (free)
2. yfinance analyst_price_targets — consensus price target + revisions (free)
3. Alpha Vantage EARNINGS API     — deeper EPS history + revision dates (free tier: 25 req/day)
   https://www.alphavantage.co/documentation/#earnings
4. CBOE options via yfinance      — ATM straddle for implied move calculation
   https://www.cboe.com

Features produced
-----------------
  eps_surprise_pct      : (actual - estimate) / |estimate|  [-1, 5]
  eps_surprise_sue      : standardised unexpected earnings (z-score over trailing history)
  eps_beat_rate         : fraction of last 8 quarters that beat estimates  [0, 1]
  eps_surprise_momentum : trailing trend in surprise direction  [-1, 1]
  revision_momentum     : analyst estimate revision momentum (up vs down)  [-1, 1]
  price_target_upside   : (consensus PT - current price) / current price  [-1, 2]
  implied_move_pct      : ATM straddle / spot price (expected earnings move)  [0, 1]
  actual_vs_implied     : actual past moves vs prior implied moves  [-1, 1]
  next_earnings_days    : trading days until next earnings report

The SUE score is the single strongest predictor in this system.
Academic reference: Bernard & Thomas (1989), Chan et al. (1996).
"""
from __future__ import annotations

import asyncio
import json
import logging
import math
import os
import time
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

_AV_KEY      = os.environ.get("ALPHA_VANTAGE_KEY", "")
_EPS_TTL     = 3600 * 6    # 6 hours
_OPTIONS_TTL = 1800         # 30 min (options chain changes intraday)


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

@dataclass
class EarningsSurpriseFeatures:
    ticker: str

    # EPS surprise
    eps_surprise_pct:      Optional[float] = None   # most recent quarter
    eps_surprise_sue:      Optional[float] = None   # standardised over trailing 8Q
    eps_beat_rate:         Optional[float] = None   # fraction of beats [0, 1]
    eps_surprise_momentum: Optional[float] = None   # recent trend [-1, 1]

    # Analyst revisions
    revision_momentum:     Optional[float] = None   # [-1, 1]
    price_target_upside:   Optional[float] = None   # [-1, 2]
    n_analysts:            Optional[int]   = None

    # Options / implied move
    implied_move_pct:      Optional[float] = None   # [0, 0.5]
    actual_vs_implied:     Optional[float] = None   # ratio history

    # Calendar
    next_earnings_days:    Optional[int]   = None   # days until next ER
    last_earnings_date:    Optional[str]   = None

    computed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_stale:    bool = True

    def as_feature_dict(self) -> dict[str, Optional[float]]:
        return {
            "earn_eps_surprise_pct":  self.eps_surprise_pct,
            "earn_eps_sue":           self.eps_surprise_sue,
            "earn_beat_rate":         self.eps_beat_rate,
            "earn_surprise_momentum": self.eps_surprise_momentum,
            "earn_revision_momentum": self.revision_momentum,
            "earn_pt_upside":         self.price_target_upside,
            "earn_implied_move":      self.implied_move_pct,
            "earn_actual_vs_implied": self.actual_vs_implied,
            "earn_next_er_days":      float(self.next_earnings_days) if self.next_earnings_days else None,
        }


# ---------------------------------------------------------------------------
# yfinance fetch helpers
# ---------------------------------------------------------------------------

def _fetch_earnings_history_sync(ticker: str) -> list[dict]:
    """
    Returns list of {quarter, estimate, actual, surprise_pct} dicts.
    Most recent quarter FIRST (descending chronological order).

    Bug fix: yfinance returns earnings_history in ascending order (oldest first).
    We must explicitly sort descending so _compute_sue correctly treats
    arr[0] as the most recent quarter when computing the z-score.
    """
    try:
        import yfinance as yf
        obj     = yf.Ticker(ticker)
        history = obj.earnings_history

        if history is None or (hasattr(history, "empty") and history.empty):
            return []

        rows = []
        for idx, row in history.iterrows():
            estimate = row.get("EPS Estimate") or row.get("epsEstimate")
            actual   = row.get("Reported EPS") or row.get("epsActual")
            if estimate is None or actual is None:
                continue
            try:
                est = float(estimate)
                act = float(actual)
                surprise_pct = (act - est) / abs(est) if abs(est) > 1e-6 else 0.0
                rows.append({
                    "date":         str(idx.date()) if hasattr(idx, "date") else str(idx),
                    "estimate":     est,
                    "actual":       act,
                    "surprise_pct": round(surprise_pct, 4),
                })
            except (TypeError, ValueError):
                continue

        # Explicit descending sort — yfinance order is not guaranteed.
        # _compute_sue treats rows[0] as the most recent quarter.
        rows.sort(key=lambda r: r["date"], reverse=True)
        return rows

    except Exception as exc:
        logger.debug("earnings_history failed for %s: %s", ticker, exc)
        return []


def _fetch_av_earnings_sync(ticker: str) -> list[dict]:
    """
    Alpha Vantage EARNINGS endpoint — up to 20 quarters of EPS with estimates.
    Free tier: 25 req/day.
    https://www.alphavantage.co/documentation/#earnings
    """
    if not _AV_KEY:
        return []
    try:
        url = (
            f"https://www.alphavantage.co/query?function=EARNINGS"
            f"&symbol={ticker}&apikey={_AV_KEY}"
        )
        with urllib.request.urlopen(url, timeout=10) as resp:
            data = json.loads(resp.read())

        rows = []
        for q in data.get("quarterlyEarnings", [])[:12]:
            try:
                est = float(q.get("estimatedEPS", 0) or 0)
                act = float(q.get("reportedEPS", 0) or 0)
                if abs(est) > 1e-6:
                    surprise_pct = (act - est) / abs(est)
                    rows.append({
                        "date":         q.get("fiscalDateEnding", ""),
                        "estimate":     est,
                        "actual":       act,
                        "surprise_pct": round(surprise_pct, 4),
                    })
            except (TypeError, ValueError):
                continue
        return rows
    except Exception as exc:
        logger.debug("Alpha Vantage EARNINGS failed for %s: %s", ticker, exc)
        return []


def _fetch_analyst_data_sync(ticker: str) -> dict:
    """Fetch analyst recommendations and price targets via yfinance."""
    result = {}
    try:
        import yfinance as yf
        obj = yf.Ticker(ticker)

        # Price targets
        try:
            targets = obj.analyst_price_targets
            if targets and not (hasattr(targets, "empty") and targets.empty):
                current = obj.fast_info.last_price or 0
                mean_pt = targets.get("mean") or targets.get("targetMeanPrice")
                n       = targets.get("numberOfAnalysts") or targets.get("targetNumberOfAnalysts")
                if mean_pt and current > 0:
                    result["price_target_upside"] = round((float(mean_pt) - current) / current, 4)
                if n:
                    result["n_analysts"] = int(n)
        except Exception:
            pass

        # Recommendation trends
        try:
            recs = obj.recommendations_summary
            if recs is not None and not (hasattr(recs, "empty") and recs.empty):
                # Most recent period
                row = recs.iloc[0] if len(recs) > 0 else {}
                strong_buy = float(row.get("strongBuy", 0) or 0)
                buy        = float(row.get("buy",       0) or 0)
                hold       = float(row.get("hold",      0) or 0)
                sell       = float(row.get("sell",      0) or 0)
                strong_sell= float(row.get("strongSell",0) or 0)
                total      = strong_buy + buy + hold + sell + strong_sell
                if total > 0:
                    bull = (strong_buy + buy) / total
                    bear = (sell + strong_sell) / total
                    result["revision_momentum"] = round(bull - bear, 4)
        except Exception:
            pass

        # Next earnings date
        try:
            cal = obj.calendar
            if cal is not None:
                for key in ("Earnings Date", "earningsDate"):
                    dt_val = cal.get(key)
                    if dt_val is not None:
                        if hasattr(dt_val, "__iter__") and not isinstance(dt_val, str):
                            dt_val = list(dt_val)[0]
                        if hasattr(dt_val, "date"):
                            dt_val = dt_val.date()
                        today = datetime.now(timezone.utc).date()
                        import datetime as _dt
                        if isinstance(dt_val, _dt.date):
                            days = (dt_val - today).days
                            result["next_earnings_days"] = max(0, days)
                        break
        except Exception:
            pass

    except Exception as exc:
        logger.debug("Analyst data fetch failed for %s: %s", ticker, exc)

    return result


def _fetch_implied_move_sync(ticker: str) -> Optional[float]:
    """
    Compute the expected move from ATM straddle price before earnings.
    Uses CBOE-listed options via yfinance.
    Formula: implied_move = (ATM_call + ATM_put) / spot_price

    Only meaningful near earnings. Returns None if far from earnings.
    """
    try:
        import yfinance as yf
        import pandas as pd

        obj  = yf.Ticker(ticker)
        spot = obj.fast_info.last_price
        if not spot or spot <= 0:
            return None

        # Get the nearest expiry options chain
        expirations = obj.options
        if not expirations:
            return None

        # Use nearest expiry within 45 days (earnings window)
        today = datetime.now(timezone.utc).date()
        near_expiry = None
        for exp_str in expirations[:4]:
            try:
                exp_date = datetime.strptime(exp_str, "%Y-%m-%d").date()
                days_to_exp = (exp_date - today).days
                if 5 <= days_to_exp <= 45:
                    near_expiry = exp_str
                    break
            except ValueError:
                continue

        if not near_expiry:
            return None

        chain = obj.option_chain(near_expiry)
        calls = chain.calls
        puts  = chain.puts

        if calls.empty or puts.empty:
            return None

        # Find ATM strike
        calls["dist"] = abs(calls["strike"] - spot)
        atm_call = calls.loc[calls["dist"].idxmin()]
        atm_put  = puts.loc[(puts["strike"] - spot).abs().idxmin()]

        call_mid = (float(atm_call.get("bid", 0) or 0) + float(atm_call.get("ask", 0) or 0)) / 2
        put_mid  = (float(atm_put.get("bid",  0) or 0) + float(atm_put.get("ask",  0) or 0)) / 2

        straddle_cost = call_mid + put_mid
        if straddle_cost <= 0:
            return None

        implied_move = straddle_cost / spot
        return round(min(0.5, max(0.0, implied_move)), 4)

    except Exception as exc:
        logger.debug("Implied move fetch failed for %s: %s", ticker, exc)
        return None


# ---------------------------------------------------------------------------
# SUE computation
# ---------------------------------------------------------------------------

def _compute_sue(surprises: list[float], trailing: int = 8) -> Optional[float]:
    """
    Standardised Unexpected Earnings = (most_recent - mean) / std_dev
    Uses trailing N quarters of surprise history.
    """
    if len(surprises) < 3:
        return None
    hist = surprises[:trailing]   # most recent first
    arr  = np.array(hist)
    mu   = float(arr[1:].mean())      # exclude most recent for the mean
    std  = float(arr[1:].std()) or 0.1
    sue  = (arr[0] - mu) / std
    return round(max(-5.0, min(5.0, sue)), 4)


def _surprise_momentum(surprises: list[float]) -> Optional[float]:
    """
    Trend in earnings surprise: positive = improving beat streak.
    Uses sign change direction over last 4 quarters.
    """
    if len(surprises) < 2:
        return None
    # Weight recent quarters more
    weights   = [0.5, 0.3, 0.15, 0.05][:len(surprises)]
    signed    = [math.copysign(1.0, s) for s in surprises[:len(weights)]]
    weighted  = sum(w * s for w, s in zip(weights, signed))
    return round(max(-1.0, min(1.0, weighted)), 4)


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

_eps_cache: dict[str, tuple[float, list]] = {}
_analyst_cache: dict[str, tuple[float, dict]] = {}
_options_cache: dict[str, tuple[float, Optional[float]]] = {}


class EarningsSurpriseEngine:
    """
    Computes earnings-related features from multiple free sources.
    """

    def __init__(self) -> None:
        self._lock = asyncio.Lock()

    async def get_features(
        self,
        ticker:        str,
        force_refresh: bool = False,
    ) -> EarningsSurpriseFeatures:
        loop = asyncio.get_running_loop()

        # ── EPS history (cached) ─────────────────────────────────────────────
        now = time.monotonic()
        async with self._lock:
            use_cache = (not force_refresh and
                         ticker in _eps_cache and
                         now < _eps_cache[ticker][0])

        if use_cache:
            async with self._lock:
                eps_rows = _eps_cache[ticker][1]
        else:
            # Try yfinance first, Alpha Vantage as fallback
            yf_task = loop.run_in_executor(None, _fetch_earnings_history_sync, ticker)
            av_task = loop.run_in_executor(None, _fetch_av_earnings_sync, ticker)
            yf_rows, av_rows = await asyncio.gather(yf_task, av_task, return_exceptions=True)

            yf_rows = yf_rows if isinstance(yf_rows, list) else []
            av_rows = av_rows if isinstance(av_rows, list) else []

            # Merge: prefer AV (more history) if yfinance is sparse
            eps_rows = yf_rows if len(yf_rows) >= len(av_rows) else av_rows

            async with self._lock:
                _eps_cache[ticker] = (now + _EPS_TTL, eps_rows)

        # ── Analyst data (cached) ────────────────────────────────────────────
        async with self._lock:
            use_analyst = (not force_refresh and
                           ticker in _analyst_cache and
                           now < _analyst_cache[ticker][0])

        if use_analyst:
            async with self._lock:
                analyst = _analyst_cache[ticker][1]
        else:
            analyst = await loop.run_in_executor(None, _fetch_analyst_data_sync, ticker)
            async with self._lock:
                _analyst_cache[ticker] = (now + _EPS_TTL, analyst)

        # ── Implied move (cached) ────────────────────────────────────────────
        async with self._lock:
            use_opts = (not force_refresh and
                        ticker in _options_cache and
                        now < _options_cache[ticker][0])

        if use_opts:
            async with self._lock:
                implied_move = _options_cache[ticker][1]
        else:
            implied_move = await loop.run_in_executor(None, _fetch_implied_move_sync, ticker)
            async with self._lock:
                _options_cache[ticker] = (now + _OPTIONS_TTL, implied_move)

        # ── Compute features ─────────────────────────────────────────────────
        feat = EarningsSurpriseFeatures(ticker=ticker)

        if eps_rows:
            surprises = [r["surprise_pct"] for r in eps_rows]

            feat.eps_surprise_pct      = eps_rows[0]["surprise_pct"] if eps_rows else None
            feat.eps_surprise_sue      = _compute_sue(surprises)
            feat.eps_beat_rate         = round(sum(1 for s in surprises[:8] if s > 0) / min(len(surprises), 8), 4)
            feat.eps_surprise_momentum = _surprise_momentum(surprises)
            feat.last_earnings_date    = eps_rows[0].get("date") if eps_rows else None
            feat.is_stale              = False
        else:
            feat.is_stale = True

        feat.revision_momentum   = analyst.get("revision_momentum")
        feat.price_target_upside = analyst.get("price_target_upside")
        feat.n_analysts          = analyst.get("n_analysts")
        feat.next_earnings_days  = analyst.get("next_earnings_days")
        feat.implied_move_pct    = implied_move

        logger.debug(
            "EarningsSurprise[%s]: SUE=%.2f beat_rate=%.0f%% revision=%.2f implied_move=%.1f%%",
            ticker,
            feat.eps_surprise_sue or 0,
            (feat.eps_beat_rate or 0) * 100,
            feat.revision_momentum or 0,
            (feat.implied_move_pct or 0) * 100,
        )
        return feat


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_engine: Optional[EarningsSurpriseEngine] = None


def get_engine() -> EarningsSurpriseEngine:
    global _engine
    if _engine is None:
        _engine = EarningsSurpriseEngine()
    return _engine
