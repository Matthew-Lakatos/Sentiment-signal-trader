"""
latency_budget.py — #12 Pipeline Latency Budget.

Tracks per-module wall-clock timing, emits slow-path alerts,
and enforces per-stage latency budgets.

Usage
-----
    from latency_budget import LatencyBudget, BudgetedTimer

    budget = LatencyBudget()

    # Context manager
    async with BudgetedTimer(budget, "nlp_stage"):
        await run_nlp(events)

    # Decorator
    @budget.track("signal_ranking")
    async def rank_signals(events):
        ...

    # Check report
    report = budget.report()
    if report.has_slow_stages:
        logger.warning(budget.report().summary())
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict, deque
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import wraps
from typing import Callable, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Default budgets per stage (seconds)
# ---------------------------------------------------------------------------

DEFAULT_BUDGETS: dict[str, float] = {
    "market_state":       10.0,
    "governance_assess":  15.0,
    "kill_switch":         2.0,
    "scrape_all":        120.0,
    "nlp_per_event":       5.0,
    "nlp_batch":          60.0,
    "embedding":           3.0,
    "dedup":               1.0,
    "materiality":         2.0,
    "novelty":             2.0,
    "signal_ranking":      5.0,
    "factor_neutralise":   5.0,
    "cross_sectional":     3.0,
    "db_write":           10.0,
    "kg_flush":            5.0,
    "alert_dispatch":      5.0,
    "positioning":        30.0,
    "liquidity":          20.0,
    "shadow_portfolio":    5.0,
    "pipeline_total":    300.0,
}


# ---------------------------------------------------------------------------
# Timing record
# ---------------------------------------------------------------------------

@dataclass
class TimingRecord:
    stage:        str
    elapsed_s:    float
    budget_s:     Optional[float]
    exceeded:     bool
    started_at:   datetime
    finished_at:  datetime
    metadata:     dict = field(default_factory=dict)

    @property
    def pct_of_budget(self) -> Optional[float]:
        if self.budget_s and self.budget_s > 0:
            return self.elapsed_s / self.budget_s
        return None


# ---------------------------------------------------------------------------
# Latency report
# ---------------------------------------------------------------------------

@dataclass
class LatencyReport:
    records:           list[TimingRecord]
    total_elapsed_s:   float
    budget_total_s:    float
    slow_stages:       list[str]

    @property
    def has_slow_stages(self) -> bool:
        return bool(self.slow_stages)

    @property
    def total_pct_of_budget(self) -> float:
        if self.budget_total_s > 0:
            return self.total_elapsed_s / self.budget_total_s
        return 0.0

    def summary(self) -> str:
        lines = [
            f"LatencyReport: total={self.total_elapsed_s:.1f}s "
            f"({self.total_pct_of_budget*100:.0f}% of budget)"
        ]
        for r in sorted(self.records, key=lambda x: -x.elapsed_s)[:8]:
            budget_str = f" [budget={r.budget_s:.0f}s ⚠️]" if r.exceeded else (
                f" [budget={r.budget_s:.0f}s]" if r.budget_s else ""
            )
            lines.append(f"  {r.stage:<25} {r.elapsed_s:6.1f}s{budget_str}")
        if self.slow_stages:
            lines.append(f"SLOW STAGES: {self.slow_stages}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# LatencyBudget
# ---------------------------------------------------------------------------

class LatencyBudget:
    """
    Tracks per-stage latency with configurable budgets and history.
    Thread- and async-safe via asyncio.Lock.
    """

    def __init__(
        self,
        budgets:       Optional[dict[str, float]] = None,
        history_size:  int   = 100,
        alert_pct:     float = 0.80,  # warn when stage uses >80% of budget
    ) -> None:
        self._budgets    = {**DEFAULT_BUDGETS, **(budgets or {})}
        self._history:   dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=history_size))
        self._records:   list[TimingRecord]       = []
        self._pipeline_start: Optional[float]     = None
        self._alert_pct  = alert_pct
        self._lock       = asyncio.Lock()

    def start_pipeline(self) -> None:
        self._pipeline_start = time.monotonic()
        self._records = []

    async def record(
        self,
        stage:      str,
        elapsed_s:  float,
        metadata:   Optional[dict] = None,
        started_at: Optional[datetime] = None,
    ) -> TimingRecord:
        budget  = self._budgets.get(stage)
        exceeded = budget is not None and elapsed_s > budget

        if exceeded:
            logger.warning(
                "SLOW STAGE [%s]: %.1fs > budget %.1fs (%.0f%%)",
                stage, elapsed_s, budget, elapsed_s / budget * 100,
            )
        elif budget and elapsed_s / budget > self._alert_pct:
            logger.info(
                "Stage [%s] approaching budget: %.1fs / %.1fs (%.0f%%)",
                stage, elapsed_s, budget, elapsed_s / budget * 100,
            )

        record = TimingRecord(
            stage       = stage,
            elapsed_s   = round(elapsed_s, 3),
            budget_s    = budget,
            exceeded    = exceeded,
            started_at  = started_at or datetime.now(timezone.utc),
            finished_at = datetime.now(timezone.utc),
            metadata    = metadata or {},
        )

        async with self._lock:
            self._records.append(record)
            self._history[stage].append(elapsed_s)

        return record

    def report(self) -> LatencyReport:
        total = (
            time.monotonic() - self._pipeline_start
            if self._pipeline_start else 0.0
        )
        slow = [r.stage for r in self._records if r.exceeded]
        return LatencyReport(
            records          = list(self._records),
            total_elapsed_s  = round(total, 2),
            budget_total_s   = self._budgets.get("pipeline_total", 300.0),
            slow_stages      = slow,
        )

    def p95(self, stage: str) -> Optional[float]:
        """95th-percentile latency for a stage from history."""
        hist = list(self._history.get(stage, []))
        if not hist:
            return None
        hist.sort()
        idx = int(len(hist) * 0.95)
        return hist[min(idx, len(hist) - 1)]

    def set_budget(self, stage: str, seconds: float) -> None:
        self._budgets[stage] = seconds


# ---------------------------------------------------------------------------
# BudgetedTimer — async context manager
# ---------------------------------------------------------------------------

class BudgetedTimer:
    """
    Async context manager that records stage timing into a LatencyBudget.

        async with BudgetedTimer(budget, "nlp_batch", metadata={"n": len(events)}):
            await run_nlp(events)
    """

    def __init__(
        self,
        budget:   LatencyBudget,
        stage:    str,
        metadata: Optional[dict] = None,
    ) -> None:
        self._budget   = budget
        self._stage    = stage
        self._metadata = metadata or {}
        self._start    = 0.0
        self._started_at: Optional[datetime] = None

    async def __aenter__(self):
        self._start      = time.monotonic()
        self._started_at = datetime.now(timezone.utc)
        return self

    async def __aexit__(self, exc_type, exc, tb):
        elapsed = time.monotonic() - self._start
        await self._budget.record(
            stage      = self._stage,
            elapsed_s  = elapsed,
            metadata   = self._metadata,
            started_at = self._started_at,
        )
        return False   # don't suppress exceptions


# ---------------------------------------------------------------------------
# Decorator helper
# ---------------------------------------------------------------------------

def timed(budget: LatencyBudget, stage: str):
    """Decorator to auto-time an async function and record it."""
    def decorator(fn: Callable):
        @wraps(fn)
        async def wrapper(*args, **kwargs):
            async with BudgetedTimer(budget, stage):
                return await fn(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_budget: Optional[LatencyBudget] = None


def get_budget() -> LatencyBudget:
    global _budget
    if _budget is None:
        _budget = LatencyBudget()
    return _budget
