"""
fundamental_features.py — Fundamental feature engine.

Data sources
------------
1. yfinance .info         — P/E, P/B, EV/EBITDA, margins, growth, debt ratios
2. FINRA Short Sale Data  — Short sale volume (bi-monthly, REGSHO programme)
   https://www.finra.org/finra-data/browse-catalog/short-sale-volume-data

Features produced
-----------------
Valuation
  pe_ratio         : trailing P/E (clipped to [-50, 200])
  forward_pe       : forward P/E
  pb_ratio         : price-to-book
  ev_to_ebitda     : enterprise value / EBITDA
  fcf_yield        : free cash flow yield = FCF / market cap  [-1, 1]
  ps_ratio         : price-to-sales

Quality / growth
  revenue_growth   : YoY revenue growth  [-1, 2]
  earnings_growth  : YoY EPS growth      [-2, 5]
  gross_margin     : gross profit margin  [0, 1]
  operating_margin : operating margin     [-1, 1]
  roe              : return on equity     [-2, 2]
  roa              : return on assets     [-1, 1]

Balance sheet
  debt_to_equity   : total debt / equity  [0, 20]
  current_ratio    : current assets / liabilities  [0, 10]
  interest_coverage: EBIT / interest expense  [-10, 50]

Short interest (FINRA)
  short_ratio      : short interest / avg daily volume (days-to-cover)
  short_pct_float  : short interest as fraction of float  [0, 1]
  finra_short_vol_ratio: FINRA daily short sale volume ratio  [0, 1]

Conditioning signals
--------------------
  value_score      : composite value signal — high when cheap + quality  [0, 1]
  quality_score    : earnings quality + growth + balance sheet  [0, 1]
  fragility_score  : debt + short interest risk  [0, 1]
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta, date
from typing import Optional

logger = logging.getLogger(__name__)

_FUNDAMENTAL_TTL = 86_400   # 24 hours — quarterly data
_SHORT_TTL       = 14_400   # 4 hours — daily FINRA data
_FINRA_REGSHO_URL = (
    "https://cdn.finra.org/equity/regsho/daily/"
    "CNMSshvol{date}.txt"
)


# ---------------------------------------------------------------------------
# Output dataclass
# ---------------------------------------------------------------------------

@dataclass
class FundamentalFeatureVector:
    ticker: str

    # Valuation
    pe_ratio:        Optional[float] = None
    forward_pe:      Optional[float] = None
    pb_ratio:        Optional[float] = None
    ev_to_ebitda:    Optional[float] = None
    fcf_yield:       Optional[float] = None
    ps_ratio:        Optional[float] = None

    # Quality / growth
    revenue_growth:   Optional[float] = None
    earnings_growth:  Optional[float] = None
    gross_margin:     Optional[float] = None
    operating_margin: Optional[float] = None
    roe:             Optional[float] = None
    roa:             Optional[float] = None

    # Balance sheet
    debt_to_equity:     Optional[float] = None
    current_ratio:      Optional[float] = None
    interest_coverage:  Optional[float] = None

    # Short interest
    short_ratio:           Optional[float] = None
    short_pct_float:       Optional[float] = None
    finra_short_vol_ratio: Optional[float] = None

    # Composite scores
    value_score:    Optional[float] = None
    quality_score:  Optional[float] = None
    fragility_score: Optional[float] = None

    computed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_stale:    bool = True

    def as_feature_dict(self) -> dict[str, Optional[float]]:
        return {
            "fund_pe_ratio":        self.pe_ratio,
            "fund_forward_pe":      self.forward_pe,
            "fund_pb_ratio":        self.pb_ratio,
            "fund_ev_ebitda":       self.ev_to_ebitda,
            "fund_fcf_yield":       self.fcf_yield,
            "fund_revenue_growth":  self.revenue_growth,
            "fund_earnings_growth": self.earnings_growth,
            "fund_gross_margin":    self.gross_margin,
            "fund_roe":             self.roe,
            "fund_debt_to_equity":  self.debt_to_equity,
            "fund_short_ratio":     self.short_ratio,
            "fund_short_pct_float": self.short_pct_float,
            "fund_finra_short_vol": self.finra_short_vol_ratio,
            "fund_value_score":     self.value_score,
            "fund_quality_score":   self.quality_score,
            "fund_fragility_score": self.fragility_score,
        }


# ---------------------------------------------------------------------------
# yfinance fetch (sync)
# ---------------------------------------------------------------------------

def _fetch_yf_info_sync(ticker: str) -> dict:
    try:
        import yfinance as yf
        info = yf.Ticker(ticker).info
        return info or {}
    except Exception as exc:
        logger.debug("yfinance .info failed for %s: %s", ticker, exc)
        return {}


def _safe(info: dict, key: str, lo: float, hi: float) -> Optional[float]:
    v = info.get(key)
    if v is None:
        return None
    try:
        f = float(v)
        if f != f:   # NaN
            return None
        return max(lo, min(hi, f))
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# FINRA REGSHO short sale volume (free, public)
# ---------------------------------------------------------------------------

_finra_cache: dict[str, tuple[float, dict]] = {}


def _fetch_finra_short_sync(ticker: str) -> Optional[float]:
    """
    Fetch the FINRA REGSHO daily short sale volume ratio for ticker.
    Returns short_vol / total_vol for the most recent available trading day.
    Data: https://www.finra.org/finra-data/browse-catalog/short-sale-volume-data
    """
    # Try last 5 trading days
    for days_back in range(1, 6):
        dt = (datetime.now(timezone.utc) - timedelta(days=days_back)).strftime("%Y%m%d")
        cache_key = f"{ticker}_{dt}"
        if cache_key in _finra_cache:
            exp, ratio = _finra_cache[cache_key]
            if time.monotonic() < exp:
                return ratio if ratio else None

        url = _FINRA_REGSHO_URL.format(date=dt)
        try:
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "FinanceAI research@financeai.dev"},
            )
            with urllib.request.urlopen(req, timeout=8) as resp:
                content = resp.read().decode("utf-8", errors="replace")

            # Format: Date|Symbol|ShortVolume|ShortExemptVolume|TotalVolume|Market
            for line in content.splitlines():
                parts = line.split("|")
                if len(parts) >= 5 and parts[1].strip() == ticker.upper():
                    short_vol = float(parts[2])
                    total_vol = float(parts[4])
                    if total_vol > 0:
                        ratio = short_vol / total_vol
                        _finra_cache[cache_key] = (time.monotonic() + _SHORT_TTL, ratio)
                        return round(ratio, 4)

        except Exception as exc:
            logger.debug("FINRA REGSHO fetch failed for %s on %s: %s", ticker, dt, exc)
            continue

    return None


# ---------------------------------------------------------------------------
# Composite score calculators
# ---------------------------------------------------------------------------

def _compute_value_score(fv: FundamentalFeatureVector) -> Optional[float]:
    """
    Composite value signal. High = cheap + quality.
    Motivated by Piotroski F-score and Fama-French value factor.
    """
    components = []

    # Low P/E is cheap (inverse) — P/E of 15 = 1.0, P/E of 30 = 0.5
    if fv.pe_ratio and fv.pe_ratio > 0:
        pe_score = min(1.0, max(0.0, 15.0 / fv.pe_ratio))
        components.append(pe_score)

    # High FCF yield is cheap
    if fv.fcf_yield is not None:
        fcf_score = min(1.0, max(0.0, fv.fcf_yield * 10))   # 10% FCF yield = 1.0
        components.append(fcf_score)

    # Low EV/EBITDA
    if fv.ev_to_ebitda and fv.ev_to_ebitda > 0:
        ev_score = min(1.0, max(0.0, 8.0 / fv.ev_to_ebitda))  # 8x = 1.0
        components.append(ev_score)

    # Positive ROE = quality signal within value screen
    if fv.roe is not None:
        roe_score = min(1.0, max(0.0, fv.roe / 0.20))  # 20% ROE = 1.0
        components.append(roe_score * 0.5)  # lower weight

    return round(sum(components) / len(components), 4) if components else None


def _compute_quality_score(fv: FundamentalFeatureVector) -> Optional[float]:
    """
    Quality signal — earnings consistency, growth, balance sheet strength.
    """
    components = []

    if fv.gross_margin is not None:
        components.append(min(1.0, max(0.0, fv.gross_margin)))

    if fv.operating_margin is not None:
        m_score = min(1.0, max(0.0, (fv.operating_margin + 0.2) / 0.4))
        components.append(m_score)

    if fv.revenue_growth is not None:
        g_score = min(1.0, max(0.0, (fv.revenue_growth + 0.05) / 0.35))
        components.append(g_score)

    if fv.roe is not None:
        roe_score = min(1.0, max(0.0, (fv.roe + 0.05) / 0.35))
        components.append(roe_score)

    if fv.current_ratio is not None:
        cr_score = min(1.0, max(0.0, (fv.current_ratio - 0.5) / 2.5))
        components.append(cr_score)

    return round(sum(components) / len(components), 4) if components else None


def _compute_fragility_score(fv: FundamentalFeatureVector) -> Optional[float]:
    """
    Fragility signal — high debt + high short interest = vulnerable.
    """
    components = []

    if fv.debt_to_equity is not None:
        de_score = min(1.0, max(0.0, fv.debt_to_equity / 3.0))
        components.append(de_score)

    if fv.short_pct_float is not None:
        short_score = min(1.0, fv.short_pct_float / 0.20)
        components.append(short_score)

    if fv.short_ratio is not None:
        dtc_score = min(1.0, fv.short_ratio / 5.0)
        components.append(dtc_score)

    if fv.finra_short_vol_ratio is not None:
        fsr_score = min(1.0, (fv.finra_short_vol_ratio - 0.3) / 0.4)
        components.append(max(0.0, fsr_score))

    return round(sum(components) / len(components), 4) if components else None


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class FundamentalFeatureEngine:
    """
    Fetches and caches fundamental ratios + FINRA short interest.
    24-hour cache for fundamentals (quarterly updates).
    """

    def __init__(self) -> None:
        self._cache: dict[str, tuple[float, FundamentalFeatureVector]] = {}
        self._lock  = asyncio.Lock()

    async def get_features(
        self,
        ticker:        str,
        force_refresh: bool = False,
    ) -> FundamentalFeatureVector:
        async with self._lock:
            now = time.monotonic()
            if not force_refresh and ticker in self._cache:
                exp, cached = self._cache[ticker]
                if now < exp:
                    return cached

        result = await self._compute(ticker)

        async with self._lock:
            self._cache[ticker] = (time.monotonic() + _FUNDAMENTAL_TTL, result)

        return result

    async def _compute(self, ticker: str) -> FundamentalFeatureVector:
        loop = asyncio.get_running_loop()

        # Parallel fetch: yfinance info + FINRA short data
        info_task   = loop.run_in_executor(None, _fetch_yf_info_sync, ticker)
        finra_task  = loop.run_in_executor(None, _fetch_finra_short_sync, ticker)
        info, finra_ratio = await asyncio.gather(info_task, finra_task)

        fv = FundamentalFeatureVector(ticker=ticker)

        # ── Valuation ────────────────────────────────────────────────────────
        fv.pe_ratio     = _safe(info, "trailingPE",          -50,   200)
        fv.forward_pe   = _safe(info, "forwardPE",           -50,   200)
        fv.pb_ratio     = _safe(info, "priceToBook",          0,     50)
        fv.ev_to_ebitda = _safe(info, "enterpriseToEbitda",  -20,   100)
        fv.ps_ratio     = _safe(info, "priceToSalesTrailing12Months", 0, 100)

        # FCF yield = FCF / market cap
        fcf  = info.get("freeCashflow")
        mcap = info.get("marketCap")
        if fcf is not None and mcap and mcap > 0:
            fv.fcf_yield = max(-1.0, min(1.0, float(fcf) / float(mcap)))

        # ── Quality / growth ─────────────────────────────────────────────────
        fv.revenue_growth   = _safe(info, "revenueGrowth",    -1.0, 2.0)
        fv.earnings_growth  = _safe(info, "earningsGrowth",   -2.0, 5.0)
        fv.gross_margin     = _safe(info, "grossMargins",     0.0,  1.0)
        fv.operating_margin = _safe(info, "operatingMargins", -1.0, 1.0)
        fv.roe              = _safe(info, "returnOnEquity",   -2.0, 2.0)
        fv.roa              = _safe(info, "returnOnAssets",   -1.0, 1.0)

        # ── Balance sheet ─────────────────────────────────────────────────────
        fv.debt_to_equity   = _safe(info, "debtToEquity",       0,    20)
        fv.current_ratio    = _safe(info, "currentRatio",        0,    10)

        # Interest coverage approximation: EBIT / interest expense
        ebit  = info.get("ebit")
        int_e = info.get("interestExpense")
        if ebit is not None and int_e and float(int_e) != 0:
            fv.interest_coverage = max(-10.0, min(50.0, float(ebit) / abs(float(int_e))))

        # ── Short interest ────────────────────────────────────────────────────
        fv.short_ratio     = _safe(info, "shortRatio",          0,    30)
        fv.short_pct_float = _safe(info, "shortPercentOfFloat", 0,    1.0)
        fv.finra_short_vol_ratio = finra_ratio

        # ── Composite scores ──────────────────────────────────────────────────
        fv.value_score    = _compute_value_score(fv)
        fv.quality_score  = _compute_quality_score(fv)
        fv.fragility_score = _compute_fragility_score(fv)

        fv.is_stale = (fv.pe_ratio is None and fv.fcf_yield is None)

        logger.debug(
            "Fundamentals[%s]: PE=%.1f FCF_yield=%.2f%% value=%.2f quality=%.2f fragility=%.2f",
            ticker,
            fv.pe_ratio or -1,
            (fv.fcf_yield or 0) * 100,
            fv.value_score or -1,
            fv.quality_score or -1,
            fv.fragility_score or -1,
        )
        return fv


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_engine: Optional[FundamentalFeatureEngine] = None


def get_engine() -> FundamentalFeatureEngine:
    global _engine
    if _engine is None:
        _engine = FundamentalFeatureEngine()
    return _engine
