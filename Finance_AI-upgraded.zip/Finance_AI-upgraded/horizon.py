"""
horizon.py — trade horizon optimisation.

Problem
-------
T+1 / T+3 / T+5 are arbitrary defaults.  The optimal holding period varies by:
  - event type  (earnings → fast decay; macro → slower)
  - signal tier (STRONG signals front-run; WEAK signals need time to resolve)
  - market regime (high-vol → faster mean reversion)

This module treats horizon as a hyperparameter and searches for the
holding period that maximises risk-adjusted IC.

Output
------
    HorizonResult.best_horizon   — int days (best overall)
    HorizonResult.by_event_type  — {event_type: best_horizon}
    HorizonResult.by_tier        — {tier: best_horizon}
    HorizonResult.ic_curve       — {horizon: ic}  for plotting

Usage
-----
    from horizon import optimise_horizon, HorizonResult

    result = optimise_horizon(events, horizons=[1, 2, 3, 5, 7, 10])
    print(result.summary())
    print(result.best_horizon)          # e.g. 3
    print(result.by_event_type)         # {"earnings": 1, "macro": 5, …}
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)

_DEFAULT_HORIZONS = [1, 2, 3, 5, 7, 10]


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class HorizonResult:
    best_horizon:    int
    ic_curve:        dict[int, float]           # horizon → IC
    sharpe_curve:    dict[int, float]           # horizon → Sharpe
    by_event_type:   dict[str, int]             # event_type → best horizon
    by_tier:         dict[str, int]             # signal_tier → best horizon
    n_events:        int
    notes:           str = ""

    def summary(self) -> str:
        lines = [
            f"\n{'─'*60}",
            f"  HORIZON OPTIMISATION",
            f"{'─'*60}",
            f"  Best overall horizon: T+{self.best_horizon}d",
            f"  n events (price-joined): {self.n_events}",
            "",
            f"  {'Horizon':<10} {'IC':>8} {'Sharpe':>8}",
            f"  {'─'*30}",
        ]
        for h in sorted(self.ic_curve):
            ic     = self.ic_curve[h]
            sharpe = self.sharpe_curve.get(h, float("nan"))
            flag   = " ◀ best" if h == self.best_horizon else ""
            ic_s   = f"{ic:.4f}" if math.isfinite(ic) else "  n/a "
            sh_s   = f"{sharpe:.2f}" if math.isfinite(sharpe) else "  n/a"
            lines.append(f"  T+{h:<8} {ic_s:>8} {sh_s:>8}{flag}")

        if self.by_event_type:
            lines += ["", "  Best horizon by event type:"]
            for et, h in sorted(self.by_event_type.items()):
                lines.append(f"    {et:<22} T+{h}d")

        if self.by_tier:
            lines += ["", "  Best horizon by signal tier:"]
            for tier, h in sorted(self.by_tier.items()):
                lines.append(f"    {tier:<22} T+{h}d")

        lines.append(f"{'─'*60}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "best_horizon":  self.best_horizon,
            "ic_curve":      {str(k): v for k, v in self.ic_curve.items()},
            "sharpe_curve":  {str(k): v for k, v in self.sharpe_curve.items()},
            "by_event_type": self.by_event_type,
            "by_tier":       self.by_tier,
            "n_events":      self.n_events,
        }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _spearman(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 3:
        return float("nan")
    try:
        from scipy.stats import spearmanr
        r, _ = spearmanr(xs, ys)
        return float(r) if math.isfinite(r) else float("nan")
    except ImportError:
        return float("nan")


def _sharpe(rets: list[float]) -> float:
    n = len(rets)
    if n < 2:
        return float("nan")
    mu  = sum(rets) / n
    var = sum((r - mu) ** 2 for r in rets) / (n - 1)
    std = math.sqrt(var)
    return (mu / std * math.sqrt(252)) if std > 1e-9 else float("nan")


def _best_horizon_for(
    events:   list[dict],
    horizons: list[int],
    ic_weight: float = 0.6,
    sh_weight: float = 0.4,
) -> int:
    """
    Score each horizon by: combined = ic_weight × IC + sh_weight × normalised_Sharpe.
    Returns the horizon with the highest combined score.
    Falls back to horizons[0] if data is insufficient.
    """
    best_h     = horizons[0]
    best_score = -999.0

    for h in horizons:
        key   = f"fwd_ret_{h}d"
        pairs = [(float(ev.get("signal_score") or 0.0), float(ev[key]))
                 for ev in events if ev.get(key) is not None]
        if len(pairs) < 5:
            continue
        sigs, rets = zip(*pairs)
        ic     = _spearman(list(sigs), list(rets))
        sharpe = _sharpe(list(rets))
        if not math.isfinite(ic):
            ic = 0.0
        if not math.isfinite(sharpe):
            sharpe = 0.0
        # Normalise Sharpe to a comparable scale (cap at ±3)
        norm_sharpe = max(-1.0, min(1.0, sharpe / 3.0))
        score = ic_weight * ic + sh_weight * norm_sharpe
        if score > best_score:
            best_score = score
            best_h     = h

    return best_h


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def optimise_horizon(
    events:   list[dict],
    horizons: Optional[list[int]] = None,
) -> HorizonResult:
    """
    Find the optimal holding period by maximising IC × Sharpe tradeoff.

    Events must have fwd_ret_{h}d for each h in horizons.
    If a particular horizon has no price data, it is skipped.

    Parameters
    ----------
    events    list of scored + price-joined event dicts
    horizons  list of candidate holding periods in trading days

    Returns
    -------
    HorizonResult with best_horizon, ic_curve, and per-slice breakdowns
    """
    if horizons is None:
        horizons = _DEFAULT_HORIZONS

    # ---- Overall IC and Sharpe curves -----------------------------------
    ic_curve     = {}
    sharpe_curve = {}
    n_valid_total = 0

    for h in horizons:
        key   = f"fwd_ret_{h}d"
        pairs = [(float(ev.get("signal_score") or 0.0), float(ev[key]))
                 for ev in events if ev.get(key) is not None]
        if len(pairs) < 3:
            ic_curve[h]     = float("nan")
            sharpe_curve[h] = float("nan")
            continue
        sigs, rets = zip(*pairs)
        ic_curve[h]     = round(_spearman(list(sigs), list(rets)), 4)
        sharpe_curve[h] = round(_sharpe(list(rets)), 4)
        n_valid_total    = max(n_valid_total, len(pairs))

    best_horizon = _best_horizon_for(events, horizons)

    # ---- Per event-type breakdown ----------------------------------------
    et_groups: dict[str, list] = {}
    for ev in events:
        et = (ev.get("event_type") or "unknown").lower()
        et_groups.setdefault(et, []).append(ev)

    by_event_type = {
        et: _best_horizon_for(evs, horizons)
        for et, evs in et_groups.items()
        if len(evs) >= 5
    }

    # ---- Per signal-tier breakdown ---------------------------------------
    tier_groups: dict[str, list] = {}
    for ev in events:
        tier = (ev.get("signal_tier") or "NOISE").upper()
        tier_groups.setdefault(tier, []).append(ev)

    by_tier = {
        tier: _best_horizon_for(evs, horizons)
        for tier, evs in tier_groups.items()
        if len(evs) >= 5
    }

    notes = []
    if best_horizon == 1:
        notes.append("T+1 optimal — signal decays fast; consider same-day monitoring")
    elif best_horizon >= 7:
        notes.append("Long horizon optimal — signal may capture slow-moving narratives")

    return HorizonResult(
        best_horizon  = best_horizon,
        ic_curve      = ic_curve,
        sharpe_curve  = sharpe_curve,
        by_event_type = by_event_type,
        by_tier       = by_tier,
        n_events      = n_valid_total,
        notes         = "; ".join(notes),
    )


def apply_horizon_weights(
    score:       float,
    event_type:  str,
    horizon_result: HorizonResult,
    default_horizon: int = 1,
) -> dict:
    """
    Given a signal score and a HorizonResult, return the recommended
    holding period and adjusted score (no change to magnitude — just metadata).
    """
    et = (event_type or "unknown").lower()
    h  = horizon_result.by_event_type.get(et, horizon_result.best_horizon)
    # Confidence discount for longer horizons (more noise)
    decay = max(0.5, 1.0 - (h - 1) * 0.08)
    return {
        "recommended_horizon": h,
        "adjusted_score":      round(score * decay, 4),
        "horizon_decay":       round(decay, 4),
    }
