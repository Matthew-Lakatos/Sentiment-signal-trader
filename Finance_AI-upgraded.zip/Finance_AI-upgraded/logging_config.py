"""
logging_config.py — structured JSON logging with fallback to text.
Ships logs to stdout so the container runtime (Docker log driver,
CloudWatch, Datadog agent) can forward them.
"""
from __future__ import annotations
import json
import logging
import sys
import traceback
from datetime import datetime, timezone

from config import settings


class _JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload: dict = {
            "ts":      datetime.now(timezone.utc).isoformat(),
            "level":   record.levelname,
            "logger":  record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            payload["exception"] = traceback.format_exception(*record.exc_info)
        for key in ("url", "domain", "duration_ms", "event_id", "alert_type"):
            if hasattr(record, key):
                payload[key] = getattr(record, key)
        return json.dumps(payload)


def setup_logging() -> None:
    root = logging.getLogger()
    root.setLevel(getattr(logging, settings.log_level, logging.INFO))

    handler = logging.StreamHandler(sys.stdout)
    if settings.log_format == "json":
        handler.setFormatter(_JsonFormatter())
    else:
        handler.setFormatter(logging.Formatter(
            "%(asctime)s %(levelname)-8s %(name)s  %(message)s"
        ))

    root.handlers.clear()
    root.addHandler(handler)

    # Suppress noisy third-party loggers
    for noisy in ("urllib3", "selenium", "aiohttp", "asyncio"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
