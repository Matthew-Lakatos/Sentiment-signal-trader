"""
liquidity_engine.py — §4 Liquidity + Microstructure Engine.

Measures market fragility and execution conditions using observable
price and volume data. No L2 orderbook or proprietary feeds required —
all inputs are computable from standard OHLCV data via yfinance.

Metrics computed
----------------
1. Amihud illiquidity ratio
   |daily_return| / dollar_volume — rises sharply in illiquid conditions.
   Normalised to [0, 1] via rolling 90th-percentile scaling.

2. High-low spread proxy
   (High - Low) / Close — a fast intraday liquidity gauge. Widens when
   bid-ask spreads widen and market depth thins.

3. Volatility regime (short vs. long window)
   10-day realised vol relative to 90-day realised vol. A ratio > 1.5
   indicates volatility clustering / regime change.

4. Rolling correlation spike
   Average pairwise correlation of sector ETFs. When correlations spike
   toward 1.0 all assets move together — a classic fragility signal.

5. Volume anomaly score
   Current volume relative to 30-day average. Abnormal volume (very
   high or very low) signals liquidity events or thin-market conditions.

Composite
---------
  liquidity_stress_index ∈ [0, 1]
    0 = deep, orderly markets
    1 = stressed, fragile liquidity conditions

  execution_fragility ∈ [0, 1]
    Expected execution difficulty for a new position. Combines spread
    proxy + Amihud + volume anomaly.

  spread_instability ∈ [0, 1]
    Rolling variance of the HL-spread proxy; indicates bid-ask drift.

  structural_fragility ∈ [0, 1]
    Correlation spike + vol-ratio composite; a leading indicator of
    systemic repricing events.

Regime classification
---------------------
  LIQUID    — stress < 0.25
  NORMAL    — stress < 0.45
  ELEVATED  — stress < 0.65
  STRESSED  — stress < 0.80
  CRITICAL  — stress ≥ 0.80

Usage
-----
    from liquidity_engine import LiquidityEngine

    engine = LiquidityEngine()
    snap = await engine.get_snapshot()

    print(snap.liquidity_stress_index, snap.regime)
    print(snap.execution_fragility, snap.structural_fragility)
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_SECTOR_ETFS = ["XLK", "XLF", "XLE", "XLV", "XLI", "XLP", "XLY", "XLU", "XLB", "XLRE", "XLC"]
_SPY         = "SPY"
_LOOKBACK    = "120d"
_CACHE_TTL   = 900   # 15 min — microstructure is faster-moving than macro state

# Regime thresholds
_REGIME_BREAKS = [
    (0.25, "LIQUID"),
    (0.45, "NORMAL"),
    (0.65, "ELEVATED"),
    (0.80, "STRESSED"),
    (1.01, "CRITICAL"),
]

# Amihud normalisation cap (basis points per $million traded)
_AMIHUD_CAP = 1e-5


# ---------------------------------------------------------------------------
# Output dataclass
# ---------------------------------------------------------------------------

@dataclass
class LiquiditySnapshot:
    # Composite scores
    liquidity_stress_index: Optional[float] = None  # [0, 1]
    execution_fragility:    Optional[float] = None  # [0, 1]
    spread_instability:     Optional[float] = None  # [0, 1]
    structural_fragility:   Optional[float] = None  # [0, 1]

    # Regime label
    regime: str = "UNKNOWN"   # LIQUID | NORMAL | ELEVATED | STRESSED | CRITICAL

    # SPY-based sub-components
    amihud_score:      Optional[float] = None
    hl_spread_score:   Optional[float] = None
    vol_ratio:         Optional[float] = None
    vol_ratio_score:   Optional[float] = None
    correlation_score: Optional[float] = None
    volume_anomaly:    Optional[float] = None
    spy_amihud_raw:    Optional[float] = None

    # #2 Cross-asset inputs
    hy_spread_score:     Optional[float] = None   # HY credit spread normalised [0,1]
    ig_spread_score:     Optional[float] = None   # IG credit spread normalised [0,1]
    vix_term_score:      Optional[float] = None   # VIX9D/VIX ratio; inversion = stress [0,1]
    fx_vol_score:        Optional[float] = None   # FX implied vol (UUP proxy) [0,1]
    move_score:          Optional[float] = None   # Bond market vol (MOVE proxy via TLT) [0,1]
    cross_asset_stress:  Optional[float] = None   # composite of the above [0,1]

    fetched_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_stale:   bool     = True
    notes:      list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Math helpers
# ---------------------------------------------------------------------------

def _safe_normalise(series: np.ndarray, cap: Optional[float] = None) -> np.ndarray:
    """Min-max normalise to [0, 1] with optional upper cap."""
    s = series.copy().astype(float)
    if cap is not None:
        s = np.clip(s, 0, cap)
    mn, mx = s.min(), s.max()
    if mx == mn:
        return np.zeros_like(s)
    return (s - mn) / (mx - mn)


def _amihud_ratio(returns: np.ndarray, dollar_volumes: np.ndarray) -> np.ndarray:
    """
    Amihud (2002) illiquidity: |r_t| / volume_t
    Returns daily illiquidity array (same length as inputs).
    """
    with np.errstate(divide="ignore", invalid="ignore"):
        ratio = np.abs(returns) / np.where(dollar_volumes > 0, dollar_volumes, np.nan)
    ratio = np.where(np.isfinite(ratio), ratio, np.nan)
    return ratio


def _rolling_pairwise_corr(price_matrix: np.ndarray, window: int = 20) -> np.ndarray:
    """
    Returns a daily series of average pairwise Pearson correlation
    across columns, computed over a rolling window.
    """
    n_days, n_assets = price_matrix.shape
    if n_assets < 2:
        return np.full(n_days, 0.0)

    rets = np.diff(np.log(price_matrix + 1e-12), axis=0)
    corrs = np.full(len(rets), np.nan)

    for i in range(window, len(rets)):
        window_rets = rets[i - window: i]
        # Skip if any column is constant
        if np.any(np.nanstd(window_rets, axis=0) == 0):
            continue
        corr_matrix = np.corrcoef(window_rets.T)
        # Upper triangle only (no diagonal)
        triu = corr_matrix[np.triu_indices(n_assets, k=1)]
        valid = triu[np.isfinite(triu)]
        corrs[i] = float(np.mean(valid)) if len(valid) > 0 else np.nan

    return corrs


# ---------------------------------------------------------------------------
# Data fetch
# ---------------------------------------------------------------------------

def _fetch_cross_asset_sync() -> dict:
    """
    Fetch cross-asset liquidity proxies from yfinance.
    HYG/LQD spreads, VIX term structure, FX vol, TLT (MOVE proxy).
    """
    try:
        import yfinance as yf
        import pandas as pd

        # HYG = HY bond ETF, LQD = IG bond ETF, UUP = USD bull ETF (FX vol proxy)
        # VIX9D = short-dated VIX, ^VIX = standard, TLT = bond vol proxy
        tickers = ["HYG", "LQD", "UUP", "^VIX", "^VIX9D", "TLT", "^MOVE"]
        raw = yf.download(tickers, period="60d", progress=False, auto_adjust=True)
        if raw.empty:
            return {}

        result = {}

        # Credit spread proxies: use price momentum as spread proxy
        # HYG falling relative to LQD = HY spread widening
        def _price_series(ticker):
            try:
                if isinstance(raw.columns, pd.MultiIndex):
                    if ticker in raw.columns.get_level_values(0):
                        return raw[ticker]["Close"].dropna()
            except Exception:
                pass
            return None

        hyg  = _price_series("HYG")
        lqd  = _price_series("LQD")
        uup  = _price_series("UUP")
        tlt  = _price_series("TLT")
        vix  = _price_series("^VIX")
        vix9 = _price_series("^VIX9D")
        move = _price_series("^MOVE")

        # HY spread score: recent HYG/LQD ratio vs 30d average
        if hyg is not None and lqd is not None and len(hyg) >= 20:
            ratio = (hyg / lqd).dropna()
            if len(ratio) >= 20:
                recent = float(ratio.iloc[-5:].mean())
                hist   = float(ratio.iloc[-20:].mean())
                # Falling ratio = widening spread = more stress
                raw_score = (hist - recent) / (hist * 0.02)   # 2% move = full stress
                result["hy_spread_score"] = float(min(1.0, max(0.0, raw_score)))

        # IG spread score: LQD price decline = IG spread widening
        if lqd is not None and len(lqd) >= 20:
            ret_5d = float(lqd.iloc[-1] / lqd.iloc[-5] - 1)
            result["ig_spread_score"] = float(min(1.0, max(0.0, -ret_5d / 0.02)))

        # VIX term structure: VIX9D/VIX ratio. Inversion (>1) = acute stress
        if vix is not None and vix9 is not None and len(vix) >= 2:
            ratio = float(vix9.iloc[-1] / vix.iloc[-1])
            # Normal: ratio ~0.9. Inverted (>1) = front-end stress = high score
            result["vix_term_score"] = float(min(1.0, max(0.0, (ratio - 0.85) / 0.20)))

        # FX vol score: UUP sharp moves = FX stress
        if uup is not None and len(uup) >= 20:
            vol_5d  = float(uup.pct_change().iloc[-5:].std()) * (252 ** 0.5)
            vol_20d = float(uup.pct_change().iloc[-20:].std()) * (252 ** 0.5)
            if vol_20d > 0:
                result["fx_vol_score"] = float(min(1.0, max(0.0, vol_5d / vol_20d - 1.0)))
            else:
                result["fx_vol_score"] = 0.0

        # MOVE proxy: TLT realised vol (bond volatility)
        if move is not None and len(move) >= 5:
            move_val = float(move.iloc[-1])
            # MOVE index: historically 50-150, extreme > 150
            result["move_score"] = float(min(1.0, max(0.0, (move_val - 50) / 150)))
        elif tlt is not None and len(tlt) >= 20:
            vol_tlt = float(tlt.pct_change().iloc[-10:].std()) * (252 ** 0.5)
            result["move_score"] = float(min(1.0, max(0.0, vol_tlt / 0.25)))

        return result

    except Exception as exc:
        logger.warning("Cross-asset fetch failed: %s", exc)
        return {}


def _fetch_sync() -> dict:
    """
    Fetch all required OHLCV data from yfinance.
    Returns a dict with keys: spy_df, sector_dfs.
    """
    try:
        import yfinance as yf
        import pandas as pd

        tickers = [_SPY] + _SECTOR_ETFS
        raw = yf.download(
            tickers,
            period=_LOOKBACK,
            progress=False,
            auto_adjust=True,
            group_by="ticker",
        )

        if raw.empty:
            return {}

        result = {}

        # SPY for Amihud + spread
        if _SPY in raw.columns.get_level_values(0) if isinstance(raw.columns, pd.MultiIndex) else []:
            spy = raw[_SPY].dropna()
        else:
            # single-ticker fallback
            spy = raw.dropna()
        result["spy"] = spy

        # Sector ETFs for correlation
        sector_closes = {}
        for etf in _SECTOR_ETFS:
            try:
                if isinstance(raw.columns, pd.MultiIndex) and etf in raw.columns.get_level_values(0):
                    df = raw[etf][["Close"]].dropna()
                    sector_closes[etf] = df["Close"].values
            except Exception:
                pass
        result["sector_closes"] = sector_closes

        return result

    except Exception as exc:
        logger.warning("Liquidity data fetch failed: %s", exc)
        return {}


# ---------------------------------------------------------------------------
# Score computation
# ---------------------------------------------------------------------------

def _compute_scores(data: dict) -> LiquiditySnapshot:
    notes: list[str] = []

    # ── SPY-based metrics ────────────────────────────────────────────────────
    amihud_score    = None
    hl_spread_score = None
    vol_ratio_score = None
    vol_ratio_raw   = None
    volume_anomaly  = None
    spy_amihud_raw  = None

    spy = data.get("spy")
    if spy is not None and len(spy) >= 30:
        try:
            import pandas as pd
            close  = spy["Close"].values.astype(float)
            high   = spy["High"].values.astype(float)
            low    = spy["Low"].values.astype(float)
            volume = spy["Volume"].values.astype(float)

            # Dollar volume
            dollar_vol = close * volume

            # Returns
            rets = np.diff(np.log(np.where(close > 0, close, np.nan)))
            rets = np.where(np.isfinite(rets), rets, 0.0)

            # Amihud illiquidity — last 30 days, normalised by 90d distribution
            amihud = _amihud_ratio(rets[-90:], dollar_vol[1:][-90:])
            valid_amihud = amihud[np.isfinite(amihud)]
            if len(valid_amihud) >= 10:
                spy_amihud_raw = float(np.nanmedian(valid_amihud[-5:]))
                p90 = np.nanpercentile(valid_amihud, 90)
                current_amihud = float(np.nanmean(valid_amihud[-5:]))
                amihud_score = float(min(1.0, current_amihud / max(p90, 1e-12)))

            # HL spread proxy
            hl_spread = (high - low) / np.where(close > 0, close, np.nan)
            hl_spread = np.where(np.isfinite(hl_spread), hl_spread, np.nan)
            valid_hl = hl_spread[np.isfinite(hl_spread)]
            if len(valid_hl) >= 10:
                p90_hl = np.nanpercentile(valid_hl, 90)
                cur_hl = float(np.nanmean(valid_hl[-5:]))
                hl_spread_score = float(min(1.0, cur_hl / max(p90_hl, 1e-12)))

            # Volatility ratio: 10-day vs 90-day realised vol
            if len(rets) >= 90:
                vol_10  = float(np.nanstd(rets[-10:]))  * math.sqrt(252)
                vol_90  = float(np.nanstd(rets[-90:]))  * math.sqrt(252)
                if vol_90 > 0:
                    vol_ratio_raw   = vol_10 / vol_90
                    vol_ratio_score = float(min(1.0, max(0.0, (vol_ratio_raw - 1.0) / 2.0)))

            # Volume anomaly: compare last 5 days to 30-day average
            if len(volume) >= 30:
                avg_vol_30  = float(np.mean(volume[-30:]))
                cur_vol     = float(np.mean(volume[-5:]))
                ratio       = cur_vol / max(avg_vol_30, 1)
                # Both very high AND very low volume are anomalous
                volume_anomaly = float(min(1.0, abs(math.log(ratio + 1e-9)) / math.log(4)))

        except Exception as exc:
            logger.warning("SPY metric computation failed: %s", exc)
            notes.append(f"spy_metric_error: {exc}")

    # ── Sector correlation spike ─────────────────────────────────────────────
    correlation_score = None
    sector_closes = data.get("sector_closes", {})
    if len(sector_closes) >= 4:
        try:
            min_len  = min(len(v) for v in sector_closes.values())
            matrix   = np.column_stack([v[-min_len:] for v in sector_closes.values()])
            corr_ser = _rolling_pairwise_corr(matrix, window=20)
            valid_corr = corr_ser[np.isfinite(corr_ser)]
            if len(valid_corr) >= 5:
                current_corr    = float(np.nanmean(valid_corr[-5:]))
                long_term_corr  = float(np.nanmean(valid_corr))
                # Spike = current corr substantially above long-term average
                corr_spike      = max(0.0, current_corr - long_term_corr)
                # Also score the absolute level (high correlation = fragile)
                correlation_score = float(min(1.0, 0.4 * current_corr + 0.6 * corr_spike / 0.3))
        except Exception as exc:
            logger.warning("Correlation computation failed: %s", exc)
            notes.append(f"corr_error: {exc}")

    # ── Composite scores ─────────────────────────────────────────────────────
    # Spread instability: variance of HL spread (if we have it)
    spread_instability = None
    if hl_spread_score is not None and spy is not None and len(spy) >= 20:
        try:
            close  = spy["Close"].values.astype(float)
            high   = spy["High"].values.astype(float)
            low    = spy["Low"].values.astype(float)
            hl     = (high - low) / np.where(close > 0, close, np.nan)
            hl_var = float(np.nanstd(hl[-20:]) / max(np.nanmean(hl[-20:]), 1e-9))
            spread_instability = float(min(1.0, hl_var / 0.5))
        except Exception:
            pass

    # Execution fragility: Amihud + HL spread + volume anomaly
    exec_components = [x for x in [amihud_score, hl_spread_score, volume_anomaly] if x is not None]
    execution_fragility = round(sum(exec_components) / len(exec_components), 4) if exec_components else None

    # Structural fragility: correlation spike + vol regime
    struct_components = [x for x in [correlation_score, vol_ratio_score] if x is not None]
    structural_fragility = round(sum(struct_components) / len(struct_components), 4) if struct_components else None

    # Liquidity stress index: all-in composite
    stress_components = [x for x in [
        amihud_score,
        hl_spread_score,
        vol_ratio_score,
        correlation_score,
        volume_anomaly,
    ] if x is not None]

    if not stress_components:
        liquidity_stress = None
        notes.append("insufficient_data")
    else:
        # Weights: Amihud and correlation are the strongest predictors
        weights = {
            "amihud":      0.30,
            "hl_spread":   0.25,
            "vol_ratio":   0.20,
            "correlation": 0.15,
            "volume":      0.10,
        }
        named = [
            ("amihud",      amihud_score),
            ("hl_spread",   hl_spread_score),
            ("vol_ratio",   vol_ratio_score),
            ("correlation", correlation_score),
            ("volume",      volume_anomaly),
        ]
        total_w  = sum(weights[k] for k, v in named if v is not None)
        weighted = sum(weights[k] * v for k, v in named if v is not None)
        liquidity_stress = round(weighted / total_w, 4) if total_w > 0 else None

    # Regime classification
    regime = "UNKNOWN"
    if liquidity_stress is not None:
        for thresh, label in _REGIME_BREAKS:
            if liquidity_stress < thresh:
                regime = label
                break

    snap = LiquiditySnapshot(
        liquidity_stress_index = liquidity_stress,
        execution_fragility    = execution_fragility,
        spread_instability     = spread_instability,
        structural_fragility   = structural_fragility,
        regime                 = regime,
        amihud_score           = amihud_score,
        hl_spread_score        = hl_spread_score,
        vol_ratio              = vol_ratio_raw,
        vol_ratio_score        = vol_ratio_score,
        correlation_score      = correlation_score,
        volume_anomaly         = volume_anomaly,
        spy_amihud_raw         = spy_amihud_raw,
        fetched_at             = datetime.now(timezone.utc),
        is_stale               = liquidity_stress is None,
        notes                  = notes,
    )
    return snap


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class LiquidityEngine:
    """
    Computes market-wide liquidity and microstructure metrics.
    Cached at the market level (not per-ticker) since the inputs
    are broad-market ETFs.
    """

    def __init__(self) -> None:
        self._cache:    Optional[tuple[float, LiquiditySnapshot]] = None
        self._lock = asyncio.Lock()

    async def get_snapshot(self, force_refresh: bool = False) -> LiquiditySnapshot:
        async with self._lock:
            now = time.monotonic()
            if not force_refresh and self._cache is not None:
                expires, cached = self._cache
                if now < expires:
                    return cached

            loop = asyncio.get_running_loop()
            spy_task   = loop.run_in_executor(None, _fetch_sync)
            cross_task = loop.run_in_executor(None, _fetch_cross_asset_sync)
            data, cross_data = await asyncio.gather(spy_task, cross_task)

            if not data:
                snap = LiquiditySnapshot(is_stale=True, notes=["fetch_failed"])
            else:
                snap = _compute_scores(data)
                # Use incremental Amihud accumulator instead of full recompute
                try:
                    from amihud_accumulator import get_accumulator as _get_amihud
                    spy_acc = _get_amihud("SPY")
                    if spy_acc.is_warm and spy_acc.normalised_score is not None:
                        snap.amihud_score  = spy_acc.normalised_score
                        snap.spy_amihud_raw = spy_acc.ewma_amihud
                    else:
                        spy_df = data.get("spy")
                        if spy_df is not None and len(spy_df) >= 5:
                            closes  = spy_df["Close"].values.astype(float).tolist()
                            volumes = spy_df["Volume"].values.astype(float).tolist()
                            await loop.run_in_executor(
                                None, spy_acc.initialise_from_history, closes, volumes
                            )
                except Exception as exc:
                    logger.debug("Amihud accumulator integration error: %s", exc)

            # Attach cross-asset components
            if cross_data:
                snap.hy_spread_score = cross_data.get("hy_spread_score")
                snap.ig_spread_score = cross_data.get("ig_spread_score")
                snap.vix_term_score  = cross_data.get("vix_term_score")
                snap.fx_vol_score    = cross_data.get("fx_vol_score")
                snap.move_score      = cross_data.get("move_score")

                ca_components = [v for v in [
                    snap.hy_spread_score, snap.ig_spread_score,
                    snap.vix_term_score, snap.fx_vol_score, snap.move_score,
                ] if v is not None]
                if ca_components:
                    snap.cross_asset_stress = round(sum(ca_components) / len(ca_components), 4)
                    if snap.liquidity_stress_index is not None:
                        snap.liquidity_stress_index = round(
                            0.80 * snap.liquidity_stress_index + 0.20 * snap.cross_asset_stress, 4
                        )
                        for thresh, label in _REGIME_BREAKS:
                            if snap.liquidity_stress_index < thresh:
                                snap.regime = label
                                break

            self._cache = (now + _CACHE_TTL, snap)

            logger.info(
                "Liquidity: stress=%.2f regime=%s exec_frag=%.2f cross_asset=%.2f amihud=%.4f",
                snap.liquidity_stress_index or -1, snap.regime,
                snap.execution_fragility    or -1,
                snap.cross_asset_stress     or -1,
                snap.amihud_score           or -1,
            )
            return snap

    def invalidate(self) -> None:
        """Force a fresh fetch on the next call."""
        self._cache = None


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_engine: Optional[LiquidityEngine] = None


def get_engine() -> LiquidityEngine:
    global _engine
    if _engine is None:
        _engine = LiquidityEngine()
    return _engine
