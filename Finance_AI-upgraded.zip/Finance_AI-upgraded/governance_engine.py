"""
governance_engine.py — §16 Governance Engine.

Computes a single governance_confidence scalar ∈ [0, 1] that answers
the question: "How much should the system trust itself right now?"

This is the central nervous system of the platform's self-awareness.
It aggregates signals from every subsystem that tracks model or market
health and converts them into a single number that the risk throttle
and kill-switch consume.

Inputs (all optional — missing inputs degrade gracefully)
---------------------------------------------------------
1. drift_monitor     — rolling IC, rolling Sharpe, gate_open
2. liquidity_engine  — liquidity_stress_index, structural_fragility
3. positioning_engine — fragility_estimate (for any tracked tickers)
4. market_state      — vix_regime, risk_regime
5. feature_stability — avg IC contribution stability (from feature_stability.py)

Component weights (adjustable via env vars)
-------------------------------------------
  model_health     40%   — IC, Sharpe, gate from drift_monitor
  market_regime    25%   — VIX + risk regime from market_state
  liquidity        20%   — stress index from liquidity_engine
  positioning      15%   — fragility from positioning_engine

Confidence interpretation
-------------------------
  ≥ 0.80  FULL        — deploy at full sizing
  ≥ 0.65  CAUTIOUS    — reduce sizing by 25%
  ≥ 0.50  REDUCED     — reduce sizing by 50%
  ≥ 0.35  DEFENSIVE   — reduce sizing by 75%; only highest-conviction trades
  <  0.35  SUSPENDED   — do not deploy new capital

GovernanceReport
----------------
  governance_confidence  ∈ [0, 1]
  mode                   str (FULL | CAUTIOUS | REDUCED | DEFENSIVE | SUSPENDED)
  component_scores       dict[str, float]  — for attribution / debugging
  warnings               list[str]         — human-readable flags
  computed_at            datetime

Usage
-----
    from governance_engine import GovernanceEngine

    gov = GovernanceEngine()
    report = await gov.assess()

    print(report.governance_confidence, report.mode)
    if report.mode in ("DEFENSIVE", "SUSPENDED"):
        # alert risk team
        ...
"""
from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from drift_monitor    import DriftMonitor, HealthReport
    from liquidity_engine import LiquiditySnapshot
    from market_state     import MarketState

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Component weights (overridable via env)
# ---------------------------------------------------------------------------

def _float_env(key: str, default: float) -> float:
    try:
        return float(os.environ[key])
    except (KeyError, ValueError):
        return default


_W_MODEL     = _float_env("GOV_W_MODEL",      0.40)
_W_REGIME    = _float_env("GOV_W_REGIME",     0.25)
_W_LIQUIDITY = _float_env("GOV_W_LIQUIDITY",  0.20)
_W_POSITION  = _float_env("GOV_W_POSITION",   0.15)

# Governance mode thresholds
_MODE_BREAKS = [
    (0.80, "FULL"),
    (0.65, "CAUTIOUS"),
    (0.50, "REDUCED"),
    (0.35, "DEFENSIVE"),
    (0.00, "SUSPENDED"),
]


# ---------------------------------------------------------------------------
# Output dataclass
# ---------------------------------------------------------------------------

@dataclass
class GovernanceReport:
    governance_confidence:   float           # [0, 1]
    governance_uncertainty:  float           # [0, 1] — spread of component scores
    governance_stability:    float           # [0, 1] — how stable confidence has been recently
    mode:                    str             # FULL | CAUTIOUS | REDUCED | DEFENSIVE | SUSPENDED
    component_scores:        dict            # {component: score}
    warnings:                list[str]
    recommended_size_scalar: float           # [0, 1]
    computed_at:             datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def is_deployable(self) -> bool:
        return self.mode not in ("SUSPENDED",)

    def is_uncertain(self) -> bool:
        """High uncertainty = components disagree; reduce conviction."""
        return self.governance_uncertainty > 0.25

    def summary(self) -> str:
        return (
            f"GovernanceReport(confidence={self.governance_confidence:.3f}, "
            f"uncertainty={self.governance_uncertainty:.3f}, "
            f"stability={self.governance_stability:.3f}, "
            f"mode={self.mode}, scalar={self.recommended_size_scalar:.2f})"
        )


# ---------------------------------------------------------------------------
# Sub-scorers (each returns a confidence component ∈ [0, 1])
# ---------------------------------------------------------------------------

def _score_model_health(
    health_report: Optional["HealthReport"],
    gate_open:     bool,
) -> tuple[float, list[str]]:
    """
    Model health score from DriftMonitor.
    IC and Sharpe are the primary inputs.
    """
    warnings: list[str] = []

    if health_report is None:
        return 0.6, ["model_health_unavailable"]   # conservative neutral

    ic     = health_report.rolling_ic     or 0.0
    sharpe = health_report.rolling_sharpe or 0.0

    # IC contribution: IC=0 → 0.3; IC=0.10 → 0.7; IC=0.20 → 1.0
    ic_score = min(1.0, max(0.0, 0.3 + ic / 0.20 * 0.7)) if ic >= 0 else max(0.0, 0.3 + ic / 0.10 * 0.3)

    # Sharpe contribution: Sharpe=0 → 0.3; Sharpe=1 → 0.7; Sharpe=2 → 1.0
    sharpe_score = min(1.0, max(0.0, 0.3 + sharpe / 2.0 * 0.7)) if sharpe >= 0 else max(0.0, 0.3 + sharpe / 1.0 * 0.3)

    # Gate penalty
    gate_factor = 1.0 if gate_open else 0.5
    if not gate_open:
        warnings.append("drift_gate_closed")

    # Regime mismatch penalty
    if getattr(health_report, "regime_mismatch", False):
        gate_factor = min(gate_factor, 0.7)
        warnings.append("regime_mismatch")

    score = (0.55 * ic_score + 0.45 * sharpe_score) * gate_factor
    return round(min(1.0, max(0.0, score)), 4), warnings


def _score_market_regime(market_state: Optional["MarketState"]) -> tuple[float, list[str]]:
    """
    Market regime confidence. Bad regimes reduce confidence.
    """
    warnings: list[str] = []

    if market_state is None:
        return 0.6, ["market_state_unavailable"]

    vix_regime  = getattr(market_state, "vix_regime",  "ELEVATED")
    risk_regime = getattr(market_state, "risk_regime",  "NEUTRAL")

    # VIX regime score
    vix_scores = {"LOW": 1.0, "ELEVATED": 0.75, "HIGH": 0.50, "SPIKE": 0.20}
    vix_score  = vix_scores.get(vix_regime, 0.6)

    # Risk regime score
    risk_scores = {"RISK_ON": 0.85, "NEUTRAL": 0.70, "RISK_OFF": 0.40}
    risk_score  = risk_scores.get(risk_regime, 0.6)

    if vix_regime == "SPIKE":
        warnings.append("vix_spike")
    if risk_regime == "RISK_OFF":
        warnings.append("risk_off_regime")

    score = 0.55 * vix_score + 0.45 * risk_score
    return round(score, 4), warnings


def _score_liquidity(liquidity_snap: Optional["LiquiditySnapshot"]) -> tuple[float, list[str]]:
    """
    Liquidity confidence: invert the stress index.
    """
    warnings: list[str] = []

    if liquidity_snap is None or liquidity_snap.is_stale:
        return 0.6, ["liquidity_unavailable"]

    stress = liquidity_snap.liquidity_stress_index
    if stress is None:
        return 0.6, ["liquidity_index_missing"]

    regime = liquidity_snap.regime
    if regime in ("STRESSED", "CRITICAL"):
        warnings.append(f"liquidity_regime_{regime.lower()}")

    struct = liquidity_snap.structural_fragility or 0.0
    if struct > 0.7:
        warnings.append("structural_fragility_elevated")

    # Confidence = 1 - stress, with structural fragility providing a further discount
    score = (1.0 - stress) * (1.0 - 0.2 * struct)
    return round(min(1.0, max(0.0, score)), 4), warnings


def _score_positioning(
    fragility_estimates: list[float],
) -> tuple[float, list[str]]:
    """
    Positioning confidence from PositioningSnapshots.
    High aggregate fragility reduces confidence.
    """
    warnings: list[str] = []

    if not fragility_estimates:
        return 0.7, ["positioning_unavailable"]

    avg_fragility = sum(fragility_estimates) / len(fragility_estimates)
    if avg_fragility > 0.7:
        warnings.append("high_positioning_fragility")

    score = 1.0 - avg_fragility
    return round(min(1.0, max(0.0, score)), 4), warnings


def _derive_mode(confidence: float) -> tuple[str, float]:
    """
    Map confidence scalar to a named mode and recommended size scalar.
    """
    mode_scalars = {
        "FULL":      1.00,
        "CAUTIOUS":  0.75,
        "REDUCED":   0.50,
        "DEFENSIVE": 0.25,
        "SUSPENDED": 0.00,
    }
    for thresh, mode in _MODE_BREAKS:
        if confidence >= thresh:
            return mode, mode_scalars[mode]
    return "SUSPENDED", 0.0


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class GovernanceEngine:
    """
    Computes the platform-wide governance_confidence scalar.

    Designed to be called once per pipeline run (or once per scheduling
    interval). Pulls from the provided subsystems; all are optional.
    """

    def __init__(
        self,
        drift_monitor    = None,   # DriftMonitor instance
        liquidity_engine = None,   # LiquidityEngine instance
        positioning_engine = None, # PositioningEngine instance
    ) -> None:
        self._drift_monitor      = drift_monitor
        self._liquidity_engine   = liquidity_engine
        self._positioning_engine = positioning_engine

    def set_drift_monitor(self, dm) -> None:
        self._drift_monitor = dm

    def set_liquidity_engine(self, le) -> None:
        self._liquidity_engine = le

    def set_positioning_engine(self, pe) -> None:
        self._positioning_engine = pe

    async def assess(
        self,
        market_state         = None,
        tracked_tickers:     Optional[list[str]] = None,
    ) -> GovernanceReport:
        """
        Compute the full governance report.

        Parameters
        ----------
        market_state     : MarketState (from market_state.get_market_state())
        tracked_tickers  : list of tickers to query for positioning fragility
        """
        all_warnings:    list[str] = []
        component_scores: dict     = {}

        # ── 1. Model health ──────────────────────────────────────────────────
        health_report = None
        gate_open     = True
        if self._drift_monitor is not None:
            try:
                health_report = self._drift_monitor.health_report()
                gate_open     = self._drift_monitor.gate_open()
            except Exception as exc:
                logger.warning("DriftMonitor query failed: %s", exc)
                all_warnings.append("drift_monitor_error")

        model_score, model_warns = _score_model_health(health_report, gate_open)
        component_scores["model_health"] = model_score
        all_warnings.extend(model_warns)

        # ── 2. Market regime ─────────────────────────────────────────────────
        regime_score, regime_warns = _score_market_regime(market_state)
        component_scores["market_regime"] = regime_score
        all_warnings.extend(regime_warns)

        # ── 3. Liquidity ─────────────────────────────────────────────────────
        liquidity_snap = None
        if self._liquidity_engine is not None:
            try:
                liquidity_snap = await self._liquidity_engine.get_snapshot()
            except Exception as exc:
                logger.warning("LiquidityEngine query failed: %s", exc)
                all_warnings.append("liquidity_engine_error")

        liq_score, liq_warns = _score_liquidity(liquidity_snap)
        component_scores["liquidity"] = liq_score
        all_warnings.extend(liq_warns)

        # ── 4. Positioning fragility ─────────────────────────────────────────
        fragilities: list[float] = []
        if self._positioning_engine is not None and tracked_tickers:
            try:
                snaps = await self._positioning_engine.get_snapshots(tracked_tickers)
                fragilities = [
                    s.fragility_estimate
                    for s in snaps.values()
                    if s.fragility_estimate is not None
                ]
            except Exception as exc:
                logger.warning("PositioningEngine query failed: %s", exc)
                all_warnings.append("positioning_engine_error")

        pos_score, pos_warns = _score_positioning(fragilities)
        component_scores["positioning"] = pos_score
        all_warnings.extend(pos_warns)

        # ── Composite confidence ─────────────────────────────────────────────
        confidence = (
            _W_MODEL     * model_score
          + _W_REGIME    * regime_score
          + _W_LIQUIDITY * liq_score
          + _W_POSITION  * pos_score
        )
        confidence = round(min(1.0, max(0.0, confidence)), 4)

        # ── Data source availability penalty ─────────────────────────────────
        try:
            from data_sources_registry import get_registry as _get_src_registry
            src_registry = _get_src_registry()
            src_penalty  = src_registry.unavailability_penalty()
            if src_penalty > 0:
                confidence = max(0.0, confidence - src_penalty)
                critical_down = src_registry.critical_sources_unavailable()
                all_warnings.append(f"data_sources_unavailable({critical_down})")
        except Exception:
            src_penalty = 0.0

        mode, size_scalar = _derive_mode(confidence)

        # ── #3 Uncertainty: std of component scores (disagreement) ───────────
        comp_values = list(component_scores.values())
        import numpy as np
        uncertainty = round(float(np.std(comp_values)), 4) if len(comp_values) >= 2 else 0.5

        # ── #3 Stability: rolling variance of recent confidence values ────────
        if not hasattr(self, "_confidence_history"):
            self._confidence_history = []
        self._confidence_history.append(confidence)
        self._confidence_history = self._confidence_history[-20:]
        if len(self._confidence_history) >= 3:
            recent_std = float(np.std(self._confidence_history[-10:]))
            stability  = round(max(0.0, 1.0 - recent_std / 0.20), 4)  # 20% std = fully unstable
        else:
            stability = 0.5   # neutral until we have history

        # Uncertainty discount: if components strongly disagree, reduce scalar
        if uncertainty > 0.30:
            size_scalar = round(max(0.0, size_scalar * (1.0 - (uncertainty - 0.30) / 0.40)), 4)
            all_warnings.append(f"high_uncertainty({uncertainty:.2f}) — size_scalar discounted")

        report = GovernanceReport(
            governance_confidence    = confidence,
            governance_uncertainty   = uncertainty,
            governance_stability     = stability,
            mode                     = mode,
            component_scores         = component_scores,
            warnings                 = list(dict.fromkeys(all_warnings)),
            recommended_size_scalar  = size_scalar,
        )

        logger.info(
            "Governance: confidence=%.3f uncertainty=%.3f stability=%.3f mode=%s scalar=%.2f",
            confidence, uncertainty, stability, mode, size_scalar,
        )
        return report


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_engine: Optional[GovernanceEngine] = None


def get_engine(
    drift_monitor    = None,
    liquidity_engine = None,
    positioning_engine = None,
) -> GovernanceEngine:
    global _engine
    if _engine is None:
        _engine = GovernanceEngine(
            drift_monitor      = drift_monitor,
            liquidity_engine   = liquidity_engine,
            positioning_engine = positioning_engine,
        )
    return _engine
