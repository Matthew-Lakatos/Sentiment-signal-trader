"""
contradiction_engine.py — §9 Contradiction & Divergence Engine.

Extracted from contradiction_detector.py, which mixed §6 (Reflexivity)
and §9 (Contradiction). This module handles §9 only: detecting structural
instability between information sources and price action.

Four contradiction types
------------------------
1. ANALYST_DISAGREEMENT
   Multiple sources covering the same event reach opposite sentiment conclusions.
   High std of sentiment scores = informational contradiction.

2. PRICE_NARRATIVE_MISMATCH
   Price already moved significantly before the narrative broke.
   The event is informational noise — the market knew first.

3. BREADTH_DIVERGENCE
   Sector peers are not confirming the entity-level move.
   Isolated move = idiosyncratic risk, not broad signal.

4. OPTIONS_EQUITY_DIVERGENCE
   Options market and equity market disagree on direction.
   Put/call skew contradicts the price move.

Outputs (ContradictionScore)
----------------------------
  contradiction_score    ∈ [0, 1]
  dominant_type          str
  signal_adjustment      float [0.2, 1.3]
  is_contradicting       bool

Relationship to reflexivity_engine
------------------------------------
  reflexivity_engine → "Is this narrative self-reinforcing?"
  contradiction_engine → "Are the sources/markets contradicting this signal?"

These are orthogonal questions with different governance implications.
"""
from __future__ import annotations

import asyncio
import logging
import math
from dataclasses import dataclass, field
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output
# ---------------------------------------------------------------------------

@dataclass
class ContradictionScore:
    contradiction_score:     float = 0.0    # [0, 1]
    dominant_type:           str   = "NONE"
    analyst_disagreement:    float = 0.0    # [0, 1]
    price_mismatch:          float = 0.0    # [0, 1]
    breadth_divergence:      float = 0.0    # [0, 1]
    options_divergence:      float = 0.0    # [0, 1]
    is_contradicting:        bool  = False
    signal_adjustment:       float = 1.0
    notes:                   list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Sub-detectors
# ---------------------------------------------------------------------------

def _analyst_disagreement(sentiment_scores: list[float]) -> float:
    """
    High cross-source sentiment std = informational contradiction.
    Returns [0, 1]; 1 = extreme disagreement.
    """
    if len(sentiment_scores) < 2:
        return 0.0
    import numpy as np
    std = float(np.std(sentiment_scores))
    # Normalise: std of 0.5 (extreme disagreement) → score 1.0
    return min(1.0, std / 0.5)


def _price_narrative_mismatch(
    price_return_pre:  Optional[float],   # return in 4h before article
    price_return_post: Optional[float],   # return in 2h after article
    sentiment:         float,             # article sentiment [-1, 1]
) -> float:
    """
    If price already moved significantly in the narrative's direction,
    the signal is stale. If it moved in the opposite direction, even more so.
    Returns [0, 1]; 1 = strong mismatch.
    """
    if price_return_pre is None:
        return 0.0

    sentiment_direction = 1.0 if sentiment > 0.1 else (-1.0 if sentiment < -0.1 else 0.0)
    if sentiment_direction == 0:
        return 0.0

    # Pre-move in same direction = news already priced
    same_direction_pre = math.copysign(1.0, price_return_pre) == sentiment_direction
    magnitude = abs(price_return_pre)

    if same_direction_pre and magnitude > 0.01:   # 1%+ pre-move
        return min(1.0, magnitude / 0.03)   # 3% pre-move = full mismatch
    if not same_direction_pre and magnitude > 0.005:   # opposite direction
        return min(1.0, 0.3 + magnitude / 0.02)

    return 0.0


def _breadth_divergence(
    entity_return:   Optional[float],
    peer_returns:    Optional[list[float]],   # same-sector peers
) -> float:
    """
    If entity is moving but sector peers are not confirming, the move
    may be idiosyncratic noise rather than a real signal.
    Returns [0, 1].
    """
    if entity_return is None or not peer_returns or len(peer_returns) < 3:
        return 0.0

    import numpy as np
    avg_peer = float(np.mean(peer_returns))
    entity_dir = math.copysign(1.0, entity_return) if abs(entity_return) > 0.002 else 0.0
    peer_dir   = math.copysign(1.0, avg_peer) if abs(avg_peer) > 0.002 else 0.0

    if entity_dir == 0 or peer_dir == 0:
        return 0.0

    if entity_dir != peer_dir:
        # Entity moving against peers = strong divergence
        return min(1.0, abs(entity_return - avg_peer) / 0.03)

    return 0.0


def _options_equity_divergence(
    put_call_ratio: Optional[float],
    price_return:   Optional[float],
) -> float:
    """
    Options market disagreement with equity move.
    Rising price + high put buying = bearish options market contradicts equity.
    Returns [0, 1].
    """
    if put_call_ratio is None or price_return is None:
        return 0.0

    equity_dir = math.copysign(1.0, price_return) if abs(price_return) > 0.003 else 0.0
    if equity_dir == 0:
        return 0.0

    # High P/C (> 1.3) + rising equity = contradiction
    if equity_dir > 0 and put_call_ratio > 1.3:
        return min(1.0, (put_call_ratio - 1.0) / 1.5)
    # Low P/C (< 0.7) + falling equity = contradiction
    if equity_dir < 0 and put_call_ratio < 0.7:
        return min(1.0, (1.0 - put_call_ratio) / 0.7)

    return 0.0


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class ContradictionEngine:
    """
    Detects structural contradictions between information sources,
    price action, and market positioning for a given event.
    """

    def analyse(
        self,
        sentiment_scores:  list[float],
        event_sentiment:   float,
        price_return_pre:  Optional[float] = None,
        price_return_post: Optional[float] = None,
        entity_return:     Optional[float] = None,
        peer_returns:      Optional[list[float]] = None,
        put_call_ratio:    Optional[float] = None,
    ) -> ContradictionScore:
        notes: list[str] = []

        disagree   = _analyst_disagreement(sentiment_scores)
        mismatch   = _price_narrative_mismatch(price_return_pre, price_return_post, event_sentiment)
        breadth    = _breadth_divergence(entity_return, peer_returns)
        options    = _options_equity_divergence(put_call_ratio, entity_return)

        if disagree > 0.3:
            notes.append(f"analyst_disagreement={disagree:.2f}")
        if mismatch > 0.3:
            notes.append(f"price_mismatch={mismatch:.2f}")
        if breadth > 0.3:
            notes.append(f"breadth_divergence={breadth:.2f}")
        if options > 0.3:
            notes.append(f"options_divergence={options:.2f}")

        # Composite: weighted average; price mismatch is most damaging
        contradiction_score = round(
            0.25 * disagree
          + 0.35 * mismatch
          + 0.25 * breadth
          + 0.15 * options,
            4,
        )

        # Dominant type
        scores_map = {
            "ANALYST_DISAGREEMENT":    disagree,
            "PRICE_NARRATIVE_MISMATCH": mismatch,
            "BREADTH_DIVERGENCE":      breadth,
            "OPTIONS_EQUITY_DIVERGENCE": options,
        }
        dominant = max(scores_map, key=lambda k: scores_map[k])
        if scores_map[dominant] < 0.15:
            dominant = "NONE"

        # Signal adjustment: contradiction reduces conviction
        # Severe mismatch (score > 0.6) → discount signal by up to 60%
        adjustment = max(0.2, 1.0 - contradiction_score * 0.8)
        is_contradicting = contradiction_score > 0.35

        return ContradictionScore(
            contradiction_score  = contradiction_score,
            dominant_type        = dominant,
            analyst_disagreement = round(disagree, 4),
            price_mismatch       = round(mismatch, 4),
            breadth_divergence   = round(breadth,  4),
            options_divergence   = round(options,  4),
            is_contradicting     = is_contradicting,
            signal_adjustment    = round(adjustment, 4),
            notes                = notes,
        )
