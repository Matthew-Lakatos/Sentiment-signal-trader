"""
robots_cache.py — per-domain robots.txt compliance and crawl-delay cache.
Parsed robots files are cached in-process (LRU, max 512 domains).
"""
from __future__ import annotations
import logging
import urllib.robotparser
from functools import lru_cache
from urllib.parse import urlparse

from config import settings

logger = logging.getLogger(__name__)

_BOT_NAME = "*"


@lru_cache(maxsize=512)
def _parser(domain: str) -> urllib.robotparser.RobotFileParser:
    rp = urllib.robotparser.RobotFileParser()
    rp.set_url(f"https://{domain}/robots.txt")
    try:
        rp.read()
    except Exception as exc:
        logger.debug("robots.txt fetch failed for %s: %s", domain, exc)
    return rp


def is_allowed(url: str) -> bool:
    """Return True if fetching *url* is permitted by robots.txt."""
    try:
        domain = urlparse(url).netloc
        return _parser(domain).can_fetch(_BOT_NAME, url)
    except Exception:
        return True   # fail-open: if we can't check, allow


def crawl_delay(url: str) -> float:
    """Return the robots.txt Crawl-delay for *url*'s domain, or the configured default."""
    try:
        domain = urlparse(url).netloc
        delay = _parser(domain).crawl_delay(_BOT_NAME)
        return float(delay) if delay is not None else settings.robots_default_delay
    except Exception:
        return settings.robots_default_delay
