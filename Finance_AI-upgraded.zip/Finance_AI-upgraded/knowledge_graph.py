"""
knowledge_graph.py — persisted entity-topic graph in PostgreSQL.
Replaces the in-memory networkx graph (which was lost on every restart).
Falls back to an in-process cache during the run for dedup performance.

v2 additions
------------
  • sentiment propagation  — weighted sentiment flows along KG edges
  • second-order inference — entity A → topic X → entity B chains
  • narrative clustering   — group entities by shared topic weight
"""
from __future__ import annotations
import logging
from typing import Optional

logger = logging.getLogger(__name__)

_session_edges: set[tuple[str, str]] = set()
# NEW: session-level sentiment accumulator { (entity, topic): [sentiment_score, …] }
_session_sentiment: dict[tuple[str, str], list[float]] = {}

_pool = None


async def init_knowledge_graph(pool) -> None:
    """Call once at startup to wire in the pool and create tables if needed."""
    global _pool
    _pool = pool
    await pool.execute("""
        CREATE TABLE IF NOT EXISTS kg_edges (
            entity    TEXT NOT NULL,
            topic     TEXT NOT NULL,
            relation  TEXT NOT NULL DEFAULT 'discusses',
            weight    INT  NOT NULL DEFAULT 1,
            avg_sentiment REAL NOT NULL DEFAULT 0.0,
            PRIMARY KEY (entity, topic, relation)
        )
    """)
    await pool.execute("CREATE INDEX IF NOT EXISTS kg_entity_idx ON kg_edges (entity)")
    await pool.execute("CREATE INDEX IF NOT EXISTS kg_topic_idx  ON kg_edges (topic)")
    # NEW: index for sentiment propagation queries
    await pool.execute(
        "CREATE INDEX IF NOT EXISTS kg_sentiment_idx ON kg_edges (avg_sentiment DESC)"
    )


def link_entity_topic(
    entity:    str,
    topic:     str,
    relation:  str   = "discusses",
    sentiment: float = 0.0,
) -> None:
    """
    Record an entity→topic edge.  Writes are batched per session and
    flushed asynchronously via flush_knowledge_graph().

    Parameters
    ----------
    sentiment   signed sentiment score [-1, 1] for this co-occurrence
    """
    key = (entity.strip(), topic.strip())
    _session_edges.add(key)
    # Accumulate sentiment scores for weighted average on flush
    _session_sentiment.setdefault(key, []).append(float(sentiment))


async def flush_knowledge_graph() -> None:
    """Upsert all session edges to PostgreSQL. Call at end of each pipeline run."""
    if not _pool or not _session_edges:
        return
    edges = list(_session_edges)
    _session_edges.clear()

    # Build rows with averaged sentiment
    rows = []
    for e, t in edges:
        scores = _session_sentiment.pop((e, t), [0.0])
        avg_s  = sum(scores) / len(scores)
        rows.append((e, t, round(avg_s, 4)))
    _session_sentiment.clear()

    try:
        await _pool.executemany("""
            INSERT INTO kg_edges (entity, topic, weight, avg_sentiment)
            VALUES ($1, $2, 1, $3)
            ON CONFLICT (entity, topic, relation)
            DO UPDATE SET
                weight        = kg_edges.weight + 1,
                avg_sentiment = (kg_edges.avg_sentiment * kg_edges.weight + EXCLUDED.avg_sentiment)
                                / (kg_edges.weight + 1)
        """, rows)
        logger.debug("Flushed %d knowledge graph edges", len(rows))
    except Exception as exc:
        logger.warning("Knowledge graph flush failed: %s", exc)


async def get_related_topics(entity: str, limit: int = 10) -> list[dict]:
    if not _pool:
        return []
    rows = await _pool.fetch("""
        SELECT topic, weight, avg_sentiment FROM kg_edges
        WHERE entity = $1
        ORDER BY weight DESC LIMIT $2
    """, entity, limit)
    return [{"topic": r["topic"], "weight": r["weight"],
             "avg_sentiment": r["avg_sentiment"]} for r in rows]


async def get_top_entities(topic: str, limit: int = 10) -> list[dict]:
    if not _pool:
        return []
    rows = await _pool.fetch("""
        SELECT entity, weight, avg_sentiment FROM kg_edges
        WHERE topic = $1
        ORDER BY weight DESC LIMIT $2
    """, topic, limit)
    return [{"entity": r["entity"], "weight": r["weight"],
             "avg_sentiment": r["avg_sentiment"]} for r in rows]


# ---------------------------------------------------------------------------
# NEW: Sentiment propagation
# ---------------------------------------------------------------------------

async def propagate_sentiment(
    entity: str,
    hops:   int = 2,
    limit:  int = 20,
) -> list[dict]:
    """
    Walk the KG outward from *entity* up to *hops* edges and return a
    weighted-average sentiment for each reachable entity.

    Algorithm
    ---------
    Hop 1: entity → topics (direct edges, weighted by kg_edges.weight)
    Hop 2: topics → other entities (via shared topics)

    Each hop applies a 0.5 decay so direct links dominate.

    Returns a list of dicts: [{entity, topic_bridge, propagated_sentiment, hops}]
    """
    if not _pool:
        return []

    results: dict[str, dict] = {}

    # Hop 1: topics this entity discusses
    h1 = await _pool.fetch("""
        SELECT topic, weight, avg_sentiment FROM kg_edges
        WHERE entity = $1 ORDER BY weight DESC LIMIT $2
    """, entity, limit)

    for row in h1:
        topic     = row["topic"]
        s1        = float(row["avg_sentiment"])
        w1        = int(row["weight"])

        if hops < 2:
            results[f"__topic__{topic}"] = {
                "entity": f"[topic] {topic}", "topic_bridge": topic,
                "propagated_sentiment": round(s1, 4), "hops": 1,
            }
            continue

        # Hop 2: entities that discuss the same topic
        h2 = await _pool.fetch("""
            SELECT entity, weight, avg_sentiment FROM kg_edges
            WHERE topic = $1 AND entity != $2
            ORDER BY weight DESC LIMIT $3
        """, topic, entity, limit)

        for row2 in h2:
            peer = row2["entity"]
            s2   = float(row2["avg_sentiment"])
            w2   = int(row2["weight"])
            # Weighted blend with 0.5 hop-decay
            propagated = (s1 * w1 + s2 * w2 * 0.5) / (w1 + w2 * 0.5 + 1e-9)
            if peer not in results or abs(propagated) > abs(results[peer]["propagated_sentiment"]):
                results[peer] = {
                    "entity":                peer,
                    "topic_bridge":          topic,
                    "propagated_sentiment":  round(propagated, 4),
                    "hops":                  2,
                }

    return sorted(results.values(), key=lambda x: abs(x["propagated_sentiment"]), reverse=True)


# ---------------------------------------------------------------------------
# NEW: Narrative clustering via shared topics
# ---------------------------------------------------------------------------

async def cluster_narratives(min_weight: int = 3, limit: int = 50) -> list[dict]:
    """
    Group entities into narrative clusters by their heaviest shared topic.
    Returns clusters sorted by total edge weight (proxy for narrative volume).
    """
    if not _pool:
        return []

    rows = await _pool.fetch("""
        SELECT topic, ARRAY_AGG(entity ORDER BY weight DESC) AS entities,
               SUM(weight) AS total_weight,
               AVG(avg_sentiment) AS cluster_sentiment
        FROM   kg_edges
        WHERE  weight >= $1
        GROUP  BY topic
        HAVING COUNT(*) >= 2
        ORDER  BY total_weight DESC
        LIMIT  $2
    """, min_weight, limit)

    return [
        {
            "topic":             r["topic"],
            "entities":          list(r["entities"]),
            "total_weight":      int(r["total_weight"]),
            "cluster_sentiment": round(float(r["cluster_sentiment"]), 4),
        }
        for r in rows
    ]
