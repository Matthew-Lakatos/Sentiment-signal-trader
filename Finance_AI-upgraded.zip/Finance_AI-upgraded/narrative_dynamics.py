"""
narrative_dynamics.py — §3 Narrative Dynamics Engine.

Models how information propagates through markets by tracking:

1. Crowd attention velocity
   Rate of change of article volume per canonical narrative cluster.
   Rising velocity → narrative gaining momentum (amplification signal).
   Falling velocity after a spike → narrative saturation.

2. Headline propagation rate
   Speed at which a story spreads across distinct source domains.
   Measured as new_domains_per_hour since first appearance.
   Fast propagation → story is being picked up broadly (high impact).

3. Narrative saturation detection
   A narrative is saturated when:
   - novelty score trend is declining (new articles are increasingly
     redundant), AND
   - article volume has plateaued or is declining.
   Saturated narratives should be down-weighted (alpha already priced).

4. Information freshness scoring
   Composite freshness score for an article given:
   - time since first appearance of the narrative
   - current novelty score
   - propagation velocity

5. Narrative momentum
   Exponentially-weighted moving average of signed sentiment over recent
   articles in the same cluster. Strong momentum = directional signal
   reinforcement.

6. Narrative decay modelling
   Effective "half-life" estimation per event type.
   Earnings: ~4h  |  Macro: ~12h  |  Regulation: ~48h  |  Rumor: ~2h

All DB queries run against the scraped_events table populated by the
pipeline. The module works with pool=None (returns fallback values) so
tests and offline environments work without a database.

Usage
-----
    from narrative_dynamics import NarrativeDynamics

    nd = NarrativeDynamics(pool)
    metrics = await nd.compute(
        event_id         = "e001",
        canonical_id     = "cluster-7",
        source_domain    = "reuters.com",
        sentiment_score  = 0.65,
        novelty_score    = 0.80,
        event_type       = "earnings",
        scraped_at       = datetime.now(timezone.utc),
    )

    print(metrics.attention_velocity)
    print(metrics.propagation_rate)
    print(metrics.is_saturated)
    print(metrics.freshness_score)
    print(metrics.narrative_momentum)
    print(metrics.effective_half_life_hours)
"""
from __future__ import annotations

import asyncio
import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Event-type half-life table (hours)
# ---------------------------------------------------------------------------

_HALF_LIVES: dict[str, float] = {
    "earnings":       4.0,
    "guidance":       4.0,
    "rumor":          2.0,
    "macro":         12.0,
    "contract":       8.0,
    "product_launch": 6.0,
    "regulation":    48.0,
    "geopolitical":  24.0,
    "analysis":      18.0,
    "unknown":        8.0,
}

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------

_SATURATION_MIN_ARTICLES    = 5    # need at least this many to call saturation
_SATURATION_NOVELTY_FLOOR   = 0.30 # mean novelty below this → saturating
_SATURATION_VELOCITY_DROP   = 0.50 # velocity fallen to <50% of peak → plateaued
_FAST_PROPAGATION_THRESHOLD = 2.0  # domains/hour → fast spread
_HIGH_VELOCITY_THRESHOLD    = 3.0  # articles/hour → high attention
_EWMA_DECAY                 = 0.7  # weight for most-recent article in momentum EMA


# ---------------------------------------------------------------------------
# NarrativeMetrics dataclass
# ---------------------------------------------------------------------------

@dataclass
class NarrativeMetrics:
    """All narrative-dynamics indicators for a single article."""

    # Attention
    attention_velocity:     float = 0.0    # articles/hour in this cluster (recent window)
    peak_attention:         float = 0.0    # maximum articles/hour seen so far
    velocity_vs_peak:       float = 1.0    # attention_velocity / peak_attention [0,1]

    # Propagation
    propagation_rate:       float = 0.0    # distinct source domains/hour since first seen
    distinct_domains:       int   = 1      # total distinct sources so far
    first_seen_at:          Optional[datetime] = None

    # Saturation
    is_saturated:           bool  = False
    saturation_reason:      str   = ""
    mean_novelty_trend:     float = 0.5    # mean novelty of recent articles

    # Freshness
    freshness_score:        float = 1.0    # [0,1]; 1 = fully fresh

    # Momentum
    narrative_momentum:     float = 0.0    # signed [-1,1]; positive = bullish trend
    momentum_n_articles:    int   = 0

    # Decay
    effective_half_life_hours: float = 8.0
    hours_since_first:      float   = 0.0
    decay_weight:           float   = 1.0  # exp decay: 0.5^(hours/half_life)

    # Metadata
    cluster_id:             Optional[str] = None
    n_articles_in_cluster:  int           = 0


# ---------------------------------------------------------------------------
# NarrativeDynamics engine
# ---------------------------------------------------------------------------

class NarrativeDynamics:
    """
    Computes narrative dynamics metrics for each incoming article.

    Designed to be called once per article in the pipeline, after NLP
    and before signal scoring.  All heavy DB queries are async and cached
    for the duration of the pipeline run.

    Parameters
    ----------
    pool        asyncpg pool (may be None — all metrics return neutral fallbacks)
    window_hours  lookback window for attention/propagation queries (default 6)
    """

    def __init__(
        self,
        pool,
        window_hours: float = 6.0,
    ):
        self._pool         = pool
        self._window_hours = window_hours
        # In-process cache: cluster_id → (expires_at, CachedClusterStats)
        self._cluster_cache: dict[str, tuple[float, "_ClusterStats"]] = {}
        self._cache_ttl = 120.0   # seconds; re-query every 2 minutes

    async def compute(
        self,
        event_id:        str,
        canonical_id:    Optional[str],
        source_domain:   str,
        sentiment_score: float,
        novelty_score:   float,
        event_type:      str,
        scraped_at:      datetime,
    ) -> NarrativeMetrics:
        """
        Compute narrative dynamics metrics for a single incoming article.

        Parameters
        ----------
        event_id        UUID of this article
        canonical_id    Cluster/canonical event ID (may be None for first article)
        source_domain   e.g. "reuters.com"
        sentiment_score Signed sentiment [-1, 1]
        novelty_score   [0, 1] from novelty.py
        event_type      From event_classifier.py
        scraped_at      Timestamp of this article
        """
        half_life = _HALF_LIVES.get(event_type.lower(), 8.0)

        # No canonical ID → completely new narrative, return fresh defaults
        if not canonical_id:
            return NarrativeMetrics(
                freshness_score          = 1.0,
                narrative_momentum       = sentiment_score,
                effective_half_life_hours= half_life,
                decay_weight             = 1.0,
                hours_since_first        = 0.0,
                cluster_id               = None,
                n_articles_in_cluster    = 1,
            )

        # Fetch cluster stats (cached)
        stats = await self._get_cluster_stats(canonical_id, scraped_at)

        hours_since = stats.hours_since_first
        decay_weight = 0.5 ** (hours_since / half_life) if hours_since > 0 else 1.0

        # Attention velocity (articles/hour in window)
        velocity = stats.articles_in_window / max(self._window_hours, 1.0)
        peak     = max(stats.peak_articles_per_hour, velocity)

        # Propagation rate (domains/hour)
        prop_rate = (
            stats.distinct_domains / max(hours_since, 0.5)
            if hours_since > 0 else 0.0
        )

        # Saturation
        is_sat, sat_reason = self._check_saturation(stats, velocity, peak)

        # Freshness: novelty × decay × (1 - saturation_penalty)
        sat_penalty    = 0.4 if is_sat else 0.0
        freshness      = max(0.0, novelty_score * decay_weight * (1 - sat_penalty))
        freshness      = round(min(1.0, freshness), 4)

        # Narrative momentum: EWMA of signed sentiment
        momentum, n_mom = self._compute_momentum(stats, sentiment_score)

        vel_vs_peak = round(velocity / max(peak, 1e-6), 4)

        return NarrativeMetrics(
            attention_velocity        = round(velocity, 4),
            peak_attention            = round(peak, 4),
            velocity_vs_peak          = vel_vs_peak,
            propagation_rate          = round(prop_rate, 4),
            distinct_domains          = stats.distinct_domains,
            first_seen_at             = stats.first_seen_at,
            is_saturated              = is_sat,
            saturation_reason         = sat_reason,
            mean_novelty_trend        = round(stats.mean_novelty, 4),
            freshness_score           = freshness,
            narrative_momentum        = round(momentum, 4),
            momentum_n_articles       = n_mom,
            effective_half_life_hours = half_life,
            hours_since_first         = round(hours_since, 2),
            decay_weight              = round(decay_weight, 4),
            cluster_id                = canonical_id,
            n_articles_in_cluster     = stats.total_articles,
        )

    # ── Cluster stats ───────────────────────────────────────────────────────

    async def _get_cluster_stats(
        self, canonical_id: str, now: datetime
    ) -> "_ClusterStats":
        import time as _time
        mono = _time.monotonic()
        cached = self._cluster_cache.get(canonical_id)
        if cached and mono < cached[0]:
            return cached[1]

        stats = await self._query_cluster(canonical_id, now)
        self._cluster_cache[canonical_id] = (mono + self._cache_ttl, stats)
        return stats

    async def _query_cluster(
        self, canonical_id: str, now: datetime
    ) -> "_ClusterStats":
        if self._pool is None:
            return _ClusterStats()

        window_start = now - timedelta(hours=self._window_hours)

        try:
            row = await self._pool.fetchrow("""
                SELECT
                    COUNT(*)                                    AS total_articles,
                    COUNT(*) FILTER (
                        WHERE scraped_at >= $2
                    )                                           AS articles_in_window,
                    COUNT(DISTINCT source_domain)               AS distinct_domains,
                    MIN(scraped_at)                             AS first_seen_at,
                    AVG(novelty_score)                          AS mean_novelty,
                    MAX(
                        EXTRACT(EPOCH FROM scraped_at - MIN(scraped_at) OVER ())
                        / 3600.0
                    )                                           AS span_hours
                FROM scraped_events
                WHERE canonical_event_id::text = $1
                  AND NOT is_duplicate
            """, canonical_id, window_start)

            if not row or row["total_articles"] == 0:
                return _ClusterStats()

            # Fetch recent sentiment values for momentum
            sent_rows = await self._pool.fetch("""
                SELECT
                    CASE sentiment_label
                        WHEN 'POSITIVE' THEN  sentiment_score
                        WHEN 'NEGATIVE' THEN -sentiment_score
                        ELSE 0.0
                    END AS signed_sent
                FROM scraped_events
                WHERE canonical_event_id::text = $1
                  AND NOT is_duplicate
                ORDER BY scraped_at DESC
                LIMIT 10
            """, canonical_id)

            first = row["first_seen_at"]
            hours_since = (
                (now.replace(tzinfo=None) - first.replace(tzinfo=None)).total_seconds() / 3600.0
                if first else 0.0
            )

            # Peak attention: estimate from span
            span = float(row["span_hours"] or 1.0)
            total = int(row["total_articles"])
            peak_est = total / max(span, self._window_hours)

            return _ClusterStats(
                total_articles          = total,
                articles_in_window      = int(row["articles_in_window"] or 0),
                distinct_domains        = int(row["distinct_domains"] or 1),
                first_seen_at           = first,
                hours_since_first       = round(hours_since, 2),
                mean_novelty            = float(row["mean_novelty"] or 0.5),
                peak_articles_per_hour  = round(peak_est, 4),
                recent_sentiments       = [float(r["signed_sent"]) for r in sent_rows],
            )

        except Exception as exc:
            logger.debug("Cluster stats query failed: %s", exc)
            return _ClusterStats()

    # ── Saturation check ────────────────────────────────────────────────────

    @staticmethod
    def _check_saturation(
        stats: "_ClusterStats",
        velocity: float,
        peak: float,
    ) -> tuple[bool, str]:
        if stats.total_articles < _SATURATION_MIN_ARTICLES:
            return False, ""

        low_novelty = stats.mean_novelty < _SATURATION_NOVELTY_FLOOR
        vel_dropped = (velocity / max(peak, 1e-6)) < _SATURATION_VELOCITY_DROP

        if low_novelty and vel_dropped:
            return True, f"low_novelty({stats.mean_novelty:.2f}) + velocity_drop({velocity/max(peak,1e-6):.2f})"
        if low_novelty:
            return True, f"low_novelty({stats.mean_novelty:.2f})"
        if vel_dropped and stats.total_articles >= 10:
            return True, f"velocity_drop_with_high_coverage(n={stats.total_articles})"
        return False, ""

    # ── Narrative momentum ──────────────────────────────────────────────────

    @staticmethod
    def _compute_momentum(
        stats: "_ClusterStats",
        current_sentiment: float,
    ) -> tuple[float, int]:
        sents = [current_sentiment] + stats.recent_sentiments
        if not sents:
            return 0.0, 0

        # EWMA: most recent gets weight _EWMA_DECAY, rest get 1-_EWMA_DECAY distributed
        momentum = sents[0]
        for s in sents[1:]:
            momentum = _EWMA_DECAY * momentum + (1 - _EWMA_DECAY) * s

        return max(-1.0, min(1.0, momentum)), len(sents)


@dataclass
class _ClusterStats:
    """Internal query result for a canonical event cluster."""
    total_articles:         int            = 0
    articles_in_window:     int            = 0
    distinct_domains:       int            = 1
    first_seen_at:          Optional[datetime] = None
    hours_since_first:      float          = 0.0
    mean_novelty:           float          = 0.5
    peak_articles_per_hour: float          = 0.0
    recent_sentiments:      list[float]    = field(default_factory=list)


# ---------------------------------------------------------------------------
# Standalone helpers (used by API endpoints and tests)
# ---------------------------------------------------------------------------

def decay_weight(hours_since_first: float, event_type: str = "unknown") -> float:
    """Return the information decay weight for a given age and event type."""
    half_life = _HALF_LIVES.get(event_type.lower(), 8.0)
    return round(0.5 ** (max(0.0, hours_since_first) / half_life), 6)


def effective_half_life(event_type: str) -> float:
    """Return the half-life in hours for a given event type."""
    return _HALF_LIVES.get(event_type.lower(), 8.0)


def freshness_from_metrics(
    novelty_score: float,
    hours_since_first: float,
    event_type: str,
    is_saturated: bool = False,
) -> float:
    """Compute freshness score outside of a DB context."""
    dw  = decay_weight(hours_since_first, event_type)
    sat = 0.4 if is_saturated else 0.0
    return round(max(0.0, min(1.0, novelty_score * dw * (1 - sat))), 4)
