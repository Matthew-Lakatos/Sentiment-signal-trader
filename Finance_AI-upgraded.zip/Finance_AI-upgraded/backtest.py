"""
backtest.py — fully integrated backtest pipeline.

Stages
------
  1. Fetch events from DB for a time window
  2. Re-score signals (or use stored scores)
  3. Join to price data with STRICT execution realism (delay + slippage)
  4. Apply signal filter to select only actionable events
  5. Run portfolio layer for position sizing + overlap resolution
  6. Compare against baselines via benchmark
  7. Calibrate weights from realised returns
  8. Run robustness suite (walk-forward + bootstrap)
  9. Output full JSON report

Usage
-----
    python backtest.py --days 90 --ticker AAPL --output report.json
    python backtest.py --start 2024-01-01 --end 2024-06-30 --ticker SPY
    python backtest.py --days 180 --ticker MSFT --calibrate --robustness
"""
from __future__ import annotations
import argparse
import asyncio
import json
import logging
import math
from datetime import datetime, timezone, timedelta
from typing import Optional

from database import get_pool
from materiality import score_materiality
from alert_engine import evaluate_alert_rules
from signal_ranker import compute_signal
from finance import get_price_history
from execution import ExecutionEngine
from signal_filter import SignalFilter, FilterConfig
from portfolio import PortfolioLayer, PortfolioConfig
from benchmark import run_benchmark, print_benchmark
from calibration import calibrate
from robustness import run_robustness_suite
from regime import classify_regimes, run_regime_split
from horizon import optimise_horizon
from capacity import CapacityAnalyser
from feature_stability import analyse_stability
from regime_model import fit_regime_models
from second_order_validation import validate_second_order
from overfitting_guard import DataSplitter, OverfittingGuard

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Price join  (execution-realistic — uses next-bar open after delay)
# ---------------------------------------------------------------------------

def _join_prices(
    events_out: list[dict],
    price_df,
    engine: ExecutionEngine,
) -> list[dict]:
    """
    Attach fwd_ret_1d/3d/5d to events using the ExecutionEngine's realistic fill
    (next-open after delay, with slippage, leakage detection).

    Events that cannot be filled or that trigger a leakage flag are marked.
    """
    import pandas as pd

    for ev in events_out:
        ts_raw = ev.get("scraped_at")
        if ts_raw is None:
            continue
        if isinstance(ts_raw, str):
            try:
                ts = datetime.fromisoformat(ts_raw)
            except Exception:
                continue
        else:
            ts = ts_raw

        label = (ev.get("sentiment_label") or "NEUTRAL").upper()
        direction = "LONG" if label == "POSITIVE" else "SHORT"

        ev["leakage_flag"] = False

        for horizon, key in [(1, "fwd_ret_1d"), (3, "fwd_ret_3d"), (5, "fwd_ret_5d")]:
            trade = engine.simulate_fill(ts, price_df, direction=direction,
                                         horizon=horizon)
            if trade is None:
                ev[key] = None
                continue

            # Leakage check: flag the event but keep the data for diagnostics
            if trade.leakage_flag:
                ev["leakage_flag"] = True

            ev[key] = trade.return_pct

    return events_out


# ---------------------------------------------------------------------------
# Core backtest
# ---------------------------------------------------------------------------

async def run_backtest(
    start:           datetime,
    end:             datetime,
    limit:           int = 50_000,
    ticker:          Optional[str] = None,
    delay_minutes:   float = 15.0,
    slippage_bps:    float = 10.0,
    filter_cfg:      Optional[FilterConfig] = None,
    portfolio_cfg:   Optional[PortfolioConfig] = None,
    run_calibration: bool = False,
    run_robustness:  bool = False,
    run_regime:      bool = False,
    run_horizon:     bool = False,
    run_capacity:    bool = False,
    run_stability:   bool = False,
    run_regime_model: bool = False,
    run_overfitting_guard: bool = False,
    with_interactions: bool = False,
    avg_daily_volume: float = 1_000_000,
    avg_price:        float = 100.0,
    signal_alpha_bps: float = 30.0,
    experiment_id:    str   = "default",
) -> dict:
    pool   = await get_pool()
    rows   = await pool.fetch("""
        SELECT
            event_id, scraped_at, url, source_domain,
            sentiment_label, sentiment_score,
            keywords, topics, summary,
            credibility_score, propaganda_score,
            materiality_tier, materiality_score,
            event_type, event_confidence,
            novelty_score, novelty_label,
            signal_score, signal_direction, signal_tier
        FROM   scraped_events
        WHERE  scraped_at BETWEEN $1 AND $2
          AND  NOT is_duplicate
        ORDER  BY scraped_at
        LIMIT  $3
    """, start, end, limit)

    # ---- Price data -------------------------------------------------------
    price_df = None
    if ticker:
        days = max(20, (end - start).days + 20)
        price_df = get_price_history(ticker, days=days)
        if price_df is not None:
            import pandas as pd
            price_df.index = pd.to_datetime(price_df.index).normalize()

    # ---- Execution engine ------------------------------------------------
    engine = ExecutionEngine(delay_minutes=delay_minutes, slippage_bps=slippage_bps)

    # ---- Per-event scoring -----------------------------------------------
    tier_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    alert_count = 0
    events_out  = []

    for row in rows:
        mat = score_materiality(
            text            = row["summary"] or "",
            keywords        = list(row["keywords"] or []),
            credibility     = float(row["credibility_score"] or 0.5),
            sentiment_score = float(row["sentiment_score"]   or 0.0),
            event_type      = row.get("event_type") or "unknown",
        )

        # Prefer stored signal score (already computed with full pipeline)
        stored = row.get("signal_score")
        if stored is not None:
            sig_score = float(stored)
            sig_dir   = row.get("signal_direction") or "NEUTRAL"
            sig_tier  = row.get("signal_tier") or "NOISE"
        else:
            sig = compute_signal(
                sentiment_label   = row["sentiment_label"] or "NEUTRAL",
                sentiment_score   = float(row["sentiment_score"] or 0.0),
                materiality_score = mat.score,
                novelty_score     = float(row.get("novelty_score") or 0.5),
                credibility_score = float(row["credibility_score"] or 0.5),
                materiality_tier  = mat.tier,
                event_type        = row.get("event_type") or "unknown",
                scraped_at        = row["scraped_at"],
            )
            sig_score = sig.score
            sig_dir   = sig.direction
            sig_tier  = sig.rank_tier

        alerts = evaluate_alert_rules({
            "propaganda_score": float(row["propaganda_score"] or 0.0),
            "source_domain":    row["source_domain"],
            "materiality_tier": mat.tier,
            "summary":          row["summary"] or "",
        })
        tier_counts[mat.tier] += 1
        if alerts:
            alert_count += 1

        ev_dict = {
            "event_id":         str(row["event_id"]),
            "scraped_at":       row["scraped_at"].isoformat(),
            "domain":           row["source_domain"],
            "sentiment_label":  row["sentiment_label"] or "NEUTRAL",
            "sentiment_score":  float(row["sentiment_score"] or 0.0),
            "event_type":       row.get("event_type") or "unknown",
            "event_confidence": float(row.get("event_confidence") or 0.0),
            "materiality_score": mat.score,
            "materiality_tier": mat.tier,
            "novelty_score":    float(row.get("novelty_score") or 0.5),
            "credibility_score": float(row["credibility_score"] or 0.5),
            "signal_score":     sig_score,
            "signal_direction": sig_dir,
            "signal_tier":      sig_tier,
            "alerts":           [a.alert_type for a in alerts],
            "fwd_ret_1d":       None,
            "fwd_ret_3d":       None,
            "fwd_ret_5d":       None,
            "leakage_flag":     False,
        }
        events_out.append(ev_dict)

    # ---- Price join (execution-realistic) --------------------------------
    if price_df is not None:
        events_out = _join_prices(events_out, price_df, engine)

    leakage_count = sum(1 for ev in events_out if ev.get("leakage_flag"))

    # ---- Signal filtering ------------------------------------------------
    filt        = SignalFilter(filter_cfg or FilterConfig())
    filtered    = filt.apply(events_out)
    filter_rpt  = filt.report(events_out, filtered)

    # ---- Portfolio layer -------------------------------------------------
    layer      = PortfolioLayer(portfolio_cfg or PortfolioConfig())
    layer.ingest(filtered)
    portfolio_rpt = layer.report()

    # ---- Baseline statistics (unfiltered, for full-sample stats) ---------
    stats: dict = {}
    price_joined = [ev for ev in events_out if ev.get("fwd_ret_1d") is not None]
    clean_joined = [ev for ev in price_joined if not ev.get("leakage_flag")]

    if clean_joined:
        sigs = [ev["signal_score"] for ev in clean_joined]
        rets = [ev["fwd_ret_1d"]   for ev in clean_joined]
        n    = len(clean_joined)

        # Spearman IC
        try:
            from scipy.stats import spearmanr
            ic, _ = spearmanr(sigs, rets)
            ic    = float(ic) if math.isfinite(ic) else 0.0
        except ImportError:
            ic = _pearson_r(sigs, rets)

        hits    = sum(1 for s, r in zip(sigs, rets)
                      if abs(s) > 0.05 and ((s > 0 and r > 0) or (s < 0 and r < 0)))
        dir_n   = sum(1 for s in sigs if abs(s) > 0.05)
        sharpe  = _sharpe(rets)

        stats = {
            "ticker":           ticker,
            "n_price_joins":    n,
            "n_leakage_flagged": leakage_count,
            "ic":               round(ic, 4),
            "hit_rate":         round(hits / max(1, dir_n), 4),
            "sharpe":           round(sharpe, 4),
            "mean_fwd_ret":     round(sum(rets) / n, 4),
        }

        # Red-flag checks
        flags = []
        if stats["ic"] > 0.15:
            flags.append("IC > 0.15 — verify no look-ahead")
        if stats["hit_rate"] > 0.65:
            flags.append("Hit rate > 65% — check timestamp alignment")
        if stats["sharpe"] > 2.0:
            flags.append("Sharpe > 2.0 — check for leakage")
        stats["red_flags"] = flags

    # ---- Benchmarking ---------------------------------------------------
    benchmark_rpt = None
    if clean_joined:
        try:
            bench = run_benchmark(clean_joined, ticker=ticker, horizon=1)
            benchmark_rpt = bench.to_dict()
            print(bench.summary())
        except Exception as exc:
            logger.warning("Benchmark failed: %s", exc)

    # ---- Calibration (optional) -----------------------------------------
    calibration_rpt = None
    if run_calibration and clean_joined:
        try:
            for method in ("ridge", "rank_ic"):
                cal = calibrate(clean_joined, horizon=1, method=method)
                logger.info(
                    "Calibration [%s]: weights=%s IC=%.4f IC_OOS=%s",
                    method, cal.weights, cal.ic, cal.ic_oos
                )
            calibration_rpt = {
                "weights": cal.weights,
                "ic":      cal.ic,
                "ic_oos":  cal.ic_oos,
                "method":  cal.method,
            }
        except Exception as exc:
            logger.warning("Calibration failed: %s", exc)

    # ---- Robustness (optional) ------------------------------------------
    robustness_rpt = None
    if run_robustness and clean_joined:
        try:
            rob = run_robustness_suite(clean_joined, horizon=1, n_windows=5)
            print(rob.summary())
            robustness_rpt = {
                "overall_ic":    rob.overall_ic,
                "ic_stability":  rob.ic_stability,
                "is_robust":     rob.is_robust,
                "bootstrap_ic":  rob.bootstrap_ic,
            }
        except Exception as exc:
            logger.warning("Robustness suite failed: %s", exc)

    # ---- Regime analysis (optional) ------------------------------------
    regime_rpt = None
    if run_regime and price_df is not None and clean_joined:
        try:
            labelled   = classify_regimes(clean_joined, price_df)
            regime_obj = run_regime_split(labelled, horizon=1)
            print(regime_obj.summary())
            regime_rpt = regime_obj.to_dict()
        except Exception as exc:
            logger.warning("Regime split failed: %s", exc)

    # ---- Horizon optimisation (optional) --------------------------------
    horizon_rpt = None
    if run_horizon and clean_joined:
        try:
            hor_obj    = optimise_horizon(clean_joined, horizons=[1, 2, 3, 5, 7, 10])
            print(hor_obj.summary())
            horizon_rpt = hor_obj.to_dict()
        except Exception as exc:
            logger.warning("Horizon optimisation failed: %s", exc)

    # ---- Capacity analysis (optional) -----------------------------------
    capacity_rpt = None
    if run_capacity:
        try:
            orders      = layer.orders()
            trading_days = max(1, (end - start).days * 5 // 7)
            cap_analyser = CapacityAnalyser(
                avg_daily_volume = avg_daily_volume,
                avg_price        = avg_price,
            )
            cap_obj     = cap_analyser.report(
                orders,
                signal_alpha_bps        = signal_alpha_bps,
                trading_days_in_window  = trading_days,
            )
            print(cap_obj.summary())
            capacity_rpt = cap_obj.to_dict()
        except Exception as exc:
            logger.warning("Capacity analysis failed: %s", exc)

    # ---- Feature stability (optional) ----------------------------------
    stability_rpt = None
    if run_stability and clean_joined:
        try:
            stab_obj    = analyse_stability(
                clean_joined, horizon=1, window=60, step=20,
                with_interactions=with_interactions,
            )
            print(stab_obj.summary())
            stability_rpt = stab_obj.to_dict()
        except Exception as exc:
            logger.warning("Feature stability failed: %s", exc)

    # ---- Regime-conditional model (optional) ----------------------------
    regime_model_rpt = None
    if run_regime_model and price_df is not None and clean_joined:
        try:
            labelled_for_model = classify_regimes(clean_joined, price_df)
            rms        = fit_regime_models(labelled_for_model, horizon=1)
            print(rms.report())
            regime_model_rpt = {
                "available_regimes": rms.available_regimes(),
                "global_ic":         rms.global_.ic,
                "n_regime_models":   sum(1 for m in rms.models.values()
                                         if not m.is_fallback),
            }
        except Exception as exc:
            logger.warning("Regime model fitting failed: %s", exc)

    # ---- Overfitting guard (optional) -----------------------------------
    overfitting_rpt = None
    if run_overfitting_guard and clean_joined:
        try:
            splitter           = DataSplitter(clean_joined, 0.6, 0.2, 0.2)
            tr_ev, va_ev, te_ev = splitter.split()
            guard              = OverfittingGuard(experiment_id)

            cal_tr = calibrate(tr_ev, horizon=1, method="ridge",
                                with_interactions=with_interactions) if run_calibration else None
            weights_for_guard = cal_tr.weights if cal_tr else {
                "sentiment": 0.25, "materiality": 0.35,
                "novelty": 0.25,   "credibility": 0.15,
            }
            ov_result = guard.full_evaluation(
                tr_ev, va_ev, te_ev, weights_for_guard, horizon=1
            )
            overfitting_rpt = ov_result
        except RuntimeError as exc:
            logger.warning("Overfitting guard: %s", exc)
            overfitting_rpt = {"error": str(exc)}
        except Exception as exc:
            logger.warning("Overfitting guard failed: %s", exc)

    total = len(rows)
    return {
        "period":           {"start": start.isoformat(), "end": end.isoformat()},
        "total_events":     total,
        "tier_counts":      tier_counts,
        "total_alerts":     alert_count,
        "alert_rate":       round(alert_count / max(1, total), 4),
        "leakage_count":    leakage_count,
        "execution": {
            "delay_minutes": delay_minutes,
            "slippage_bps":  slippage_bps,
        },
        "filter":           filter_rpt,
        "portfolio":        portfolio_rpt,
        "stats":            stats,
        "benchmark":        benchmark_rpt,
        "calibration":      calibration_rpt,
        "robustness":       robustness_rpt,
        "regime":           regime_rpt,
        "horizon":          horizon_rpt,
        "capacity":         capacity_rpt,
        "feature_stability": stability_rpt,
        "regime_model":     regime_model_rpt,
        "overfitting_guard": overfitting_rpt,
        "events":           events_out,
    }


# ---------------------------------------------------------------------------
# Statistical helpers
# ---------------------------------------------------------------------------

def _pearson_r(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 3:
        return 0.0
    mx = sum(xs) / n
    my = sum(ys) / n
    num   = sum((x - mx) * (y - my) for x, y in zip(xs, ys))
    den_x = math.sqrt(sum((x - mx) ** 2 for x in xs))
    den_y = math.sqrt(sum((y - my) ** 2 for y in ys))
    if den_x < 1e-9 or den_y < 1e-9:
        return 0.0
    return num / (den_x * den_y)


def _sharpe(returns: list[float]) -> float:
    n = len(returns)
    if n < 2:
        return 0.0
    mean = sum(returns) / n
    var  = sum((r - mean) ** 2 for r in returns) / (n - 1)
    std  = math.sqrt(var)
    if std < 1e-9:
        return 0.0
    return round(mean / std * math.sqrt(252), 4)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

async def _main(args: argparse.Namespace) -> None:
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    if args.days:
        end   = datetime.now(timezone.utc)
        start = end - timedelta(days=args.days)
    else:
        start = datetime.fromisoformat(args.start).replace(tzinfo=timezone.utc)
        end   = datetime.fromisoformat(args.end).replace(tzinfo=timezone.utc)

    logger.info("Running backtest %s → %s", start.date(), end.date())

    filter_cfg = FilterConfig(
        min_score       = args.min_score,
        top_pct         = args.top_pct,
        min_novelty     = args.min_novelty,
        max_age_hours   = 48.0,
        allowed_tiers   = ["STRONG", "MODERATE", "WEAK"],
    )
    portfolio_cfg = PortfolioConfig(
        max_position   = args.max_position,
        sizing         = args.sizing,
        overlap        = args.overlap,
    )

    report = await run_backtest(
        start              = start,
        end                = end,
        ticker             = args.ticker or None,
        delay_minutes      = args.delay_minutes,
        slippage_bps       = args.slippage_bps,
        filter_cfg         = filter_cfg,
        portfolio_cfg      = portfolio_cfg,
        run_calibration    = args.calibrate,
        run_robustness     = args.robustness,
        run_regime         = args.regime,
        run_horizon        = args.horizon,
        run_capacity       = args.capacity,
        run_stability      = args.stability,
        run_regime_model   = args.regime_model,
        run_overfitting_guard = args.overfitting_guard,
        with_interactions  = args.interactions,
        avg_daily_volume   = args.adv,
        avg_price          = args.avg_price,
        signal_alpha_bps   = args.alpha_bps,
        experiment_id      = args.experiment_id,
    )

    print(f"\n{'═'*60}")
    print(f"  BACKTEST RESULTS")
    print(f"{'═'*60}")
    print(f"  Period:         {report['period']['start'][:10]} → {report['period']['end'][:10]}")
    print(f"  Total events:   {report['total_events']}")
    print(f"  Tier counts:    {report['tier_counts']}")
    print(f"  Alerts fired:   {report['total_alerts']}  ({report['alert_rate']:.1%})")
    print(f"  Leakage flags:  {report['leakage_count']}")

    f = report.get("filter") or {}
    print(f"\n  Filter:  {f.get('passed',0)}/{f.get('total_events',0)} passed "
          f"({f.get('pass_rate',0):.1%})")

    p = report.get("portfolio") or {}
    print(f"  Orders:  {p.get('n_orders',0)}  "
          f"gross ${p.get('gross_exposure',0):,.0f}  "
          f"util {p.get('utilisation_pct',0):.1f}%")

    s = report.get("stats") or {}
    if s:
        print(f"\n  ── Price-join stats ({s.get('ticker')}) ──────────────")
        print(f"  Joined:        {s.get('n_price_joins')}")
        print(f"  IC (Spearman): {s.get('ic', 0):.4f}")
        print(f"  Hit rate:      {s.get('hit_rate', 0):.1%}")
        print(f"  Sharpe (ann.): {s.get('sharpe', 0):.2f}")
        print(f"  Mean T+1 ret:  {s.get('mean_fwd_ret', 0):.4f}%")
        if s.get("red_flags"):
            for flag in s["red_flags"]:
                print(f"  🚨 {flag}")

    if args.output:
        with open(args.output, "w") as f_:
            json.dump(report, f_, indent=2, default=str)
        logger.info("Report written to %s", args.output)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Finance AI — fully integrated backtest",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    grp = parser.add_mutually_exclusive_group(required=True)
    grp.add_argument("--days",  type=int,  help="Lookback in calendar days")
    grp.add_argument("--start", type=str,  help="Start date YYYY-MM-DD")
    parser.add_argument("--end",           type=str,   default="",
                        help="End date YYYY-MM-DD (default: today)")
    parser.add_argument("--output",        type=str,   default="",
                        help="Write JSON report to this path")
    parser.add_argument("--ticker",        type=str,   default="",
                        help="Ticker for price join and market baseline (e.g. AAPL)")
    # Execution realism
    parser.add_argument("--delay-minutes", type=float, default=15.0,
                        help="Minimum event→fill delay in minutes")
    parser.add_argument("--slippage-bps",  type=float, default=10.0,
                        help="Slippage in basis points per side")
    # Signal filter
    parser.add_argument("--min-score",     type=float, default=0.20,
                        help="Minimum |signal_score| to trade")
    parser.add_argument("--top-pct",       type=float, default=0.0,
                        help="Keep top X fraction of signals (0 = keep all passing gate)")
    parser.add_argument("--min-novelty",   type=float, default=0.30,
                        help="Minimum novelty_score to trade")
    # Portfolio
    parser.add_argument("--max-position",  type=float, default=10_000.0,
                        help="Max notional per position ($)")
    parser.add_argument("--sizing",        type=str,   default="PROP",
                        choices=["FIXED", "PROP", "KELLY"],
                        help="Position sizing rule")
    parser.add_argument("--overlap",       type=str,   default="AVERAGE",
                        choices=["STACK", "AVERAGE", "STRONGEST"],
                        help="Overlapping signal resolution strategy")
    # Optional full-suite
    parser.add_argument("--stability",     action="store_true",
                        help="Run rolling feature stability analysis")
    parser.add_argument("--regime-model",  action="store_true",
                        help="Fit regime-conditional models (requires --regime)")
    parser.add_argument("--overfitting-guard", action="store_true",
                        help="Run train/val/test split with single-use test lock")
    parser.add_argument("--interactions",  action="store_true",
                        help="Include sent×novelty and mat×cred interaction terms")
    parser.add_argument("--experiment-id", type=str, default="default",
                        help="Unique experiment ID for overfitting guard lock")
    parser.add_argument("--robustness",    action="store_true",
                        help="Run full robustness suite (walk-forward + bootstrap)")
    parser.add_argument("--regime",        action="store_true",
                        help="Run regime split analysis (vol + trend)")
    parser.add_argument("--horizon",       action="store_true",
                        help="Optimise holding period as a hyperparameter")
    parser.add_argument("--capacity",      action="store_true",
                        help="Run capacity and market impact analysis")
    parser.add_argument("--adv",           type=float, default=1_000_000,
                        help="Avg daily volume (shares) for capacity analysis")
    parser.add_argument("--avg-price",     type=float, default=100.0,
                        help="Avg share price for capacity analysis")
    parser.add_argument("--alpha-bps",     type=float, default=30.0,
                        help="Expected gross alpha per trade in bps")

    args = parser.parse_args()
    if args.start and not args.end:
        args.end = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    asyncio.run(_main(args))
