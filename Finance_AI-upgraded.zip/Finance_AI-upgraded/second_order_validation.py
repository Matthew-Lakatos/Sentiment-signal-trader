"""
second_order_validation.py — validate whether second-order alpha adds value.

Problem
-------
Second-order signals (entity A → topic → entity B propagation) can dilute
the first-order signal if the KG relationships are noisy.  Before blending
them you MUST compare:

    first_order_only          vs
    first_order + second_order

Across: IC, Sharpe, robustness (walk-forward IC std).

Decision rule
-------------
  If IC_combined >= IC_first × (1 - TOLERANCE)  → keep second-order
  If IC_combined <  IC_first × (1 - TOLERANCE)  → discard / reduce λ

Usage
-----
    from second_order_validation import validate_second_order

    result = validate_second_order(
        first_order_events  = events,          # scored with signal_score
        second_order_events = second_signals,  # from SecondOrderAlpha.propagate_sync()
        blend_lambda        = 0.30,            # weight of second-order contribution
        horizon             = 1,
    )
    print(result.summary())

    if result.keep:
        # Use blended signal
        blended_score = result.blend(first_score, second_score)
    else:
        # Discard second-order for this entity
        blended_score = first_score
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Optional

logger = logging.getLogger(__name__)

# If combined IC is within TOLERANCE of first-order, still accept (noise floor)
_TOLERANCE = 0.02


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _spearman(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 3:
        return float("nan")
    try:
        from scipy.stats import spearmanr
        r, _ = spearmanr(xs, ys)
        return float(r) if math.isfinite(r) else float("nan")
    except ImportError:
        return float("nan")


def _sharpe(rets: list[float]) -> float:
    n = len(rets)
    if n < 2:
        return float("nan")
    mu  = sum(rets) / n
    std = math.sqrt(sum((r - mu) ** 2 for r in rets) / (n - 1))
    return (mu / std * math.sqrt(252)) if std > 1e-9 else float("nan")


def _walk_forward_ic_std(
    signals: list[float],
    returns: list[float],
    n_windows: int = 4,
) -> float:
    """Compute std of IC across walk-forward windows — proxy for IC stability."""
    n      = len(signals)
    size   = n // n_windows
    ics    = []
    for i in range(n_windows):
        s = signals[i * size: (i + 1) * size]
        r = returns[i * size: (i + 1) * size]
        ic = _spearman(s, r)
        if math.isfinite(ic):
            ics.append(ic)
    if len(ics) < 2:
        return float("nan")
    mean = sum(ics) / len(ics)
    return math.sqrt(sum((x - mean) ** 2 for x in ics) / (len(ics) - 1))


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class SecondOrderValidationResult:
    horizon:             int
    blend_lambda:        float         # weight given to second-order signal

    # First-order only
    ic_first:            float
    sharpe_first:        float
    ic_std_first:        float         # walk-forward IC std

    # Blended (first + second)
    ic_combined:         float
    sharpe_combined:     float
    ic_std_combined:     float

    # Verdict
    keep:                bool          # True → keep second-order contribution
    ic_lift:             float         # ic_combined - ic_first
    recommended_lambda:  float         # suggested blend weight after validation
    notes:               str = ""

    def summary(self) -> str:
        lines = [
            f"\n{'═'*62}",
            f"  SECOND-ORDER ALPHA VALIDATION  (T+{self.horizon}d  λ={self.blend_lambda})",
            f"{'═'*62}",
            f"  {'Metric':<28} {'First-only':>12} {'Combined':>12}",
            f"{'─'*62}",
            f"  {'IC (Spearman)':<28} {self._fmt(self.ic_first):>12} {self._fmt(self.ic_combined):>12}",
            f"  {'IC lift':<28} {'':>12} {self.ic_lift:>+12.4f}",
            f"  {'Sharpe (ann.)':<28} {self._fmt(self.sharpe_first):>12} {self._fmt(self.sharpe_combined):>12}",
            f"  {'IC stability (σ)':<28} {self._fmt(self.ic_std_first):>12} {self._fmt(self.ic_std_combined):>12}",
            f"{'─'*62}",
        ]
        verdict = "✓  KEEP" if self.keep else "✗  DISCARD"
        lines.append(f"  Verdict:  {verdict} second-order signals")
        lines.append(f"  Recommended λ: {self.recommended_lambda:.2f}")
        if self.notes:
            lines.append(f"  Note: {self.notes}")
        lines.append(f"{'═'*62}")
        return "\n".join(lines)

    @staticmethod
    def _fmt(v: float) -> str:
        return f"{v:.4f}" if math.isfinite(v) else "  n/a  "

    def blend(self, first_score: float, second_score: float) -> float:
        """
        Apply the validated (or recommended) blend.
        If keep=False, returns first_score unchanged.
        """
        if not self.keep:
            return round(first_score, 4)
        lam = self.recommended_lambda
        return round((1 - lam) * first_score + lam * second_score, 4)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_second_order(
    first_order_events:  list[dict],
    second_order_events: list[dict],
    blend_lambda:        float = 0.30,
    horizon:             int   = 1,
    n_windows:           int   = 4,
) -> SecondOrderValidationResult:
    """
    Compare first-order-only vs blended (first + second-order) signals.

    Parameters
    ----------
    first_order_events
        Scored event dicts with signal_score and fwd_ret_{horizon}d.
    second_order_events
        Output of SecondOrderAlpha.propagate_sync() — dicts with secondary_score.
        Must be aligned with first_order_events (same length and order) OR
        provide a mapping via "source_event_id".
    blend_lambda
        Weight of second-order contribution in [0, 1].
        blended = (1 - λ) × first + λ × second
    horizon
        Return horizon in trading days.
    n_windows
        Walk-forward windows for IC stability.

    Returns
    -------
    SecondOrderValidationResult with keep flag and recommended_lambda.
    """
    ret_key = f"fwd_ret_{horizon}d"

    # ---- Build first-order signal/return pairs --------------------------------
    first_pairs: list[tuple[float, float]] = []
    for ev in first_order_events:
        ret = ev.get(ret_key)
        sig = ev.get("signal_score")
        if ret is not None and sig is not None and math.isfinite(float(ret)):
            first_pairs.append((float(sig), float(ret)))

    if len(first_pairs) < 10:
        notes = f"Insufficient first-order events ({len(first_pairs)} < 10)"
        logger.warning(notes)
        return _null_result(horizon, blend_lambda, notes)

    f_sigs, f_rets = zip(*first_pairs)

    # ---- Build blended pairs -----------------------------------------------
    # Align second-order by position (or return 0.0 if missing)
    soa_lookup: dict[str, float] = {}
    for ev in second_order_events:
        src = ev.get("source_event_id") or ""
        if src:
            soa_lookup[src] = float(ev.get("secondary_score") or 0.0)

    blended_pairs: list[tuple[float, float]] = []
    for i, ev in enumerate(first_order_events):
        ret = ev.get(ret_key)
        if ret is None or not math.isfinite(float(ret)):
            continue
        first_s = float(ev.get("signal_score") or 0.0)

        # Look up second-order by event_id, then by position
        eid     = str(ev.get("event_id") or "")
        second_s = soa_lookup.get(eid, 0.0)
        if second_s == 0.0 and i < len(second_order_events):
            second_s = float(second_order_events[i].get("secondary_score") or 0.0)

        blended = (1 - blend_lambda) * first_s + blend_lambda * second_s
        blended_pairs.append((blended, float(ret)))

    if len(blended_pairs) < 10:
        notes = f"Insufficient blended pairs ({len(blended_pairs)} < 10)"
        return _null_result(horizon, blend_lambda, notes)

    b_sigs, b_rets = zip(*blended_pairs)

    # ---- Compute metrics ---------------------------------------------------
    ic_first    = _spearman(list(f_sigs), list(f_rets))
    ic_combined = _spearman(list(b_sigs), list(b_rets))

    sh_first    = _sharpe(list(f_rets))
    sh_combined = _sharpe(list(b_rets))

    ic_std_f = _walk_forward_ic_std(list(f_sigs), list(f_rets), n_windows)
    ic_std_b = _walk_forward_ic_std(list(b_sigs), list(b_rets), n_windows)

    ic_lift  = (ic_combined - ic_first) if (math.isfinite(ic_combined) and math.isfinite(ic_first)) else 0.0

    # ---- Decision rule -----------------------------------------------------
    threshold = ic_first - _TOLERANCE if math.isfinite(ic_first) else 0.0
    keep      = math.isfinite(ic_combined) and ic_combined >= threshold

    # Recommend a scaled-down lambda if combined IC is marginally worse
    if keep and ic_lift < 0:
        # Reduce lambda proportionally to the shortfall
        shortfall = -ic_lift / max(abs(ic_first), 1e-6)
        recommended_lambda = max(0.05, blend_lambda * (1.0 - shortfall))
    elif keep:
        recommended_lambda = blend_lambda
    else:
        recommended_lambda = 0.0

    notes = []
    if not keep:
        notes.append(
            f"Second-order reduces IC by {abs(ic_lift):.4f} > tolerance {_TOLERANCE} "
            "— discard or reduce λ"
        )
    if math.isfinite(ic_std_b) and math.isfinite(ic_std_f) and ic_std_b > ic_std_f * 1.3:
        notes.append("Combined IC is less stable than first-order alone")
    if math.isfinite(sh_combined) and math.isfinite(sh_first) and sh_combined < sh_first * 0.8:
        notes.append("Blended Sharpe is >20% lower than first-order Sharpe")

    return SecondOrderValidationResult(
        horizon             = horizon,
        blend_lambda        = blend_lambda,
        ic_first            = round(ic_first, 4)    if math.isfinite(ic_first)    else 0.0,
        sharpe_first        = round(sh_first, 4)    if math.isfinite(sh_first)    else 0.0,
        ic_std_first        = round(ic_std_f, 4)    if math.isfinite(ic_std_f)    else 0.0,
        ic_combined         = round(ic_combined, 4) if math.isfinite(ic_combined) else 0.0,
        sharpe_combined     = round(sh_combined, 4) if math.isfinite(sh_combined) else 0.0,
        ic_std_combined     = round(ic_std_b, 4)    if math.isfinite(ic_std_b)    else 0.0,
        keep                = keep,
        ic_lift             = round(ic_lift, 4),
        recommended_lambda  = round(recommended_lambda, 3),
        notes               = "; ".join(notes),
    )


def _null_result(horizon: int, lam: float, notes: str) -> SecondOrderValidationResult:
    return SecondOrderValidationResult(
        horizon=horizon, blend_lambda=lam,
        ic_first=0.0, sharpe_first=0.0, ic_std_first=0.0,
        ic_combined=0.0, sharpe_combined=0.0, ic_std_combined=0.0,
        keep=False, ic_lift=0.0, recommended_lambda=0.0, notes=notes,
    )
