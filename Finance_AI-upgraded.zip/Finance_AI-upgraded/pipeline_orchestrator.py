"""
pipeline_orchestrator.py — #10 Formal Pipeline State Machine.

Replaces the implicit procedural flow in main.py with an explicit,
recoverable state machine. This is the backbone of semi-autonomy.

States
------
  INIT       → initial state; acquire pool, initialise subsystems
  INGEST     → scrape URLs, crawl, discover new sources
  SCORE      → NLP, embedding, signal ranking per event
  GOVERN     → governance assessment, throttle update, kill-switch check
  THROTTLE   → apply size scalar, filter signals by min score
  EXECUTE    → write to DB, shadow portfolio, alert dispatch
  LOG        → write latency report, state vectors, governance snapshot
  SUSPEND    → kill-switch engaged; no new positions; await recovery
  ERROR      → unrecoverable error; requires manual intervention

Transitions
-----------
  INIT    → INGEST (success) | ERROR (pool fail)
  INGEST  → SCORE  (events scraped) | LOG (no events)
  SCORE   → GOVERN (always)
  GOVERN  → THROTTLE | SUSPEND (kill-switch engaged)
  THROTTLE → EXECUTE
  EXECUTE  → LOG
  LOG      → INIT  (next cycle) | SUSPEND (if health degraded)
  SUSPEND  → INIT  (auto-recovery) | ERROR (manual reset required)

Usage
-----
    from pipeline_orchestrator import PipelineOrchestrator

    orch = PipelineOrchestrator(config=settings, pool=pool)
    await orch.run(urls=FINANCE_URLS)

    # Check state
    print(orch.current_state, orch.state_history[-3:])
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Callable, Optional

from latency_budget import LatencyBudget, BudgetedTimer, get_budget
from kill_switch    import KillSwitch, KillState, get_switch
from state_versioning import StateVector, StateVectorStore, get_store

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# State definitions
# ---------------------------------------------------------------------------

class PipelineState(str, Enum):
    INIT     = "INIT"
    INGEST   = "INGEST"
    SCORE    = "SCORE"
    GOVERN   = "GOVERN"
    THROTTLE = "THROTTLE"
    EXECUTE  = "EXECUTE"
    LOG      = "LOG"
    SUSPEND  = "SUSPEND"
    ERROR    = "ERROR"


_VALID_TRANSITIONS: dict[PipelineState, list[PipelineState]] = {
    PipelineState.INIT:     [PipelineState.INGEST,   PipelineState.ERROR],
    PipelineState.INGEST:   [PipelineState.SCORE,    PipelineState.LOG, PipelineState.ERROR],
    PipelineState.SCORE:    [PipelineState.GOVERN,   PipelineState.ERROR],
    PipelineState.GOVERN:   [PipelineState.THROTTLE, PipelineState.SUSPEND, PipelineState.ERROR],
    PipelineState.THROTTLE: [PipelineState.EXECUTE,  PipelineState.ERROR],
    PipelineState.EXECUTE:  [PipelineState.LOG,      PipelineState.ERROR],
    PipelineState.LOG:      [PipelineState.INIT,     PipelineState.SUSPEND, PipelineState.ERROR],
    PipelineState.SUSPEND:  [PipelineState.INIT,     PipelineState.ERROR],
    PipelineState.ERROR:    [PipelineState.INIT],    # manual reset only
}


# ---------------------------------------------------------------------------
# Pipeline context — the mutable bag of state passed between stages
# ---------------------------------------------------------------------------

@dataclass
class PipelineContext:
    urls:           list[str]                  = field(default_factory=list)
    raw_events:     list[dict]                 = field(default_factory=list)   # after scrape
    scored_events:  list[dict]                 = field(default_factory=list)   # after NLP+signal
    filtered_events: list[dict]               = field(default_factory=list)   # after throttle
    market_state:   Optional[object]          = None
    governance_report: Optional[object]       = None
    throttle_state: Optional[object]          = None
    kill_state:     Optional[KillState]       = None
    cycle_id:       str                       = ""
    started_at:     datetime                  = field(default_factory=lambda: datetime.now(timezone.utc))
    errors:         list[str]                 = field(default_factory=list)
    metadata:       dict                      = field(default_factory=dict)

    def add_error(self, msg: str) -> None:
        self.errors.append(msg)
        logger.error("[Pipeline] %s", msg)

    @property
    def has_errors(self) -> bool:
        return bool(self.errors)

    @property
    def elapsed_s(self) -> float:
        return (datetime.now(timezone.utc) - self.started_at).total_seconds()


# ---------------------------------------------------------------------------
# Transition record
# ---------------------------------------------------------------------------

@dataclass
class TransitionRecord:
    from_state:  str
    to_state:    str
    reason:      str
    timestamp:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# PipelineOrchestrator
# ---------------------------------------------------------------------------

class PipelineOrchestrator:
    """
    Formal, recoverable pipeline state machine.

    Stage handlers are registered as async callables. The orchestrator
    invokes them in order, records timing, and handles transitions.
    Unhandled exceptions in a stage transition the machine to ERROR.

    Parameters
    ----------
    kill_switch  : KillSwitch instance
    budget       : LatencyBudget for timing
    sv_store     : StateVectorStore for versioning
    """

    def __init__(
        self,
        kill_switch:   Optional[KillSwitch]       = None,
        budget:        Optional[LatencyBudget]    = None,
        sv_store:      Optional[StateVectorStore] = None,
    ) -> None:
        self._state         = PipelineState.INIT
        self._kill_switch   = kill_switch or get_switch()
        self._budget        = budget      or get_budget()
        self._sv_store      = sv_store    or get_store()
        self._history:      list[TransitionRecord] = []
        self._lock          = asyncio.Lock()

        # Stage handlers: state → async callable(ctx) → PipelineState
        self._handlers: dict[PipelineState, Callable] = {}

    # ------------------------------------------------------------------
    # Handler registration
    # ------------------------------------------------------------------

    def register(self, state: PipelineState, handler: Callable) -> None:
        """
        Register an async callable for a pipeline state.
        The callable receives PipelineContext and returns the next PipelineState.

        Example
        -------
            @orch.register(PipelineState.INGEST)
            async def ingest_stage(ctx: PipelineContext) -> PipelineState:
                ctx.raw_events = await scrape_all_urls(ctx.urls)
                return PipelineState.SCORE if ctx.raw_events else PipelineState.LOG
        """
        self._handlers[state] = handler

    def register_default_handlers(
        self,
        ingest_fn:   Optional[Callable] = None,
        score_fn:    Optional[Callable] = None,
        govern_fn:   Optional[Callable] = None,
        throttle_fn: Optional[Callable] = None,
        execute_fn:  Optional[Callable] = None,
        log_fn:      Optional[Callable] = None,
    ) -> None:
        """Convenience method: register all handlers at once."""
        mapping = {
            PipelineState.INGEST:   ingest_fn,
            PipelineState.SCORE:    score_fn,
            PipelineState.GOVERN:   govern_fn,
            PipelineState.THROTTLE: throttle_fn,
            PipelineState.EXECUTE:  execute_fn,
            PipelineState.LOG:      log_fn,
        }
        for state, fn in mapping.items():
            if fn is not None:
                self._handlers[state] = fn

    # ------------------------------------------------------------------
    # State machine execution
    # ------------------------------------------------------------------

    async def run(self, urls: list[str], cycle_id: str = "") -> PipelineContext:
        """
        Execute one full pipeline cycle.
        Returns the PipelineContext with full audit trail.
        """
        import uuid
        ctx = PipelineContext(
            urls      = urls,
            cycle_id  = cycle_id or str(uuid.uuid4())[:8],
        )

        self._budget.start_pipeline()
        logger.info("Pipeline cycle [%s] starting in state %s", ctx.cycle_id, self._state.value)

        # Reset to INIT if coming from a prior cycle's LOG
        if self._state == PipelineState.LOG:
            self._transition(PipelineState.INIT, "new_cycle")

        # Run state machine
        while self._state not in (PipelineState.ERROR, PipelineState.SUSPEND):
            next_state = await self._execute_state(ctx)
            if next_state is None:
                break
            self._transition(next_state, f"completed_{self._state.value}")
            if next_state == PipelineState.LOG:
                break  # one cycle complete

        # Final latency report
        latency_report = self._budget.report()
        ctx.metadata["latency_report"] = latency_report.summary()
        if latency_report.has_slow_stages:
            ctx.metadata["slow_stages"] = latency_report.slow_stages

        logger.info(
            "Pipeline cycle [%s] complete. Final state=%s  elapsed=%.1fs  events=%d",
            ctx.cycle_id, self._state.value, ctx.elapsed_s, len(ctx.scored_events),
        )

        # Store state vector for reproducibility
        self._sv_store.push(StateVector.from_dict(
            data        = {
                "cycle_id":      ctx.cycle_id,
                "state":         self._state.value,
                "n_urls":        len(ctx.urls),
                "n_raw_events":  len(ctx.raw_events),
                "n_scored":      len(ctx.scored_events),
                "n_filtered":    len(ctx.filtered_events),
                "elapsed_s":     round(ctx.elapsed_s, 1),
                "errors":        ctx.errors,
                "kill_state":    ctx.kill_state.value if ctx.kill_state else "ACTIVE",
            },
            schema_name = "pipeline_cycle",
            source      = "pipeline_orchestrator",
        ))

        return ctx

    async def _execute_state(self, ctx: PipelineContext) -> Optional[PipelineState]:
        """Execute the handler for the current state."""
        state = self._state

        # Kill-switch check before every state
        if not self._kill_switch.is_deployable() and state not in (
            PipelineState.INIT, PipelineState.LOG, PipelineState.SUSPEND
        ):
            logger.critical("Kill switch engaged — moving to SUSPEND")
            ctx.kill_state = self._kill_switch.current_state
            return PipelineState.SUSPEND

        handler = self._handlers.get(state)
        if handler is None:
            # No handler registered — use default pass-through
            return self._default_transition(state)

        stage_name = state.value.lower()
        try:
            async with BudgetedTimer(self._budget, stage_name):
                next_state = await handler(ctx)
            return next_state
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            logger.error(
                "Stage %s failed: %s", state.value, exc, exc_info=True
            )
            ctx.add_error(f"{state.value}: {exc}")
            return PipelineState.ERROR

    def _default_transition(self, state: PipelineState) -> PipelineState:
        """Default linear transitions when no handler is registered."""
        defaults = {
            PipelineState.INIT:     PipelineState.INGEST,
            PipelineState.INGEST:   PipelineState.SCORE,
            PipelineState.SCORE:    PipelineState.GOVERN,
            PipelineState.GOVERN:   PipelineState.THROTTLE,
            PipelineState.THROTTLE: PipelineState.EXECUTE,
            PipelineState.EXECUTE:  PipelineState.LOG,
            PipelineState.LOG:      PipelineState.INIT,
            PipelineState.SUSPEND:  PipelineState.INIT,
        }
        return defaults.get(state, PipelineState.ERROR)

    # ------------------------------------------------------------------
    # State transitions
    # ------------------------------------------------------------------

    def _transition(self, new_state: PipelineState, reason: str = "") -> None:
        allowed = _VALID_TRANSITIONS.get(self._state, [])
        if new_state not in allowed:
            logger.error(
                "Invalid transition %s → %s (reason=%s). Allowed: %s",
                self._state.value, new_state.value, reason,
                [s.value for s in allowed],
            )
            # Force ERROR state on invalid transition
            new_state = PipelineState.ERROR

        record = TransitionRecord(
            from_state = self._state.value,
            to_state   = new_state.value,
            reason     = reason,
        )
        self._history.append(record)

        if new_state in (PipelineState.ERROR, PipelineState.SUSPEND):
            log_fn = logger.error if new_state == PipelineState.ERROR else logger.warning
        else:
            log_fn = logger.debug

        log_fn("Pipeline: %s → %s (%s)", self._state.value, new_state.value, reason)
        self._state = new_state

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    @property
    def current_state(self) -> PipelineState:
        return self._state

    @property
    def state_history(self) -> list[TransitionRecord]:
        return list(self._history)

    def is_healthy(self) -> bool:
        return self._state not in (PipelineState.ERROR, PipelineState.SUSPEND)

    def force_reset(self, reason: str = "manual") -> None:
        """Force-reset to INIT from any state. Use for operator intervention."""
        logger.warning("Pipeline force-reset to INIT: %s", reason)
        self._history.append(TransitionRecord(
            from_state = self._state.value,
            to_state   = PipelineState.INIT.value,
            reason     = f"FORCE_RESET: {reason}",
        ))
        self._state = PipelineState.INIT

    def status(self) -> dict:
        return {
            "state":            self._state.value,
            "is_healthy":       self.is_healthy(),
            "kill_switch":      self._kill_switch.current_state.value,
            "transitions_total": len(self._history),
            "last_transition":  {
                "from":   self._history[-1].from_state,
                "to":     self._history[-1].to_state,
                "reason": self._history[-1].reason,
                "at":     self._history[-1].timestamp.isoformat(),
            } if self._history else None,
        }


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_orchestrator: Optional[PipelineOrchestrator] = None


def get_orchestrator(**kwargs) -> PipelineOrchestrator:
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = PipelineOrchestrator(**kwargs)
    return _orchestrator
