"""
execution_simulator_v2.py — #16 Execution Simulator v2.

Replaces the flat-slippage ExecutionEngine in execution.py with a
realistic market-impact model that accounts for:

1. Partial fill simulation
   Large orders relative to ADV are not fully filled immediately.
   Partial fills model the expected fill fraction based on order size
   vs. 10-day average daily volume.

2. Slippage curves
   Market impact is non-linear: doubling order size more than doubles
   slippage. Uses Almgren-Chriss square-root market impact model.

3. Liquidity-aware sizing
   Automatically reduces order size when liquidity is low, preventing
   outsized market impact in thin markets.

4. Volatility-aware sizing
   Scales position size inversely with recent realised volatility
   (Kelly-inspired risk parity adjustment).

Slippage model
--------------
  impact_bps = base_bps + eta × sqrt(participation_rate) × vol_daily × 10000

Where:
  participation_rate = order_size / adv_10d
  vol_daily          = 10-day realised daily vol
  eta                = market-impact coefficient (default 0.1)

Usage
-----
    from execution_simulator_v2 import ExecutionSimulatorV2

    sim = ExecutionSimulatorV2()
    result = await sim.simulate_fill(
        ticker        = "AAPL",
        direction     = "LONG",
        notional      = 50_000,
        liquidity_snap = liq_snap,
        horizon       = 5,
    )
    print(result.fill_pct, result.actual_slippage_bps, result.adj_notional)
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_ADV_LOOKBACK      = "30d"
_MAX_PARTICIPATION = 0.10   # never exceed 10% of ADV in a single order
_ETA               = 0.10   # Almgren-Chriss impact coefficient
_CACHE_TTL         = 600    # 10 min

# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class SimulatedFill:
    ticker:              str
    direction:           str
    requested_notional:  float
    adj_notional:        float          # after liquidity/vol sizing
    fill_pct:            float          # fraction actually filled [0, 1]
    filled_notional:     float          # adj_notional × fill_pct
    fill_price:          Optional[float]
    entry_price_ref:     Optional[float] # mid-market reference
    actual_slippage_bps: float
    expected_slippage_bps: float
    participation_rate:  float          # order / ADV
    vol_daily:           Optional[float]
    adv_10d:             Optional[float]
    liquidity_regime:    str            # from LiquiditySnapshot
    sizing_notes:        list[str] = field(default_factory=list)
    simulated_at:        datetime  = field(default_factory=lambda: datetime.now(timezone.utc))


# ---------------------------------------------------------------------------
# Data fetch
# ---------------------------------------------------------------------------

_cache: dict[str, tuple[float, dict]] = {}


def _fetch_ticker_data_sync(ticker: str) -> dict:
    now = time.monotonic()
    if ticker in _cache:
        exp, data = _cache[ticker]
        if now < exp:
            return data

    try:
        import yfinance as yf
        import numpy as np

        df = yf.download(ticker, period=_ADV_LOOKBACK, progress=False, auto_adjust=True)
        if df.empty:
            return {}

        closes = df["Close"].values.astype(float)
        volumes = df["Volume"].values.astype(float)

        # 10-day ADV in dollar terms
        adv_vol = float(volumes[-10:].mean()) if len(volumes) >= 10 else float(volumes.mean())
        mid     = float(closes[-1]) if len(closes) > 0 else None
        adv_10d = adv_vol * mid if mid else None

        # 10-day realised daily vol
        if len(closes) >= 11:
            rets    = np.diff(np.log(closes[-11:]))
            vol_10d = float(np.std(rets))
        else:
            vol_10d = None

        result = {
            "mid":     mid,
            "adv_10d": adv_10d,
            "vol_10d": vol_10d,
        }
        _cache[ticker] = (now + _CACHE_TTL, result)
        return result

    except Exception as exc:
        logger.warning("Ticker data fetch failed for %s: %s", ticker, exc)
        return {}


# ---------------------------------------------------------------------------
# Slippage model
# ---------------------------------------------------------------------------

def _almgren_chriss_slippage(
    participation_rate: float,
    vol_daily:          float,
    base_bps:           float = 5.0,
    eta:                float = _ETA,
) -> float:
    """
    Square-root market impact model.
    Returns estimated slippage in basis points.

    impact = base + eta × sqrt(participation) × vol × 10000
    """
    impact = base_bps + eta * math.sqrt(participation_rate) * vol_daily * 10_000
    return round(impact, 2)


def _partial_fill_fraction(
    participation_rate: float,
    liquidity_regime:   str,
) -> float:
    """
    Estimate the fraction of the order that can be filled given
    participation rate and market liquidity conditions.

    Returns fill fraction ∈ [0.10, 1.0].
    """
    # Liquid conditions: can fill most of the order
    regime_caps = {
        "LIQUID":   1.00,
        "NORMAL":   0.90,
        "ELEVATED": 0.75,
        "STRESSED": 0.50,
        "CRITICAL": 0.25,
        "UNKNOWN":  0.80,
    }
    cap = regime_caps.get(liquidity_regime, 0.80)

    # Linear decay: at participation_rate=0 → full; at max_participation → cap
    fill = max(0.10, cap * (1.0 - participation_rate / _MAX_PARTICIPATION * 0.3))
    return round(min(1.0, fill), 4)


# ---------------------------------------------------------------------------
# Simulator
# ---------------------------------------------------------------------------

class ExecutionSimulatorV2:
    """
    Liquidity-aware, volatility-aware execution simulator.

    Provides realistic fill fractions and slippage estimates before
    any order reaches the (real or shadow) execution layer.
    """

    def __init__(
        self,
        base_slippage_bps: float = 5.0,
        max_participation: float = _MAX_PARTICIPATION,
        eta:               float = _ETA,
        vol_scalar:        float = 1.0,   # 1.0 = full Kelly; lower = more conservative
    ) -> None:
        self._base_bps         = base_slippage_bps
        self._max_participation = max_participation
        self._eta              = eta
        self._vol_scalar       = vol_scalar

    async def simulate_fill(
        self,
        ticker:         str,
        direction:      str,
        notional:       float,
        liquidity_snap  = None,   # Optional[LiquiditySnapshot]
        horizon:        int = 1,
    ) -> SimulatedFill:
        """
        Simulate a fill for `ticker` with `notional` at current market conditions.

        Parameters
        ----------
        ticker         : equity ticker
        direction      : LONG | SHORT
        notional       : requested position size in USD
        liquidity_snap : LiquiditySnapshot from liquidity_engine (optional)
        horizon        : intended hold period in days (affects vol scaling)
        """
        loop     = asyncio.get_running_loop()
        data     = await loop.run_in_executor(None, _fetch_ticker_data_sync, ticker)
        notes:   list[str] = []

        mid     = data.get("mid")
        adv_10d = data.get("adv_10d")
        vol_10d = data.get("vol_10d")

        liquidity_regime = "UNKNOWN"
        if liquidity_snap is not None and not liquidity_snap.is_stale:
            liquidity_regime = liquidity_snap.regime

        # ── Liquidity-aware sizing ──────────────────────────────────────────
        adj_notional = notional

        if adv_10d is not None and adv_10d > 0:
            participation_rate = notional / adv_10d
            if participation_rate > self._max_participation:
                adj_notional = self._max_participation * adv_10d
                notes.append(
                    f"size_capped: {notional:.0f} → {adj_notional:.0f} "
                    f"(participation={participation_rate:.2%} > {self._max_participation:.0%})"
                )
                participation_rate = self._max_participation
        else:
            participation_rate = 0.01   # assume small relative to ADV
            notes.append("adv_unavailable: assuming small participation")

        # Liquidity regime discount
        regime_discounts = {
            "LIQUID":   1.00, "NORMAL":   0.95, "ELEVATED": 0.85,
            "STRESSED": 0.70, "CRITICAL": 0.50, "UNKNOWN":  0.90,
        }
        regime_discount = regime_discounts.get(liquidity_regime, 0.90)
        if regime_discount < 1.0:
            adj_notional *= regime_discount
            notes.append(f"regime_discount={regime_discount:.0%} ({liquidity_regime})")

        # ── Volatility-aware sizing ─────────────────────────────────────────
        if vol_10d is not None and vol_10d > 0:
            # Scale by annualised vol target (target: 15% annualised)
            vol_ann    = vol_10d * math.sqrt(252)
            vol_target = 0.15
            vol_adj    = min(1.0, vol_target / vol_ann) * self._vol_scalar
            adj_notional *= vol_adj
            if vol_adj < 0.95:
                notes.append(f"vol_adj={vol_adj:.2f} (ann_vol={vol_ann:.1%})")

        # ── Slippage model ──────────────────────────────────────────────────
        if vol_10d is not None:
            expected_bps = _almgren_chriss_slippage(
                participation_rate, vol_10d, self._base_bps, self._eta
            )
        else:
            expected_bps = self._base_bps * 2.0   # conservative when vol unknown
            notes.append("vol_unavailable: doubled base slippage")

        # Regime slippage multiplier
        regime_slippage_mult = {
            "LIQUID": 0.8, "NORMAL": 1.0, "ELEVATED": 1.5,
            "STRESSED": 2.5, "CRITICAL": 4.0, "UNKNOWN": 1.2,
        }
        actual_bps = expected_bps * regime_slippage_mult.get(liquidity_regime, 1.2)

        # ── Partial fill ────────────────────────────────────────────────────
        fill_pct = _partial_fill_fraction(participation_rate, liquidity_regime)
        filled_notional = adj_notional * fill_pct
        if fill_pct < 1.0:
            notes.append(f"partial_fill={fill_pct:.1%}")

        # ── Fill price ──────────────────────────────────────────────────────
        fill_price = None
        if mid is not None:
            slippage_factor = actual_bps / 10_000
            fill_price = mid * (1 + slippage_factor) if direction == "LONG" else mid * (1 - slippage_factor)

        result = SimulatedFill(
            ticker               = ticker,
            direction            = direction,
            requested_notional   = round(notional, 2),
            adj_notional         = round(adj_notional, 2),
            fill_pct             = fill_pct,
            filled_notional      = round(filled_notional, 2),
            fill_price           = round(fill_price, 4) if fill_price else None,
            entry_price_ref      = round(mid, 4) if mid else None,
            actual_slippage_bps  = round(actual_bps, 2),
            expected_slippage_bps = round(expected_bps, 2),
            participation_rate   = round(participation_rate, 6),
            vol_daily            = round(vol_10d, 6) if vol_10d else None,
            adv_10d              = round(adv_10d, 0) if adv_10d else None,
            liquidity_regime     = liquidity_regime,
            sizing_notes         = notes,
        )

        logger.info(
            "SimFill[%s %s]: req=%.0f adj=%.0f fill=%.0f%% slippage=%.1fbps regime=%s",
            direction, ticker, notional, adj_notional, fill_pct * 100,
            actual_bps, liquidity_regime,
        )
        return result
