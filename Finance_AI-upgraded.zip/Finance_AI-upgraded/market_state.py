"""
market_state.py — §9 Market-State Feature Layer.

Fetches and caches market context once per pipeline run:
  - VIX level + regime (LOW / ELEVATED / HIGH / SPIKE)
  - Yield curve slope (10Y minus 3M Treasury spread) + state
  - SPY 20-day momentum + above/below 20-day MA
  - Risk-on / risk-off / neutral composite classification
  - Earnings season calendar flag
  - Sector ETF momentum (11 SPDR sectors)
  - Market breadth (SPY vs RSP equal-weight ratio)

All yfinance calls run in a thread executor — never blocks the event loop.
Results are cached for MARKET_STATE_TTL_SECONDS (default 3600).
On any network failure the module returns a neutral fallback state so the
pipeline continues without interruption.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, date
from typing import Optional

from config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Tickers
# ---------------------------------------------------------------------------

_SECTOR_ETFS: dict[str, str] = {
    "technology":              "XLK",
    "financials":              "XLF",
    "energy":                  "XLE",
    "healthcare":              "XLV",
    "industrials":             "XLI",
    "consumer_staples":        "XLP",
    "utilities":               "XLU",
    "materials":               "XLB",
    "real_estate":             "XLRE",
    "communication":           "XLC",
    "consumer_discretionary":  "XLY",
}

_ALL_TICKERS = (
    ["^VIX", "^TNX", "^IRX", "SPY", "RSP"]
    + list(_SECTOR_ETFS.values())
)

# ---------------------------------------------------------------------------
# Regime thresholds
# ---------------------------------------------------------------------------

_VIX_LOW      = 15.0
_VIX_ELEVATED = 25.0
_VIX_HIGH     = 35.0

_SLOPE_NORMAL   =  0.0075   # 10Y-3M in decimal (0.75%)
_SLOPE_INVERTED = -0.0025   # -0.25%

_RISK_ON_VIX_MAX     = 20.0
_RISK_ON_SLOPE_MIN   =  0.0025
_RISK_ON_SPY_MIN     =  0.01
_RISK_OFF_VIX_MIN    = 28.0
_RISK_OFF_SLOPE_MAX  = -0.005
_RISK_OFF_SPY_MAX    = -0.05

# Earnings season windows: (month_start, day_start, month_end, day_end)
_EARNINGS_WINDOWS: list[tuple[int, int, int, int]] = [
    (1, 13, 2, 21),   # Q4 results
    (4, 14, 5, 16),   # Q1 results
    (7, 14, 8, 15),   # Q2 results
    (10, 13, 11, 14), # Q3 results
]

# In-memory cache: (expires_at_unix, MarketState)
_cache: Optional[tuple[float, "MarketState"]] = None
_cache_lock = asyncio.Lock()


# ---------------------------------------------------------------------------
# MarketState dataclass
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class MarketState:
    # VIX
    vix: float = 20.0
    vix_regime: str = "ELEVATED"          # LOW / ELEVATED / HIGH / SPIKE

    # Treasuries (now sourced from Treasury.gov direct as primary)
    yield_10y: float = 0.04               # decimal (e.g. 0.045 = 4.5%)
    yield_3m: float  = 0.04
    yield_slope: float = 0.0             # 10Y − 3M
    yield_curve_state: str = "FLAT"       # NORMAL / FLAT / INVERTED

    # CBOE VIX term structure (new — from CBOE public data)
    vix_9d: float = 20.0
    vix_3m: float = 20.0
    vix_term_slope: float = 0.0          # VIX3M - VIX; positive=contango, negative=stress
    vix_term_score: float = 0.5          # [0,1] — 1 = maximum term stress

    # Equity momentum
    spy_return_20d: float = 0.0
    spy_above_ma20: bool = True

    # Macro composite (from FRED + ECB + Treasury)
    macro_stress_score: float = 0.5      # [0,1] from MacroFeatureEngine
    macro_growth_score: float = 0.5      # [0,1]
    fred_hy_spread: Optional[float] = None   # HY OAS spread
    ecb_eurusd: Optional[float] = None       # EUR/USD
    tsy_10y_2y_spread: Optional[float] = None  # yield curve: 10Y-2Y official

    # Composite regime
    risk_regime: str = "NEUTRAL"          # RISK_ON / RISK_OFF / NEUTRAL

    # Calendar
    earnings_season: bool = False

    # Sector momentum — sector → 20d return (decimal)
    sector_momentum: dict = field(default_factory=dict)

    # Market breadth: RSP_ret_20d − SPY_ret_20d; positive = broad participation
    breadth_score: float = 0.0

    # Metadata
    fetched_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc)
    )
    is_stale: bool = True   # True when using fallback/cached data


# ---------------------------------------------------------------------------
# Classification helpers
# ---------------------------------------------------------------------------

def _classify_vix(vix: float) -> str:
    if vix < _VIX_LOW:
        return "LOW"
    if vix < _VIX_ELEVATED:
        return "ELEVATED"
    if vix < _VIX_HIGH:
        return "HIGH"
    return "SPIKE"


def _classify_yield_curve(slope: float) -> str:
    if slope > _SLOPE_NORMAL:
        return "NORMAL"
    if slope < _SLOPE_INVERTED:
        return "INVERTED"
    return "FLAT"


def _classify_risk(vix: float, slope: float, spy_ret: float) -> str:
    if (
        vix     <= _RISK_ON_VIX_MAX
        and slope  >= _RISK_ON_SLOPE_MIN
        and spy_ret >= _RISK_ON_SPY_MIN
    ):
        return "RISK_ON"
    if (
        vix     >= _RISK_OFF_VIX_MIN
        or slope   <= _RISK_OFF_SLOPE_MAX
        or spy_ret <= _RISK_OFF_SPY_MAX
    ):
        return "RISK_OFF"
    return "NEUTRAL"


def _is_earnings_season(today: Optional[date] = None) -> bool:
    if today is None:
        today = datetime.now(timezone.utc).date()
    for m_start, d_start, m_end, d_end in _EARNINGS_WINDOWS:
        window_start = date(today.year, m_start, d_start)
        window_end   = date(today.year, m_end,   d_end)
        if window_start <= today <= window_end:
            return True
    return False


# ---------------------------------------------------------------------------
# Synchronous fetch (runs in executor)
# ---------------------------------------------------------------------------

def _fetch_sync() -> MarketState:
    """
    Fetch all market data in one yfinance batch call.
    Returns a populated MarketState or the neutral fallback on any error.
    """
    try:
        import yfinance as yf
    except ImportError:
        logger.warning("yfinance not installed — market state will use fallback")
        return _fallback()

    raw: dict[str, object] = {}

    try:
        data = yf.download(
            _ALL_TICKERS,
            period="65d",
            progress=False,
            auto_adjust=True,
            group_by="ticker",
        )
    except Exception as exc:
        logger.warning("yfinance batch download failed: %s", exc)
        return _fallback()

    def _close(ticker: str, n: int = 1):
        """Return last n closing prices for ticker, or empty list on error."""
        try:
            col = data[ticker]["Close"].dropna()
            return list(col.iloc[-n:].values) if len(col) >= n else []
        except Exception:
            return []

    def _ret_20d(ticker: str) -> Optional[float]:
        prices = _close(ticker, 22)
        if len(prices) < 22:
            return None
        return float(prices[-1] / prices[0] - 1)

    # --- VIX ---
    vix_vals = _close("^VIX")
    vix = float(vix_vals[-1]) if vix_vals else 20.0

    # --- Treasuries (^TNX and ^IRX are quoted in percent, e.g. 4.5 = 4.5%) ---
    tnx_vals = _close("^TNX")
    irx_vals = _close("^IRX")
    yield_10y = float(tnx_vals[-1]) / 100.0 if tnx_vals else 0.04
    yield_3m  = float(irx_vals[-1]) / 100.0 if irx_vals else 0.04
    slope     = yield_10y - yield_3m

    # --- SPY ---
    spy_ret_20d = _ret_20d("SPY") or 0.0
    spy_prices  = _close("SPY", 22)
    spy_price   = float(spy_prices[-1]) if spy_prices else None
    spy_ma20    = float(sum(spy_prices[-20:]) / 20) if len(spy_prices) >= 20 else None
    spy_above   = (spy_price > spy_ma20) if (spy_price and spy_ma20) else True

    # --- Sector momentum ---
    sector_momentum: dict[str, float] = {}
    for sector, etf in _SECTOR_ETFS.items():
        ret = _ret_20d(etf)
        if ret is not None:
            sector_momentum[sector] = round(ret, 5)

    # --- Breadth (RSP vs SPY) ---
    rsp_ret = _ret_20d("RSP") or 0.0
    breadth = max(-1.0, min(1.0, (rsp_ret - spy_ret_20d) * 10))

    # --- Enrich with macro_features (Treasury direct, CBOE VIX term, FRED, ECB) ---
    macro_stress  = 0.5
    macro_growth  = 0.5
    hy_spread     = None
    eurusd        = None
    tsy_10y_2y    = None
    vix_9d_val    = vix
    vix_3m_val    = vix
    vix_term_slope_val = 0.0
    vix_term_score_val = 0.5

    try:
        from macro_features import get_engine as _get_macro
        macro_snap = await _get_macro().get_snapshot()

        # Override Treasury yields with official Treasury.gov data if available
        if macro_snap.tsy_10y is not None:
            yield_10y = macro_snap.tsy_10y
        if macro_snap.tsy_3m is not None:
            yield_3m  = macro_snap.tsy_3m
        if macro_snap.tsy_10y and macro_snap.tsy_3m:
            slope = macro_snap.tsy_10y - macro_snap.tsy_3m

        # CBOE VIX term structure
        if macro_snap.cboe_vix is not None:
            vix = macro_snap.cboe_vix
        if macro_snap.cboe_vix9d is not None:
            vix_9d_val = macro_snap.cboe_vix9d
        if macro_snap.cboe_vix3m is not None:
            vix_3m_val = macro_snap.cboe_vix3m
        if macro_snap.cboe_vix_term_slope is not None:
            vix_term_slope_val = macro_snap.cboe_vix_term_slope
        if macro_snap.cboe_vix_term_score is not None:
            vix_term_score_val = macro_snap.cboe_vix_term_score

        # Macro composites
        if macro_snap.macro_stress_score is not None:
            macro_stress = macro_snap.macro_stress_score
        if macro_snap.macro_growth_score is not None:
            macro_growth = macro_snap.macro_growth_score
        hy_spread  = macro_snap.fred_hy_spread
        eurusd     = macro_snap.ecb_eurusd
        tsy_10y_2y = macro_snap.tsy_10y_2y_spread

        # Integrate macro regime with equity regime
        if macro_snap.global_risk_regime == "RISK_OFF":
            # Override equity regime if macro is decisively risk-off
            if _classify_risk(vix, slope, spy_ret_20d) != "RISK_OFF":
                pass   # let equity regime stand; macro is additional signal

    except Exception as exc:
        logger.debug("macro_features enrichment failed: %s", exc)

    return MarketState(
        vix               = round(vix, 2),
        vix_regime        = _classify_vix(vix),
        yield_10y         = round(yield_10y, 5),
        yield_3m          = round(yield_3m,  5),
        yield_slope       = round(slope, 5),
        yield_curve_state = _classify_yield_curve(slope),
        vix_9d            = round(vix_9d_val, 2),
        vix_3m            = round(vix_3m_val, 2),
        vix_term_slope    = round(vix_term_slope_val, 3),
        vix_term_score    = round(vix_term_score_val, 4),
        spy_return_20d    = round(spy_ret_20d, 5),
        spy_above_ma20    = spy_above,
        macro_stress_score = round(macro_stress, 4),
        macro_growth_score = round(macro_growth, 4),
        fred_hy_spread    = hy_spread,
        ecb_eurusd        = eurusd,
        tsy_10y_2y_spread = tsy_10y_2y,
        risk_regime       = _classify_risk(vix, slope, spy_ret_20d),
        earnings_season   = _is_earnings_season(),
        sector_momentum   = sector_momentum,
        breadth_score     = round(breadth, 4),
        fetched_at        = datetime.now(timezone.utc),
        is_stale          = False,
    )


def _fallback() -> MarketState:
    """Neutral MarketState used when data is unavailable."""
    return MarketState(
        vix=20.0, vix_regime="ELEVATED",
        yield_10y=0.04, yield_3m=0.04, yield_slope=0.0,
        yield_curve_state="FLAT",
        spy_return_20d=0.0, spy_above_ma20=True,
        risk_regime="NEUTRAL",
        earnings_season=_is_earnings_season(),
        sector_momentum={}, breadth_score=0.0,
        fetched_at=datetime.now(timezone.utc),
        is_stale=True,
    )


# ---------------------------------------------------------------------------
# Public async API
# ---------------------------------------------------------------------------

async def get_market_state(force_refresh: bool = False) -> MarketState:
    """
    Return the current MarketState, fetching fresh data if the cache has
    expired or force_refresh is True.

    Thread-safe via asyncio.Lock — concurrent callers wait for the first
    fetch to complete rather than all hammering Yahoo Finance simultaneously.
    """
    global _cache

    ttl = float(getattr(settings, "market_state_ttl_seconds", 3600))

    async with _cache_lock:
        now = time.monotonic()
        if not force_refresh and _cache is not None:
            expires_at, cached_state = _cache
            if now < expires_at:
                return cached_state

        logger.info("Fetching fresh market state from Yahoo Finance…")
        loop = asyncio.get_running_loop()
        try:
            state = await loop.run_in_executor(None, _fetch_sync)
        except Exception as exc:
            logger.error("Market state fetch raised unexpectedly: %s", exc)
            state = _fallback()

        _cache = (now + ttl, state)
        logger.info(
            "Market state: VIX=%.1f (%s)  slope=%.2f%%  regime=%s  earnings_season=%s",
            state.vix, state.vix_regime,
            state.yield_slope * 100,
            state.risk_regime,
            state.earnings_season,
        )
        return state
