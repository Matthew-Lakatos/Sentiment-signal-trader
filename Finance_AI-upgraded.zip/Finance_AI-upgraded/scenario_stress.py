"""
scenario_stress.py — #20 Scenario Generation & Stress Engine (§26).

Tests platform robustness to regimes not present in historical backtest data.
Historical data is incomplete — every crisis has unique features.

Scenarios implemented
---------------------
1. VOLATILITY_SHOCK      — VIX spike (25 → 60) with correlated drawdowns
2. LIQUIDITY_FREEZE      — bid-ask spreads 5× normal; partial fills only
3. CONTAGION_CASCADE     — sector-by-sector correlation spike (0.3 → 0.95)
4. MACRO_DISLOCATION     — yield curve inversion + credit spread blowout
5. MOMENTUM_REVERSAL     — all recent winners sell off simultaneously
6. GOV_CONFIDENCE_SHOCK  — governance confidence drops to 0.15 for 5 cycles

For each scenario, the harness:
  1. Constructs a synthetic market environment
  2. Runs the full governance stack through it
  3. Checks that safety mechanisms engage correctly
  4. Records the outcome and any system failures

Usage
-----
    from scenario_stress import ScenarioStressHarness, StressScenario

    harness = ScenarioStressHarness()
    results = await harness.run_all()

    for result in results:
        print(result.scenario, result.passed, result.failures)
"""
from __future__ import annotations

import asyncio
import logging
import math
import random
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Scenario definition
# ---------------------------------------------------------------------------

@dataclass
class StressScenario:
    name:         str
    description:  str
    n_cycles:     int = 10          # number of simulated cycles to run
    seed:         int = 42


@dataclass
class ScenarioResult:
    scenario:        str
    passed:          bool
    failures:        list[str]
    warnings:        list[str]
    kill_switch_engaged: bool
    throttle_mode_at_peak: str
    governance_confidence_min: float
    governance_confidence_mean: float
    n_cycles_run:    int
    notes:           list[str] = field(default_factory=list)
    run_at:          datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def summary(self) -> str:
        status = "✓ PASSED" if self.passed else "✗ FAILED"
        return (
            f"{status} [{self.scenario}]: "
            f"min_gov={self.governance_confidence_min:.2f}  "
            f"peak_mode={self.throttle_mode_at_peak}  "
            f"kill_engaged={self.kill_switch_engaged}  "
            f"failures={self.failures or 'none'}"
        )


# ---------------------------------------------------------------------------
# Synthetic market environments
# ---------------------------------------------------------------------------

def _make_vol_shock_env(cycle: int, n_cycles: int, seed: int) -> dict:
    """VIX spikes from 20 to 60 over first half, recovers over second half."""
    rng = random.Random(seed + cycle)
    peak = cycle / (n_cycles // 2) if cycle <= n_cycles // 2 else 2 - cycle / (n_cycles // 2)
    vix = 20 + 40 * min(1.0, peak)
    return {
        "governance_confidence": max(0.1, 0.85 - 0.60 * min(1.0, peak) + rng.gauss(0, 0.02)),
        "liquidity_stress":      min(1.0, 0.2 + 0.65 * min(1.0, peak)),
        "ic":                    max(-0.15, 0.08 - 0.18 * min(1.0, peak) + rng.gauss(0, 0.01)),
        "execution_errors":      int(rng.random() * 4 * min(1.0, peak)),
        "vix":                   vix,
    }


def _make_liquidity_freeze_env(cycle: int, n_cycles: int, seed: int) -> dict:
    """Liquidity freezes suddenly mid-way through."""
    rng = random.Random(seed + cycle)
    frozen = (n_cycles // 3) <= cycle <= (2 * n_cycles // 3)
    return {
        "governance_confidence": 0.55 - (0.35 if frozen else 0) + rng.gauss(0, 0.03),
        "liquidity_stress":      0.88 if frozen else 0.25 + rng.gauss(0, 0.05),
        "ic":                    0.04 if not frozen else -0.02 + rng.gauss(0, 0.01),
        "execution_errors":      int(rng.random() * (8 if frozen else 1)),
        "infrastructure_errors": int(rng.random() * (3 if frozen else 0)),
    }


def _make_contagion_env(cycle: int, n_cycles: int, seed: int) -> dict:
    """Correlation spike cascades through sectors."""
    rng = random.Random(seed + cycle)
    contagion_level = min(1.0, cycle / (n_cycles * 0.6))
    return {
        "governance_confidence": max(0.15, 0.80 - 0.55 * contagion_level + rng.gauss(0, 0.02)),
        "liquidity_stress":      min(0.90, 0.25 + 0.60 * contagion_level),
        "ic":                    max(-0.12, 0.06 - 0.16 * contagion_level + rng.gauss(0, 0.01)),
        "execution_errors":      int(rng.random() * 3 * contagion_level),
    }


def _make_macro_dislocation_env(cycle: int, n_cycles: int, seed: int) -> dict:
    """Macro dislocation: sustained bad environment."""
    rng = random.Random(seed + cycle)
    return {
        "governance_confidence": 0.40 + rng.gauss(0, 0.05),
        "liquidity_stress":      0.65 + rng.gauss(0, 0.05),
        "ic":                    0.01 + rng.gauss(0, 0.02),
        "execution_errors":      int(rng.random() * 2),
    }


def _make_momentum_reversal_env(cycle: int, n_cycles: int, seed: int) -> dict:
    """Momentum reversal: short sharp shock then normalization."""
    rng = random.Random(seed + cycle)
    shock = cycle <= 3
    return {
        "governance_confidence": 0.25 if shock else (0.60 + rng.gauss(0, 0.03)),
        "liquidity_stress":      0.80 if shock else (0.35 + rng.gauss(0, 0.05)),
        "ic":                    -0.10 if shock else (0.05 + rng.gauss(0, 0.02)),
        "consecutive_losses":    5 if shock else rng.randint(0, 1),
        "execution_errors":      int(rng.random() * (6 if shock else 1)),
    }


def _make_gov_shock_env(cycle: int, n_cycles: int, seed: int) -> dict:
    """Governance confidence drops to 0.15 for 5 cycles."""
    rng = random.Random(seed + cycle)
    shocked = 2 <= cycle <= 6
    return {
        "governance_confidence": 0.15 if shocked else (0.80 + rng.gauss(0, 0.03)),
        "liquidity_stress":      0.35 + rng.gauss(0, 0.05),
        "ic":                    0.05 + rng.gauss(0, 0.02),
        "execution_errors":      0,
    }


_SCENARIO_ENVS: dict[str, Callable] = {
    "VOLATILITY_SHOCK":    _make_vol_shock_env,
    "LIQUIDITY_FREEZE":    _make_liquidity_freeze_env,
    "CONTAGION_CASCADE":   _make_contagion_env,
    "MACRO_DISLOCATION":   _make_macro_dislocation_env,
    "MOMENTUM_REVERSAL":   _make_momentum_reversal_env,
    "GOV_CONFIDENCE_SHOCK": _make_gov_shock_env,
}

_SCENARIOS = [
    StressScenario("VOLATILITY_SHOCK",    "VIX spike 20→60 with correlated drawdowns",       n_cycles=12),
    StressScenario("LIQUIDITY_FREEZE",    "Bid-ask 5× normal; execution failures",            n_cycles=12),
    StressScenario("CONTAGION_CASCADE",   "Sector correlation spike 0.3→0.95",                n_cycles=15),
    StressScenario("MACRO_DISLOCATION",   "Yield inversion + credit spread blowout",          n_cycles=10),
    StressScenario("MOMENTUM_REVERSAL",   "All recent winners reverse simultaneously",        n_cycles=10),
    StressScenario("GOV_CONFIDENCE_SHOCK","Governance collapses to 0.15 for 5 cycles",        n_cycles=10),
]


# ---------------------------------------------------------------------------
# Harness
# ---------------------------------------------------------------------------

class ScenarioStressHarness:
    """
    Runs all stress scenarios against the governance stack and
    validates that safety mechanisms engage correctly.
    """

    async def run_all(self, scenarios: Optional[list[StressScenario]] = None) -> list[ScenarioResult]:
        scenarios = scenarios or _SCENARIOS
        results   = []
        for scenario in scenarios:
            logger.info("Running stress scenario: %s", scenario.name)
            result = await self.run_scenario(scenario)
            results.append(result)
            logger.info(result.summary())
        return results

    async def run_scenario(self, scenario: StressScenario) -> ScenarioResult:
        """Run a single scenario and validate governance responses."""
        from kill_switch import KillSwitch
        from risk_throttle import RiskThrottle
        from governance_engine import GovernanceReport, _derive_mode

        # Fresh isolated instances for each scenario
        ks       = KillSwitch()
        throttle = RiskThrottle(hysteresis_cycles=2)   # faster for testing

        env_fn = _SCENARIO_ENVS.get(scenario.name)
        if env_fn is None:
            return ScenarioResult(
                scenario=scenario.name, passed=False,
                failures=[f"No environment function for {scenario.name}"],
                warnings=[], kill_switch_engaged=False,
                throttle_mode_at_peak="UNKNOWN",
                governance_confidence_min=1.0,
                governance_confidence_mean=1.0,
                n_cycles_run=0,
            )

        failures:  list[str] = []
        warnings:  list[str] = []
        conf_vals: list[float] = []
        throttle_modes: list[str] = []
        ks_engaged = False

        for cycle in range(scenario.n_cycles):
            env = env_fn(cycle, scenario.n_cycles, scenario.seed)

            # Governance report (synthetic)
            gov_conf = max(0.0, min(1.0, env.get("governance_confidence", 0.7)))
            mode, scalar = _derive_mode(gov_conf)
            report = GovernanceReport(
                governance_confidence   = gov_conf,
                governance_uncertainty  = 0.15,
                governance_stability    = 0.60,
                mode                    = mode,
                component_scores        = {"synthetic": gov_conf},
                warnings                = [],
                recommended_size_scalar = scalar,
            )

            # Kill switch cycle
            ks_state = await ks.record_cycle(
                governance_confidence = gov_conf,
                liquidity_stress      = env.get("liquidity_stress"),
                execution_errors      = env.get("execution_errors", 0),
                infrastructure_errors = env.get("infrastructure_errors", 0),
                ic                    = env.get("ic"),
                consecutive_losses    = env.get("consecutive_losses", 0),
            )

            # Throttle update
            t_state = throttle.update(report)

            conf_vals.append(gov_conf)
            throttle_modes.append(t_state.mode)

            if not ks.is_active():
                ks_engaged = True

        # ── Validation rules ────────────────────────────────────────────────
        conf_min  = min(conf_vals)
        conf_mean = sum(conf_vals) / len(conf_vals)
        peak_mode = max(set(throttle_modes), key=throttle_modes.count)

        # Rule 1: When governance confidence < 0.35, system should have engaged DEFENSIVE+
        min_conf_cycle = conf_vals.index(conf_min)
        restrictive_modes = {"DEFENSIVE", "SUSPENDED"}
        mode_at_worst = throttle_modes[min(min_conf_cycle, len(throttle_modes) - 1)]
        if conf_min < 0.35 and mode_at_worst not in restrictive_modes:
            failures.append(
                f"Safety failure: min_confidence={conf_min:.3f} but mode={mode_at_worst}"
            )

        # Rule 2: VOLATILITY_SHOCK / CONTAGION_CASCADE should trigger kill switch
        high_stress = {"VOLATILITY_SHOCK", "CONTAGION_CASCADE", "LIQUIDITY_FREEZE"}
        if scenario.name in high_stress and not ks_engaged:
            warnings.append(f"{scenario.name}: expected kill-switch engagement but didn't trigger")

        # Rule 3: GOV_CONFIDENCE_SHOCK should suppress all new positions
        if scenario.name == "GOV_CONFIDENCE_SHOCK":
            suspended_seen = any(m == "SUSPENDED" for m in throttle_modes)
            if not suspended_seen:
                failures.append("GOV_CONFIDENCE_SHOCK: throttle never reached SUSPENDED mode")

        # Rule 4: System should not stay in FULL mode during any shock
        if conf_min < 0.50 and all(m == "FULL" for m in throttle_modes):
            failures.append("Throttle never responded to stress conditions")

        passed = len(failures) == 0

        return ScenarioResult(
            scenario                   = scenario.name,
            passed                     = passed,
            failures                   = failures,
            warnings                   = warnings,
            kill_switch_engaged        = ks_engaged,
            throttle_mode_at_peak      = peak_mode,
            governance_confidence_min  = round(conf_min, 4),
            governance_confidence_mean = round(conf_mean, 4),
            n_cycles_run               = scenario.n_cycles,
        )
