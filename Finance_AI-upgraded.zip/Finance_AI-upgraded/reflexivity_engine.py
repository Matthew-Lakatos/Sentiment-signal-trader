"""
reflexivity_engine.py — §6 Reflexivity Engine (split from contradiction_detector).

Models recursive narrative-price feedback loops. Answers:
"Is this event being amplified by reflexive market behaviour?"

Reflexivity (Soros): narratives change prices, which change narratives,
which change prices — a recursive feedback loop. Identifying when a
narrative is in this loop is alpha-critical: it tells you both that
the current move is accelerating AND that it is fragile.

This module detects four reflexivity signals:

1. PANIC_CASCADE
   Short-term price acceleration + narrative velocity spike.
   The market and the news are amplifying each other.

2. BUBBLE_DYNAMIC
   Sustained price trend + narrative saturation near peak.
   The narrative has "used up" its explanatory power.

3. NARRATIVE_EXHAUSTION
   High narrative volume but decelerating price response.
   The crowd has priced in the story.

4. MOMENTUM_FEEDBACK
   Price momentum leads narrative → price is running ahead of news.

Outputs (ReflexivityResult)
--------------------------
  reflexivity_score    ∈ [0, 1]   — overall reflexivity intensity
  feedback_type        str        — dominant type (or NONE)
  feedback_intensity   ∈ [0, 1]
  panic_probability    ∈ [0, 1]
  bubble_probability   ∈ [0, 1]
  exhaustion_score     ∈ [0, 1]
  signal_adjustment    float      — multiply signal score by this [0.2, 1.3]

Usage
-----
    from reflexivity_engine import ReflexivityEngine

    engine = ReflexivityEngine()
    result = await engine.analyse(event, ticker="AAPL")

    # Adjust signal score
    adjusted = raw_signal * result.signal_adjustment
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_PANIC_PRICE_THRESHOLD    = 0.02   # 2% intraday move = potential panic
_BUBBLE_TREND_DAYS        = 20     # look-back window for trend detection
_EXHAUSTION_SATURATION    = 0.70   # narrative saturation above this = exhaustion risk
_MOMENTUM_LEAD_HOURS      = 4      # hours before narrative for price-lead detection
_PRICE_CACHE_TTL          = 300    # seconds


# ---------------------------------------------------------------------------
# Result
# ---------------------------------------------------------------------------

@dataclass
class ReflexivityResult:
    ticker:              str
    reflexivity_score:   float = 0.0    # [0, 1]
    feedback_type:       str   = "NONE" # PANIC_CASCADE | BUBBLE_DYNAMIC | EXHAUSTION | MOMENTUM_FEEDBACK | NONE
    feedback_intensity:  float = 0.0
    panic_probability:   float = 0.0
    bubble_probability:  float = 0.0
    exhaustion_score:    float = 0.0
    momentum_feedback:   float = 0.0
    price_acceleration:  Optional[float] = None  # 1d return minus 5d average daily return
    narrative_velocity:  Optional[float] = None  # articles/day over last 24h vs 7d avg
    signal_adjustment:   float = 1.0    # multiply raw signal by this
    notes:               list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Price data helper
# ---------------------------------------------------------------------------

_price_cache: dict[str, tuple[float, object]] = {}


def _fetch_price_data_sync(ticker: str, period: str = "30d"):
    """Fetch OHLCV from yfinance. Returns DataFrame or None."""
    try:
        import yfinance as yf
        df = yf.download(ticker, period=period, progress=False, auto_adjust=True)
        return df if not df.empty else None
    except Exception as exc:
        logger.debug("Price fetch failed for %s: %s", ticker, exc)
        return None


async def _get_price_data(ticker: str):
    now = time.monotonic()
    if ticker in _price_cache:
        expires, cached = _price_cache[ticker]
        if now < expires:
            return cached
    loop = asyncio.get_running_loop()
    df = await loop.run_in_executor(None, _fetch_price_data_sync, ticker)
    _price_cache[ticker] = (now + _PRICE_CACHE_TTL, df)
    return df


# ---------------------------------------------------------------------------
# Sub-detectors
# ---------------------------------------------------------------------------

def _detect_panic_cascade(df, narrative_velocity: Optional[float]) -> tuple[float, list[str]]:
    """
    PANIC_CASCADE: simultaneous price acceleration + narrative spike.
    Returns (probability, notes).
    """
    notes = []
    if df is None or len(df) < 5:
        return 0.0, ["no_price_data"]

    import numpy as np
    closes = df["Close"].values.astype(float)

    # 1-day return vs 5-day average
    ret_1d    = (closes[-1] / closes[-2] - 1) if len(closes) >= 2 else 0.0
    avg_ret_5d = abs(np.mean(np.diff(closes[-6:]) / closes[-6:-1])) if len(closes) >= 6 else 0.0

    price_accel = abs(ret_1d) - avg_ret_5d
    is_price_spike = abs(ret_1d) > _PANIC_PRICE_THRESHOLD

    if not is_price_spike:
        return 0.0, []

    panic_prob = min(1.0, abs(ret_1d) / 0.05)  # normalise: 5% move → full panic signal

    # Amplify if narrative velocity is also elevated
    if narrative_velocity is not None and narrative_velocity > 2.0:
        panic_prob = min(1.0, panic_prob + 0.2)
        notes.append("narrative_velocity_amplifies_panic")

    notes.append(f"price_spike={ret_1d:.2%}")
    return round(panic_prob, 4), notes


def _detect_bubble_dynamic(df) -> tuple[float, list[str]]:
    """
    BUBBLE_DYNAMIC: sustained trend + decelerating narrative response.
    Returns (probability, notes).
    """
    notes = []
    if df is None or len(df) < _BUBBLE_TREND_DAYS:
        return 0.0, ["insufficient_history"]

    import numpy as np
    closes = df["Close"].values.astype(float)

    ret_20d  = (closes[-1] / closes[-_BUBBLE_TREND_DAYS] - 1)
    ret_5d   = (closes[-1] / closes[-5] - 1) if len(closes) >= 5 else 0.0

    # Bubble signal: large 20d trend, but recent 5d deceleration
    if abs(ret_20d) < 0.10:
        return 0.0, []

    deceleration = abs(ret_20d) - abs(ret_5d) * 4  # compare annualised
    if deceleration < 0:
        return 0.0, []

    bubble_prob = min(1.0, abs(ret_20d) / 0.30 * 0.7 + deceleration / 0.10 * 0.3)
    notes.append(f"trend_20d={ret_20d:.2%}  decel={deceleration:.3f}")
    return round(bubble_prob, 4), notes


def _detect_exhaustion(
    narrative_saturation: Optional[float],
    price_response: Optional[float],
) -> tuple[float, list[str]]:
    """
    NARRATIVE_EXHAUSTION: high narrative volume but weak price response.
    """
    notes = []
    if narrative_saturation is None:
        return 0.0, ["no_saturation_data"]

    exhaustion = 0.0

    if narrative_saturation > _EXHAUSTION_SATURATION:
        exhaustion = (narrative_saturation - _EXHAUSTION_SATURATION) / (1.0 - _EXHAUSTION_SATURATION)
        notes.append(f"saturation={narrative_saturation:.2f}")

        # Amplify if price response is weak despite saturated narrative
        if price_response is not None and abs(price_response) < 0.005:
            exhaustion = min(1.0, exhaustion + 0.2)
            notes.append("price_response_weak")

    return round(exhaustion, 4), notes


def _detect_momentum_feedback(df) -> tuple[float, list[str]]:
    """
    MOMENTUM_FEEDBACK: price is accelerating beyond fundamentals.
    Uses price relative to its own short-term mean-reversion model.
    """
    notes = []
    if df is None or len(df) < 10:
        return 0.0, ["no_price_data"]

    import numpy as np
    closes = df["Close"].values.astype(float)

    # Compare current price to 10d Bollinger-band upper bound
    mean_10d  = np.mean(closes[-10:])
    std_10d   = np.std(closes[-10:])
    if std_10d == 0:
        return 0.0, []

    z = (closes[-1] - mean_10d) / std_10d
    if abs(z) < 1.5:
        return 0.0, []

    momentum_feedback = min(1.0, (abs(z) - 1.5) / 2.5)
    notes.append(f"z_vs_10d_band={z:.2f}")
    return round(momentum_feedback, 4), notes


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class ReflexivityEngine:
    """
    Detects reflexive price-narrative feedback loops.
    Lightweight: uses only price data + event narrative metadata.
    """

    async def analyse(
        self,
        event: dict,
        ticker: Optional[str] = None,
        narrative_velocity:    Optional[float] = None,   # articles/day ratio; from narrative_dynamics
        narrative_saturation:  Optional[float] = None,   # from narrative_dynamics
    ) -> ReflexivityResult:
        """
        Analyse a single event for reflexivity signals.

        Parameters
        ----------
        event                : the scraped event dict
        ticker               : override ticker (defaults to event['target_entity'])
        narrative_velocity   : articles-per-day ratio (current vs 7d avg)
        narrative_saturation : [0,1] narrative saturation score
        """
        ticker = ticker or event.get("target_entity", "")
        result = ReflexivityResult(ticker=ticker)

        if not ticker:
            result.notes.append("no_ticker")
            return result

        # Fetch price data
        df = await _get_price_data(ticker)

        # Run sub-detectors
        panic_prob, panic_notes = _detect_panic_cascade(df, narrative_velocity)
        bubble_prob, bubble_notes = _detect_bubble_dynamic(df)

        price_response = None
        if df is not None and len(df) >= 2:
            closes = df["Close"].values.astype(float)
            price_response = float(closes[-1] / closes[-2] - 1)

        exhaustion, exh_notes = _detect_exhaustion(narrative_saturation, price_response)
        momentum, mom_notes   = _detect_momentum_feedback(df)

        # Composite score
        reflexivity = max(panic_prob, bubble_prob, exhaustion, momentum)
        # Blend for smoothing
        blend = (
            0.35 * panic_prob
          + 0.25 * bubble_prob
          + 0.20 * exhaustion
          + 0.20 * momentum
        )
        reflexivity_score = round((reflexivity + blend) / 2.0, 4)

        # Dominant type
        scores = {
            "PANIC_CASCADE":      panic_prob,
            "BUBBLE_DYNAMIC":     bubble_prob,
            "NARRATIVE_EXHAUSTION": exhaustion,
            "MOMENTUM_FEEDBACK":  momentum,
        }
        feedback_type = max(scores, key=lambda k: scores[k])
        if scores[feedback_type] < 0.15:
            feedback_type = "NONE"

        # Signal adjustment
        # Reflexivity cuts both ways:
        #   PANIC_CASCADE       → strong signal (riding the cascade) but fragile: discount
        #   BUBBLE_DYNAMIC      → significant discount (topping signal)
        #   NARRATIVE_EXHAUSTION → significant discount (story priced in)
        #   MOMENTUM_FEEDBACK   → mild discount (over-extension)
        adjustment_map = {
            "NONE":                 1.00,
            "PANIC_CASCADE":        0.70,   # reduce — fragile cascade
            "BUBBLE_DYNAMIC":       0.40,   # reduce significantly
            "NARRATIVE_EXHAUSTION": 0.50,   # reduce — story told
            "MOMENTUM_FEEDBACK":    0.80,   # mild reduce
        }
        signal_adjustment = adjustment_map.get(feedback_type, 1.0)

        result.reflexivity_score  = reflexivity_score
        result.feedback_type      = feedback_type
        result.feedback_intensity = scores.get(feedback_type, 0.0)
        result.panic_probability  = panic_prob
        result.bubble_probability = bubble_prob
        result.exhaustion_score   = exhaustion
        result.momentum_feedback  = momentum
        result.price_acceleration = price_response
        result.narrative_velocity = narrative_velocity
        result.signal_adjustment  = signal_adjustment
        result.notes              = panic_notes + bubble_notes + exh_notes + mom_notes

        if reflexivity_score > 0.5:
            logger.info(
                "Reflexivity[%s]: score=%.2f  type=%s  adj=%.2f",
                ticker, reflexivity_score, feedback_type, signal_adjustment,
            )
        return result
