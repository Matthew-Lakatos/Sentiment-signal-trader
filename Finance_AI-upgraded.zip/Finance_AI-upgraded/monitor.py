"""
monitor.py — Prometheus metrics + in-process timing helper.
Metrics are exported on /metrics via a background HTTP server.
"""
from __future__ import annotations
import time
import logging

from config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Prometheus counters / histograms / gauges
# ---------------------------------------------------------------------------
try:
    from prometheus_client import (
        Counter, Histogram, Gauge,
        start_http_server as _start_prom,
        REGISTRY,
    )
    _PROM_AVAILABLE = True
except ImportError:
    _PROM_AVAILABLE = False
    logger.warning("prometheus_client not installed — metrics will not be exported")

if _PROM_AVAILABLE:
    events_scraped   = Counter("scraper_events_total",     "Events scraped",        ["domain", "status"])
    scrape_latency   = Histogram("scraper_latency_seconds", "Per-URL scrape time",   buckets=[0.5,1,2,5,10,20,30])
    nlp_latency      = Histogram("scraper_nlp_seconds",    "Per-article NLP time",  buckets=[0.1,0.5,1,2,5])
    dead_sources     = Gauge("scraper_dead_sources_total", "Dead source count")
    alerts_fired     = Counter("scraper_alerts_total",     "Alerts dispatched",     ["type", "severity"])
    pipeline_runs    = Counter("scraper_pipeline_runs_total", "Pipeline run count")
    duplicate_events = Counter("scraper_duplicates_total",   "Duplicate events detected")


def start_metrics_server() -> None:
    if not _PROM_AVAILABLE:
        return
    try:
        _start_prom(settings.prometheus_port)
        logger.info("Prometheus metrics on :%d/metrics", settings.prometheus_port)
    except OSError:
        logger.warning("Prometheus port %d already in use", settings.prometheus_port)


def record_scrape(domain: str, success: bool, duration: float) -> None:
    if not _PROM_AVAILABLE:
        return
    events_scraped.labels(domain=domain, status="ok" if success else "fail").inc()
    scrape_latency.observe(duration)


def record_nlp(duration: float) -> None:
    if _PROM_AVAILABLE:
        nlp_latency.observe(duration)


def record_duplicate() -> None:
    if _PROM_AVAILABLE:
        duplicate_events.inc()


def record_alert(alert_type: str, severity: str) -> None:
    if _PROM_AVAILABLE:
        alerts_fired.labels(type=alert_type, severity=severity).inc()


def record_pipeline_run() -> None:
    if _PROM_AVAILABLE:
        pipeline_runs.inc()


def update_dead_sources(count: int) -> None:
    if _PROM_AVAILABLE:
        dead_sources.set(count)


# ---------------------------------------------------------------------------
# In-process timer (used in main.py for per-stage timing)
# ---------------------------------------------------------------------------

class Timer:
    def __enter__(self):
        self._start = time.perf_counter()
        return self

    def __exit__(self, *_):
        self.duration = time.perf_counter() - self._start


class Monitor:
    """Lightweight per-pipeline-run accumulator (not persisted)."""
    def __init__(self):
        self.scraped      = 0
        self.cached       = 0
        self.duplicates   = 0
        self.persisted    = 0
        self.scrape_times: list[float] = []
        self.nlp_times:    list[float] = []

    def record_scrape(self, duration: float):
        self.scraped += 1
        self.scrape_times.append(duration)

    def record_cached(self):
        self.cached += 1

    def record_nlp(self, duration: float):
        self.nlp_times.append(duration)

    def record_duplicate(self):
        self.duplicates += 1
        record_duplicate()

    def summary(self) -> dict:
        return {
            "scraped":        self.scraped,
            "cached":         self.cached,
            "duplicates":     self.duplicates,
            "persisted":      self.persisted,
            "avg_scrape_s":   round(sum(self.scrape_times) / max(1, len(self.scrape_times)), 3),
            "avg_nlp_s":      round(sum(self.nlp_times)    / max(1, len(self.nlp_times)),    3),
        }
