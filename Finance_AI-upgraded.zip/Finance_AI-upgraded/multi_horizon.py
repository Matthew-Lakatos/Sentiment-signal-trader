"""
multi_horizon.py — §20 Multi-Horizon Alpha System.

Runs three simultaneous models for different alpha decay structures and
blends their outputs into a single confidence-weighted signal.

Three horizon layers
--------------------
  T+1  Intraday reaction      Fast decay; captures price impact of surprise
  T+5  Short-term repricing   Medium decay; narrative digestion
  T+20 Thematic diffusion     Slow decay; structural information re-pricing

Each horizon maintains its own OnlineLearner with a horizon-specific
forgetting factor — faster decay for T+1 (market reacts quickly, learns
fast) and slower decay for T+20 (structural trends persist).

Confidence-weighted blending
----------------------------
The blended signal is:

    blended = Σ_h  w_h × signal_h

where w_h = confidence_h / Σ_h confidence_h

confidence_h is the geometric mean of:
  - |rolling_IC_h|       (predictive power at this horizon)
  - (1 − IC_std_h)       (IC stability at this horizon)

Clamped to [0, 1].

If all confidences are zero (insufficient data), falls back to equal
weighting across the three horizon signals.

Event-type horizon affinity
----------------------------
Certain event types have known decay structures:

  earnings     → T+1 dominates (immediate price reaction)
  macro        → T+5 to T+20  (slower macro repricing)
  contract     → T+5           (medium-speed digestion)
  regulation   → T+20          (structural impact)
  rumor        → T+1 only      (fast decay if unconfirmed)
  analysis     → T+5 to T+20  (no immediate catalyst)
  geopolitical → T+20          (long-tail uncertainty)

When event_type affinity overrides the IC-based blend, the dominant
horizon's weight is boosted by EVENT_TYPE_BOOST (default 0.40) at the
expense of the others.

Usage
-----
    from multi_horizon import MultiHorizonModel

    model = MultiHorizonModel()

    # Feed realised returns to update all three learners
    model.update_batch(events_with_fwd_rets)

    # Score a new event
    result = model.score(event)
    print(result.blended_score)
    print(result.by_horizon)     # {"T1": 0.42, "T5": 0.38, "T20": 0.25}
    print(result.dominant_horizon)
    print(result.confidences)    # {"T1": 0.72, "T5": 0.61, "T20": 0.44}
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from typing import Optional

from online_learning import OnlineLearner, _event_to_features, _ONLINE_FEATURES

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Horizon definitions
# ---------------------------------------------------------------------------

HORIZONS: dict[str, int] = {"T1": 1, "T5": 5, "T20": 20}

# Forgetting factors per horizon
# T+1  → fast adaptation (effective window ~7 obs at λ=0.90)
# T+5  → medium           (effective window ~23 at λ=0.97)
# T+20 → slow             (effective window ~70 at λ=0.99)
_FORGETTING: dict[str, float] = {"T1": 0.90, "T5": 0.97, "T20": 0.99}

# Rolling IC history length per learner
_HISTORY_LEN = 200

# Boost applied to the affinitive horizon weight when event_type matches
EVENT_TYPE_BOOST = 0.40

# Minimum events before IC confidence is non-zero
_MIN_IC_EVENTS = 20

# Event-type → dominant horizon key
_EVENT_TYPE_AFFINITY: dict[str, str] = {
    "earnings":    "T1",
    "rumor":       "T1",
    "contract":    "T5",
    "product_launch": "T5",
    "macro":       "T20",
    "regulation":  "T20",
    "geopolitical":"T20",
    "analysis":    "T5",
    "unknown":     "T5",
}


# ---------------------------------------------------------------------------
# Score result
# ---------------------------------------------------------------------------

@dataclass
class HorizonScoreResult:
    blended_score:     float               # confidence-weighted blend [-1, 1]
    by_horizon:        dict[str, float]    # {horizon_key: raw score}
    confidences:       dict[str, float]    # {horizon_key: confidence [0,1]}
    weights_used:      dict[str, float]    # {horizon_key: normalised weight}
    dominant_horizon:  str                 # e.g. "T1"
    event_type_affinity: Optional[str]     # horizon key from event type, or None
    n_updates:         dict[str, int]      # {horizon_key: n_updates}


# ---------------------------------------------------------------------------
# IC tracker (rolling mean and std of per-window IC)
# ---------------------------------------------------------------------------

class _ICTracker:
    """Maintains a rolling history of IC values for one horizon."""

    def __init__(self, maxlen: int = 20):
        self._history: list[float] = []
        self._maxlen  = maxlen

    def push(self, ic: float) -> None:
        if math.isfinite(ic):
            self._history.append(ic)
            if len(self._history) > self._maxlen:
                self._history.pop(0)

    @property
    def mean(self) -> float:
        if not self._history:
            return 0.0
        return sum(self._history) / len(self._history)

    @property
    def std(self) -> float:
        if len(self._history) < 2:
            return 1.0   # max uncertainty
        mu  = self.mean
        var = sum((v - mu) ** 2 for v in self._history) / (len(self._history) - 1)
        return math.sqrt(var)

    @property
    def confidence(self) -> float:
        """Geometric mean of |mean_IC| and (1 − std_IC), clamped to [0,1]."""
        ic_strength  = min(1.0, abs(self.mean))
        ic_stability = max(0.0, 1.0 - self.std)
        return round(math.sqrt(ic_strength * ic_stability), 4)


# ---------------------------------------------------------------------------
# MultiHorizonModel
# ---------------------------------------------------------------------------

class MultiHorizonModel:
    """
    Manages three OnlineLearners (T+1, T+5, T+20) and blends their signals.
    """

    def __init__(self):
        self._learners: dict[str, OnlineLearner] = {
            h: OnlineLearner(
                features    = _ONLINE_FEATURES,
                forgetting  = _FORGETTING[h],
                history_len = _HISTORY_LEN,
            )
            for h in HORIZONS
        }
        self._ic_trackers: dict[str, _ICTracker] = {h: _ICTracker() for h in HORIZONS}
        self._eval_buffer: dict[str, list[dict]] = {h: [] for h in HORIZONS}
        self._eval_window  = 50   # events before computing IC estimate

        logger.info("MultiHorizonModel initialised: horizons=%s", list(HORIZONS.keys()))

    # ── Update ──────────────────────────────────────────────────────────────

    def update_batch(self, events: list[dict]) -> dict[str, int]:
        """
        Feed realised return data to all three learners simultaneously.
        Returns {horizon_key: n_updates}.
        """
        updated: dict[str, int] = {}
        for hk, horizon_days in HORIZONS.items():
            n = self._learners[hk].update_batch(events, horizon=horizon_days)
            updated[hk] = n

            # Rolling IC estimate — use the same events as a hold-out evaluation
            self._eval_buffer[hk].extend(events)
            if len(self._eval_buffer[hk]) >= self._eval_window:
                ic = self._estimate_ic(hk, self._eval_buffer[hk])
                self._ic_trackers[hk].push(ic)
                self._eval_buffer[hk].clear()

        return updated

    def _estimate_ic(self, hk: str, events: list[dict]) -> float:
        """Spearman IC of learner's predicted score vs realised return."""
        key    = f"fwd_ret_{HORIZONS[hk]}d"
        learner = self._learners[hk]
        w_dict  = learner.weights

        pairs: list[tuple[float, float]] = []
        for ev in events:
            ret = ev.get(key) or ev.get("fwd_ret")
            if ret is None or not math.isfinite(float(ret)):
                continue
            x_dict = _event_to_features(ev)
            pred   = sum(w_dict.get(f, 0.0) * x_dict.get(f, 0.0)
                         for f in _ONLINE_FEATURES)
            pairs.append((pred, float(ret)))

        if len(pairs) < 5:
            return float("nan")

        preds, rets = zip(*pairs)
        return _spearman_list(list(preds), list(rets))

    # ── Score ────────────────────────────────────────────────────────────────

    def score(self, event: dict) -> HorizonScoreResult:
        """
        Score a single event across all three horizons and return the
        confidence-weighted blended result.
        """
        x_dict = _event_to_features(event)

        # Raw score from each horizon's learner
        by_horizon: dict[str, float] = {}
        for hk in HORIZONS:
            w = self._learners[hk].weights
            raw = sum(w.get(f, 0.0) * x_dict.get(f, 0.0) for f in _ONLINE_FEATURES)
            by_horizon[hk] = round(max(-1.0, min(1.0, raw)), 4)

        # Confidence per horizon
        confidences = {hk: self._ic_trackers[hk].confidence for hk in HORIZONS}

        # Event-type affinity
        event_type   = (event.get("event_type") or "unknown").lower()
        affinity_key: Optional[str] = _EVENT_TYPE_AFFINITY.get(event_type)

        # Compute normalised weights
        weights = self._compute_weights(confidences, affinity_key)

        # Blended score
        blended = sum(weights[hk] * by_horizon[hk] for hk in HORIZONS)
        blended = round(max(-1.0, min(1.0, blended)), 4)

        dominant = max(weights, key=lambda hk: weights[hk])
        n_updates = {hk: self._learners[hk].n_updates for hk in HORIZONS}

        return HorizonScoreResult(
            blended_score       = blended,
            by_horizon          = by_horizon,
            confidences         = confidences,
            weights_used        = {hk: round(weights[hk], 4) for hk in HORIZONS},
            dominant_horizon    = dominant,
            event_type_affinity = affinity_key,
            n_updates           = n_updates,
        )

    def _compute_weights(
        self,
        confidences:  dict[str, float],
        affinity_key: Optional[str],
    ) -> dict[str, float]:
        """
        Compute blend weights from confidences, applying event-type boost.
        Falls back to equal weighting if total confidence is near zero.
        """
        total_conf = sum(confidences.values())

        if total_conf < 1e-6:
            # Equal weights fallback — guaranteed sum=1.0 via remainder adjustment
            keys    = list(HORIZONS.keys())
            n       = len(keys)
            rounded = [round(1.0 / n, 4)] * n
            diff    = round(1.0 - sum(rounded), 4)
            if diff != 0.0:
                rounded[0] = round(rounded[0] + diff, 4)
            return {hk: rounded[i] for i, hk in enumerate(keys)}

        # Base weights from IC confidence
        weights = {hk: confidences[hk] / total_conf for hk in HORIZONS}

        # Apply affinity boost
        if affinity_key and affinity_key in weights:
            boost     = EVENT_TYPE_BOOST
            # Redistribute boost from non-affinity horizons proportionally
            non_keys  = [hk for hk in HORIZONS if hk != affinity_key]
            available = min(boost, sum(weights[hk] for hk in non_keys))
            weights[affinity_key] += available
            # Reduce non-affinity proportionally
            non_total = sum(weights[hk] for hk in non_keys) or 1.0
            for hk in non_keys:
                fraction       = weights[hk] / non_total
                weights[hk]   -= fraction * available

        # Re-normalise to ensure sum = 1.0 exactly (round-safe)
        total = sum(weights.values()) or 1.0
        keys  = list(HORIZONS.keys())
        raw   = [max(0.0, weights[hk] / total) for hk in keys]
        rounded = [round(v, 4) for v in raw]
        diff    = round(1.0 - sum(rounded), 4)
        if diff != 0.0:
            idx = max(range(len(rounded)), key=lambda i: rounded[i])
            rounded[idx] = round(rounded[idx] + diff, 4)
        return {hk: rounded[i] for i, hk in enumerate(keys)}

    # ── Diagnostics ─────────────────────────────────────────────────────────

    def summary(self) -> dict:
        return {
            hk: {
                "n_updates":   self._learners[hk].n_updates,
                "ic_mean":     round(self._ic_trackers[hk].mean, 5),
                "ic_std":      round(self._ic_trackers[hk].std, 5),
                "confidence":  self._ic_trackers[hk].confidence,
                "weights":     self._learners[hk].weights,
            }
            for hk in HORIZONS
        }

    def reset(self) -> None:
        for hk in HORIZONS:
            self._learners[hk].reset()
            self._ic_trackers[hk] = _ICTracker()
            self._eval_buffer[hk].clear()


# ---------------------------------------------------------------------------
# Spearman helper (pure Python)
# ---------------------------------------------------------------------------

def _spearman_list(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 3:
        return float("nan")

    def _rank(lst: list[float]) -> list[float]:
        s = sorted(range(n), key=lambda i: lst[i])
        r = [0.0] * n
        for rank, idx in enumerate(s):
            r[idx] = float(rank)
        return r

    rx, ry = _rank(xs), _rank(ys)
    mx = sum(rx) / n
    my = sum(ry) / n
    num    = sum((rx[i] - mx) * (ry[i] - my) for i in range(n))
    den_x  = math.sqrt(sum((rx[i] - mx) ** 2 for i in range(n)))
    den_y  = math.sqrt(sum((ry[i] - my) ** 2 for i in range(n)))
    denom  = den_x * den_y
    return num / denom if denom > 1e-9 else 0.0


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_model: Optional[MultiHorizonModel] = None


def get_multi_horizon_model() -> MultiHorizonModel:
    global _model
    if _model is None:
        _model = MultiHorizonModel()
    return _model
