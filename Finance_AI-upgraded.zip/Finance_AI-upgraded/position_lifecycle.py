"""
position_lifecycle.py — §13 Position Lifecycle State Machine.

Models the evolution of trade conviction from signal inception to exit,
replacing the portfolio layer's binary open/close model.

State machine
-------------
    OPEN ──► SCALE_IN ──► HOLD ──► REDUCE ──► EXIT
                                     │
                                     ▼
                               INVALIDATED

Transitions are governed by:
  - Signal reinforcement   (new event in same direction → SCALE_IN)
  - Conviction decay       (time-decay of original signal → REDUCE)
  - Thesis invalidation    (contradicting event → INVALIDATED)
  - Profit target          (position P&L > target → REDUCE/EXIT)
  - Stop loss              (position P&L < stop → EXIT)
  - Max hold period        (age > max_hold_days → REDUCE → EXIT)

Position sizing at each state
------------------------------
  OPEN       : initial_size (e.g. 0.50 × max_position)
  SCALE_IN   : min(current_size + scale_step, max_position)
  HOLD       : current_size (unchanged)
  REDUCE     : current_size × reduce_fraction
  EXIT       : 0.0
  INVALIDATED: 0.0 (immediate exit)

Key features
------------
- Overlapping signals: a second reinforcing event triggers SCALE_IN
  before the first position reaches HOLD; a contradicting event
  at any stage forces INVALIDATED.
- Partial exits: REDUCE brings size to reduce_fraction × current,
  not to zero. Multiple REDUCE steps staircase toward EXIT.
- Adaptive holding: holding period extended when a reinforcing signal
  arrives during HOLD; shortened when conviction_score decays below
  reduce_threshold.
- Thesis invalidation: any new event with opposing direction and
  |signal_score| > invalidation_threshold immediately transitions
  to INVALIDATED regardless of current state.

Usage
-----
    from position_lifecycle import PositionManager, PositionConfig

    cfg = PositionConfig(max_position=25_000, max_hold_days=10)
    mgr = PositionManager(cfg)

    # Open on first signal
    pos = mgr.open("AAPL", signal_score=0.65, direction="BULLISH", event_id="e001")

    # Reinforce (e.g. second earnings beat)
    mgr.on_new_signal("AAPL", signal_score=0.55, direction="BULLISH", event_id="e002")

    # Contradicting event
    mgr.on_new_signal("AAPL", signal_score=-0.70, direction="BEARISH", event_id="e003")

    orders = mgr.pending_orders()     # list of (ticker, side, notional)
    mgr.mark_executed(orders)
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# State definition
# ---------------------------------------------------------------------------

class PositionState(str, Enum):
    OPEN        = "OPEN"
    SCALE_IN    = "SCALE_IN"
    HOLD        = "HOLD"
    REDUCE      = "REDUCE"
    EXIT        = "EXIT"
    INVALIDATED = "INVALIDATED"


_TERMINAL = {PositionState.EXIT, PositionState.INVALIDATED}


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class PositionConfig:
    # Sizing
    max_position:          float = 25_000.0    # max notional per ticker
    initial_fraction:      float = 0.50        # fraction of max_position at OPEN
    scale_step_fraction:   float = 0.25        # increment per SCALE_IN step
    reduce_fraction:       float = 0.50        # size kept after each REDUCE

    # Thresholds for state transitions
    scale_in_threshold:    float = 0.20        # min reinforcing score to trigger SCALE_IN
    reduce_threshold:      float = 0.12        # conviction below this → REDUCE
    invalidation_threshold:float = 0.30        # opposing score above this → INVALIDATED

    # Time limits
    max_hold_days:         int   = 10          # force REDUCE after this many days
    max_total_days:        int   = 20          # force EXIT after this many days

    # P&L limits (as fraction of initial notional)
    profit_target:         float = 0.08        # +8% → start REDUCE
    stop_loss:             float = -0.05       # -5% → EXIT immediately

    # Conviction decay: half-life in hours
    conviction_half_life_hours: float = 48.0


# ---------------------------------------------------------------------------
# Position
# ---------------------------------------------------------------------------

@dataclass
class Position:
    ticker:          str
    state:           PositionState
    direction:       str               # BULLISH | BEARISH
    conviction:      float             # current conviction score [0, 1]
    notional:        float             # current position size ($)
    initial_notional:float             # opening notional ($)
    opened_at:       datetime
    updated_at:      datetime
    event_ids:       list[str]         # contributing event IDs
    state_history:   list[tuple[str, str]] = field(default_factory=list)
    # (state_name, iso_timestamp) pairs

    # Realised P&L tracking (set externally from execution)
    unrealised_pnl:  float = 0.0

    @property
    def age_hours(self) -> float:
        return (datetime.now(timezone.utc) - self.opened_at).total_seconds() / 3600.0

    @property
    def age_days(self) -> float:
        return self.age_hours / 24.0

    def is_terminal(self) -> bool:
        return self.state in _TERMINAL


# ---------------------------------------------------------------------------
# Order (output of the state machine)
# ---------------------------------------------------------------------------

@dataclass
class LifecycleOrder:
    ticker:    str
    side:      str          # BUY | SELL
    notional:  float        # absolute dollar amount
    reason:    str          # human-readable state transition label
    state:     PositionState


# ---------------------------------------------------------------------------
# Position Manager
# ---------------------------------------------------------------------------

class PositionManager:
    """
    Manages the lifecycle of all open positions.

    Thread safety: not thread-safe. In the async pipeline, call from a
    single-writer coroutine or wrap with asyncio.Lock.
    """

    def __init__(self, config: Optional[PositionConfig] = None):
        self.config    = config or PositionConfig()
        self._positions: dict[str, Position] = {}  # ticker → Position
        self._pending_orders: list[LifecycleOrder] = []

    # ── Open ────────────────────────────────────────────────────────────────

    def open(
        self,
        ticker:      str,
        signal_score: float,
        direction:   str,
        event_id:    str,
    ) -> Position:
        """
        Open a new position. If a position already exists for this ticker,
        route to on_new_signal() instead.
        """
        if ticker in self._positions and not self._positions[ticker].is_terminal():
            return self.on_new_signal(ticker, signal_score, direction, event_id)

        cfg     = self.config
        notional = cfg.max_position * cfg.initial_fraction
        now      = datetime.now(timezone.utc)

        pos = Position(
            ticker           = ticker,
            state            = PositionState.OPEN,
            direction        = direction.upper(),
            conviction       = min(1.0, abs(signal_score)),
            notional         = notional,
            initial_notional = notional,
            opened_at        = now,
            updated_at       = now,
            event_ids        = [event_id],
            state_history    = [(PositionState.OPEN.value, now.isoformat())],
        )
        self._positions[ticker] = pos

        side = "BUY" if direction.upper() == "BULLISH" else "SELL"
        self._pending_orders.append(LifecycleOrder(
            ticker=ticker, side=side, notional=notional,
            reason="open", state=PositionState.OPEN,
        ))
        logger.info("OPEN  %s  dir=%s  notional=%.0f  score=%.3f",
                    ticker, direction, notional, signal_score)
        return pos

    # ── New signal event ────────────────────────────────────────────────────

    def on_new_signal(
        self,
        ticker:       str,
        signal_score: float,
        direction:    str,
        event_id:     str,
    ) -> Optional[Position]:
        """
        Process a new signal event for an existing position.
        Handles reinforcement (SCALE_IN), contradiction (INVALIDATED),
        and neutral updates (HOLD).
        """
        pos = self._positions.get(ticker)
        if pos is None:
            return self.open(ticker, signal_score, direction, event_id)
        if pos.is_terminal():
            return self.open(ticker, signal_score, direction, event_id)

        cfg       = self.config
        now       = datetime.now(timezone.utc)
        incoming  = direction.upper()
        score_abs = abs(signal_score)

        pos.event_ids.append(event_id)
        pos.updated_at = now

        # ── Thesis invalidation ─────────────────────────────────────────────
        if (
            incoming != pos.direction
            and incoming in ("BULLISH", "BEARISH")
            and score_abs >= cfg.invalidation_threshold
        ):
            self._transition(pos, PositionState.INVALIDATED, now,
                             "opposing signal above invalidation threshold")
            side = "SELL" if pos.direction == "BULLISH" else "BUY"
            self._pending_orders.append(LifecycleOrder(
                ticker=ticker, side=side, notional=pos.notional,
                reason="invalidated", state=PositionState.INVALIDATED,
            ))
            pos.notional = 0.0
            logger.info("INVALIDATED  %s  opposing_score=%.3f", ticker, signal_score)
            return pos

        # ── Reinforcement → SCALE_IN ────────────────────────────────────────
        if (
            incoming == pos.direction
            and score_abs >= cfg.scale_in_threshold
            and pos.state not in (PositionState.REDUCE, PositionState.EXIT)
        ):
            additional = cfg.max_position * cfg.scale_step_fraction
            new_size   = min(pos.notional + additional, cfg.max_position)
            delta      = new_size - pos.notional

            if delta > 0:
                pos.notional  = new_size
                pos.conviction = min(1.0, pos.conviction + 0.10 * score_abs)
                self._transition(pos, PositionState.SCALE_IN, now,
                                 f"reinforcing signal score={signal_score:.3f}")
                side = "BUY" if pos.direction == "BULLISH" else "SELL"
                self._pending_orders.append(LifecycleOrder(
                    ticker=ticker, side=side, notional=delta,
                    reason="scale_in", state=PositionState.SCALE_IN,
                ))
                logger.info("SCALE_IN  %s  delta=%.0f  total=%.0f",
                            ticker, delta, pos.notional)
        else:
            # Neutral / weak signal → move toward HOLD if currently SCALE_IN or OPEN
            if pos.state in (PositionState.OPEN, PositionState.SCALE_IN):
                self._transition(pos, PositionState.HOLD, now, "signal acknowledged, holding")

        return pos

    # ── Time-based updates ──────────────────────────────────────────────────

    def tick(self, unrealised_pnl_map: Optional[dict[str, float]] = None) -> list[LifecycleOrder]:
        """
        Advance all open positions by one time step.
        Call once per pipeline run (typically hourly).

        unrealised_pnl_map: {ticker: pnl_fraction} from execution engine.
        Returns new orders generated by time-based transitions.
        """
        cfg       = self.config
        now       = datetime.now(timezone.utc)
        new_orders: list[LifecycleOrder] = []

        for ticker, pos in list(self._positions.items()):
            if pos.is_terminal():
                continue

            # Update P&L
            if unrealised_pnl_map:
                pos.unrealised_pnl = unrealised_pnl_map.get(ticker, pos.unrealised_pnl)

            pnl_frac = pos.unrealised_pnl / max(pos.initial_notional, 1e-9)

            # ── Stop loss ───────────────────────────────────────────────────
            if pnl_frac <= cfg.stop_loss:
                self._transition(pos, PositionState.EXIT, now, f"stop_loss pnl={pnl_frac:.3f}")
                side = "SELL" if pos.direction == "BULLISH" else "BUY"
                new_orders.append(LifecycleOrder(
                    ticker=ticker, side=side, notional=pos.notional,
                    reason="stop_loss", state=PositionState.EXIT,
                ))
                pos.notional = 0.0
                continue

            # ── Profit target ───────────────────────────────────────────────
            if pnl_frac >= cfg.profit_target and pos.state == PositionState.HOLD:
                self._transition(pos, PositionState.REDUCE, now, f"profit_target pnl={pnl_frac:.3f}")
                sell_notional = pos.notional * (1.0 - cfg.reduce_fraction)
                pos.notional  = pos.notional * cfg.reduce_fraction
                side = "SELL" if pos.direction == "BULLISH" else "BUY"
                new_orders.append(LifecycleOrder(
                    ticker=ticker, side=side, notional=sell_notional,
                    reason="profit_target_reduce", state=PositionState.REDUCE,
                ))
                continue

            # ── Max hold exceeded ───────────────────────────────────────────
            if pos.age_days >= cfg.max_total_days:
                self._transition(pos, PositionState.EXIT, now, "max_total_days exceeded")
                side = "SELL" if pos.direction == "BULLISH" else "BUY"
                new_orders.append(LifecycleOrder(
                    ticker=ticker, side=side, notional=pos.notional,
                    reason="max_total_days", state=PositionState.EXIT,
                ))
                pos.notional = 0.0
                continue

            if pos.age_days >= cfg.max_hold_days and pos.state == PositionState.HOLD:
                self._transition(pos, PositionState.REDUCE, now, "max_hold_days reached")
                sell_notional = pos.notional * (1.0 - cfg.reduce_fraction)
                pos.notional  = pos.notional * cfg.reduce_fraction
                side = "SELL" if pos.direction == "BULLISH" else "BUY"
                new_orders.append(LifecycleOrder(
                    ticker=ticker, side=side, notional=sell_notional,
                    reason="max_hold_days_reduce", state=PositionState.REDUCE,
                ))
                continue

            # ── Conviction decay ────────────────────────────────────────────
            hours_since = (now - pos.updated_at).total_seconds() / 3600.0
            half_life   = cfg.conviction_half_life_hours
            decayed     = pos.conviction * (0.5 ** (hours_since / half_life))
            pos.conviction = max(0.0, decayed)

            if pos.conviction < cfg.reduce_threshold and pos.state == PositionState.HOLD:
                self._transition(pos, PositionState.REDUCE, now,
                                 f"conviction decay conviction={pos.conviction:.3f}")
                sell_notional = pos.notional * (1.0 - cfg.reduce_fraction)
                pos.notional  = pos.notional * cfg.reduce_fraction
                side = "SELL" if pos.direction == "BULLISH" else "BUY"
                new_orders.append(LifecycleOrder(
                    ticker=ticker, side=side, notional=sell_notional,
                    reason="conviction_decay", state=PositionState.REDUCE,
                ))

            # ── OPEN/SCALE_IN → HOLD after first tick with no new signals ──
            elif pos.state in (PositionState.OPEN, PositionState.SCALE_IN):
                self._transition(pos, PositionState.HOLD, now, "settling to HOLD")

        self._pending_orders.extend(new_orders)
        return new_orders

    # ── Order management ────────────────────────────────────────────────────

    def pending_orders(self) -> list[LifecycleOrder]:
        return list(self._pending_orders)

    def mark_executed(self, orders: Optional[list[LifecycleOrder]] = None) -> None:
        """Clear pending orders (call after execution engine confirms fills)."""
        if orders is None:
            self._pending_orders.clear()
        else:
            executed_set = {id(o) for o in orders}
            self._pending_orders = [o for o in self._pending_orders
                                    if id(o) not in executed_set]

    # ── Summary ─────────────────────────────────────────────────────────────

    def summary(self) -> dict:
        active = {t: p for t, p in self._positions.items() if not p.is_terminal()}
        return {
            "open_positions":   len(active),
            "total_notional":   round(sum(p.notional for p in active.values()), 2),
            "by_state":         {
                s.value: sum(1 for p in active.values() if p.state == s)
                for s in PositionState
            },
            "pending_orders":   len(self._pending_orders),
        }

    def get_position(self, ticker: str) -> Optional[Position]:
        return self._positions.get(ticker)

    # ── Helpers ─────────────────────────────────────────────────────────────

    @staticmethod
    def _transition(pos: Position, new_state: PositionState,
                    now: datetime, reason: str) -> None:
        pos.state = new_state
        pos.state_history.append((new_state.value, now.isoformat()))
        logger.debug("  %s  %s → %s  (%s)", pos.ticker,
                     pos.state_history[-2][0] if len(pos.state_history) > 1 else "?",
                     new_state.value, reason)
