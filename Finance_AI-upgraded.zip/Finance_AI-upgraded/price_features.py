"""
price_features.py — Price-based feature engine.

Computes all price-derived features from the EOD price cache already
in the system.  Zero additional network calls.

Features produced
-----------------
  momentum_1m   : 1-month return                    [-1, 1]
  momentum_3m   : 3-month return                    [-1, 1]
  momentum_6m   : 6-month return                    [-1, 1]
  momentum_12m  : 12-month return (classic WML)     [-1, 1]
  vol_10d       : 10-day realised volatility (ann.)  [0, 1]
  vol_30d       : 30-day realised volatility (ann.)  [0, 1]
  vol_regime    : short/long vol ratio — >1 = clustering [0, 2]
  week52_pct    : distance from 52-week high         [-1, 0]
  beta_30d      : 30-day rolling beta to SPY         [-3, 3]
  dollar_vol    : log10 of avg daily dollar volume    [6, 12]
  price_to_sma50: close / 50-day SMA                 [0.5, 2]
  rsi_14        : 14-day RSI                         [0, 1]

Conditioning interpretations wired into signal_ranker
------------------------------------------------------
  High momentum_12m + positive sentiment  → confirm (amplify)
  Low  momentum_12m + positive sentiment  → contrarian (attenuate)
  High vol_regime                         → uncertainty (attenuate)
  Near 52-week high + positive sentiment  → breakout (amplify)
  Low dollar_vol                          → illiquid (attenuate)
"""
from __future__ import annotations

import asyncio
import logging
import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

_TRADING_DAYS_YEAR = 252
_CACHE_TTL = 3600   # 1 hour — price features change daily, not intraday


# ---------------------------------------------------------------------------
# Output dataclass
# ---------------------------------------------------------------------------

@dataclass
class PriceFeatureVector:
    ticker: str

    # Momentum (winsorised to [-1, 1])
    momentum_1m:   Optional[float] = None
    momentum_3m:   Optional[float] = None
    momentum_6m:   Optional[float] = None
    momentum_12m:  Optional[float] = None

    # Volatility
    vol_10d:       Optional[float] = None   # annualised
    vol_30d:       Optional[float] = None   # annualised
    vol_regime:    Optional[float] = None   # vol_10d / vol_30d

    # Range / trend
    week52_pct:    Optional[float] = None   # (close - 52w_high) / 52w_high
    price_to_sma50: Optional[float] = None  # close / 50d SMA
    rsi_14:        Optional[float] = None   # [0, 1]

    # Liquidity
    beta_30d:      Optional[float] = None
    dollar_vol_log: Optional[float] = None  # log10(avg daily dollar vol)

    # Metadata
    computed_at:   datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    n_days_history: int = 0
    is_stale:      bool = True

    def as_feature_dict(self) -> dict[str, Optional[float]]:
        return {
            "price_momentum_1m":   self.momentum_1m,
            "price_momentum_3m":   self.momentum_3m,
            "price_momentum_6m":   self.momentum_6m,
            "price_momentum_12m":  self.momentum_12m,
            "price_vol_10d":       self.vol_10d,
            "price_vol_30d":       self.vol_30d,
            "price_vol_regime":    self.vol_regime,
            "price_week52_pct":    self.week52_pct,
            "price_to_sma50":      self.price_to_sma50,
            "price_rsi_14":        self.rsi_14,
            "price_beta_30d":      self.beta_30d,
            "price_dollar_vol_log": self.dollar_vol_log,
        }


# ---------------------------------------------------------------------------
# Computation helpers (pure numpy — fast)
# ---------------------------------------------------------------------------

def _momentum(closes: np.ndarray, trading_days: int) -> Optional[float]:
    """Simple price return over trailing trading_days bars."""
    if len(closes) <= trading_days:
        return None
    ret = float(closes[-1] / closes[-trading_days - 1] - 1.0)
    return max(-1.0, min(1.0, ret))


def _annualised_vol(closes: np.ndarray, window: int) -> Optional[float]:
    if len(closes) < window + 1:
        return None
    rets = np.diff(np.log(closes[-window - 1:]))
    vol  = float(np.std(rets)) * math.sqrt(_TRADING_DAYS_YEAR)
    return max(0.0, min(1.0, vol))


def _rsi(closes: np.ndarray, period: int = 14) -> Optional[float]:
    if len(closes) < period + 1:
        return None
    deltas = np.diff(closes[-period - 1:])
    gains  = deltas[deltas > 0].mean() if (deltas > 0).any() else 0.0
    losses = -deltas[deltas < 0].mean() if (deltas < 0).any() else 1e-9
    rs     = gains / losses
    rsi    = 1.0 - 1.0 / (1.0 + rs)   # normalised to [0, 1]
    return round(float(rsi), 4)


def _beta(stock_closes: np.ndarray, spy_closes: np.ndarray, window: int = 30) -> Optional[float]:
    n = min(window, len(stock_closes) - 1, len(spy_closes) - 1)
    if n < 10:
        return None
    s_rets  = np.diff(np.log(stock_closes[-n - 1:]))
    m_rets  = np.diff(np.log(spy_closes[-n - 1:]))
    if np.std(m_rets) < 1e-8:
        return None
    cov     = float(np.cov(s_rets, m_rets)[0, 1])
    var_m   = float(np.var(m_rets))
    beta    = cov / var_m
    return max(-3.0, min(3.0, round(beta, 4)))


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class PriceFeatureEngine:
    """
    Computes price-derived features from the EOD price cache.
    No network calls — all data comes from the local SQLite sidecar.
    """

    def __init__(self) -> None:
        self._cache: dict[str, tuple[float, PriceFeatureVector]] = {}
        self._lock  = asyncio.Lock()

    async def get_features(
        self,
        ticker:        str,
        force_refresh: bool = False,
    ) -> PriceFeatureVector:
        async with self._lock:
            now = time.monotonic()
            if not force_refresh and ticker in self._cache:
                exp, cached = self._cache[ticker]
                if now < exp:
                    return cached

        result = await self._compute(ticker)

        async with self._lock:
            self._cache[ticker] = (time.monotonic() + _CACHE_TTL, result)

        return result

    async def _compute(self, ticker: str) -> PriceFeatureVector:
        from eod_price_cache import get_cache

        cache   = get_cache()
        history = cache.get_history(ticker, days=260)   # 1 year of trading days + buffer

        if not history:
            return PriceFeatureVector(ticker=ticker, is_stale=True)

        closes = np.array([r["close"] for r in history], dtype=np.float64)
        vols   = np.array([r.get("volume", 0) or 0 for r in history], dtype=np.float64)
        n      = len(closes)

        # Fetch SPY for beta (may be absent if cache not warmed)
        spy_hist   = cache.get_history("SPY", days=260)
        spy_closes = np.array([r["close"] for r in spy_hist], dtype=np.float64) if spy_hist else None

        # Momentum
        m1  = _momentum(closes, 21)
        m3  = _momentum(closes, 63)
        m6  = _momentum(closes, 126)
        m12 = _momentum(closes, 252)

        # Volatility
        v10 = _annualised_vol(closes, 10)
        v30 = _annualised_vol(closes, 30)
        vol_regime = round(v10 / v30, 4) if (v10 and v30 and v30 > 0) else None

        # 52-week high distance
        week52_high = float(closes[-252:].max()) if n >= 252 else float(closes.max())
        w52_pct     = round((closes[-1] - week52_high) / week52_high, 4)

        # SMA50
        sma50       = float(closes[-50:].mean()) if n >= 50 else None
        p_to_sma    = round(closes[-1] / sma50, 4) if sma50 else None

        # RSI 14
        rsi = _rsi(closes, 14)

        # Beta to SPY
        beta = _beta(closes, spy_closes, 30) if spy_closes is not None else None

        # Dollar volume (log10)
        if n >= 20:
            avg_dvol = float(np.mean(closes[-20:] * vols[-20:]))
            dvol_log = round(math.log10(max(avg_dvol, 1.0)), 4) if avg_dvol > 0 else None
        else:
            dvol_log = None

        return PriceFeatureVector(
            ticker         = ticker,
            momentum_1m    = m1,
            momentum_3m    = m3,
            momentum_6m    = m6,
            momentum_12m   = m12,
            vol_10d        = v10,
            vol_30d        = v30,
            vol_regime     = vol_regime,
            week52_pct     = w52_pct,
            price_to_sma50 = p_to_sma,
            rsi_14         = rsi,
            beta_30d       = beta,
            dollar_vol_log = dvol_log,
            n_days_history = n,
            is_stale       = (n < 5),
        )

    async def get_features_batch(
        self,
        tickers: list[str],
    ) -> dict[str, PriceFeatureVector]:
        results = await asyncio.gather(*[self.get_features(t) for t in tickers])
        return dict(zip(tickers, results))


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_engine: Optional[PriceFeatureEngine] = None


def get_engine() -> PriceFeatureEngine:
    global _engine
    if _engine is None:
        _engine = PriceFeatureEngine()
    return _engine
