"""
amihud_accumulator.py — Incremental Amihud illiquidity ratio.

The liquidity_engine currently downloads 120 days of OHLCV and recomputes
Amihud from scratch every 15 minutes.  For the daily-bar use-case this is
wasteful: a new bar arrives once per day and the rolling ratio only needs
an O(1) update.

This module provides an online accumulator using an exponentially-weighted
variant of the Amihud (2002) measure:

  EWMA_Amihud_t = λ × EWMA_Amihud_{t-1}  +  (1-λ) × |r_t| / dvol_t

Where:
  r_t    = daily log return
  dvol_t = daily dollar volume (close × volume)
  λ      = forgetting factor (default 0.94 ≈ 30-day half-life)

The rolling-window version (unweighted average over the last N days) is
also supported for compatibility with the existing liquidity_engine.

For intraday use (tick-by-tick or 1-min bars), the accumulator updates
incrementally and recomputes the normalised Amihud score without fetching
any historical data.

Usage
-----
    from amihud_accumulator import AmihudAccumulator, get_accumulator

    acc = get_accumulator("AAPL")

    # On each new daily bar:
    acc.update(close=182.50, volume=55_000_000, prev_close=180.00)
    score = acc.normalised_score   # [0, 1] — relative to historical distribution

    # Batch initialise from historical data (call once at startup):
    acc.initialise_from_history(closes=[...], volumes=[...])
"""
from __future__ import annotations

import logging
import math
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default parameters
# ---------------------------------------------------------------------------

_EWMA_LAMBDA     = 0.94     # forgetting factor (30-day half-life)
_WINDOW          = 30       # rolling-window length in trading days
_NORMALISE_PCTILE = 95      # percentile used as normalisation cap


# ---------------------------------------------------------------------------
# Bar dataclass
# ---------------------------------------------------------------------------

@dataclass
class OHLCVBar:
    date:        str
    close:       float
    volume:      float
    prev_close:  float

    @property
    def log_return(self) -> float:
        if self.prev_close <= 0:
            return 0.0
        return math.log(self.close / self.prev_close)

    @property
    def dollar_volume(self) -> float:
        return self.close * self.volume


# ---------------------------------------------------------------------------
# Amihud accumulator
# ---------------------------------------------------------------------------

class AmihudAccumulator:
    """
    Online Amihud illiquidity estimator for a single ticker.

    Maintains two parallel estimates:
    1. EWMA (exponentially-weighted, favours recent bars)
    2. Rolling window (unweighted, matches original liquidity_engine)

    Both are updated with a single call to update().
    The normalised score is computed relative to the historical distribution
    maintained inside the accumulator — no external lookups needed.
    """

    def __init__(
        self,
        ticker:      str,
        ewma_lambda: float = _EWMA_LAMBDA,
        window:      int   = _WINDOW,
    ) -> None:
        self.ticker       = ticker
        self._lambda      = ewma_lambda
        self._window      = window

        # State
        self._ewma:       Optional[float]  = None   # current EWMA estimate
        self._raw_buf:    deque[float]     = deque(maxlen=window)   # rolling window
        self._history:    deque[float]     = deque(maxlen=252)      # 1Y of values for normalisation
        self._last_close: Optional[float]  = None
        self._n_updates:  int              = 0
        self._updated_at: Optional[datetime] = None

    # ------------------------------------------------------------------
    # Update
    # ------------------------------------------------------------------

    def update(
        self,
        close:      float,
        volume:     float,
        prev_close: Optional[float] = None,
    ) -> Optional[float]:
        """
        Process one new bar.  O(1) time and space.

        Parameters
        ----------
        close      : today's closing price
        volume     : today's volume (shares or contracts)
        prev_close : yesterday's close (optional — uses last seen close if None)

        Returns
        -------
        raw_amihud : |return| / dollar_volume for this bar (not normalised)
        """
        if prev_close is None:
            prev_close = self._last_close

        self._last_close = close

        if prev_close is None or prev_close <= 0 or close <= 0 or volume <= 0:
            return None

        # Amihud ratio for this bar
        log_ret    = abs(math.log(close / prev_close))
        dvol       = close * volume
        amihud_bar = log_ret / dvol if dvol > 0 else 0.0

        # EWMA update
        if self._ewma is None:
            self._ewma = amihud_bar
        else:
            self._ewma = self._lambda * self._ewma + (1 - self._lambda) * amihud_bar

        # Rolling window
        self._raw_buf.append(amihud_bar)
        self._history.append(amihud_bar)

        self._n_updates  += 1
        self._updated_at  = datetime.now(timezone.utc)

        return amihud_bar

    # ------------------------------------------------------------------
    # Derived metrics
    # ------------------------------------------------------------------

    @property
    def ewma_amihud(self) -> Optional[float]:
        """Current EWMA Amihud estimate."""
        return self._ewma

    @property
    def rolling_amihud(self) -> Optional[float]:
        """Unweighted average over the rolling window."""
        if not self._raw_buf:
            return None
        return float(np.mean(list(self._raw_buf)))

    @property
    def normalised_score(self) -> Optional[float]:
        """
        [0, 1] score relative to historical distribution.
        0 = very liquid (low Amihud), 1 = very illiquid (high Amihud).
        """
        if self._ewma is None or len(self._history) < 5:
            return None
        hist_arr = np.array(list(self._history))
        cap      = float(np.percentile(hist_arr, _NORMALISE_PCTILE))
        if cap <= 0:
            return 0.0
        return float(min(1.0, self._ewma / cap))

    @property
    def is_warm(self) -> bool:
        """True once enough bars have been seen for reliable estimates.
        Requires at least 10 updates, or half the window — whichever is smaller."""
        return self._n_updates >= max(5, min(self._window // 3, 10))

    # ------------------------------------------------------------------
    # Initialise from historical data
    # ------------------------------------------------------------------

    def initialise_from_history(
        self,
        closes:  list[float],
        volumes: list[float],
    ) -> None:
        """
        Seed the accumulator from a list of historical daily closes and volumes.
        Processes bars in chronological order — call once at startup.
        """
        if len(closes) < 2 or len(closes) != len(volumes):
            return

        for i in range(1, len(closes)):
            self.update(
                close      = closes[i],
                volume     = volumes[i],
                prev_close = closes[i - 1],
            )

        logger.info(
            "AmihudAccumulator[%s]: initialised from %d bars, "
            "ewma=%.3e  score=%.3f",
            self.ticker, len(closes) - 1,
            self._ewma or 0, self.normalised_score or 0,
        )

    async def warm_from_yfinance(self, days: int = 60) -> bool:
        """
        Convenience: fetch history from yfinance and initialise.
        Returns True if successful.
        """
        try:
            import asyncio
            import yfinance as yf

            loop = asyncio.get_running_loop()

            def _fetch():
                df = yf.download(
                    self.ticker, period=f"{days}d",
                    progress=False, auto_adjust=True,
                )
                return df

            df = await loop.run_in_executor(None, _fetch)
            if df.empty:
                return False

            closes  = df["Close"].values.astype(float).tolist()
            volumes = df["Volume"].values.astype(float).tolist()
            self.initialise_from_history(closes, volumes)
            return True

        except Exception as exc:
            logger.warning("AmihudAccumulator warm failed for %s: %s", self.ticker, exc)
            return False


# ---------------------------------------------------------------------------
# Registry — one accumulator per ticker
# ---------------------------------------------------------------------------

_accumulators: dict[str, AmihudAccumulator] = {}


def get_accumulator(
    ticker:      str,
    ewma_lambda: float = _EWMA_LAMBDA,
    window:      int   = _WINDOW,
) -> AmihudAccumulator:
    """Return (or create) the AmihudAccumulator for a ticker."""
    if ticker not in _accumulators:
        _accumulators[ticker] = AmihudAccumulator(
            ticker      = ticker,
            ewma_lambda = ewma_lambda,
            window      = window,
        )
    return _accumulators[ticker]


async def warm_all(
    tickers: list[str],
    days:    int = 60,
) -> dict[str, bool]:
    """
    Warm accumulators for all given tickers concurrently.
    Returns {ticker: success}.
    """
    import asyncio
    sem = asyncio.Semaphore(5)

    async def _warm_one(t: str) -> tuple[str, bool]:
        async with sem:
            acc = get_accumulator(t)
            if acc.is_warm:
                return t, True
            ok = await acc.warm_from_yfinance(days=days)
            return t, ok

    results = await asyncio.gather(*[_warm_one(t) for t in tickers])
    return dict(results)


def registry_summary() -> list[dict]:
    return [
        {
            "ticker":           acc.ticker,
            "n_updates":        acc._n_updates,
            "ewma_amihud":      acc.ewma_amihud,
            "normalised_score": acc.normalised_score,
            "is_warm":          acc.is_warm,
        }
        for acc in _accumulators.values()
    ]
