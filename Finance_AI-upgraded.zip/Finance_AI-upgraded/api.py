"""
api.py — FastAPI application with:
  - API key authentication on all write endpoints
  - Rate limiting per client IP
  - SSRF protection on /analyze
  - Cursor-based pagination on /results
  - Job ID tracking for background tasks
  - Async DB via asyncpg (never blocks event loop)
  - Semantic search via pgvector
  - Prometheus metrics on /internal/metrics
"""
from __future__ import annotations
import asyncio
import ipaddress
import logging
import socket
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

from fastapi import Depends, FastAPI, HTTPException, Query, Request, BackgroundTasks
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from config import settings
from database import get_pool, close_pool
from discovery import discover_urls
from embeddings import generate_embedding
from logging_config import setup_logging
from main import run_pipeline, run_finance_pipeline, DEFAULT_URLS, FINANCE_URLS
from security import verify_api_key, check_rate_limit
from vector_store import semantic_search

setup_logging()
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# In-memory job registry {job_id: {status, submitted_at, completed_at, error}}
#
# WARNING: this dict is local to one worker process.  In a multi-worker
# Uvicorn / Gunicorn deployment (e.g. `--workers 4`) a job submitted to
# worker A will return 404 when polled on worker B.
#
# For multi-worker setups replace this with a DB-backed or Redis-backed
# store.  A minimal asyncpg drop-in is straightforward:
#
#   CREATE TABLE jobs (
#       job_id       UUID PRIMARY KEY,
#       status       TEXT    NOT NULL DEFAULT 'queued',
#       submitted_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
#       completed_at TIMESTAMPTZ,
#       error        TEXT
#   );
#
# ---------------------------------------------------------------------------
_jobs: dict[str, dict] = {}

# Private/link-local ranges for SSRF guard (mirrors scraper.py)
_PRIVATE_NETS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    # IPv6 loopback / link-local
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fe80::/10"),
    ipaddress.ip_network("fc00::/7"),
]


def _ssrf_check(url: str) -> None:
    """
    Reject URLs that resolve to private/internal addresses.

    FIX: the previous implementation silently passed on *any* non-HTTP
    exception (ValueError from a malformed URL, socket.gaierror from a
    failed DNS lookup, etc.), which could allow a crafted URL to slip
    through.  Non-HTTPException errors are now treated as rejections:
      - ValueError / urlparse failure  → 400 Bad Request
      - DNS resolution failure         → 400 Bad Request (fail-closed)
      - Any other unexpected error     → 400 Bad Request (fail-closed)
    """
    try:
        parsed = urlparse(url)
        host   = parsed.hostname or ""
        scheme = parsed.scheme

        if not host:
            raise HTTPException(status_code=400, detail="URL has no resolvable hostname")

        if scheme not in ("http", "https"):
            raise HTTPException(status_code=400, detail="Only http/https URLs are allowed")

    except HTTPException:
        raise
    except Exception as exc:
        # Malformed URL — urlparse itself raised
        logger.warning("SSRF pre-check rejected malformed URL %r: %s", url, exc)
        raise HTTPException(status_code=400, detail="Invalid or malformed URL") from exc

    # DNS resolution — fail-closed: any resolution error rejects the URL
    try:
        raw_addr = socket.gethostbyname(host)
        addr     = ipaddress.ip_address(raw_addr)
    except socket.gaierror as exc:
        logger.warning("SSRF check: DNS resolution failed for %r: %s", host, exc)
        raise HTTPException(
            status_code=400,
            detail=f"Could not resolve hostname '{host}' — request rejected",
        ) from exc
    except ValueError as exc:
        # ip_address() received something it cannot parse (shouldn't happen
        # after gethostbyname, but defend anyway)
        logger.warning("SSRF check: unparseable address for %r: %s", host, exc)
        raise HTTPException(status_code=400, detail="Could not validate target address") from exc
    except Exception as exc:
        # Unexpected error — fail closed
        logger.error("SSRF check: unexpected error for %r: %s", host, exc, exc_info=True)
        raise HTTPException(status_code=400, detail="URL validation error") from exc

    if any(addr in net for net in _PRIVATE_NETS):
        raise HTTPException(status_code=400, detail="Private/internal URLs are not allowed")


# ---------------------------------------------------------------------------
# Lifespan
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    from monitor import start_metrics_server
    start_metrics_server()
    logger.info("API startup complete")
    yield
    # Shutdown
    await close_pool()
    logger.info("API shutdown complete")


app = FastAPI(
    title="AI Web Scraper API",
    version="2.0.0",
    lifespan=lifespan,
)


# ---------------------------------------------------------------------------
# Rate-limit middleware
# ---------------------------------------------------------------------------

@app.middleware("http")
async def rate_limit_middleware(request: Request, call_next):
    client_ip = request.client.host if request.client else "unknown"
    try:
        check_rate_limit(client_ip)
    except HTTPException as exc:
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail},
                            headers=exc.headers or {})
    return await call_next(request)


# ---------------------------------------------------------------------------
# Request/Response models
# ---------------------------------------------------------------------------

class URLRequest(BaseModel):
    urls: list[str]


class SemanticQuery(BaseModel):
    query: str
    k: int = 5
    min_similarity: float = 0.0
    domain_filter: Optional[str] = None


class JobResponse(BaseModel):
    job_id: str
    status: str
    submitted_at: str


# ---------------------------------------------------------------------------
# Job helpers
# ---------------------------------------------------------------------------

def _create_job() -> str:
    job_id = str(uuid.uuid4())
    _jobs[job_id] = {
        "status": "queued",
        "submitted_at": datetime.now(timezone.utc).isoformat(),
        "completed_at": None,
        "error": None,
    }
    return job_id


async def _run_job(job_id: str, coro):
    _jobs[job_id]["status"] = "running"
    try:
        await coro
        _jobs[job_id]["status"] = "completed"
        _jobs[job_id]["completed_at"] = datetime.now(timezone.utc).isoformat()
    except Exception as exc:
        _jobs[job_id]["status"] = "failed"
        _jobs[job_id]["error"] = str(exc)
        logger.error("Job %s failed: %s", job_id, exc, exc_info=True)


# ---------------------------------------------------------------------------
# Public endpoints
# ---------------------------------------------------------------------------

@app.get("/")
async def root():
    return {"status": "running", "version": "2.0.0"}


@app.get("/health")
async def health():
    try:
        pool = await get_pool()
        await pool.fetchval("SELECT 1")
        return {"status": "healthy", "db": "ok"}
    except Exception as exc:
        return JSONResponse(status_code=503, content={"status": "unhealthy", "db": str(exc)})


# ---------------------------------------------------------------------------
# Submission endpoints (auth required)
# ---------------------------------------------------------------------------

@app.post("/analyze", response_model=JobResponse, dependencies=[Depends(verify_api_key)])
async def analyze_urls(request: URLRequest, background_tasks: BackgroundTasks):
    for url in request.urls:
        _ssrf_check(url)
    urls    = list(dict.fromkeys(request.urls))   # dedup, preserve order
    job_id  = _create_job()
    background_tasks.add_task(_run_job, job_id, run_pipeline(urls))
    return JobResponse(job_id=job_id, status="queued",
                       submitted_at=_jobs[job_id]["submitted_at"])


@app.post("/discover", response_model=JobResponse, dependencies=[Depends(verify_api_key)])
async def discover_topic(topic: str, background_tasks: BackgroundTasks):
    urls    = discover_urls(topic)
    job_id  = _create_job()
    background_tasks.add_task(_run_job, job_id, run_pipeline(urls))
    return JobResponse(job_id=job_id, status="queued",
                       submitted_at=_jobs[job_id]["submitted_at"])


@app.post("/crawl", response_model=JobResponse, dependencies=[Depends(verify_api_key)])
async def crawl_site(url: str, background_tasks: BackgroundTasks, max_pages: int = 50):
    _ssrf_check(url)
    from crawler import crawl as _crawl

    async def _task():
        pool    = await get_pool()
        crawled = await _crawl(pool, [url], max_pages=max_pages)
        await run_pipeline(crawled)

    job_id = _create_job()
    background_tasks.add_task(_run_job, job_id, _task())
    return JobResponse(job_id=job_id, status="queued",
                       submitted_at=_jobs[job_id]["submitted_at"])


@app.post("/run-default", response_model=JobResponse, dependencies=[Depends(verify_api_key)])
async def run_default(background_tasks: BackgroundTasks):
    job_id = _create_job()
    background_tasks.add_task(_run_job, job_id, run_pipeline(DEFAULT_URLS))
    return JobResponse(job_id=job_id, status="queued",
                       submitted_at=_jobs[job_id]["submitted_at"])


@app.post("/run-finance", response_model=JobResponse, dependencies=[Depends(verify_api_key)])
async def run_finance(background_tasks: BackgroundTasks):
    job_id = _create_job()
    background_tasks.add_task(_run_job, job_id, run_finance_pipeline())
    return JobResponse(job_id=job_id, status="queued",
                       submitted_at=_jobs[job_id]["submitted_at"])


@app.get("/jobs/{job_id}")
async def get_job(job_id: str):
    job = _jobs.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return {"job_id": job_id, **job}


# ---------------------------------------------------------------------------
# Query endpoints (auth required)
# ---------------------------------------------------------------------------

@app.get("/results", dependencies=[Depends(verify_api_key)])
async def get_results(
    limit:        int            = Query(default=50, le=500),
    cursor:       Optional[str]  = Query(default=None, description="ISO-8601 scraped_at for cursor pagination"),
    domain:       Optional[str]  = Query(default=None),
    tier:         Optional[str]  = Query(default=None),
    sentiment:    Optional[str]  = Query(default=None),
    duplicates:   bool           = Query(default=False),
):
    """
    Cursor-based pagination on scraped_events.
    Pass `cursor` from the last result's scraped_at to get the next page.
    """
    pool = await get_pool()

    conditions = ["TRUE"]
    params: list = []
    p = 1

    if not duplicates:
        conditions.append("NOT is_duplicate")

    if cursor:
        conditions.append(f"scraped_at < ${p}")
        params.append(datetime.fromisoformat(cursor))
        p += 1

    if domain:
        conditions.append(f"source_domain = ${p}")
        params.append(domain)
        p += 1

    if tier:
        conditions.append(f"materiality_tier = ${p}")
        params.append(tier.upper())
        p += 1

    if sentiment:
        conditions.append(f"sentiment_label = ${p}")
        params.append(sentiment.upper())
        p += 1

    params.append(limit)
    where = " AND ".join(conditions)
    rows = await pool.fetch(f"""
        SELECT event_id, url, source_domain, scraped_at,
               sentiment_label, sentiment_score, summary,
               keywords, topics, credibility_score,
               propaganda_score, materiality_tier, is_duplicate
        FROM   scraped_events
        WHERE  {where}
        ORDER  BY scraped_at DESC
        LIMIT  ${p}
    """, *params)

    results = [
        {
            "event_id":       str(r["event_id"]),
            "url":            r["url"],
            "source_domain":  r["source_domain"],
            "scraped_at":     r["scraped_at"].isoformat(),
            "sentiment":      r["sentiment_label"],
            "score":          r["sentiment_score"],
            "summary":        r["summary"],
            "keywords":       list(r["keywords"] or []),
            "topics":         list(r["topics"]   or []),
            "credibility":    r["credibility_score"],
            "propaganda":     r["propaganda_score"],
            "tier":           r["materiality_tier"],
            "is_duplicate":   r["is_duplicate"],
        }
        for r in rows
    ]

    next_cursor = results[-1]["scraped_at"] if results else None
    return {"results": results, "count": len(results), "next_cursor": next_cursor}


@app.get("/metrics", dependencies=[Depends(verify_api_key)])
async def get_metrics():
    pool = await get_pool()
    total = await pool.fetchval("SELECT COUNT(*) FROM scraped_events WHERE NOT is_duplicate")
    sent  = await pool.fetch("""
        SELECT sentiment_label, COUNT(*) AS cnt
        FROM scraped_events WHERE NOT is_duplicate
        GROUP BY sentiment_label
    """)
    tiers = await pool.fetch("""
        SELECT materiality_tier, COUNT(*) AS cnt
        FROM scraped_events WHERE NOT is_duplicate
        GROUP BY materiality_tier
    """)
    dead  = await pool.fetchval("SELECT COUNT(*) FROM source_health WHERE is_dead")
    return {
        "total_events":         total,
        "sentiment_breakdown":  {r["sentiment_label"]: r["cnt"] for r in sent},
        "tier_breakdown":       {r["materiality_tier"]: r["cnt"] for r in tiers},
        "dead_sources":         dead,
    }


@app.post("/semantic-search", dependencies=[Depends(verify_api_key)])
async def semantic_search_endpoint(request: SemanticQuery):
    embedding = await generate_embedding(request.query)
    if embedding is None:
        return {"results": [], "query": request.query}
    pool    = await get_pool()
    results = await semantic_search(
        pool, embedding, k=request.k,
        min_similarity=request.min_similarity,
        domain_filter=request.domain_filter,
    )
    return {"query": request.query, "results": results}


@app.get("/alerts", dependencies=[Depends(verify_api_key)])
async def get_alerts(limit: int = Query(default=50, le=200)):
    pool = await get_pool()
    rows = await pool.fetch("""
        SELECT alert_id, fired_at, alert_type, severity, source_domain,
               payload, delivered, delivery_error
        FROM alert_log
        ORDER BY fired_at DESC
        LIMIT $1
    """, limit)
    return {"alerts": [dict(r) for r in rows]}


@app.get("/source-health", dependencies=[Depends(verify_api_key)])
async def get_source_health():
    pool = await get_pool()
    rows = await pool.fetch("""
        SELECT domain, last_success_at, consecutive_fails, is_dead, dead_since
        FROM source_health ORDER BY consecutive_fails DESC
    """)
    return {"sources": [dict(r) for r in rows]}


# ---------------------------------------------------------------------------
# Signal Intelligence endpoints (v2)
# ---------------------------------------------------------------------------

@app.get("/signals", dependencies=[Depends(verify_api_key)])
async def get_top_signals(
    limit:      int   = Query(default=20, le=200),
    tier:       str   = Query(default="", description="STRONG|MODERATE|WEAK|NOISE"),
    event_type: str   = Query(default="", description="earnings|macro|contract|…"),
    direction:  str   = Query(default="", description="BULLISH|BEARISH|NEUTRAL"),
    min_novelty: float = Query(default=0.0, ge=0.0, le=1.0),
):
    """
    Return top-ranked alpha signals, optionally filtered.
    Results are ordered by |signal_score| descending.
    """
    pool = await get_pool()
    filters = ["NOT is_duplicate"]
    params: list = []

    if tier:
        params.append(tier.upper())
        filters.append(f"signal_tier = ${len(params)}")
    if event_type:
        params.append(event_type.lower())
        filters.append(f"event_type = ${len(params)}")
    if direction:
        params.append(direction.upper())
        filters.append(f"signal_direction = ${len(params)}")
    if min_novelty > 0:
        params.append(min_novelty)
        filters.append(f"novelty_score >= ${len(params)}")

    params.append(limit)
    where = " AND ".join(filters)
    rows = await pool.fetch(f"""
        SELECT event_id, scraped_at, source_domain, summary,
               event_type, event_confidence,
               sentiment_label, sentiment_score,
               materiality_score, materiality_tier,
               novelty_score, novelty_label,
               signal_score, signal_direction, signal_tier,
               dollar_value, pct_change,
               credibility_score, url
        FROM   scraped_events
        WHERE  {where}
        ORDER  BY ABS(signal_score) DESC
        LIMIT  ${len(params)}
    """, *params)

    return {"signals": [dict(r) for r in rows]}


@app.get("/signals/by-event-type", dependencies=[Depends(verify_api_key)])
async def signals_by_event_type():
    """Aggregate signal stats broken down by event type."""
    pool = await get_pool()
    rows = await pool.fetch("""
        SELECT
            event_type,
            COUNT(*)                    AS event_count,
            AVG(signal_score)           AS avg_signal,
            AVG(novelty_score)          AS avg_novelty,
            AVG(materiality_score)      AS avg_materiality,
            SUM(CASE WHEN signal_direction='BULLISH'  THEN 1 ELSE 0 END) AS bullish,
            SUM(CASE WHEN signal_direction='BEARISH'  THEN 1 ELSE 0 END) AS bearish,
            SUM(CASE WHEN signal_direction='NEUTRAL'  THEN 1 ELSE 0 END) AS neutral
        FROM scraped_events
        WHERE NOT is_duplicate
          AND scraped_at > NOW() - INTERVAL '7 days'
        GROUP BY event_type
        ORDER BY ABS(AVG(signal_score)) DESC
    """)
    return {"breakdown": [dict(r) for r in rows]}


@app.get("/knowledge-graph/propagate/{entity}", dependencies=[Depends(verify_api_key)])
async def kg_propagate_sentiment(entity: str, hops: int = Query(default=2, le=3)):
    """Propagate sentiment outward from entity through the knowledge graph."""
    from knowledge_graph import propagate_sentiment
    result = await propagate_sentiment(entity, hops=hops)
    return {"entity": entity, "hops": hops, "propagated": result}


@app.get("/knowledge-graph/clusters", dependencies=[Depends(verify_api_key)])
async def kg_narrative_clusters(min_weight: int = Query(default=3, ge=1)):
    """Return narrative clusters grouped by shared entity-topic edges."""
    from knowledge_graph import cluster_narratives
    clusters = await cluster_narratives(min_weight=min_weight)
    return {"clusters": clusters}


@app.get("/narratives/summary", dependencies=[Depends(verify_api_key)])
async def narrative_summary():
    """Return NarrativeEngine cluster stats and top clusters."""
    from narrative_engine import engine as ne
    return {
        "stats":        ne.cluster_summary(),
        "top_clusters": ne.top_clusters(n=10),
    }


# ---------------------------------------------------------------------------
# Round 3: Regime / Horizon / Capacity endpoints
# ---------------------------------------------------------------------------

@app.get("/signals/regime", dependencies=[Depends(verify_api_key)])
async def signals_by_regime(
    ticker:  str   = Query(..., description="Ticker for price history (e.g. SPY)"),
    days:    int   = Query(default=90, le=365),
    horizon: int   = Query(default=1, ge=1, le=10),
):
    """
    Return per-regime IC / Sharpe breakdown for recent signals.
    Requires a ticker for vol and trend regime classification.
    """
    from regime import classify_regimes, run_regime_split
    from finance import get_price_history
    import pandas as pd

    pool = await get_pool()
    rows = await pool.fetch("""
        SELECT event_id, scraped_at, signal_score, signal_direction,
               sentiment_label, sentiment_score, event_type,
               materiality_score, novelty_score, credibility_score
        FROM   scraped_events
        WHERE  scraped_at > NOW() - ($1 || ' days')::INTERVAL
          AND  NOT is_duplicate
        ORDER  BY scraped_at
        LIMIT  5000
    """, str(days))

    price_df = get_price_history(ticker, days=days + 20)
    if price_df is None:
        raise HTTPException(status_code=404, detail=f"No price data for {ticker}")
    price_df.index = pd.to_datetime(price_df.index).normalize()

    events   = [dict(r) for r in rows]
    labelled = classify_regimes(events, price_df)
    report   = run_regime_split(labelled, horizon=horizon)
    return report.to_dict()


@app.get("/signals/horizon", dependencies=[Depends(verify_api_key)])
async def optimise_signal_horizon(
    ticker:   str  = Query(..., description="Ticker for price joins"),
    days:     int  = Query(default=180, le=730),
):
    """
    Find the optimal holding period for recent signals.
    Returns ic_curve, sharpe_curve, and per-event-type best horizons.
    """
    from horizon import optimise_horizon
    from finance import get_price_history
    from execution import ExecutionEngine
    import pandas as pd

    pool = await get_pool()
    rows = await pool.fetch("""
        SELECT event_id, scraped_at, signal_score, signal_direction,
               sentiment_label, event_type, signal_tier
        FROM   scraped_events
        WHERE  scraped_at > NOW() - ($1 || ' days')::INTERVAL
          AND  NOT is_duplicate
        ORDER  BY scraped_at
        LIMIT  10000
    """, str(days))

    price_df = get_price_history(ticker, days=days + 20)
    if price_df is None:
        raise HTTPException(status_code=404, detail=f"No price data for {ticker}")
    price_df.index = pd.to_datetime(price_df.index).normalize()

    engine = ExecutionEngine(delay_minutes=15, slippage_bps=10)
    events = [dict(r) for r in rows]

    # Join prices for each horizon
    for ev in events:
        ts = ev.get("scraped_at")
        if ts is None:
            continue
        if not isinstance(ts, str):
            ts = ts.isoformat()
        from datetime import datetime
        ts_dt = datetime.fromisoformat(ts) if isinstance(ts, str) else ts
        label = (ev.get("sentiment_label") or "NEUTRAL").upper()
        direction = "LONG" if label == "POSITIVE" else "SHORT"
        for h in [1, 2, 3, 5, 7, 10]:
            trade = engine.simulate_fill(ts_dt, price_df, direction=direction, horizon=h)
            ev[f"fwd_ret_{h}d"] = trade.return_pct if trade else None

    result = optimise_horizon(events, horizons=[1, 2, 3, 5, 7, 10])
    return result.to_dict()


@app.get("/signals/capacity", dependencies=[Depends(verify_api_key)])
async def capacity_report(
    adv:         float = Query(default=1_000_000, description="Avg daily volume (shares)"),
    avg_price:   float = Query(default=100.0,     description="Avg share price"),
    alpha_bps:   float = Query(default=30.0,      description="Expected alpha per trade (bps)"),
    days:        int   = Query(default=30,  le=180),
):
    """
    Estimate market impact and capacity ceiling for recent portfolio orders.
    """
    from capacity import CapacityAnalyser
    from signal_filter import SignalFilter, FilterConfig
    from portfolio import PortfolioLayer, PortfolioConfig

    pool = await get_pool()
    rows = await pool.fetch("""
        SELECT event_id, scraped_at, signal_score, signal_direction,
               signal_tier, source_domain
        FROM   scraped_events
        WHERE  scraped_at > NOW() - ($1 || ' days')::INTERVAL
          AND  NOT is_duplicate
          AND  signal_tier IN ('STRONG', 'MODERATE')
        ORDER  BY ABS(signal_score) DESC
        LIMIT  500
    """, str(days))

    events = [dict(r) for r in rows]
    filt   = SignalFilter(FilterConfig(min_score=0.20, allowed_tiers=["STRONG", "MODERATE"]))
    filtered = filt.apply(events)

    layer  = PortfolioLayer(PortfolioConfig(max_position=10_000, sizing="PROP"))
    layer.ingest(filtered)
    orders = layer.orders()

    trading_days = max(1, days * 5 // 7)
    cap = CapacityAnalyser(avg_daily_volume=adv, avg_price=avg_price)
    rpt = cap.report(orders, signal_alpha_bps=alpha_bps,
                     trading_days_in_window=trading_days)
    return rpt.to_dict()


@app.get("/signals/second-order/{entity}", dependencies=[Depends(verify_api_key)])
async def second_order_signals(
    entity:     str,
    base_score: float = Query(default=0.5, ge=-1.0, le=1.0),
    min_score:  float = Query(default=0.10, ge=0.0, le=1.0),
):
    """
    Generate second-order alpha signals for entities related to *entity*
    via the knowledge graph's sentiment propagation.
    """
    from capacity import SecondOrderAlpha
    pool = await get_pool()
    soa  = SecondOrderAlpha(pool)
    signals = await soa.propagate(entity=entity, base_score=base_score,
                                  min_score=min_score)
    return {"entity": entity, "base_score": base_score, "secondary_signals": signals}


@app.get("/calibration/orthogonality", dependencies=[Depends(verify_api_key)])
async def feature_orthogonality(days: int = Query(default=90, le=365)):
    """Run feature orthogonality diagnostics (correlation matrix + VIF) on recent events."""
    from calibration import compute_orthogonality, _build_feature_matrix, FEATURE_NAMES

    pool = await get_pool()
    rows = await pool.fetch("""
        SELECT sentiment_score, sentiment_label, materiality_score,
               novelty_score, credibility_score
        FROM   scraped_events
        WHERE  scraped_at > NOW() - ($1 || ' days')::INTERVAL
          AND  NOT is_duplicate
        LIMIT  5000
    """, str(days))

    events = []
    for r in rows:
        label = (r["sentiment_label"] or "NEUTRAL").upper()
        sign  = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
        events.append({
            "sentiment_label":   label,
            "sentiment_score":   float(r["sentiment_score"] or 0.0),
            "materiality_score": float(r["materiality_score"] or 0.0),
            "novelty_score":     float(r["novelty_score"] or 0.5),
            "credibility_score": float(r["credibility_score"] or 0.5),
            "fwd_ret": sign * float(r["sentiment_score"] or 0.0),
        })

    X, _ = _build_feature_matrix(events)
    if X is None:
        raise HTTPException(status_code=422, detail="Insufficient data for orthogonality check")

    orth = compute_orthogonality(X)
    return {
        "n_events":      len(rows),
        "features":      FEATURE_NAMES,
        "corr_matrix":   orth["corr_matrix"],
        "vif":           orth["vif"],
        "corr_warnings": orth["corr_warnings"],
        "vif_warnings":  orth["vif_warnings"],
    }


@app.get("/signals/stability", dependencies=[Depends(verify_api_key)])
async def feature_stability_report(
    days:              int  = Query(default=180, le=730),
    horizon:           int  = Query(default=1,   ge=1, le=10),
    window:            int  = Query(default=60,  ge=20),
    step:              int  = Query(default=20,  ge=5),
    with_interactions: bool = Query(default=False),
):
    """Rolling feature stability: coefficient traces and drift warnings."""
    from feature_stability import analyse_stability
    from execution import ExecutionEngine
    from finance import get_price_history
    import pandas as pd

    pool = await get_pool()
    rows = await pool.fetch("""
        SELECT event_id, scraped_at, signal_score, sentiment_label, sentiment_score,
               materiality_score, novelty_score, credibility_score, event_type
        FROM   scraped_events
        WHERE  scraped_at > NOW() - ($1 || ' days')::INTERVAL
          AND  NOT is_duplicate
        ORDER  BY scraped_at
        LIMIT  10000
    """, str(days))

    events = [dict(r) for r in rows]
    report = analyse_stability(
        events, horizon=horizon, window=window, step=step,
        with_interactions=with_interactions,
    )
    return report.to_dict()


@app.get("/signals/regime-model", dependencies=[Depends(verify_api_key)])
async def fit_regime_model_endpoint(
    ticker:  str = Query(..., description="Ticker for regime classification"),
    days:    int = Query(default=180, le=730),
    horizon: int = Query(default=1, ge=1, le=10),
):
    """Fit per-regime conditional models and return IC per regime bucket."""
    from regime_model import fit_regime_models
    from regime import classify_regimes
    from finance import get_price_history
    import pandas as pd

    pool     = await get_pool()
    rows     = await pool.fetch("""
        SELECT event_id, scraped_at, signal_score, sentiment_label, sentiment_score,
               materiality_score, novelty_score, credibility_score, event_type
        FROM   scraped_events
        WHERE  scraped_at > NOW() - ($1 || ' days')::INTERVAL
          AND  NOT is_duplicate
        ORDER  BY scraped_at
        LIMIT  10000
    """, str(days))

    price_df = get_price_history(ticker, days=days + 20)
    if price_df is None:
        raise HTTPException(status_code=404, detail=f"No price data for {ticker}")
    price_df.index = pd.to_datetime(price_df.index).normalize()

    events   = [dict(r) for r in rows]
    labelled = classify_regimes(events, price_df)
    ms       = fit_regime_models(labelled, horizon=horizon)
    return {
        "horizon":           horizon,
        "available_regimes": ms.available_regimes(),
        "global_ic":         ms.global_.ic,
        "models": {
            k: {"n_samples": m.n_samples, "ic": m.ic, "is_fallback": m.is_fallback}
            for k, m in ms.models.items()
        },
    }


@app.post("/signals/validate-second-order", dependencies=[Depends(verify_api_key)])
async def validate_second_order_endpoint(payload: dict):
    """
    Validate whether second-order signals add IC over first-order alone.

    Payload: {
        first_order_events:  [...],
        second_order_events: [...],
        blend_lambda:        0.3,
        horizon:             1
    }
    """
    from second_order_validation import validate_second_order

    first   = payload.get("first_order_events", [])
    second  = payload.get("second_order_events", [])
    lam     = float(payload.get("blend_lambda", 0.3))
    horizon = int(payload.get("horizon", 1))

    result = validate_second_order(first, second, blend_lambda=lam, horizon=horizon)
    return {
        "keep":               result.keep,
        "ic_first":           result.ic_first,
        "ic_combined":        result.ic_combined,
        "ic_lift":            result.ic_lift,
        "sharpe_first":       result.sharpe_first,
        "sharpe_combined":    result.sharpe_combined,
        "recommended_lambda": result.recommended_lambda,
        "notes":              result.notes,
    }


# ============================================================================
# Governance endpoints  (§16 Governance Engine, §17 Risk Throttle, §23 Kill Switch)
# ============================================================================

@app.get("/governance/status", dependencies=[Depends(verify_api_key)])
async def governance_status():
    """
    Return the current governance confidence, throttle mode, and kill-switch state.
    This is the single most important system-health endpoint.
    """
    from governance_engine  import get_engine   as _get_gov
    from risk_throttle      import get_throttle as _get_throttle
    from kill_switch        import get_switch   as _get_switch
    from market_state       import get_market_state
    from liquidity_engine   import get_engine   as _get_liq
    from positioning_engine import get_engine   as _get_pos

    liq_engine = _get_liq()
    pos_engine = _get_pos()
    gov_engine = _get_gov(
        liquidity_engine   = liq_engine,
        positioning_engine = pos_engine,
    )
    throttle   = _get_throttle()
    ks         = _get_switch()

    ms = await get_market_state()
    report = await gov_engine.assess(market_state=ms)
    t_state = throttle.update(report)

    return {
        "governance": {
            "confidence":             report.governance_confidence,
            "mode":                   report.mode,
            "recommended_size_scalar": report.recommended_size_scalar,
            "component_scores":       report.component_scores,
            "warnings":               report.warnings,
            "computed_at":            report.computed_at.isoformat(),
        },
        "throttle": {
            "mode":             t_state.mode,
            "size_scalar":      t_state.size_scalar,
            "max_positions":    t_state.max_positions,
            "signal_min_score": t_state.signal_min_score,
            "new_positions_ok": t_state.new_positions_ok,
            "message":          t_state.message,
        },
        "kill_switch": ks.status(),
    }


@app.get("/governance/liquidity", dependencies=[Depends(verify_api_key)])
async def liquidity_snapshot():
    """Return the latest market liquidity and microstructure snapshot."""
    from liquidity_engine import get_engine as _get_liq
    snap = await _get_liq().get_snapshot()
    return {
        "liquidity_stress_index": snap.liquidity_stress_index,
        "execution_fragility":    snap.execution_fragility,
        "spread_instability":     snap.spread_instability,
        "structural_fragility":   snap.structural_fragility,
        "regime":                 snap.regime,
        "components": {
            "amihud_score":     snap.amihud_score,
            "hl_spread_score":  snap.hl_spread_score,
            "vol_ratio":        snap.vol_ratio,
            "correlation_score": snap.correlation_score,
            "volume_anomaly":   snap.volume_anomaly,
        },
        "fetched_at": snap.fetched_at.isoformat(),
        "is_stale":   snap.is_stale,
        "notes":      snap.notes,
    }


@app.get("/governance/positioning/{ticker}", dependencies=[Depends(verify_api_key)])
async def positioning_snapshot(ticker: str):
    """Return the positioning and flow snapshot for a ticker."""
    from positioning_engine import get_engine as _get_pos
    snap = await _get_pos().get_snapshot(ticker.upper())
    return {
        "ticker":                snap.ticker,
        "crowding_score":        snap.crowding_score,
        "squeeze_probability":   snap.squeeze_probability,
        "positioning_imbalance": snap.positioning_imbalance,
        "forced_flow_prob":      snap.forced_flow_prob,
        "fragility_estimate":    snap.fragility_estimate,
        "signal_direction":      snap.signal_direction,
        "components": {
            "short_pct_float":  snap.short_pct_float,
            "days_to_cover":    snap.days_to_cover,
            "put_call_ratio":   snap.put_call_ratio,
            "iv_skew":          snap.iv_skew,
            "call_vol_surge":   snap.call_vol_surge,
            "put_vol_surge":    snap.put_vol_surge,
            "insider_buy_frac": snap.insider_buy_frac,
            "etf_flow_signal":  snap.etf_flow_signal,
        },
        "fetched_at": snap.fetched_at.isoformat(),
        "is_stale":   snap.is_stale,
        "notes":      snap.notes,
    }


@app.post("/governance/kill-switch/suspend", dependencies=[Depends(verify_api_key)])
async def kill_switch_suspend(payload: dict):
    """
    Operator-triggered system suspension.
    Required payload: {"reason": "...", "operator": "..."}
    """
    from kill_switch import get_switch as _get_switch
    reason   = payload.get("reason", "").strip()
    operator = payload.get("operator", "").strip()
    if not reason or not operator:
        raise HTTPException(status_code=400, detail="Both 'reason' and 'operator' are required")

    ks = _get_switch()
    ks.manual_suspend(reason=reason, operator=operator)
    return {"state": ks.current_state.value, "message": f"System suspended by {operator}"}


@app.post("/governance/kill-switch/reset", dependencies=[Depends(verify_api_key)])
async def kill_switch_reset(payload: dict):
    """
    Reset from SUSPENDED or KILLED state.
    Required payload: {"reason": "...", "operator": "..."}
    """
    from kill_switch import get_switch as _get_switch
    reason   = payload.get("reason", "").strip()
    operator = payload.get("operator", "").strip()
    if not reason or not operator:
        raise HTTPException(status_code=400, detail="Both 'reason' and 'operator' are required")

    ks = _get_switch()
    try:
        ks.reset(reason=reason, operator=operator)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return {"state": ks.current_state.value, "message": f"Kill switch reset by {operator}"}


@app.get("/governance/kill-switch/history", dependencies=[Depends(verify_api_key)])
async def kill_switch_history():
    """Return the full kill-switch event history."""
    from kill_switch import get_switch as _get_switch
    ks = _get_switch()
    return {"events": ks.event_history(), "current_state": ks.current_state.value}


# ============================================================================
# Data sources registry endpoints
# ============================================================================

@app.get("/data-sources/status", dependencies=[Depends(verify_api_key)])
async def data_sources_status():
    """
    Health report for all registered data sources.
    Includes: FRED, ECB SDW, US Treasury, CBOE, FINRA, Reddit, AP Business,
    Reuters, SEC EDGAR, yfinance, Alpha Vantage, Google Trends, Congressional.
    """
    from data_sources_registry import get_registry
    return get_registry().health_report()


@app.post("/data-sources/{source_name}/record-success",
          dependencies=[Depends(verify_api_key)])
async def record_source_success(source_name: str):
    """Manually record a successful fetch for a data source."""
    from data_sources_registry import get_registry
    reg = get_registry()
    await reg.record_success(source_name)
    src = reg.get(source_name)
    return {"source": source_name, "health": src.health.value if src else "unknown"}


@app.get("/data-sources/macro/snapshot", dependencies=[Depends(verify_api_key)])
async def macro_snapshot():
    """
    Current macro feature snapshot from FRED, ECB SDW, US Treasury, and CBOE.
    Includes: yields, VIX term structure, HY/IG spreads, EUR/USD, macro regime.
    """
    from macro_features import get_engine as _get_macro
    snap = await _get_macro().get_snapshot()
    return {
        "fred": {
            "unemployment":    snap.fred_unemployment,
            "cpi_yoy":         snap.fred_cpi_yoy,
            "initial_claims":  snap.fred_initial_claims,
            "hy_spread":       snap.fred_hy_spread,
            "ig_spread":       snap.fred_ig_spread,
            "breakeven_5y":    snap.fred_breakeven_5y,
            "ted_spread":      snap.fred_ted_spread,
        },
        "us_treasury": {
            "tsy_3m":          snap.tsy_3m,
            "tsy_2y":          snap.tsy_2y,
            "tsy_5y":          snap.tsy_5y,
            "tsy_10y":         snap.tsy_10y,
            "tsy_30y":         snap.tsy_30y,
            "spread_10y_2y":   snap.tsy_10y_2y_spread,
            "spread_10y_3m":   snap.tsy_10y_3m_spread,
        },
        "cboe": {
            "vix_9d":          snap.cboe_vix9d,
            "vix_30d":         snap.cboe_vix,
            "vix_3m":          snap.cboe_vix3m,
            "vix_6m":          snap.cboe_vix6m,
            "term_slope":      snap.cboe_vix_term_slope,
            "term_score":      snap.cboe_vix_term_score,
        },
        "ecb": {
            "eurusd":          snap.ecb_eurusd,
            "euribor_3m":      snap.ecb_euribor_3m,
            "bund_10y":        snap.ecb_de_bund_10y,
            "ita_de_spread":   snap.ecb_spread_ita_de,
        },
        "composite": {
            "macro_stress_score": snap.macro_stress_score,
            "macro_growth_score": snap.macro_growth_score,
            "global_risk_regime": snap.global_risk_regime,
        },
        "sources_ok":  snap.sources_ok,
        "fetched_at":  snap.fetched_at.isoformat(),
        "is_stale":    snap.is_stale,
    }


@app.get("/data-sources/financial/{ticker}", dependencies=[Depends(verify_api_key)])
async def financial_features_ticker(ticker: str):
    """
    Full financial feature vector for a ticker.
    Includes: price momentum, fundamentals, earnings surprise (EPS SUE),
    CBOE implied move, FINRA short vol, analyst revisions.
    """
    from financial_features import get_engine as _get_fin
    fv = await _get_fin().get_features(ticker.upper())
    return {
        "ticker": fv.ticker,
        "price":  fv.price.as_feature_dict()       if fv.price       else None,
        "fundamental": fv.fundamental.as_feature_dict() if fv.fundamental else None,
        "earnings": fv.earnings.as_feature_dict()   if fv.earnings    else None,
        "macro":  fv.macro.as_feature_dict()        if fv.macro       else None,
        "signal_conditioning": fv.as_signal_conditioning_dict(),
        "is_usable": fv.is_usable,
        "computed_at": fv.computed_at.isoformat(),
    }
