"""
positioning_engine.py — §2 Positioning + Flow Engine.

Infers crowding, forced flows, and squeeze risk from publicly available
data sources without requiring prime brokerage or proprietary feeds.

Data sources
------------
1. Short interest         — yfinance .info (shortRatio, shortPercentOfFloat)
2. Options positioning    — data_connectors.OptionsSnapshot (P/C, IV skew, vol surge)
3. ETF flow proxy         — yfinance sector ETF AUM momentum (XLK, XLF, etc.)
4. Insider activity       — yfinance .get_insider_transactions()
5. Market state context   — market_state.MarketState (vix, risk_regime)

Outputs (PositioningSnapshot)
------------------------------
  crowding_score         ∈ [0, 1]  — 0 = uncrowded, 1 = extremely crowded
  squeeze_probability    ∈ [0, 1]  — probability of a short squeeze
  positioning_imbalance  ∈ [-1, 1] — negative = heavy short, positive = heavy long
  forced_flow_prob       ∈ [0, 1]  — probability of forced/mechanical flows
  fragility_estimate     ∈ [0, 1]  — positioning fragility (tail risk proxy)
  signal_direction       str       — 'CONTRARIAN_LONG' | 'CONTRARIAN_SHORT' | 'NEUTRAL'

Degradation
-----------
All sub-components are optional. On any data failure the component is
omitted from the composite and logged. The snapshot is always returned —
it may have is_stale=True with None component fields if all sources fail.

Usage
-----
    from positioning_engine import PositioningEngine

    engine = PositioningEngine()
    snap = await engine.get_snapshot("AAPL")
    print(snap.crowding_score, snap.squeeze_probability, snap.signal_direction)

    # Batch query for multiple tickers
    snaps = await engine.get_snapshots(["AAPL", "MSFT", "NVDA"])
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------

# Short interest thresholds (% of float)
_SHORT_LOW   = 0.03   # < 3%  → uncrowded
_SHORT_MED   = 0.10   # < 10% → moderate
_SHORT_HIGH  = 0.20   # > 20% → heavily shorted (squeeze candidate)

# Days-to-cover thresholds
_DTC_LOW  = 1.0
_DTC_HIGH = 5.0

# IV skew thresholds (put IV - call IV in %)
_SKEW_BEARISH_MED  = 2.0
_SKEW_BEARISH_HIGH = 5.0

# Put/call ratio thresholds
_PC_NEUTRAL_LOW  = 0.70
_PC_NEUTRAL_HIGH = 1.20
_PC_EXTREME      = 2.00

# Insider buy threshold — fraction of recent transactions that are purchases
_INSIDER_BUY_THRESHOLD = 0.60

# Cache TTL seconds
_CACHE_TTL = 1800  # 30 min


# ---------------------------------------------------------------------------
# Output dataclass
# ---------------------------------------------------------------------------

@dataclass
class PositioningSnapshot:
    ticker: str

    # Composite scores
    crowding_score:        Optional[float] = None   # [0, 1]
    squeeze_probability:   Optional[float] = None   # [0, 1]
    positioning_imbalance: Optional[float] = None   # [-1, 1]
    forced_flow_prob:      Optional[float] = None   # [0, 1]
    fragility_estimate:    Optional[float] = None   # [0, 1]

    # Signal direction derived from positioning
    signal_direction: str = "NEUTRAL"   # CONTRARIAN_LONG | CONTRARIAN_SHORT | NEUTRAL

    # Sub-component data
    short_pct_float:   Optional[float] = None
    days_to_cover:     Optional[float] = None
    put_call_ratio:    Optional[float] = None
    iv_skew:           Optional[float] = None
    call_vol_surge:    bool = False
    put_vol_surge:     bool = False
    insider_buy_frac:  Optional[float] = None   # fraction of recent txns that are buys
    etf_flow_signal:   Optional[float] = None   # [-1, 1] sector ETF flow momentum

    # Metadata
    fetched_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_stale:   bool = True
    notes:      list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Helper: clamp
# ---------------------------------------------------------------------------

def _clamp(v: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, v))


# ---------------------------------------------------------------------------
# Sub-scorers
# ---------------------------------------------------------------------------

def _short_crowding(short_pct: Optional[float], dtc: Optional[float]) -> tuple[float, float]:
    """
    Returns (crowding_component, squeeze_component) ∈ [0, 1] each.

    High short interest + high DTC = crowded short = squeeze candidate.
    """
    if short_pct is None:
        return 0.5, 0.5   # neutral fallback

    # Normalise short % of float
    if short_pct < _SHORT_LOW:
        crowd = 0.1
        squeeze = 0.05
    elif short_pct < _SHORT_MED:
        crowd = 0.3 + (short_pct - _SHORT_LOW) / (_SHORT_MED - _SHORT_LOW) * 0.3
        squeeze = 0.2
    elif short_pct < _SHORT_HIGH:
        crowd = 0.6 + (short_pct - _SHORT_MED) / (_SHORT_HIGH - _SHORT_MED) * 0.3
        squeeze = 0.5
    else:
        crowd   = 0.9
        squeeze = 0.8

    # Days-to-cover amplifies squeeze risk
    if dtc is not None:
        dtc_factor = _clamp((dtc - _DTC_LOW) / (_DTC_HIGH - _DTC_LOW))
        squeeze = _clamp(squeeze + dtc_factor * 0.15)

    return round(crowd, 4), round(squeeze, 4)


def _options_signals(
    pc_ratio:       Optional[float],
    iv_skew:        Optional[float],
    call_vol_surge: bool,
    put_vol_surge:  bool,
) -> tuple[float, float]:
    """
    Returns (options_crowding_component, positioning_imbalance_component).

    positioning_imbalance: negative = crowded short (bearish options), positive = crowded long.
    """
    if pc_ratio is None and iv_skew is None:
        return 0.5, 0.0

    imbalance = 0.0
    crowding  = 0.0

    # Put/call ratio contribution
    if pc_ratio is not None:
        if pc_ratio > _PC_EXTREME:
            # Extreme put buying — bearish crowding → contrarian long signal
            imbalance -= 0.5
            crowding   = 0.8
        elif pc_ratio > _PC_NEUTRAL_HIGH:
            imbalance -= (pc_ratio - _PC_NEUTRAL_HIGH) / (_PC_EXTREME - _PC_NEUTRAL_HIGH) * 0.5
            crowding   = 0.4 + (pc_ratio - _PC_NEUTRAL_HIGH) / (_PC_EXTREME - _PC_NEUTRAL_HIGH) * 0.4
        elif pc_ratio < _PC_NEUTRAL_LOW:
            # Low put buying — bullish crowding → contrarian short signal
            imbalance += (_PC_NEUTRAL_LOW - pc_ratio) / _PC_NEUTRAL_LOW * 0.4
            crowding   = 0.4 + (_PC_NEUTRAL_LOW - pc_ratio) / _PC_NEUTRAL_LOW * 0.3

    # IV skew contribution (put skew = bearish crowding)
    if iv_skew is not None:
        if iv_skew > _SKEW_BEARISH_HIGH:
            imbalance -= 0.3
            crowding   = max(crowding, 0.7)
        elif iv_skew > _SKEW_BEARISH_MED:
            imbalance -= (iv_skew - _SKEW_BEARISH_MED) / (_SKEW_BEARISH_HIGH - _SKEW_BEARISH_MED) * 0.3
            crowding   = max(crowding, 0.5)
        elif iv_skew < 0:
            # Negative skew = call IV > put IV = unusual bullish crowding
            imbalance += min(0.3, abs(iv_skew) / 3.0)
            crowding   = max(crowding, 0.4)

    # Volume surges increase fragility / forced-flow probability
    if call_vol_surge:
        imbalance += 0.1   # unusual call buying
        crowding   = max(crowding, 0.6)
    if put_vol_surge:
        imbalance -= 0.1
        crowding   = max(crowding, 0.6)

    return round(_clamp(crowding), 4), round(_clamp(imbalance, -1.0, 1.0), 4)


def _insider_signal(buy_frac: Optional[float]) -> float:
    """
    Returns positioning_imbalance adjustment from insider activity.
    Heavy insider buying → positive (undervalued / crowded short).
    Heavy selling → negative.
    """
    if buy_frac is None:
        return 0.0
    # Centre around 0.5 (50% buys = neutral)
    return round(_clamp((buy_frac - 0.5) * 0.6, -0.3, 0.3), 4)


def _derive_signal_direction(
    positioning_imbalance: float,
    squeeze_probability:   float,
    crowding_score:        float,
) -> str:
    """
    Crowded positions are a contrarian indicator:
    - Heavily short-crowded (imbalance < -0.3) + high squeeze prob → CONTRARIAN_LONG
    - Heavily long-crowded (imbalance > 0.3)                       → CONTRARIAN_SHORT
    - Otherwise                                                     → NEUTRAL
    """
    if positioning_imbalance < -0.3 and crowding_score > 0.6:
        return "CONTRARIAN_LONG"
    if positioning_imbalance > 0.3 and crowding_score > 0.6:
        return "CONTRARIAN_SHORT"
    if squeeze_probability > 0.70:
        return "CONTRARIAN_LONG"
    return "NEUTRAL"


# ---------------------------------------------------------------------------
# Fetch helpers (run in executor — yfinance is sync)
# ---------------------------------------------------------------------------

def _fetch_short_data_sync(ticker: str) -> tuple[Optional[float], Optional[float]]:
    """Returns (short_pct_float, days_to_cover)."""
    try:
        import yfinance as yf
        info = yf.Ticker(ticker).info
        spf = info.get("shortPercentOfFloat")
        dtc = info.get("shortRatio")
        return (float(spf) if spf is not None else None,
                float(dtc)  if dtc  is not None else None)
    except Exception as exc:
        logger.debug("Short data fetch failed for %s: %s", ticker, exc)
        return None, None


def _fetch_insider_sync(ticker: str) -> Optional[float]:
    """
    Returns fraction of recent insider transactions that are purchases.
    Uses the last 10 transactions.
    """
    try:
        import yfinance as yf
        obj = yf.Ticker(ticker)
        txns = obj.get_insider_transactions()
        if txns is None or (hasattr(txns, "empty") and txns.empty):
            return None
        # The 'Transaction' column contains the action description
        recent = txns.head(10)
        if "Transaction" not in recent.columns:
            return None
        purchases = recent["Transaction"].str.lower().str.contains(
            "purchase|buy|acquisition", na=False
        ).sum()
        return round(float(purchases) / len(recent), 4)
    except Exception as exc:
        logger.debug("Insider data fetch failed for %s: %s", ticker, exc)
        return None


def _fetch_etf_flow_proxy_sync(sector_etfs: list[str]) -> Optional[float]:
    """
    Rough ETF flow proxy: average 5d return of sector ETFs vs 20d return.
    Positive = money flowing in (momentum); negative = outflows.
    Returns [-1, 1].
    """
    try:
        import yfinance as yf
        import pandas as pd
        data = yf.download(sector_etfs, period="30d", progress=False, auto_adjust=True)
        if data.empty:
            return None
        closes = data["Close"] if "Close" in data else data
        if isinstance(closes, pd.Series):
            closes = closes.to_frame()
        ret_5d  = (closes.iloc[-1] / closes.iloc[-5]  - 1).mean()
        ret_20d = (closes.iloc[-1] / closes.iloc[-20] - 1).mean() if len(closes) >= 20 else ret_5d
        # Normalise: 5d momentum relative to 20d; clip at ±5%
        flow = _clamp((ret_5d - ret_20d) / 0.05, -1.0, 1.0)
        return round(float(flow), 4)
    except Exception as exc:
        logger.debug("ETF flow proxy failed: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

_SECTOR_ETFS = ["XLK", "XLF", "XLE", "XLV", "XLI", "XLP", "XLY", "XLU", "XLB", "XLRE", "XLC"]


class PositioningEngine:
    """
    Computes positioning and flow metrics for individual tickers.
    Results are cached for _CACHE_TTL seconds.
    """

    def __init__(self) -> None:
        self._cache: dict[str, tuple[float, PositioningSnapshot]] = {}
        self._lock = asyncio.Lock()

    async def get_snapshot(
        self,
        ticker:        str,
        options_snap   = None,   # Optional[OptionsSnapshot] from data_connectors
        force_refresh: bool = False,
    ) -> PositioningSnapshot:
        """
        Return a PositioningSnapshot for ``ticker``.

        Pass ``options_snap`` to avoid a redundant yfinance options call if
        the caller already has one from data_connectors.OptionsConnector.
        """
        async with self._lock:
            now = time.monotonic()
            if not force_refresh and ticker in self._cache:
                expires, cached = self._cache[ticker]
                if now < expires:
                    return cached

            snap = await self._build_snapshot(ticker, options_snap)
            self._cache[ticker] = (now + _CACHE_TTL, snap)
            return snap

    async def get_snapshots(
        self,
        tickers: list[str],
        options_snaps: Optional[dict] = None,
    ) -> dict[str, PositioningSnapshot]:
        """Batch query — runs tickers concurrently."""
        options_snaps = options_snaps or {}
        tasks = [
            self.get_snapshot(t, options_snaps.get(t))
            for t in tickers
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        out: dict[str, PositioningSnapshot] = {}
        for ticker, result in zip(tickers, results):
            if isinstance(result, Exception):
                logger.warning("Positioning snapshot failed for %s: %s", ticker, result)
                out[ticker] = PositioningSnapshot(ticker=ticker, is_stale=True)
            else:
                out[ticker] = result
        return out

    async def _build_snapshot(
        self,
        ticker:       str,
        options_snap  = None,
    ) -> PositioningSnapshot:
        loop = asyncio.get_running_loop()
        notes: list[str] = []

        # ── Fetch concurrently ───────────────────────────────────────────────
        short_task   = loop.run_in_executor(None, _fetch_short_data_sync, ticker)
        insider_task = loop.run_in_executor(None, _fetch_insider_sync,    ticker)
        etf_task     = loop.run_in_executor(None, _fetch_etf_flow_proxy_sync, _SECTOR_ETFS)

        (short_pct, dtc), insider_buy_frac, etf_flow = await asyncio.gather(
            short_task, insider_task, etf_task
        )

        # ── Options data ─────────────────────────────────────────────────────
        if options_snap is not None and not options_snap.is_stale:
            pc_ratio    = options_snap.put_call_ratio
            iv_skew     = options_snap.iv_skew
            call_surge  = options_snap.call_vol_surge
            put_surge   = options_snap.put_vol_surge
        else:
            # Attempt a direct fetch
            try:
                from data_connectors import options as _opt_connector
                snap = await _opt_connector.get_snapshot(ticker)
                pc_ratio   = snap.put_call_ratio  if snap and not snap.is_stale else None
                iv_skew    = snap.iv_skew          if snap and not snap.is_stale else None
                call_surge = snap.call_vol_surge   if snap else False
                put_surge  = snap.put_vol_surge    if snap else False
            except Exception as exc:
                logger.debug("Options fallback fetch failed for %s: %s", ticker, exc)
                pc_ratio = iv_skew = None
                call_surge = put_surge = False
                notes.append("options_unavailable")

        # ── Score components ─────────────────────────────────────────────────
        crowd_short, squeeze = _short_crowding(short_pct, dtc)
        crowd_opts,  imbal   = _options_signals(pc_ratio, iv_skew, call_surge, put_surge)
        insider_adj          = _insider_signal(insider_buy_frac)

        # Crowding: weighted blend of short + options components
        n_sources = sum([short_pct is not None, pc_ratio is not None])
        if n_sources == 0:
            crowding_score = None
            notes.append("no_crowding_data")
        elif n_sources == 1:
            crowding_score = crowd_short if short_pct is not None else crowd_opts
        else:
            crowding_score = round(0.55 * crowd_short + 0.45 * crowd_opts, 4)

        # Positioning imbalance
        positioning_imbalance = round(
            _clamp(imbal * 0.6 + insider_adj * 0.4, -1.0, 1.0), 4
        )

        # Squeeze probability: short component + options amplification
        squeeze_prob = None
        if short_pct is not None:
            squeeze_prob = squeeze
            if call_surge:                         # unusual call buying during high short interest
                squeeze_prob = _clamp(squeeze_prob + 0.15)
            if iv_skew is not None and iv_skew < 0:  # call skew = expectation of upward move
                squeeze_prob = _clamp(squeeze_prob + 0.10)
            squeeze_prob = round(squeeze_prob, 4)

        # Forced flow probability
        # High options volume surges + high crowding → likely mechanical/forced flows
        forced_flow = None
        if crowding_score is not None:
            ff = crowding_score * 0.6
            if call_surge or put_surge:
                ff = _clamp(ff + 0.2)
            if etf_flow is not None and abs(etf_flow) > 0.5:
                ff = _clamp(ff + 0.1)
            forced_flow = round(ff, 4)

        # Fragility: combine crowding + forced flow + squeeze
        components = [x for x in [crowding_score, forced_flow, squeeze_prob] if x is not None]
        fragility = round(sum(components) / len(components), 4) if components else None

        # Derive direction
        direction = "NEUTRAL"
        if crowding_score is not None and squeeze_prob is not None:
            direction = _derive_signal_direction(
                positioning_imbalance or 0.0, squeeze_prob, crowding_score
            )

        is_stale = (crowding_score is None and squeeze_prob is None)

        snap = PositioningSnapshot(
            ticker                 = ticker,
            crowding_score         = crowding_score,
            squeeze_probability    = squeeze_prob,
            positioning_imbalance  = positioning_imbalance,
            forced_flow_prob       = forced_flow,
            fragility_estimate     = fragility,
            signal_direction       = direction,
            short_pct_float        = short_pct,
            days_to_cover          = dtc,
            put_call_ratio         = pc_ratio,
            iv_skew                = iv_skew,
            call_vol_surge         = call_surge,
            put_vol_surge          = put_surge,
            insider_buy_frac       = insider_buy_frac,
            etf_flow_signal        = etf_flow,
            fetched_at             = datetime.now(timezone.utc),
            is_stale               = is_stale,
            notes                  = notes,
        )

        logger.info(
            "Positioning[%s]: crowding=%.2f  squeeze=%.2f  imbalance=%.2f  dir=%s",
            ticker,
            crowding_score  or -1,
            squeeze_prob    or -1,
            positioning_imbalance or 0,
            direction,
        )
        return snap


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# #1 — PositioningSmoothing layer (EWMA + z-score + stability check)
# ---------------------------------------------------------------------------

class PositioningSmoothing:
    """
    Prevents false "crowding spikes" by:
    1. EWMA smoothing of raw component scores
    2. Z-score normalisation relative to 90-day rolling history
    3. Sector-relative adjustment (score vs sector peers)
    4. Rolling stability check — suppresses signals when parameters are unstable
    """

    def __init__(self, alpha: float = 0.25, window: int = 60) -> None:
        from scaling_framework import RollingScaler
        self._alpha   = alpha
        self._window  = window
        # One scaler per scored component
        self._scalers: dict[str, "RollingScaler"] = {
            name: RollingScaler(window=window, method="zscore")
            for name in ["crowding_score", "squeeze_probability",
                         "positioning_imbalance", "fragility_estimate"]
        }
        # EWMA state per component
        self._ewma: dict[str, Optional[float]] = {k: None for k in self._scalers}
        # Sector peer history: sector → deque of recent crowding scores
        from collections import defaultdict, deque
        self._sector_history: dict = defaultdict(lambda: deque(maxlen=50))

    def smooth(
        self,
        snap: "PositioningSnapshot",
        sector: Optional[str] = None,
    ) -> "PositioningSnapshot":
        """
        Apply all smoothing passes and return a new smoothed snapshot.
        Modifies scores in-place and adds 'smoothed' flag to notes.
        """
        # EWMA pass
        for field_name, scaler in self._scalers.items():
            raw = getattr(snap, field_name, None)
            if raw is None:
                continue
            # EWMA
            prev_ewma = self._ewma[field_name]
            if prev_ewma is None:
                smoothed = raw
            else:
                smoothed = self._alpha * raw + (1.0 - self._alpha) * prev_ewma
            self._ewma[field_name] = smoothed
            # Z-score normalise into [0,1] (crowding/fragility) or [-1,1] (imbalance)
            scaler.update(smoothed)
            if scaler.is_warm:
                z = scaler.transform(smoothed)
                if field_name == "positioning_imbalance":
                    normalised = _clamp(z / 3.0, -1.0, 1.0)   # z ∈ [-3,3] → [-1,1]
                else:
                    normalised = _clamp((z + 3.0) / 6.0)       # z ∈ [-3,3] → [0,1]
                setattr(snap, field_name, round(normalised, 4))
            else:
                setattr(snap, field_name, round(smoothed, 4))

        # Sector-relative adjustment on crowding_score
        if sector and snap.crowding_score is not None:
            self._sector_history[sector].append(snap.crowding_score)
            if len(self._sector_history[sector]) >= 5:
                import numpy as np
                sector_avg = float(np.mean(list(self._sector_history[sector])[:-1]))
                sector_std = float(np.std(list(self._sector_history[sector])[:-1])) or 0.1
                # Adjust crowding relative to sector baseline
                relative = (snap.crowding_score - sector_avg) / sector_std
                snap.crowding_score = round(_clamp((relative + 3.0) / 6.0), 4)
                snap.notes.append(f"sector_relative_adj(sector={sector})")

        # Stability check: if scalers are unstable, suppress the signal
        stabilities = [s.stability_score() for s in self._scalers.values()]
        avg_stability = sum(stabilities) / len(stabilities)
        if avg_stability < 0.30:
            snap.notes.append(f"low_stability({avg_stability:.2f}) — signals suppressed")
            snap.crowding_score       = None
            snap.squeeze_probability  = None
            snap.fragility_estimate   = None
            snap.signal_direction     = "NEUTRAL"
            snap.is_stale             = True
        elif avg_stability < 0.60:
            snap.notes.append(f"moderate_stability({avg_stability:.2f})")

        snap.notes.append("ewma_smoothed")
        return snap


_smoother: Optional[PositioningSmoothing] = None


def get_smoother() -> PositioningSmoothing:
    global _smoother
    if _smoother is None:
        _smoother = PositioningSmoothing()
    return _smoother


_engine: Optional[PositioningEngine] = None


def get_engine() -> PositioningEngine:
    global _engine
    if _engine is None:
        _engine = PositioningEngine()
    return _engine
