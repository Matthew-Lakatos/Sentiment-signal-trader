"""
cache.py — PostgreSQL-backed URL scrape cache.
Replaces the previous SQLite-coupled implementation.
"""
from __future__ import annotations
from datetime import datetime, timezone, timedelta

from asyncpg.pool import Pool
from config import settings


def _now() -> datetime:
    return datetime.now(timezone.utc)


async def is_cache_valid(pool: Pool, url: str) -> bool:
    row = await pool.fetchrow(
        "SELECT last_scraped_at FROM scrape_cache WHERE url = $1", url
    )
    if not row:
        return False
    last = row["last_scraped_at"]
    if last.tzinfo is None:
        last = last.replace(tzinfo=timezone.utc)
    return _now() < last + timedelta(hours=settings.cache_expiry_hours)


async def update_cache(pool: Pool, url: str) -> None:
    await pool.execute("""
        INSERT INTO scrape_cache (url, last_scraped_at)
        VALUES ($1, NOW())
        ON CONFLICT (url) DO UPDATE SET last_scraped_at = NOW()
    """, url)
