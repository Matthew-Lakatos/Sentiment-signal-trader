import numpy as np
from embeddings import generate_embedding
import time
import math


SIM_THRESHOLD = 0.82


class NarrativeEngine:

    def __init__(self):
        self.clusters = []

    def _similarity(self, a, b):
        a = np.array(a)
        b = np.array(b)
        return float(np.dot(a, b))

    @staticmethod
    def recency_weight(timestamp):
        age_days = (time.time() - timestamp) / 86400
        return math.exp(-0.05 * age_days)

    @staticmethod
    def narrative_importance(cluster):
        credibility = cluster.get("credibility", 0.5)
        timestamp   = cluster.get("timestamp", time.time())
        size        = cluster.get("size", 1)
        return credibility * NarrativeEngine.recency_weight(timestamp) * size

    def add_article(self, text, summary):
        emb = generate_embedding(summary or text[:500])
        if emb is None:
            return None

        for cluster in self.clusters:
            sim = self._similarity(emb, cluster["centroid"])
            if sim > SIM_THRESHOLD:
                cluster["articles"].append(summary)
                cluster["centroid"] = (
                    (np.array(cluster["centroid"]) + np.array(emb)) / 2
                ).tolist()
                cluster["size"] = cluster.get("size", 1) + 1
                return cluster["id"]

        cid = len(self.clusters)
        self.clusters.append({
            "id":          cid,
            "centroid":    emb,
            "articles":    [summary],
            "timestamp":   time.time(),
            "credibility": 0.5,
            "size":        1,
        })
        return cid

    # -----------------------------------------------------------------------
    # NEW: Novelty detection using in-process cluster centroids
    # -----------------------------------------------------------------------

    def compute_novelty(self, embedding: list, window_hours: float = 48.0) -> float:
        """
        Return novelty score in [0, 1] by comparing *embedding* against
        recent cluster centroids weighted by recency decay.

        1.0 = completely novel (no similar cluster in window)
        0.0 = highly similar to a recent cluster
        """
        from novelty import narrative_novelty
        cutoff = time.time() - window_hours * 3600.0
        recent_centroids  = []
        recent_timestamps = []
        for c in self.clusters:
            if c.get("timestamp", 0) >= cutoff:
                recent_centroids.append(c["centroid"])
                recent_timestamps.append(c["timestamp"])
        return narrative_novelty(embedding, recent_centroids, recent_timestamps)

    def top_clusters(self, n: int = 10) -> list[dict]:
        """Return the top-n clusters by narrative importance (recency × size × credibility)."""
        scored = [
            {**c, "importance": self.narrative_importance(c)}
            for c in self.clusters
        ]
        return sorted(scored, key=lambda x: x["importance"], reverse=True)[:n]

    def cluster_summary(self) -> dict:
        """High-level stats about the current narrative landscape."""
        if not self.clusters:
            return {"total_clusters": 0, "total_articles": 0}
        sizes = [c.get("size", 1) for c in self.clusters]
        return {
            "total_clusters":  len(self.clusters),
            "total_articles":  sum(sizes),
            "largest_cluster": max(sizes),
            "mean_cluster_size": round(sum(sizes) / len(sizes), 2),
        }


engine = NarrativeEngine()
