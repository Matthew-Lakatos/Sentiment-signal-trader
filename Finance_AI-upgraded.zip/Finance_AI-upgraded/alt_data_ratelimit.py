"""
alt_data_ratelimit.py — Rate limiting and circuit breakers for alt-data connectors.

Running the pipeline hourly without rate limiting will exhaust:
  - Reddit unauthenticated API: ~60 req/min, ~1000 req/day per IP
  - SEC EDGAR: 10 req/sec (hard limit, results in 429)
  - Congressional trades: S3 bucket, effectively unlimited but polite
  - Google Trends / pytrends: undocumented limits, ~100 req/day

This module provides:
1. TokenBucketRateLimiter   — leaky bucket per connector
2. ConnectorCircuitBreaker  — open/half-open/closed per connector
3. RateLimitedConnector     — decorator that wraps any connector fetch()
4. Global rate limit registry

Usage
-----
    from alt_data_ratelimit import get_limiter, get_breaker, rate_limited

    # Wrap a fetch call
    limiter = get_limiter("reddit", rate=10, per_seconds=60)
    breaker = get_breaker("reddit", fail_threshold=5, reset_seconds=300)

    @rate_limited("sec_edgar")
    async def fetch_sec(ticker):
        ...

    # Or manually
    await limiter.acquire()
    try:
        result = await fetch_something()
        breaker.record_success()
    except Exception as exc:
        breaker.record_failure(exc)
        raise
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from functools import wraps
from typing import Callable, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Token bucket rate limiter
# ---------------------------------------------------------------------------

class TokenBucketRateLimiter:
    """
    Leaky-bucket rate limiter.

    Allows `rate` tokens per `per_seconds` window.
    Tokens refill continuously. Callers that exceed the rate
    are queued and wait for a token to become available.
    """

    def __init__(
        self,
        name:        str,
        rate:        float,   # max calls
        per_seconds: float,   # per this window
        burst:       Optional[float] = None,  # max burst above rate (default = rate)
    ) -> None:
        self._name        = name
        self._rate        = rate / per_seconds   # tokens per second
        self._max_tokens  = burst or rate
        self._tokens      = float(self._max_tokens)
        self._last_refill = time.monotonic()
        self._lock        = asyncio.Lock()
        self._total_waits = 0
        self._total_calls = 0

    async def acquire(self, tokens: float = 1.0) -> float:
        """
        Wait until `tokens` tokens are available, then consume them.
        Returns the wait time in seconds.
        """
        async with self._lock:
            self._refill()
            self._total_calls += 1

            if self._tokens >= tokens:
                self._tokens -= tokens
                return 0.0

            # Must wait
            deficit   = tokens - self._tokens
            wait_secs = deficit / self._rate
            self._total_waits += 1

        await asyncio.sleep(wait_secs)

        async with self._lock:
            self._refill()
            self._tokens = max(0.0, self._tokens - tokens)

        if wait_secs > 0.5:
            logger.debug("Rate limiter [%s]: waited %.2fs", self._name, wait_secs)
        return wait_secs

    def _refill(self) -> None:
        now      = time.monotonic()
        elapsed  = now - self._last_refill
        self._tokens = min(
            self._max_tokens,
            self._tokens + elapsed * self._rate,
        )
        self._last_refill = now

    @property
    def stats(self) -> dict:
        return {
            "name":         self._name,
            "total_calls":  self._total_calls,
            "total_waits":  self._total_waits,
            "current_tokens": round(self._tokens, 2),
            "rate_per_sec":   round(self._rate, 4),
        }


# ---------------------------------------------------------------------------
# Circuit breaker
# ---------------------------------------------------------------------------

class CircuitState(str, Enum):
    CLOSED    = "CLOSED"      # Normal: all calls go through
    OPEN      = "OPEN"        # Tripped: all calls fail immediately
    HALF_OPEN = "HALF_OPEN"   # Probing: one call allowed to test recovery


@dataclass
class ConnectorCircuitBreaker:
    """
    Three-state circuit breaker for data connectors.

    CLOSED (normal) → OPEN (tripped after N failures)
    OPEN → HALF_OPEN (after reset_seconds elapsed)
    HALF_OPEN → CLOSED (on success) | OPEN (on failure)
    """
    name:             str
    fail_threshold:   int   = 5
    reset_seconds:    float = 300.0  # 5 minutes

    _state:           CircuitState = field(default=CircuitState.CLOSED, init=False)
    _failure_count:   int          = field(default=0, init=False)
    _last_failure_at: float        = field(default=0.0, init=False)
    _last_success_at: float        = field(default=0.0, init=False)
    _total_failures:  int          = field(default=0, init=False)
    _total_calls:     int          = field(default=0, init=False)
    _lock:            asyncio.Lock = field(default_factory=asyncio.Lock, init=False)

    def is_open(self) -> bool:
        """True if the circuit is open (calls should be rejected)."""
        if self._state == CircuitState.OPEN:
            # Check if reset window has elapsed
            if time.monotonic() - self._last_failure_at >= self.reset_seconds:
                self._state = CircuitState.HALF_OPEN
                logger.info("Circuit [%s]: OPEN → HALF_OPEN (probing)", self.name)
                return False
            return True
        return False

    def allow_call(self) -> bool:
        """Return True if the call should proceed."""
        self._total_calls += 1
        if self._state == CircuitState.CLOSED:
            return True
        if self._state == CircuitState.OPEN:
            return not self.is_open()
        if self._state == CircuitState.HALF_OPEN:
            return True   # Allow one probe call
        return False

    def record_success(self) -> None:
        self._failure_count  = 0
        self._last_success_at = time.monotonic()
        if self._state == CircuitState.HALF_OPEN:
            self._state = CircuitState.CLOSED
            logger.info("Circuit [%s]: HALF_OPEN → CLOSED (recovery confirmed)", self.name)

    def record_failure(self, exc: Optional[Exception] = None) -> None:
        self._failure_count  += 1
        self._total_failures += 1
        self._last_failure_at = time.monotonic()

        if self._state == CircuitState.HALF_OPEN:
            self._state = CircuitState.OPEN
            logger.warning(
                "Circuit [%s]: HALF_OPEN → OPEN (probe failed: %s)", self.name, exc
            )
        elif self._failure_count >= self.fail_threshold:
            self._state = CircuitState.OPEN
            logger.error(
                "Circuit [%s]: CLOSED → OPEN after %d failures. "
                "Will retry in %.0fs.",
                self.name, self._failure_count, self.reset_seconds,
            )

    @property
    def state(self) -> CircuitState:
        return self._state

    @property
    def stats(self) -> dict:
        return {
            "name":            self.name,
            "state":           self._state.value,
            "failure_count":   self._failure_count,
            "total_failures":  self._total_failures,
            "total_calls":     self._total_calls,
            "last_failure_ago": round(time.monotonic() - self._last_failure_at, 1)
                                if self._last_failure_at else None,
        }


# ---------------------------------------------------------------------------
# Default connector configurations
# ---------------------------------------------------------------------------

_DEFAULT_LIMITS: dict[str, dict] = {
    "sec_edgar":           {"rate": 8,   "per_seconds": 1,    "burst": 15},
    "reddit":              {"rate": 10,  "per_seconds": 60,   "burst": 15},
    "google_trends":       {"rate": 1,   "per_seconds": 10,   "burst": 3},
    "congressional_trades": {"rate": 2,  "per_seconds": 60,   "burst": 5},
    "job_postings":        {"rate": 2,   "per_seconds": 60,   "burst": 4},
    "uspto_patents":       {"rate": 5,   "per_seconds": 1,    "burst": 10},
    "yfinance":            {"rate": 100, "per_seconds": 60,   "burst": 200},
    "fred":                {"rate": 20,  "per_seconds": 60,   "burst": 30},
    "web_scraper":         {"rate": 20,  "per_seconds": 1,    "burst": 50},
}

_DEFAULT_BREAKERS: dict[str, dict] = {
    "sec_edgar":           {"fail_threshold": 5,  "reset_seconds": 300},
    "reddit":              {"fail_threshold": 5,  "reset_seconds": 300},
    "google_trends":       {"fail_threshold": 3,  "reset_seconds": 600},
    "congressional_trades": {"fail_threshold": 3, "reset_seconds": 1800},
    "job_postings":        {"fail_threshold": 5,  "reset_seconds": 600},
    "uspto_patents":       {"fail_threshold": 5,  "reset_seconds": 300},
    "yfinance":            {"fail_threshold": 10, "reset_seconds": 120},
}


# ---------------------------------------------------------------------------
# Global registry
# ---------------------------------------------------------------------------

_limiters:  dict[str, TokenBucketRateLimiter] = {}
_breakers:  dict[str, ConnectorCircuitBreaker] = {}


def get_limiter(
    name:        str,
    rate:        Optional[float] = None,
    per_seconds: Optional[float] = None,
    burst:       Optional[float] = None,
) -> TokenBucketRateLimiter:
    if name not in _limiters:
        cfg = _DEFAULT_LIMITS.get(name, {"rate": 10, "per_seconds": 60})
        _limiters[name] = TokenBucketRateLimiter(
            name        = name,
            rate        = rate        or cfg["rate"],
            per_seconds = per_seconds or cfg["per_seconds"],
            burst       = burst       or cfg.get("burst"),
        )
    return _limiters[name]


def get_breaker(
    name:            str,
    fail_threshold:  Optional[int]   = None,
    reset_seconds:   Optional[float] = None,
) -> ConnectorCircuitBreaker:
    if name not in _breakers:
        cfg = _DEFAULT_BREAKERS.get(name, {"fail_threshold": 5, "reset_seconds": 300})
        _breakers[name] = ConnectorCircuitBreaker(
            name           = name,
            fail_threshold = fail_threshold or cfg["fail_threshold"],
            reset_seconds  = reset_seconds  or cfg["reset_seconds"],
        )
    return _breakers[name]


def registry_stats() -> dict:
    return {
        "limiters": {name: l.stats for name, l in _limiters.items()},
        "breakers": {name: b.stats for name, b in _breakers.items()},
    }


# ---------------------------------------------------------------------------
# Decorator
# ---------------------------------------------------------------------------

def rate_limited(connector_name: str):
    """
    Decorator that applies rate limiting and circuit-breaker protection
    to any async function (typically a connector's fetch method).

    Usage:
        @rate_limited("sec_edgar")
        async def fetch_filings(ticker):
            ...
    """
    def decorator(fn: Callable):
        @wraps(fn)
        async def wrapper(*args, **kwargs):
            limiter = get_limiter(connector_name)
            breaker = get_breaker(connector_name)

            if not breaker.allow_call():
                logger.warning(
                    "Circuit OPEN for [%s] — skipping call (resets in ~%.0fs)",
                    connector_name,
                    breaker.reset_seconds - (time.monotonic() - breaker._last_failure_at),
                )
                return []   # empty result — caller must handle

            await limiter.acquire()

            try:
                result = await fn(*args, **kwargs)
                breaker.record_success()
                return result
            except Exception as exc:
                breaker.record_failure(exc)
                logger.warning("[%s] connector error: %s", connector_name, exc)
                return []   # degrade gracefully

        return wrapper
    return decorator
