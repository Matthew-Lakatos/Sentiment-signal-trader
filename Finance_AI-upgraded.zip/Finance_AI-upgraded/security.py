"""
security.py — FastAPI security: API key auth + rate limiting.
"""
from __future__ import annotations
import time
from collections import defaultdict
from threading import Lock

from fastapi import HTTPException, Security, status
from fastapi.security import APIKeyHeader

from config import settings

_api_key_header = APIKeyHeader(name="X-API-Key", auto_error=True)


async def verify_api_key(key: str = Security(_api_key_header)) -> str:
    if key != settings.api_key:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid API key",
        )
    return key


# ---------------------------------------------------------------------------
# Simple in-process rate limiter (per IP, sliding window)
# ---------------------------------------------------------------------------

_rate_lock   = Lock()
_request_log: dict[str, list[float]] = defaultdict(list)


def check_rate_limit(client_ip: str) -> None:
    limit    = settings.api_rate_limit_per_minute
    window   = 60.0
    now      = time.time()
    with _rate_lock:
        times = _request_log[client_ip]
        times = [t for t in times if now - t < window]
        _request_log[client_ip] = times
        if len(times) >= limit:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=f"Rate limit: {limit} requests/minute exceeded",
                headers={"Retry-After": "60"},
            )
        _request_log[client_ip].append(now)
