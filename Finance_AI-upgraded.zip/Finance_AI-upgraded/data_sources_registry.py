"""
data_sources_registry.py — Central data source registry with health tracking.

Every data source the platform uses is registered here with:
  - Name and URL
  - Category (macro, alternative, news, market, regulatory)
  - Health status (HEALTHY / DEGRADED / UNAVAILABLE)
  - Last successful fetch timestamp
  - Failure count and circuit breaker state
  - Staleness threshold (how old data can be before considered stale)

This registry is:
  1. Queried by the governance engine to discount confidence when
     critical sources are unavailable
  2. Exposed via the API at /data-sources/status
  3. Used by the alt_data_ratelimit circuit breakers for coordinated
     failure handling across the platform

Sources tracked
---------------
  News           Reuters, AP Business, SEC EDGAR
  Alternative    Reddit (PRAW), Google Trends, Congressional trades,
                 USPTO patents, FINRA short interest
  Market         yfinance (price, options, fundamentals)
                 Alpha Vantage (EPS history fallback)
  Macro          FRED, ECB SDW, US Treasury, CBOE VIX
  Regulatory     SEC EDGAR XBRL, FINRA REGSHO

Usage
-----
    from data_sources_registry import get_registry, SourceHealth

    registry = get_registry()
    registry.record_success("fred")
    registry.record_failure("ecb_sdw", "timeout")

    status = registry.health_report()
    critical_down = registry.critical_sources_unavailable()
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Health states
# ---------------------------------------------------------------------------

class SourceHealth(str, Enum):
    HEALTHY     = "HEALTHY"
    DEGRADED    = "DEGRADED"       # intermittent failures
    UNAVAILABLE = "UNAVAILABLE"    # circuit open / all recent fetches failed
    UNKNOWN     = "UNKNOWN"        # never been fetched


# ---------------------------------------------------------------------------
# Source definition
# ---------------------------------------------------------------------------

@dataclass
class DataSource:
    name:               str
    url:                str
    category:           str        # news | alternative | market | macro | regulatory
    is_critical:        bool       # affects governance_confidence if unavailable
    staleness_threshold_h: float   # hours before data considered stale

    # Runtime state
    health:             SourceHealth = SourceHealth.UNKNOWN
    last_success_at:    Optional[float] = None    # monotonic
    last_failure_at:    Optional[float] = None
    consecutive_failures: int = 0
    total_calls:        int = 0
    total_successes:    int = 0
    total_failures:     int = 0
    last_error:         Optional[str] = None

    @property
    def success_rate(self) -> Optional[float]:
        if self.total_calls == 0:
            return None
        return round(self.total_successes / self.total_calls, 4)

    @property
    def is_stale(self) -> bool:
        if self.last_success_at is None:
            return True
        age_h = (time.monotonic() - self.last_success_at) / 3600
        return age_h > self.staleness_threshold_h

    def to_dict(self) -> dict:
        return {
            "name":                self.name,
            "url":                 self.url,
            "category":            self.category,
            "is_critical":         self.is_critical,
            "health":              self.health.value,
            "success_rate":        self.success_rate,
            "consecutive_failures": self.consecutive_failures,
            "is_stale":            self.is_stale,
            "last_error":          self.last_error,
            "total_calls":         self.total_calls,
            "total_successes":     self.total_successes,
        }


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

_SOURCE_DEFINITIONS: list[dict] = [
    # ── News sources ─────────────────────────────────────────────────────────
    dict(name="reuters",         url="https://www.reuters.com",
         category="news",        is_critical=False, staleness_threshold_h=2),
    dict(name="ap_business",     url="https://apnews.com/hub/business",
         category="news",        is_critical=False, staleness_threshold_h=2),
    dict(name="sec_edgar_news",  url="https://efts.sec.gov/LATEST/search-index",
         category="news",        is_critical=True,  staleness_threshold_h=6),

    # ── Alternative data ──────────────────────────────────────────────────────
    dict(name="reddit_praw",     url="https://praw.readthedocs.io",
         category="alternative", is_critical=False, staleness_threshold_h=4),
    dict(name="google_trends",   url="https://trends.google.com",
         category="alternative", is_critical=False, staleness_threshold_h=12),
    dict(name="congressional",   url="https://housestockwatcher.com/api",
         category="alternative", is_critical=False, staleness_threshold_h=24),
    dict(name="uspto_patents",   url="https://developer.uspto.gov",
         category="alternative", is_critical=False, staleness_threshold_h=168),
    dict(name="finra_short",     url="https://www.finra.org/finra-data/browse-catalog/short-sale-volume-data",
         category="regulatory",  is_critical=False, staleness_threshold_h=26),

    # ── Market data ───────────────────────────────────────────────────────────
    dict(name="yfinance",        url="https://finance.yahoo.com",
         category="market",      is_critical=True,  staleness_threshold_h=1),
    dict(name="alpha_vantage",   url="https://www.alphavantage.co",
         category="market",      is_critical=False, staleness_threshold_h=6),
    dict(name="cboe_vix",        url="https://www.cboe.com",
         category="market",      is_critical=True,  staleness_threshold_h=2),

    # ── Macro data ────────────────────────────────────────────────────────────
    dict(name="fred",            url="https://fred.stlouisfed.org",
         category="macro",       is_critical=True,  staleness_threshold_h=26),
    dict(name="ecb_sdw",         url="https://data.ecb.europa.eu",
         category="macro",       is_critical=False, staleness_threshold_h=26),
    dict(name="us_treasury",     url="https://home.treasury.gov/resource-center/data-chart-center/interest-rates",
         category="macro",       is_critical=True,  staleness_threshold_h=26),

    # ── Regulatory ────────────────────────────────────────────────────────────
    dict(name="sec_edgar_xbrl",  url="https://www.sec.gov/edgar/search",
         category="regulatory",  is_critical=False, staleness_threshold_h=24),
]


class DataSourceRegistry:
    """
    Central health tracker for all data sources.
    Thread-safe via asyncio.Lock.
    """

    def __init__(self) -> None:
        self._sources: dict[str, DataSource] = {
            defn["name"]: DataSource(**defn)
            for defn in _SOURCE_DEFINITIONS
        }
        self._lock = asyncio.Lock()
        self._DEGRADED_THRESHOLD   = 3    # consecutive failures → DEGRADED
        self._UNAVAILABLE_THRESHOLD = 7   # consecutive failures → UNAVAILABLE

    # ------------------------------------------------------------------
    # Recording
    # ------------------------------------------------------------------

    async def record_success(self, source_name: str) -> None:
        async with self._lock:
            src = self._sources.get(source_name)
            if src is None:
                return
            src.total_calls       += 1
            src.total_successes   += 1
            src.last_success_at    = time.monotonic()
            src.consecutive_failures = 0
            src.health = SourceHealth.HEALTHY

    async def record_failure(self, source_name: str, error: str = "") -> None:
        async with self._lock:
            src = self._sources.get(source_name)
            if src is None:
                return
            src.total_calls          += 1
            src.total_failures        += 1
            src.last_failure_at       = time.monotonic()
            src.consecutive_failures  += 1
            src.last_error            = error[:200] if error else None

            if src.consecutive_failures >= self._UNAVAILABLE_THRESHOLD:
                if src.health != SourceHealth.UNAVAILABLE:
                    logger.error("Source [%s] marked UNAVAILABLE after %d failures",
                                 source_name, src.consecutive_failures)
                src.health = SourceHealth.UNAVAILABLE
            elif src.consecutive_failures >= self._DEGRADED_THRESHOLD:
                if src.health == SourceHealth.HEALTHY:
                    logger.warning("Source [%s] DEGRADED after %d failures",
                                   source_name, src.consecutive_failures)
                src.health = SourceHealth.DEGRADED

    # ------------------------------------------------------------------
    # Sync wrappers (for non-async contexts)
    # ------------------------------------------------------------------

    def record_success_sync(self, source_name: str) -> None:
        src = self._sources.get(source_name)
        if src:
            src.total_calls += 1
            src.total_successes += 1
            src.last_success_at = time.monotonic()
            src.consecutive_failures = 0
            src.health = SourceHealth.HEALTHY

    def record_failure_sync(self, source_name: str, error: str = "") -> None:
        src = self._sources.get(source_name)
        if not src:
            return
        src.total_calls += 1
        src.total_failures += 1
        src.consecutive_failures += 1
        src.last_error = error[:200] if error else None
        if src.consecutive_failures >= self._UNAVAILABLE_THRESHOLD:
            src.health = SourceHealth.UNAVAILABLE
        elif src.consecutive_failures >= self._DEGRADED_THRESHOLD:
            src.health = SourceHealth.DEGRADED

    # ------------------------------------------------------------------
    # Queries
    # ------------------------------------------------------------------

    def get(self, name: str) -> Optional[DataSource]:
        return self._sources.get(name)

    def critical_sources_unavailable(self) -> list[str]:
        """Return names of critical sources that are currently UNAVAILABLE."""
        return [
            name for name, src in self._sources.items()
            if src.is_critical and src.health == SourceHealth.UNAVAILABLE
        ]

    def unavailability_penalty(self) -> float:
        """
        Returns a confidence penalty [0, 0.30] based on how many critical
        sources are unavailable.  Consumed by governance_engine.
        """
        critical_down = self.critical_sources_unavailable()
        critical_total = sum(1 for s in self._sources.values() if s.is_critical)
        if critical_total == 0:
            return 0.0
        fraction_down = len(critical_down) / critical_total
        return round(min(0.30, fraction_down * 0.40), 4)

    def health_report(self) -> dict:
        by_health = {h.value: [] for h in SourceHealth}
        for name, src in self._sources.items():
            by_health[src.health.value].append(name)

        return {
            "summary": {h: len(names) for h, names in by_health.items()},
            "critical_unavailable": self.critical_sources_unavailable(),
            "unavailability_penalty": self.unavailability_penalty(),
            "sources": {name: src.to_dict() for name, src in self._sources.items()},
        }

    def register(
        self,
        name:                  str,
        url:                   str,
        category:              str,
        is_critical:           bool  = False,
        staleness_threshold_h: float = 24.0,
    ) -> DataSource:
        """Register a new data source at runtime."""
        src = DataSource(
            name                  = name,
            url                   = url,
            category              = category,
            is_critical           = is_critical,
            staleness_threshold_h = staleness_threshold_h,
        )
        self._sources[name] = src
        return src


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_registry: Optional[DataSourceRegistry] = None


def get_registry() -> DataSourceRegistry:
    global _registry
    if _registry is None:
        _registry = DataSourceRegistry()
    return _registry
