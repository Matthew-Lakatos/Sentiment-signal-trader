"""
regime.py — market regime classification and per-regime signal analysis.

Reality check
-------------
A single model calibrated on all data implicitly assumes the market is
stationary — that sentiment matters equally in a bull run and a crash.
It isn't. This module splits backtests by regime so you can see:

  - Whether your signal survives vol spikes (e.g. VIX > 25)
  - Whether it works in both bull and bear periods
  - Whether you need a regime-conditional weight set

Two regime axes
---------------
1. Volatility regime  — LOW / MEDIUM / HIGH / SPIKE
   Measured by 20-day rolling realised vol of the price series.

2. Trend regime       — BULL / NEUTRAL / BEAR
   Measured by 60-day rolling return of the underlying.

Usage
-----
    from regime import classify_regimes, run_regime_split

    # Attach regime labels to each event
    events = classify_regimes(events, price_df)

    # Run per-regime IC / Sharpe / hit-rate
    report = run_regime_split(events, horizon=1)
    print(report.summary())
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Optional

import pandas as pd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Thresholds (configurable)
# ---------------------------------------------------------------------------

# Annualised vol thresholds
_VOL_LOW    = 0.10   # < 10% ann. → LOW
_VOL_MEDIUM = 0.18   # 10–18%    → MEDIUM
_VOL_HIGH   = 0.30   # 18–30%    → HIGH
                     # > 30%     → SPIKE

# Rolling 60-day return thresholds
_BULL_THRESHOLD = 0.05   # > +5%  → BULL
_BEAR_THRESHOLD = -0.05  # < -5%  → BEAR


# ---------------------------------------------------------------------------
# Regime classification
# ---------------------------------------------------------------------------

def _rolling_vol(price_df: pd.DataFrame, window: int = 20) -> pd.Series:
    """
    Compute 20-day rolling annualised realised volatility.
    Uses log returns to match standard convention.
    """
    log_ret = (price_df["Close"] / price_df["Close"].shift(1)).apply(math.log)
    return log_ret.rolling(window).std() * math.sqrt(252)


def _rolling_trend(price_df: pd.DataFrame, window: int = 60) -> pd.Series:
    """60-day rolling return (simple, not annualised)."""
    return price_df["Close"].pct_change(window)


def _vol_label(vol: float) -> str:
    if not math.isfinite(vol):
        return "UNKNOWN"
    if vol < _VOL_LOW:
        return "LOW"
    if vol < _VOL_MEDIUM:
        return "MEDIUM"
    if vol < _VOL_HIGH:
        return "HIGH"
    return "SPIKE"


def _trend_label(ret: float) -> str:
    if not math.isfinite(ret):
        return "UNKNOWN"
    if ret > _BULL_THRESHOLD:
        return "BULL"
    if ret < _BEAR_THRESHOLD:
        return "BEAR"
    return "NEUTRAL"


def build_regime_index(price_df: pd.DataFrame) -> pd.DataFrame:
    """
    Return a DataFrame indexed by date with columns:
        vol_regime   — LOW / MEDIUM / HIGH / SPIKE
        trend_regime — BULL / NEUTRAL / BEAR
        rolling_vol  — float (annualised)
        rolling_ret  — float (60-day simple return)
    """
    rv   = _rolling_vol(price_df)
    rt   = _rolling_trend(price_df)
    out  = pd.DataFrame({
        "rolling_vol":  rv,
        "rolling_ret":  rt,
        "vol_regime":   rv.apply(_vol_label),
        "trend_regime": rt.apply(_trend_label),
    }, index=price_df.index)
    return out


def classify_regimes(
    events:    list[dict],
    price_df:  pd.DataFrame,
) -> list[dict]:
    """
    Attach vol_regime and trend_regime to each event dict based on the
    price data on the event's scraped_at date.

    Events with no matching price date get regime = "UNKNOWN".
    """
    regime_idx = build_regime_index(price_df)
    result     = []

    for ev in events:
        ts = ev.get("scraped_at")
        if ts is None:
            result.append({**ev, "vol_regime": "UNKNOWN", "trend_regime": "UNKNOWN"})
            continue
        if isinstance(ts, str):
            try:
                ts = pd.Timestamp(ts).normalize()
            except Exception:
                result.append({**ev, "vol_regime": "UNKNOWN", "trend_regime": "UNKNOWN"})
                continue
        else:
            ts = pd.Timestamp(ts).normalize()

        # Ensure tz-naive for comparison (regime_idx is tz-naive)
        if ts.tzinfo is not None:
            ts = ts.tz_localize(None)

        # Find nearest past date in regime index
        valid_dates = regime_idx.index[regime_idx.index <= ts]
        if valid_dates.empty:
            result.append({**ev, "vol_regime": "UNKNOWN", "trend_regime": "UNKNOWN"})
            continue

        nearest = valid_dates[-1]
        row     = regime_idx.loc[nearest]
        result.append({
            **ev,
            "vol_regime":   str(row["vol_regime"]),
            "trend_regime": str(row["trend_regime"]),
            "rolling_vol":  round(float(row["rolling_vol"]), 4)
                            if math.isfinite(float(row["rolling_vol"])) else None,
        })

    return result


# ---------------------------------------------------------------------------
# Per-regime statistics
# ---------------------------------------------------------------------------

@dataclass
class RegimeSlice:
    regime_key:  str
    n:           int
    ic:          float
    sharpe:      float
    hit_rate:    float
    mean_ret:    float


@dataclass
class RegimeReport:
    horizon:     int
    vol_cuts:    list[RegimeSlice]
    trend_cuts:  list[RegimeSlice]
    overall_ic:  float

    def summary(self) -> str:
        lines = [
            f"\n{'─'*62}",
            f"  REGIME ANALYSIS  (T+{self.horizon}d)   overall IC={self.overall_ic:.4f}",
            f"{'─'*62}",
            f"  {'Regime':<22} {'n':>5} {'IC':>7} {'Hit%':>7} {'Sharpe':>8}",
            f"{'─'*62}",
        ]
        lines.append("  ── Volatility regime ───────────────────────────")
        for s in self.vol_cuts:
            ok = "✓" if math.isfinite(s.ic) and s.ic > 0 else "⚠"
            lines.append(
                f"  {ok} {s.regime_key:<20} {s.n:>5} "
                f"{s.ic:>7.4f} {s.hit_rate:>6.1%} {s.sharpe:>8.2f}"
            )
        lines.append("  ── Trend regime ────────────────────────────────")
        for s in self.trend_cuts:
            ok = "✓" if math.isfinite(s.ic) and s.ic > 0 else "⚠"
            lines.append(
                f"  {ok} {s.regime_key:<20} {s.n:>5} "
                f"{s.ic:>7.4f} {s.hit_rate:>6.1%} {s.sharpe:>8.2f}"
            )
        lines.append(f"{'─'*62}")
        lines += self._verdict()
        return "\n".join(lines)

    def _verdict(self) -> list[str]:
        v = []
        ics = [s.ic for s in self.vol_cuts + self.trend_cuts
               if math.isfinite(s.ic) and s.n >= 5]
        if not ics:
            return ["  ⚠  Insufficient data for regime verdict"]
        pos = sum(1 for ic in ics if ic > 0.005)
        if pos == len(ics):
            v.append("  ✓  Signal positive IC across ALL regime cuts")
        elif pos / len(ics) >= 0.6:
            v.append(f"  ✓  Signal positive IC in {pos}/{len(ics)} regime cuts")
        else:
            v.append(f"  ⚠  Signal positive IC in only {pos}/{len(ics)} cuts — regime-dependent")

        spike_slices = [s for s in self.vol_cuts if "SPIKE" in s.regime_key]
        if spike_slices and spike_slices[0].ic < 0:
            v.append("  ⚠  Signal REVERSES in vol-spike regime — consider regime gate")
        return v

    def to_dict(self) -> dict:
        def _s(sl):
            return {"regime": sl.regime_key, "n": sl.n, "ic": sl.ic,
                    "sharpe": sl.sharpe, "hit_rate": sl.hit_rate}
        return {
            "overall_ic":  self.overall_ic,
            "vol_cuts":    [_s(s) for s in self.vol_cuts],
            "trend_cuts":  [_s(s) for s in self.trend_cuts],
        }


# ---------------------------------------------------------------------------
# Internal metric helpers
# ---------------------------------------------------------------------------

def _spearman(xs: list, ys: list) -> float:
    n = len(xs)
    if n < 3:
        return float("nan")
    try:
        from scipy.stats import spearmanr
        r, _ = spearmanr(xs, ys)
        return float(r) if math.isfinite(r) else float("nan")
    except ImportError:
        return float("nan")


def _sharpe(rets: list) -> float:
    n = len(rets)
    if n < 2:
        return float("nan")
    mu  = sum(rets) / n
    std = math.sqrt(sum((r - mu) ** 2 for r in rets) / (n - 1))
    return (mu / std * math.sqrt(252)) if std > 1e-9 else float("nan")


def _hit_rate(sigs: list, rets: list, thr: float = 0.05) -> float:
    pairs = [(s, r) for s, r in zip(sigs, rets) if abs(s) > thr]
    if not pairs:
        return float("nan")
    hits = sum(1 for s, r in pairs if (s > 0 and r > 0) or (s < 0 and r < 0))
    return hits / len(pairs)


def _slice_stats(events: list[dict], key: str, ret_key: str) -> RegimeSlice:
    valid = [(float(ev.get("signal_score") or 0.0), float(ev[ret_key]))
             for ev in events if ev.get(ret_key) is not None]
    if not valid:
        return RegimeSlice(key, 0, float("nan"), float("nan"), float("nan"), float("nan"))
    sigs, rets = zip(*valid)
    return RegimeSlice(
        regime_key = key,
        n          = len(valid),
        ic         = round(_spearman(list(sigs), list(rets)), 4),
        sharpe     = round(_sharpe(list(rets)), 4),
        hit_rate   = round(_hit_rate(list(sigs), list(rets)), 4),
        mean_ret   = round(sum(rets) / len(rets), 4),
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_regime_split(
    events:  list[dict],
    horizon: int = 1,
) -> RegimeReport:
    """
    Run IC / Sharpe / hit-rate per vol and trend regime.

    Events must already have vol_regime and trend_regime fields
    (attach via classify_regimes() first).

    Parameters
    ----------
    events   list of scored + regime-labelled event dicts
    horizon  return horizon: 1, 3, or 5 days
    """
    ret_key = f"fwd_ret_{horizon}d"

    # Overall IC
    all_valid = [(float(ev.get("signal_score") or 0.0), float(ev[ret_key]))
                 for ev in events if ev.get(ret_key) is not None]
    overall_ic = (_spearman([s for s, _ in all_valid], [r for _, r in all_valid])
                  if all_valid else float("nan"))

    # Vol regime cuts
    vol_order  = ["LOW", "MEDIUM", "HIGH", "SPIKE", "UNKNOWN"]
    vol_groups = {label: [] for label in vol_order}
    for ev in events:
        vr = ev.get("vol_regime", "UNKNOWN")
        vol_groups.setdefault(vr, []).append(ev)

    vol_cuts = [
        _slice_stats(vol_groups[label], f"vol:{label}", ret_key)
        for label in vol_order
        if vol_groups.get(label)
    ]

    # Trend regime cuts
    trend_order  = ["BULL", "NEUTRAL", "BEAR", "UNKNOWN"]
    trend_groups = {label: [] for label in trend_order}
    for ev in events:
        tr = ev.get("trend_regime", "UNKNOWN")
        trend_groups.setdefault(tr, []).append(ev)

    trend_cuts = [
        _slice_stats(trend_groups[label], f"trend:{label}", ret_key)
        for label in trend_order
        if trend_groups.get(label)
    ]

    return RegimeReport(
        horizon    = horizon,
        vol_cuts   = vol_cuts,
        trend_cuts = trend_cuts,
        overall_ic = round(float(overall_ic), 4) if math.isfinite(overall_ic) else 0.0,
    )
