"""
robustness.py — statistical robustness testing for signal validation.

Prevents over-fitting by verifying results hold across:
  1. Walk-forward windows     — IC is consistent over time, not one lucky period
  2. Threshold sensitivity    — IC doesn't collapse when thresholds change ±20%
  3. Sector / event-type cuts — signal works across different event types
  4. Bootstrap IC CI          — 95% confidence interval for IC via resampling

If results are robust → Sharpe / IC hold across all cuts.
If results are brittle → one window / event-type is carrying the performance.

Usage
-----
    from robustness import run_robustness_suite, RobustnessReport

    report = run_robustness_suite(events, horizon=1)
    print(report.summary())
    report.save("robustness.json")
"""
from __future__ import annotations

import json
import logging
import math
import random
from dataclasses import dataclass, asdict
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Shared metric helpers (duplicated here to keep module self-contained)
# ---------------------------------------------------------------------------

def _spearman(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 3:
        return float("nan")
    try:
        from scipy.stats import spearmanr
        r, _ = spearmanr(xs, ys)
        return float(r) if math.isfinite(r) else float("nan")
    except ImportError:
        def _rank(lst):
            s = sorted(range(len(lst)), key=lambda i: lst[i])
            r = [0.0] * len(lst)
            for rank, i in enumerate(s):
                r[i] = float(rank)
            return r
        rx, ry = _rank(xs), _rank(ys)
        d2 = sum((a - b) ** 2 for a, b in zip(rx, ry))
        return 1.0 - 6.0 * d2 / (n * (n ** 2 - 1))


def _sharpe(returns: list[float]) -> float:
    n = len(returns)
    if n < 2:
        return float("nan")
    mu  = sum(returns) / n
    var = sum((r - mu) ** 2 for r in returns) / (n - 1)
    std = math.sqrt(var)
    return (mu / std * math.sqrt(252)) if std > 1e-9 else float("nan")


def _hit_rate(signals: list[float], returns: list[float], thr: float = 0.05) -> float:
    pairs = [(s, r) for s, r in zip(signals, returns) if abs(s) > thr]
    if not pairs:
        return float("nan")
    hits = sum(1 for s, r in pairs if (s > 0 and r > 0) or (s < 0 and r < 0))
    return hits / len(pairs)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class WindowResult:
    label:    str
    n:        int
    ic:       float
    sharpe:   float
    hit_rate: float


@dataclass
class RobustnessReport:
    horizon:              int
    walk_forward_windows: list[WindowResult]
    event_type_cuts:      list[WindowResult]
    threshold_sensitivity:list[dict]           # [{threshold, ic, n_events}]
    bootstrap_ic:         dict                  # {mean, std, ci_low, ci_high, n_boot}
    overall_ic:           float
    ic_stability:         float                 # std of walk-forward ICs
    is_robust:            bool

    def summary(self) -> str:
        lines = [
            f"\n{'═'*62}",
            f"  ROBUSTNESS REPORT  (T+{self.horizon}d)",
            f"{'═'*62}",
            f"  Overall IC:     {self.overall_ic:.4f}",
            f"  IC stability:   σ = {self.ic_stability:.4f}  "
            f"({'STABLE' if self.ic_stability < 0.05 else 'VOLATILE'})",
        ]

        # Bootstrap CI
        b = self.bootstrap_ic
        lines.append(
            f"  Bootstrap IC:   {b['mean']:.4f} ± {b['std']:.4f}  "
            f"[95% CI: {b['ci_low']:.4f}, {b['ci_high']:.4f}]"
        )

        # Walk-forward
        lines += ["", f"  Walk-forward windows ({len(self.walk_forward_windows)}):"]
        for w in self.walk_forward_windows:
            flag = "⚠" if abs(w.ic) < 0.01 else "✓"
            lines.append(f"    {flag} {w.label:<18} IC={w.ic:>6.3f}  "
                         f"Sharpe={w.sharpe:>5.2f}  n={w.n}")

        # Event-type cuts
        if self.event_type_cuts:
            lines += ["", "  By event type:"]
            for c in self.event_type_cuts:
                lines.append(f"    {c.label:<22} IC={c.ic:>6.3f}  n={c.n}")

        # Threshold sensitivity
        lines += ["", "  Threshold sensitivity (score cutoff → IC):"]
        for t in self.threshold_sensitivity:
            lines.append(f"    cutoff={t['threshold']:.2f}  IC={t['ic']:>6.3f}  "
                         f"n={t['n_events']}")

        # Verdict
        lines += ["", f"{'─'*62}"]
        if self.is_robust:
            lines.append("  ✓  Signal is ROBUST — IC consistent across windows and cuts")
        else:
            lines.append("  ⚠  Signal is FRAGILE — IC concentrated in specific subset")
        lines.append(f"{'═'*62}")
        return "\n".join(lines)

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(asdict(self), f, indent=2, default=str)
        logger.info("Robustness report saved → %s", path)


# ---------------------------------------------------------------------------
# Walk-forward windows
# ---------------------------------------------------------------------------

def _split_windows(events: list[dict], n_windows: int) -> list[list[dict]]:
    """Split events (sorted by scraped_at) into n equal time windows."""
    n = len(events)
    if n < n_windows * 3:
        n_windows = max(1, n // 3)
    size = n // n_windows
    return [events[i * size:(i + 1) * size] for i in range(n_windows)]


def _window_stats(window: list[dict], key: str, label: str) -> WindowResult:
    valid = [(float(ev.get("signal_score") or 0.0), float(ev[key]))
             for ev in window if ev.get(key) is not None]
    if not valid:
        return WindowResult(label=label, n=0, ic=float("nan"),
                            sharpe=float("nan"), hit_rate=float("nan"))
    sigs, rets = zip(*valid)
    return WindowResult(
        label    = label,
        n        = len(valid),
        ic       = round(_spearman(list(sigs), list(rets)), 4),
        sharpe   = round(_sharpe(list(rets)), 4),
        hit_rate = round(_hit_rate(list(sigs), list(rets)), 4),
    )


# ---------------------------------------------------------------------------
# Bootstrap IC confidence interval
# ---------------------------------------------------------------------------

def _bootstrap_ic(
    signals: list[float],
    returns: list[float],
    n_boot:  int = 500,
    seed:    int = 42,
) -> dict:
    rng   = random.Random(seed)
    n     = len(signals)
    ics   = []
    for _ in range(n_boot):
        idx = [rng.randint(0, n - 1) for _ in range(n)]
        s   = [signals[i] for i in idx]
        r   = [returns[i] for i in idx]
        ic  = _spearman(s, r)
        if math.isfinite(ic):
            ics.append(ic)
    if not ics:
        return {"mean": 0.0, "std": 0.0, "ci_low": 0.0, "ci_high": 0.0, "n_boot": 0}
    ics.sort()
    lo  = ics[int(0.025 * len(ics))]
    hi  = ics[int(0.975 * len(ics))]
    mu  = sum(ics) / len(ics)
    std = math.sqrt(sum((x - mu) ** 2 for x in ics) / len(ics))
    return {
        "mean":    round(mu, 4),
        "std":     round(std, 4),
        "ci_low":  round(lo, 4),
        "ci_high": round(hi, 4),
        "n_boot":  len(ics),
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_robustness_suite(
    events:     list[dict],
    horizon:    int  = 1,
    n_windows:  int  = 5,
    n_boot:     int  = 500,
    thresholds: Optional[list[float]] = None,
) -> RobustnessReport:
    """
    Run full robustness suite on a list of scored+price-joined events.

    Each event dict must have:
        signal_score, scraped_at, event_type
        fwd_ret_{horizon}d  — forward return (may be None)

    Parameters
    ----------
    events      list of scored+price-joined event dicts
    horizon     return horizon in trading days
    n_windows   number of walk-forward time windows
    n_boot      bootstrap resamples for IC CI
    thresholds  score cutoffs to test (default: [0.10, 0.20, 0.30, 0.40])
    """
    if thresholds is None:
        thresholds = [0.10, 0.20, 0.30, 0.40]

    key = f"fwd_ret_{horizon}d"

    # Sort by time
    def _ts(ev):
        ts = ev.get("scraped_at") or ""
        return str(ts)

    events_sorted = sorted(events, key=_ts)

    # Valid pairs
    valid = [(ev, float(ev.get("signal_score") or 0.0), float(ev[key]))
             for ev in events_sorted if ev.get(key) is not None]

    all_sigs  = [s for _, s, _ in valid]
    all_rets  = [r for _, _, r in valid]
    all_evs   = [e for e, _, _ in valid]

    overall_ic = _spearman(all_sigs, all_rets) if all_sigs else float("nan")

    # ---- Walk-forward windows ------------------------------------------- #
    windows    = _split_windows(all_evs, n_windows)
    wf_results = []
    for i, w in enumerate(windows):
        wf_results.append(_window_stats(w, key, label=f"window_{i+1}"))

    valid_ics  = [w.ic for w in wf_results if math.isfinite(w.ic)]
    ic_std     = (math.sqrt(sum((x - sum(valid_ics)/len(valid_ics))**2 for x in valid_ics) /
                            max(1, len(valid_ics) - 1))
                  if len(valid_ics) >= 2 else float("nan"))

    # ---- Event-type cuts ------------------------------------------------ #
    et_groups: dict[str, list] = {}
    for ev, s, r in valid:
        et = (ev.get("event_type") or "unknown").lower()
        et_groups.setdefault(et, []).append((s, r))

    et_results = []
    for et, pairs in sorted(et_groups.items(), key=lambda x: -len(x[1])):
        ss, rs = zip(*pairs)
        et_results.append(WindowResult(
            label    = et,
            n        = len(pairs),
            ic       = round(_spearman(list(ss), list(rs)), 4),
            sharpe   = round(_sharpe(list(rs)), 4),
            hit_rate = round(_hit_rate(list(ss), list(rs)), 4),
        ))

    # ---- Threshold sensitivity ------------------------------------------ #
    thresh_rows = []
    for thr in thresholds:
        filtered = [(s, r) for s, r in zip(all_sigs, all_rets) if abs(s) >= thr]
        if not filtered:
            thresh_rows.append({"threshold": thr, "ic": float("nan"), "n_events": 0})
            continue
        fs, fr = zip(*filtered)
        thresh_rows.append({
            "threshold": thr,
            "ic":        round(_spearman(list(fs), list(fr)), 4),
            "n_events":  len(filtered),
        })

    # ---- Bootstrap IC CI ------------------------------------------------ #
    boot = _bootstrap_ic(all_sigs, all_rets, n_boot=n_boot)

    # ---- Robustness verdict --------------------------------------------- #
    n_positive_windows = sum(1 for w in wf_results
                             if math.isfinite(w.ic) and w.ic > 0.005)
    is_robust = (
        math.isfinite(ic_std) and ic_std < 0.08
        and n_positive_windows >= math.ceil(len(wf_results) * 0.6)
        and boot["ci_low"] > -0.02   # CI doesn't include strongly negative IC
    )

    return RobustnessReport(
        horizon               = horizon,
        walk_forward_windows  = wf_results,
        event_type_cuts       = et_results,
        threshold_sensitivity = thresh_rows,
        bootstrap_ic          = boot,
        overall_ic            = round(overall_ic, 4) if math.isfinite(overall_ic) else 0.0,
        ic_stability          = round(ic_std, 4) if math.isfinite(ic_std) else 0.0,
        is_robust             = is_robust,
    )
