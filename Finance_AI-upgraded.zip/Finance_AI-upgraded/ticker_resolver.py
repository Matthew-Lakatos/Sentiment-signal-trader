"""
ticker_resolver.py — Entity-to-ticker resolution.

Resolves company names and entity strings to exchange ticker symbols
using a multi-source fallback chain:

1. Static cache (loaded from SEC CIK->ticker mapping on startup)
2. yfinance search (reliable for US equities)
3. SEC EDGAR company search API (free, no auth)
4. Fuzzy name match against pre-loaded universe

All resolutions are cached permanently in-process and optionally
persisted to a lightweight SQLite sidecar (ticker_cache.db).

Usage
-----
    from ticker_resolver import resolve_ticker, resolve_tickers_batch

    ticker = await resolve_ticker("Apple Inc")          # → "AAPL"
    ticker = await resolve_ticker("NVIDIA Corporation") # → "NVDA"
    ticker = await resolve_ticker("JPMorgan Chase")     # → "JPM"

    # Batch (concurrent)
    tickers = await resolve_tickers_batch(["Apple", "Microsoft", "Tesla"])
    # → {"Apple": "AAPL", "Microsoft": "MSFT", "Tesla": "TSLA"}
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import sqlite3
import time
import unicodedata
from functools import lru_cache
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_CACHE_PATH   = os.environ.get("TICKER_CACHE_PATH", "ticker_cache.db")
_SEC_COMPANY_SEARCH = "https://efts.sec.gov/LATEST/search-index?q=%22{name}%22&dateRange=custom&startdt=2023-01-01&forms=10-K"
_HEADERS = {"User-Agent": "FinanceAI research@financeai.dev"}

# Known hard-coded overrides (high-frequency ambiguous names)
_OVERRIDES: dict[str, str] = {
    "apple":          "AAPL",  "apple inc":      "AAPL",
    "microsoft":      "MSFT",  "microsoft corp":  "MSFT",
    "amazon":         "AMZN",  "amazon.com":      "AMZN",
    "alphabet":       "GOOGL", "google":          "GOOGL",
    "meta":           "META",  "facebook":        "META",
    "nvidia":         "NVDA",  "nvidia corp":     "NVDA",
    "tesla":          "TSLA",  "tesla inc":       "TSLA",
    "berkshire":      "BRK-B", "berkshire hathaway": "BRK-B",
    "jpmorgan":       "JPM",   "jpmorgan chase":  "JPM",
    "goldman sachs":  "GS",    "goldman":         "GS",
    "morgan stanley": "MS",
    "bank of america": "BAC",  "bofa":            "BAC",
    "citigroup":      "C",     "citi":            "C",
    "wells fargo":    "WFC",
    "johnson & johnson": "JNJ", "j&j":            "JNJ",
    "pfizer":         "PFE",
    "eli lilly":      "LLY",   "lilly":           "LLY",
    "abbvie":         "ABBV",
    "unitedhealth":   "UNH",
    "exxon":          "XOM",   "exxonmobil":      "XOM",
    "chevron":        "CVX",
    "walmart":        "WMT",
    "home depot":     "HD",
    "visa":           "V",
    "mastercard":     "MA",
    "broadcom":       "AVGO",
    "intel":          "INTC",  "intel corp":      "INTC",
    "amd":            "AMD",   "advanced micro":  "AMD",
    "qualcomm":       "QCOM",
    "oracle":         "ORCL",
    "salesforce":     "CRM",
    "adobe":          "ADBE",
    "netflix":        "NFLX",
    "spotify":        "SPOT",
    "uber":           "UBER",
    "lyft":           "LYFT",
    "airbnb":         "ABNB",
    "palantir":       "PLTR",
    "coinbase":       "COIN",
    "snowflake":      "SNOW",
    "datadog":        "DDOG",
    "crowdstrike":    "CRWD",
    "palo alto":      "PANW",
    "arista":         "ANET",
    "asml":           "ASML",
    "tsmc":           "TSM",   "taiwan semiconductor": "TSM",
    "samsung":        "SSNLF",
    "toyota":         "TM",
    "volkswagen":     "VWAGY",
    "shell":          "SHEL",
    "bp":             "BP",
    "rio tinto":      "RIO",
    "bhp":            "BHP",
    "federal reserve": None,   # not a stock
    "sec":             None,
    "fed":             None,
    "ecb":             None,
    "treasury":        None,
}


# ---------------------------------------------------------------------------
# Normalisation
# ---------------------------------------------------------------------------

def _normalise(name: str) -> str:
    """Lowercase, strip punctuation, normalise unicode."""
    name = unicodedata.normalize("NFKD", name)
    name = name.lower().strip()
    # Remove legal suffixes
    name = re.sub(
        r"\b(inc\.?|corp\.?|corporation|ltd\.?|llc\.?|plc\.?|co\.?|group|holdings?|"
        r"international|technologies?|systems?|solutions?|services?|"
        r"enterprises?|industries?)\b",
        "", name, flags=re.IGNORECASE,
    )
    name = re.sub(r"[^\w\s]", " ", name)
    name = re.sub(r"\s+", " ", name).strip()
    return name


# ---------------------------------------------------------------------------
# SQLite sidecar cache
# ---------------------------------------------------------------------------

_db_lock = asyncio.Lock()
_mem_cache: dict[str, Optional[str]] = {}


def _init_db() -> sqlite3.Connection:
    conn = sqlite3.connect(_CACHE_PATH, check_same_thread=False)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ticker_cache (
            normalised_name TEXT PRIMARY KEY,
            ticker          TEXT,
            source          TEXT,
            resolved_at     REAL
        )
    """)
    conn.commit()
    return conn


_conn: Optional[sqlite3.Connection] = None


def _get_conn() -> sqlite3.Connection:
    global _conn
    if _conn is None:
        _conn = _init_db()
    return _conn


def _db_lookup(norm: str) -> Optional[tuple[Optional[str], str]]:
    try:
        row = _get_conn().execute(
            "SELECT ticker, source FROM ticker_cache WHERE normalised_name=?", (norm,)
        ).fetchone()
        return (row[0], row[1]) if row else None
    except Exception:
        return None


def _db_store(norm: str, ticker: Optional[str], source: str) -> None:
    try:
        _get_conn().execute(
            "INSERT OR REPLACE INTO ticker_cache VALUES (?,?,?,?)",
            (norm, ticker, source, time.time()),
        )
        _get_conn().commit()
    except Exception as exc:
        logger.debug("DB store failed: %s", exc)


# ---------------------------------------------------------------------------
# Remote lookups (sync, run in executor)
# ---------------------------------------------------------------------------

def _yfinance_search_sync(name: str) -> Optional[str]:
    try:
        import yfinance as yf
        results = yf.Search(name, max_results=3)
        quotes  = results.quotes if hasattr(results, "quotes") else []
        if not quotes:
            return None
        # Prefer US equities (EQUITY type, exchange NYSE/NASDAQ)
        for q in quotes:
            q_type = q.get("quoteType", "")
            exchange = q.get("exchange", "")
            if q_type == "EQUITY" and exchange in ("NYQ", "NMS", "NCM", "NGM", "PCX"):
                return q.get("symbol")
        return quotes[0].get("symbol") if quotes else None
    except Exception as exc:
        logger.debug("yfinance search failed for '%s': %s", name, exc)
        return None


def _sec_search_sync(name: str) -> Optional[str]:
    """Search SEC EDGAR for a company by name and extract its ticker."""
    try:
        import urllib.request
        url = f"https://efts.sec.gov/LATEST/search-index?q=%22{urllib.parse.quote(name)}%22&forms=10-K"
        req = urllib.request.Request(url, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.loads(resp.read())
        hits = data.get("hits", {}).get("hits", [])
        if not hits:
            return None
        # Extract ticker from display_names like "AAPL (Apple Inc)"
        for hit in hits[:3]:
            names = hit.get("_source", {}).get("display_names", [])
            for display in names:
                m = re.search(r"\(([A-Z]{1,5})\)", display)
                if m:
                    return m.group(1)
        return None
    except Exception as exc:
        logger.debug("SEC search failed for '%s': %s", name, exc)
        return None


def _is_already_ticker(name: str) -> Optional[str]:
    """Return name if it looks like a ticker symbol itself."""
    clean = name.strip().upper()
    if re.match(r'^[A-Z]{1,5}(-[A-Z])?$', clean):
        return clean
    return None


# ---------------------------------------------------------------------------
# Main resolver
# ---------------------------------------------------------------------------

async def resolve_ticker(entity: str) -> Optional[str]:
    """
    Resolve an entity string to a ticker symbol.
    Returns None if the entity is not a publicly traded company.
    Caches all results (positive and negative) permanently.
    """
    if not entity or not entity.strip():
        return None

    # Fast path: already a ticker
    as_ticker = _is_already_ticker(entity)
    if as_ticker:
        return as_ticker

    norm = _normalise(entity)
    if not norm:
        return None

    # In-memory cache
    if norm in _mem_cache:
        return _mem_cache[norm]

    # Static overrides
    if norm in _OVERRIDES:
        result = _OVERRIDES[norm]
        _mem_cache[norm] = result
        return result

    # DB cache
    async with _db_lock:
        cached = _db_lookup(norm)
    if cached is not None:
        ticker, _ = cached
        _mem_cache[norm] = ticker
        return ticker

    # Remote resolution — run in executor
    loop   = asyncio.get_running_loop()
    ticker: Optional[str] = None
    source = "none"

    # 1. yfinance search
    try:
        ticker = await asyncio.wait_for(
            loop.run_in_executor(None, _yfinance_search_sync, entity),
            timeout=5.0,
        )
        if ticker:
            source = "yfinance"
    except asyncio.TimeoutError:
        logger.debug("yfinance timeout for '%s'", entity)

    # 2. SEC EDGAR search
    if not ticker:
        try:
            ticker = await asyncio.wait_for(
                loop.run_in_executor(None, _sec_search_sync, entity),
                timeout=8.0,
            )
            if ticker:
                source = "sec_edgar"
        except asyncio.TimeoutError:
            logger.debug("SEC timeout for '%s'", entity)

    # Cache result (even None — prevents repeated failed lookups)
    _mem_cache[norm] = ticker
    async with _db_lock:
        _db_store(norm, ticker, source)

    if ticker:
        logger.debug("Resolved '%s' → '%s' via %s", entity, ticker, source)
    else:
        logger.debug("Could not resolve '%s' to a ticker", entity)

    return ticker


async def resolve_tickers_batch(
    entities: list[str],
    max_concurrency: int = 8,
) -> dict[str, Optional[str]]:
    """Resolve multiple entities concurrently. Returns {entity: ticker}."""
    sem = asyncio.Semaphore(max_concurrency)

    async def _resolve_one(entity: str) -> tuple[str, Optional[str]]:
        async with sem:
            return entity, await resolve_ticker(entity)

    results = await asyncio.gather(*[_resolve_one(e) for e in entities])
    return dict(results)


def resolve_ticker_sync(entity: str) -> Optional[str]:
    """Synchronous wrapper for use outside async context."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(1) as pool:
                future = pool.submit(asyncio.run, resolve_ticker(entity))
                return future.result(timeout=15)
        return loop.run_until_complete(resolve_ticker(entity))
    except Exception:
        return None
