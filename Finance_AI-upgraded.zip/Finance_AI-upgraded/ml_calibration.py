"""
ml_calibration.py — §19 Alternative ML Architecture Layer.

Drop-in replacements for the ridge regression model in calibration.py.

New methods added to calibrate(method=...):
  "lgbm"      LightGBM gradient-boosted trees (nonlinear, handles interactions)
  "xgboost"   XGBoost gradient-boosted trees
  "bayesian"  Bayesian Ridge regression (uncertainty-aware, automatic relevance)
  "ensemble"  Equal-weight blend of ridge + lgbm + bayesian

All methods return a CalibrationResult identical to the ridge baseline so
the rest of the codebase requires no changes.  Feature importance is stored
in CalibrationResult.notes as a JSON string when available.

Graceful degradation
--------------------
LightGBM and XGBoost are optional dependencies.  If they are not installed,
the respective method falls back to ridge regression with a logged warning.
Bayesian Ridge uses scikit-learn (already required) so it always works.

Interpretability
----------------
LightGBM and XGBoost expose feature_importances_ (split gain or mean
decrease in impurity).  These are normalised to [0,1] and stored in
CalibrationResult.weights — giving the same interface as ridge weights —
so apply_calibrated_weights() works unchanged.

When to use each
----------------
  ridge       Fast, interpretable, good baseline. Use when n < 200.
  bayesian    Like ridge but estimates its own regularisation (λ).
              More robust when feature count is close to sample count.
  lgbm        Best for nonlinear regime interactions (n ≥ 300).
              Captures e.g. "earnings surprise matters more in RISK_OFF".
  xgboost     Similar to lgbm; slightly different regularisation.
  ensemble    Reduces variance; best for production use.

Usage
-----
    from calibration import calibrate

    # Drop-in: just change method=
    result = calibrate(events, horizon=1, method="lgbm", with_interactions=True)
    result = calibrate(events, horizon=1, method="ensemble")
    result = calibrate(events, horizon=1, method="bayesian")

    print(result.weights)
    print(result.ic, result.ic_oos)
"""
from __future__ import annotations

import json
import logging
import math
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Bayesian Ridge (scikit-learn — always available)
# ---------------------------------------------------------------------------

def _bayesian_calibrate(
    X,
    y,
    feature_names: Optional[list[str]] = None,
) -> dict:
    """
    Bayesian Ridge regression via sklearn.
    Automatically selects regularisation strength from the data.
    Returns posterior mean weights + std (uncertainty estimate stored in notes).
    """
    import numpy as np
    from sklearn.linear_model import BayesianRidge
    from scipy.stats import spearmanr

    fnames = feature_names or []
    n, p   = X.shape

    model = BayesianRidge(
        max_iter      = 500,
        tol           = 1e-4,
        compute_score = True,
        fit_intercept = True,
    )
    model.fit(X, y)

    coef      = model.coef_                            # posterior mean
    coef_std  = np.sqrt(np.diag(model.sigma_))         # posterior std

    # Normalise so abs-sum = 1.0, preserving signs.
    # (ridge weights are always positive after L2; bayesian may be negative.)
    # We store signed weights so apply_calibrated_weights handles them correctly.
    abs_total  = sum(abs(c) for c in coef) or 1.0
    weights    = {f: round(float(coef[i] / abs_total), 4) for i, f in enumerate(fnames)}
    # Fix rounding: ensure abs-sum is exactly 1.0
    abs_sum    = sum(abs(v) for v in weights.values())
    if abs(abs_sum - 1.0) > 1e-4 and weights:
        key = max(weights, key=lambda k: abs(weights[k]))
        diff = round(1.0 - abs_sum, 4)
        weights[key] = round(weights[key] + (diff if weights[key] >= 0 else -diff), 4)

    y_hat     = model.predict(X)
    ss_res    = float(((y - y_hat) ** 2).sum())
    ss_tot    = float(((y - y.mean()) ** 2).sum())
    r2        = 1.0 - ss_res / max(ss_tot, 1e-12)

    ic, _     = spearmanr(model.predict(X), y)

    # Uncertainty metadata (stored in notes)
    uncertainty = {f: round(float(coef_std[i] / abs_total), 5)
                   for i, f in enumerate(fnames)}
    notes     = json.dumps({"lambda_": round(float(model.lambda_), 4),
                             "alpha_": round(float(model.alpha_), 4),
                             "uncertainty": uncertainty})

    return {
        "weights":   weights,
        "r_squared": round(float(r2), 4),
        "t_stats":   None,
        "p_values":  None,
        "_ic":       round(float(ic), 4) if math.isfinite(ic) else 0.0,
        "_notes":    notes,
    }


# ---------------------------------------------------------------------------
# LightGBM
# ---------------------------------------------------------------------------

def _lgbm_calibrate(
    X,
    y,
    feature_names: Optional[list[str]] = None,
    n_estimators:  int   = 200,
    learning_rate: float = 0.05,
    max_depth:     int   = 4,
    num_leaves:    int   = 15,
    min_child_samples: int = 10,
    reg_lambda:    float = 1.0,
) -> dict:
    """
    LightGBM gradient-boosted trees for nonlinear signal weight calibration.
    Falls back to ridge if lightgbm is not installed.
    """
    try:
        import lightgbm as lgb
    except ImportError:
        logger.warning("lightgbm not installed — falling back to ridge for method='lgbm'")
        from calibration import _ridge_calibrate
        r = _ridge_calibrate(X, y, feature_names=feature_names)
        r.setdefault("_ic", 0.0)
        r.setdefault("_notes", json.dumps({"model": "lgbm_fallback_ridge"}))
        return r

    import numpy as np
    from scipy.stats import spearmanr

    fnames = feature_names or []
    n, p   = X.shape

    params = {
        "objective":         "regression",
        "metric":            "rmse",
        "n_estimators":      n_estimators,
        "learning_rate":     learning_rate,
        "max_depth":         max_depth,
        "num_leaves":        num_leaves,
        "min_child_samples": min_child_samples,
        "reg_lambda":        reg_lambda,
        "verbose":           -1,
        "n_jobs":            -1,
        "random_state":      42,
    }

    model = lgb.LGBMRegressor(**params)
    model.fit(X, y, feature_name=fnames if fnames else "auto")

    importances = model.feature_importances_     # split count
    total_imp   = importances.sum() or 1.0
    weights     = {f: round(float(importances[i] / total_imp), 4)
                   for i, f in enumerate(fnames)}

    y_hat    = model.predict(X)
    ss_res   = float(((y - y_hat) ** 2).sum())
    ss_tot   = float(((y - y.mean()) ** 2).sum())
    r2       = 1.0 - ss_res / max(ss_tot, 1e-12)
    ic, _    = spearmanr(y_hat, y)

    notes = json.dumps({
        "model":          "lgbm",
        "n_estimators":   n_estimators,
        "best_iteration": getattr(model, "best_iteration_", n_estimators),
        "feature_importance": {f: int(importances[i]) for i, f in enumerate(fnames)},
    })

    return {
        "weights":   weights,
        "r_squared": round(float(r2), 4),
        "t_stats":   None,
        "p_values":  None,
        "_ic":       round(float(ic), 4) if math.isfinite(ic) else 0.0,
        "_notes":    notes,
    }


# ---------------------------------------------------------------------------
# XGBoost
# ---------------------------------------------------------------------------

def _xgboost_calibrate(
    X,
    y,
    feature_names: Optional[list[str]] = None,
    n_estimators:  int   = 200,
    learning_rate: float = 0.05,
    max_depth:     int   = 4,
    reg_lambda:    float = 1.0,
    reg_alpha:     float = 0.1,
) -> dict:
    """
    XGBoost gradient-boosted trees.
    Falls back to ridge if xgboost is not installed.
    """
    try:
        from xgboost import XGBRegressor
    except ImportError:
        logger.warning("xgboost not installed — falling back to ridge for method='xgboost'")
        from calibration import _ridge_calibrate
        r = _ridge_calibrate(X, y, feature_names=feature_names)
        r.setdefault("_ic", 0.0)
        r.setdefault("_notes", json.dumps({"model": "xgboost_fallback_ridge"}))
        return r

    import numpy as np
    from scipy.stats import spearmanr

    fnames = feature_names or []

    model = XGBRegressor(
        n_estimators  = n_estimators,
        learning_rate = learning_rate,
        max_depth     = max_depth,
        reg_lambda    = reg_lambda,
        reg_alpha     = reg_alpha,
        verbosity     = 0,
        random_state  = 42,
        n_jobs        = -1,
    )
    model.fit(X, y)

    importances = model.feature_importances_     # normalised gain
    total_imp   = importances.sum() or 1.0
    weights     = {f: round(float(importances[i] / total_imp), 4)
                   for i, f in enumerate(fnames)}

    y_hat    = model.predict(X)
    ss_res   = float(((y - y_hat) ** 2).sum())
    ss_tot   = float(((y - y.mean()) ** 2).sum())
    r2       = 1.0 - ss_res / max(ss_tot, 1e-12)
    ic, _    = spearmanr(y_hat, y)

    notes = json.dumps({
        "model":        "xgboost",
        "n_estimators": n_estimators,
        "feature_importance": {f: round(float(importances[i]), 4)
                               for i, f in enumerate(fnames)},
    })

    return {
        "weights":   weights,
        "r_squared": round(float(r2), 4),
        "t_stats":   None,
        "p_values":  None,
        "_ic":       round(float(ic), 4) if math.isfinite(ic) else 0.0,
        "_notes":    notes,
    }


# ---------------------------------------------------------------------------
# Ensemble (ridge + lgbm + bayesian blend)
# ---------------------------------------------------------------------------

def _ensemble_calibrate(
    X,
    y,
    feature_names: Optional[list[str]] = None,
    ridge_weight:  float = 0.34,
    lgbm_weight:   float = 0.33,
    bayes_weight:  float = 0.33,
    ridge_alpha:   float = 1.0,
) -> dict:
    """
    Equal-weight ensemble of ridge + LightGBM + Bayesian Ridge.
    Reduces model variance; recommended for production deployment.

    Weights are averaged across models with optional custom blending.
    IC is computed on the blended prediction.
    """
    import numpy as np
    from scipy.stats import spearmanr
    from calibration import _ridge_calibrate

    fnames = feature_names or []

    # Fit each component
    r_ridge = _ridge_calibrate(X, y, alpha=ridge_alpha, feature_names=fnames)
    r_bayes = _bayesian_calibrate(X, y, feature_names=fnames)

    # LightGBM (falls back to ridge if not installed)
    r_lgbm = _lgbm_calibrate(X, y, feature_names=fnames)

    # Normalise blend weights
    total_w  = ridge_weight + lgbm_weight + bayes_weight
    w_r      = ridge_weight / total_w
    w_l      = lgbm_weight  / total_w
    w_b      = bayes_weight / total_w

    # Blend feature weights (weighted average across models)
    blended: dict[str, float] = {}
    for f in fnames:
        blended[f] = round(
            w_r * r_ridge["weights"].get(f, 0.0)
          + w_l * r_lgbm["weights"].get(f,  0.0)
          + w_b * r_bayes["weights"].get(f, 0.0),
            4,
        )

    # Re-normalise so weights sum to 1.0
    total_bw = sum(abs(v) for v in blended.values()) or 1.0
    blended  = {f: round(v / total_bw, 4) for f, v in blended.items()}
    # Fix rounding to ensure exact sum=1.0
    diff = round(1.0 - sum(blended.values()), 4)
    if diff != 0.0 and blended:
        key = max(blended, key=lambda k: abs(blended[k]))
        blended[key] = round(blended[key] + diff, 4)

    w_vec = np.array([blended.get(f, 0.0) for f in fnames])
    y_hat = X @ w_vec
    ic, _ = spearmanr(y_hat, y)
    ss_res = float(((y - y_hat) ** 2).sum())
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2     = 1.0 - ss_res / max(ss_tot, 1e-12)

    notes = json.dumps({
        "model":        "ensemble",
        "components":   ["ridge", "lgbm", "bayesian"],
        "blend_weights": {"ridge": w_r, "lgbm": w_l, "bayesian": w_b},
        "component_ic": {
            "ridge":   r_ridge.get("_ic", 0.0),
            "lgbm":    r_lgbm.get("_ic",  0.0),
            "bayesian":r_bayes.get("_ic", 0.0),
        },
    })

    return {
        "weights":   blended,
        "r_squared": round(float(r2), 4),
        "t_stats":   None,
        "p_values":  None,
        "_ic":       round(float(ic), 4) if math.isfinite(ic) else 0.0,
        "_notes":    notes,
    }


# ---------------------------------------------------------------------------
# Dispatch table — registered with calibration.py's calibrate() function
# ---------------------------------------------------------------------------

ML_METHODS: dict[str, callable] = {
    "bayesian":  _bayesian_calibrate,
    "lgbm":      _lgbm_calibrate,
    "xgboost":   _xgboost_calibrate,
    "ensemble":  _ensemble_calibrate,
}


def is_ml_method(method: str) -> bool:
    """Return True if method is handled by this module (not calibration.py)."""
    return method in ML_METHODS


def dispatch(method: str, X, y, feature_names, **kwargs) -> dict:
    """
    Dispatch an ML calibration method and return a raw result dict
    compatible with calibration.py's CalibrationResult constructor.
    """
    if method not in ML_METHODS:
        raise ValueError(
            f"Unknown ML method: '{method}'. "
            f"Available: {list(ML_METHODS.keys())}"
        )
    fn = ML_METHODS[method]
    return fn(X, y, feature_names=feature_names, **kwargs)
