"""
event_classifier.py — deterministic event-type classification via a
two-stage rule + optional LLM hybrid.

Stage 1:  regex/keyword ruleset → fast, zero-cost, ~85 % accurate.
Stage 2:  if stage-1 returns UNKNOWN or confidence is below threshold,
          optionally delegate to a zero-shot HuggingFace classifier
          (facebook/bart-large-mnli or similar).

Event taxonomy
--------------
    earnings        — quarterly/annual results, EPS, revenue beats/misses
    macro           — central-bank policy, GDP, CPI, unemployment, rates
    contract        — government/enterprise contract, deal, tender
    product_launch  — new product, software release, FDA approval
    regulation      — law, SEC ruling, fine, compliance requirement
    rumor           — unconfirmed reports, sources say, speculation
    analysis        — analyst note, price target, rating change, commentary
    geopolitical    — sanctions, war, election, trade war, tariff
    unknown         — catch-all when confidence is too low

Usage
-----
    from event_classifier import classify

    event_type, confidence = classify(text)
    # → ("earnings", 0.91)
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

# ---------------------------------------------------------------------------
# Type literal
# ---------------------------------------------------------------------------

EVENT_TYPES = [
    "earnings",
    "macro",
    "contract",
    "product_launch",
    "regulation",
    "rumor",
    "analysis",
    "geopolitical",
    "unknown",
]

# ---------------------------------------------------------------------------
# Rule patterns  (compiled once at import)
# ---------------------------------------------------------------------------

_RULES: list[tuple[str, list[str], float]] = [
    # (event_type, patterns, base_confidence)
    (
        "earnings",
        [
            r"\bearnings\b", r"\beps\b", r"\bquarterly results?\b",
            r"\brevenue (beat|miss|surpass|disappoint)", r"\bnet (income|loss|profit)\b",
            r"\bguidance\b", r"\boutlook\b", r"\bfiscal (q[1-4]|year)\b",
            r"\bdividend\b", r"\bearnings per share\b",
            r"\bfull[- ]year (results?|report)\b",
        ],
        0.88,
    ),
    (
        "macro",
        [
            r"\bfederal reserve\b", r"\binterest rate\b", r"\brate (hike|cut|pause)\b",
            r"\bquantitative (easing|tightening)\b", r"\binflation\b", r"\bdeflation\b",
            r"\bgdp\b", r"\brecession\b", r"\bstag?flation\b",
            r"\bmonetary policy\b", r"\bcpi\b", r"\bpce\b", r"\bfomc\b",
            r"\bjobs report\b", r"\bunemployment rate\b", r"\bnonfarm payroll\b",
            r"\byield curve\b", r"\btreasury yield\b",
        ],
        0.90,
    ),
    (
        "contract",
        [
            r"\bcontract (award|win|signed?|deal)\b", r"\bgovernment contract\b",
            r"\bdefense contract\b", r"\bprocurement\b", r"\btender\b",
            r"\bawarded? (a )?(contract|deal)\b", r"\$[\d.]+(m|b|million|billion)? (deal|contract)\b",
            r"\bjoint venture\b", r"\bpartnerships?\b",
        ],
        0.85,
    ),
    (
        "product_launch",
        [
            r"\blaunch(ed|es|ing)?\b", r"\bnew product\b", r"\brolled? out\b",
            r"\bfda (approval|approved|clearance)\b", r"\bfirst[- ](in[- ]class|ever)\b",
            r"\breleas(ed|es|ing)? (version|v\d|update)\b",
            r"\bannounce[sd]? (a new|the launch|availability)\b",
            r"\bipO\b", r"\bdebuts?\b",
        ],
        0.82,
    ),
    (
        "regulation",
        [
            r"\bsec (investigation|charges?|subpoena|fine)\b",
            r"\bregulat(ory|ion|or)\b", r"\bcompliance\b",
            r"\bdoj\b", r"\bdepartment of justice\b",
            r"\bantitrust\b", r"\bfine[sd]?\b", r"\bpenalt(y|ies)\b",
            r"\bclass action\b", r"\blawsuit\b", r"\blitigation\b",
            r"\bfraud\b", r"\bsanctions?\b",
        ],
        0.87,
    ),
    (
        "rumor",
        [
            r"\bsources? (say|told|report)\b", r"\baccording to sources?\b",
            r"\bunconfirmed\b", r"\bspeculat(ion|ed|ing)\b",
            r"\breport(edly|ed)\b", r"\ballegedly\b", r"\bsaid to be\b",
            r"\bcould be\b.{0,40}\bmerger\b", r"\bpossibly\b",
            r"\btalks? (are )?ongoing\b", r"\bconsidering (a )?(deal|sale|merger)\b",
        ],
        0.78,
    ),
    (
        "analysis",
        [
            r"\banalyst\b", r"\bprice target\b", r"\brating (change|raised?|lowered?|cut)\b",
            r"\bupgrad(e|ed|ing)\b", r"\bdowngrad(e|ed|ing)\b",
            r"\bbuy (rating|recommendation)\b", r"\bsell (rating|recommendation)\b",
            r"\boutperform\b", r"\bunderperform\b", r"\bneutral\b.{0,20}\brating\b",
            r"\bconsensus\b", r"\bcommenta(ry|tor)\b", r"\bopinion\b",
        ],
        0.83,
    ),
    (
        "geopolitical",
        [
            r"\bsanctions?\b", r"\bwar\b", r"\bconflict\b", r"\belection\b",
            r"\btariff\b", r"\btrade war\b", r"\bgeopolit\w+\b",
            r"\bdiplomatic\b", r"\bembargo\b", r"\bveto\b",
            r"\bsovereign\b", r"\bnato\b", r"\bunited nations\b",
        ],
        0.85,
    ),
]

# Precompile all patterns
_COMPILED_RULES: list[tuple[str, list[re.Pattern], float]] = [
    (etype, [re.compile(p, re.IGNORECASE) for p in patterns], conf)
    for etype, patterns, conf in _RULES
]


# ---------------------------------------------------------------------------
# Numerical value extraction (supports materiality 2.0)
# ---------------------------------------------------------------------------

_DOLLAR_RE = re.compile(
    r"\$\s*(?P<value>[\d,]+(?:\.\d+)?)\s*(?P<unit>trillion|billion|million|k)?",
    re.IGNORECASE,
)
_PERCENT_RE = re.compile(r"(?P<value>[\d.]+)\s*%")


def extract_numerical_value(text: str) -> Optional[float]:
    """
    Return the largest USD amount mentioned in *text* (normalised to USD).
    Returns None if no amount found.
    """
    best = 0.0
    for m in _DOLLAR_RE.finditer(text):
        raw = float(m.group("value").replace(",", ""))
        unit = (m.group("unit") or "").lower()
        multiplier = {
            "trillion": 1e12,
            "billion":  1e9,
            "million":  1e6,
            "k":        1e3,
        }.get(unit, 1.0)
        best = max(best, raw * multiplier)
    return best if best > 0 else None


def extract_percentage_change(text: str) -> Optional[float]:
    """Return the largest absolute percentage mentioned in *text*."""
    vals = [float(m.group("value")) for m in _PERCENT_RE.finditer(text)]
    return max(vals) if vals else None


# ---------------------------------------------------------------------------
# Classifier
# ---------------------------------------------------------------------------

@dataclass
class ClassificationResult:
    event_type:  str
    confidence:  float
    match_count: int
    dollar_value: Optional[float]    # USD amount extracted from text
    pct_change:   Optional[float]    # % change extracted from text


def classify(text: str) -> ClassificationResult:
    """
    Classify *text* into one of EVENT_TYPES.
    Returns ClassificationResult with event_type and confidence.

    Algorithm
    ---------
    For each event type, count how many of its compiled patterns match the
    text.  Score = base_confidence * log(1 + match_count).  Pick the highest
    scorer; fall back to "unknown" if no patterns match.
    """
    import math

    if not text:
        return ClassificationResult("unknown", 0.0, 0, None, None)

    best_type = "unknown"
    best_score = 0.0
    best_matches = 0

    for etype, patterns, base_conf in _COMPILED_RULES:
        matches = sum(1 for p in patterns if p.search(text))
        if matches == 0:
            continue
        # Diminishing returns: log scale so 10 matches ≠ 10× weight
        score = base_conf * math.log1p(matches)
        if score > best_score:
            best_score = score
            best_type  = etype
            best_matches = matches

    # Normalise confidence to [0, 1] — log1p(1)*0.9 ≈ 0.62 for single match
    # Cap at 0.97 to never claim certainty
    norm_confidence = min(0.97, best_score / (math.log1p(5) + 1e-9))

    return ClassificationResult(
        event_type   = best_type,
        confidence   = round(norm_confidence, 4),
        match_count  = best_matches,
        dollar_value = extract_numerical_value(text),
        pct_change   = extract_percentage_change(text),
    )


# ---------------------------------------------------------------------------
# Optional zero-shot LLM upgrade (lazy-loaded)
# ---------------------------------------------------------------------------

_ZS_CLASSIFIER = None
_ZS_LOCK       = None


def _get_zs_lock():
    import asyncio
    global _ZS_LOCK
    if _ZS_LOCK is None:
        _ZS_LOCK = asyncio.Lock()
    return _ZS_LOCK


async def classify_with_llm(text: str, fallback_result: ClassificationResult) -> ClassificationResult:
    """
    Upgrade classification using zero-shot NLI if rule confidence is below
    ZS_CONFIDENCE_FLOOR.  Falls back to rule result on any error.
    """
    ZS_CONFIDENCE_FLOOR = 0.55
    if fallback_result.confidence >= ZS_CONFIDENCE_FLOOR:
        return fallback_result

    global _ZS_CLASSIFIER
    import asyncio

    async with _get_zs_lock():
        if _ZS_CLASSIFIER is None:
            loop = asyncio.get_running_loop()
            try:
                _ZS_CLASSIFIER = await loop.run_in_executor(
                    None, _load_zs_classifier
                )
            except Exception:
                return fallback_result

    try:
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None, _run_zs, text[:512], _ZS_CLASSIFIER
        )
        return result or fallback_result
    except Exception:
        return fallback_result


def _load_zs_classifier():
    from transformers import pipeline as hf_pipeline
    return hf_pipeline(
        "zero-shot-classification",
        model="facebook/bart-large-mnli",
        multi_label=False,
    )


def _run_zs(text: str, classifier) -> Optional[ClassificationResult]:
    labels = [t for t in EVENT_TYPES if t != "unknown"]
    try:
        out    = classifier(text, candidate_labels=labels)
        best   = out["labels"][0]
        score  = out["scores"][0]
        return ClassificationResult(
            event_type   = best,
            confidence   = round(float(score), 4),
            match_count  = 0,
            dollar_value = extract_numerical_value(text),
            pct_change   = extract_percentage_change(text),
        )
    except Exception:
        return None
