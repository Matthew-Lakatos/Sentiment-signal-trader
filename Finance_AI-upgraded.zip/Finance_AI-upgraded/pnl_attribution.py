"""
pnl_attribution.py — §16 Attribution & Diagnostics Engine.

Decomposes realised P&L into eight orthogonal components so you know
exactly where the strategy's edge (or lack thereof) comes from.

The eight components
--------------------
1. sentiment_pnl      — P&L explained by the raw sentiment signal
2. novelty_pnl        — incremental P&L from the novelty filter
3. surprise_pnl       — incremental P&L from expectation surprise (Phase 1)
4. regime_pnl         — incremental P&L from market-regime conditioning (Phase 1)
5. kg_pnl             — incremental P&L from KG second-order signals
6. factor_pnl         — P&L from (or cost of) residual factor exposure
7. execution_drag     — slippage + market impact cost
8. tc_drag            — round-trip transaction cost
9. residual           — unexplained remainder

Decomposition method
--------------------
Uses a sequential attribution framework (Brinson-Hood-Beebower style,
adapted for signal-based strategies):

    full_signal = f(sentiment, novelty, surprise, regime, kg, factor)
    baseline    = sign(sentiment) × |fwd_ret|

    sentiment_pnl = baseline P&L
    novelty_pnl   = full − sentiment_only signal, × fwd_ret direction
    ...

Each incremental component is:
    incremental_pnl_n = (signal_n − signal_{n-1}) × fwd_ret_signed

where signal_0 = sentiment_only, signal_k adds one component at a time.

Execution drag:
    execution_drag = fill_price / reference_price − 1 (slippage loss)
    tc_drag        = round_trip_cost × |notional|

Residual:
    residual = actual_strategy_pnl − sum(all_explained_components)

Usage
-----
    from pnl_attribution import attribute_batch, AttributionReport

    events_with_returns = [...]   # each has fwd_ret_1d, signal components
    report = attribute_batch(events_with_returns, horizon=1)

    print(report.summary())
    print(report.ic_by_component)
    print(report.pnl_by_component)
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# Default slippage and TC assumptions (overridden by per-event fields if present)
_DEFAULT_SLIPPAGE_BPS   = 10.0   # one-way
_DEFAULT_TC_RT_BPS      = 20.0   # round-trip
_ANNUALISE_FACTOR       = 252.0


# ─────────────────────────────────────────────────────────────────────────────
# Attribution result types
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EventAttribution:
    """Per-event P&L breakdown."""
    event_id:       str
    fwd_ret:        float     # raw realised forward return
    strategy_pnl:   float     # signal-weighted strategy P&L (pre-cost)
    net_pnl:        float     # after slippage + TC

    # Additive components (sum to strategy_pnl within tolerance)
    sentiment_pnl:   float = 0.0
    novelty_pnl:     float = 0.0
    surprise_pnl:    float = 0.0
    regime_pnl:      float = 0.0
    kg_pnl:          float = 0.0
    factor_pnl:      float = 0.0
    execution_drag:  float = 0.0   # slippage
    tc_drag:         float = 0.0   # round-trip TC
    residual:        float = 0.0

    # Metadata
    signal_score:   float = 0.0
    direction:      str   = "NEUTRAL"
    market_regime:  str   = "NEUTRAL"


@dataclass
class AttributionReport:
    """Aggregate P&L attribution across a batch of events."""
    n_events:        int
    horizon:         int
    total_strategy_pnl: float
    total_net_pnl:      float

    # Component totals
    pnl_by_component: dict[str, float] = field(default_factory=dict)

    # IC per component (Spearman correlation of component score vs fwd_ret)
    ic_by_component: dict[str, float] = field(default_factory=dict)

    # Fraction of total strategy P&L explained by each component
    fraction_explained: dict[str, float] = field(default_factory=dict)

    # Per-event detail
    events: list[EventAttribution] = field(default_factory=list)

    # Metadata
    computed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    mean_signal: float = 0.0
    hit_rate:    float = 0.0   # fraction of trades where sign(signal) = sign(fwd_ret)
    sharpe:      float = 0.0   # net P&L annualised Sharpe

    def summary(self) -> str:
        lines = [
            f"Attribution Report  n={self.n_events}  horizon=T+{self.horizon}d",
            f"  Strategy P&L: {self.total_strategy_pnl*100:+.3f}%  "
            f"Net P&L: {self.total_net_pnl*100:+.3f}%  "
            f"Sharpe: {self.sharpe:+.2f}  "
            f"HitRate: {self.hit_rate:.3f}",
            "  Component breakdown (% of total strategy P&L):",
        ]
        total = abs(self.total_strategy_pnl) or 1.0
        for comp, pnl in sorted(self.pnl_by_component.items(),
                                 key=lambda x: abs(x[1]), reverse=True):
            ic   = self.ic_by_component.get(comp, float("nan"))
            frac = pnl / (abs(pnl) + abs(total)) * 200  # avoid div-by-zero
            frac = self.fraction_explained.get(comp, 0.0)
            lines.append(
                f"    {comp:<22} P&L={pnl*100:+.3f}%  IC={ic:+.4f}  "
                f"({frac*100:+.1f}% of total)"
            )
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "n_events":            self.n_events,
            "horizon":             self.horizon,
            "total_strategy_pnl":  round(self.total_strategy_pnl, 6),
            "total_net_pnl":       round(self.total_net_pnl, 6),
            "pnl_by_component":    {k: round(v, 6) for k, v in self.pnl_by_component.items()},
            "ic_by_component":     {k: round(v, 5) for k, v in self.ic_by_component.items()},
            "fraction_explained":  {k: round(v, 4) for k, v in self.fraction_explained.items()},
            "hit_rate":            round(self.hit_rate, 4),
            "sharpe":              round(self.sharpe, 3),
            "mean_signal":         round(self.mean_signal, 4),
        }


# ─────────────────────────────────────────────────────────────────────────────
# Component signal extractors
# ─────────────────────────────────────────────────────────────────────────────

def _signed_sentiment(ev: dict) -> float:
    """Raw signed sentiment: sign(label) × score."""
    label    = (ev.get("sentiment_label") or "NEUTRAL").upper()
    score    = float(ev.get("sentiment_score") or 0.0)
    sign     = 1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)
    return sign * score


def _incremental_score(ev: dict, components: list[str]) -> float:
    """
    Build the composite signal score from a specific subset of components.
    Uses the actual stored weights from the signal_ranker.

    Weights (from signal_ranker.py defaults):
        sentiment   0.25 × (1 - w_surprise × 0.9)
        materiality 0.35 × (1 - w_surprise × 0.9)
        novelty     0.25 × (1 - w_surprise × 0.9)
        credibility 0.15 × (1 - w_surprise × 0.9)
        surprise    0.10
    """
    W = {
        "sentiment":   0.225,   # 0.25 × 0.9
        "materiality": 0.315,   # 0.35 × 0.9
        "novelty":     0.225,   # 0.25 × 0.9
        "credibility": 0.135,   # 0.15 × 0.9
        "surprise":    0.100,
    }

    score = 0.0
    for comp in components:
        if comp == "sentiment":
            score += W["sentiment"] * _signed_sentiment(ev)
        elif comp == "materiality":
            score += W["materiality"] * float(ev.get("materiality_score") or 0.0)
        elif comp == "novelty":
            score += W["novelty"] * float(ev.get("novelty_score") or 0.5)
        elif comp == "credibility":
            score += W["credibility"] * float(ev.get("credibility_score") or 0.5)
        elif comp == "surprise":
            score += W["surprise"] * float(ev.get("surprise_score") or 0.0)

    # Regime multiplier
    if "regime" in components:
        mult = _regime_multiplier(ev)
        score *= mult

    # Factor neutralisation reduces magnitude
    if "factor" in components:
        fn = ev.get("factor_neutral_score")
        if fn is not None:
            score = float(fn)  # use the actual factor-neutral score

    # KG second-order contribution
    if "kg" in components:
        kg_score = float(ev.get("kg_signal_score") or 0.0)
        score    = score * 0.85 + kg_score * 0.15

    return max(-1.0, min(1.0, score))


def _regime_multiplier(ev: dict) -> float:
    """Return the regime multiplier that was applied to this event's signal."""
    regime  = (ev.get("market_regime") or "NEUTRAL").upper()
    if regime == "RISK_OFF":
        return 0.60
    if regime == "RISK_ON":
        return 1.10
    return 1.0


def _spearman(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 3:
        return float("nan")

    def rank(lst):
        s = sorted(range(n), key=lambda i: lst[i])
        r = [0.0] * n
        for rk, i in enumerate(s):
            r[i] = float(rk)
        return r

    rx, ry = rank(xs), rank(ys)
    mx, my = sum(rx)/n, sum(ry)/n
    num    = sum((rx[i]-mx)*(ry[i]-my) for i in range(n))
    dxs    = math.sqrt(sum((rx[i]-mx)**2 for i in range(n)))
    dys    = math.sqrt(sum((ry[i]-my)**2 for i in range(n)))
    return num / (dxs * dys) if dxs * dys > 1e-9 else 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Core attribution function
# ─────────────────────────────────────────────────────────────────────────────

# Sequential build-up of components for incremental attribution.
# materiality and credibility are collapsed into the sentiment step because
# they are multipliers on base signal quality (not separate alpha sources),
# and EventAttribution only stores 6 named component fields + residual.
# This guarantees: sentiment_pnl + novelty_pnl + ... + residual = strategy_pnl.
_COMPONENT_SEQUENCE = [
    # Base signal quality = sentiment direction × materiality × credibility
    ("sentiment",   ["sentiment", "materiality", "credibility"]),
    # Novelty filter: incremental P&L from adding novelty score
    ("novelty",     ["sentiment", "materiality", "credibility", "novelty"]),
    # Phase 1 §2: expectation surprise contribution
    ("surprise",    ["sentiment", "materiality", "credibility", "novelty", "surprise"]),
    # Phase 1 §9: market-regime conditioning
    ("regime",      ["sentiment", "materiality", "credibility", "novelty", "surprise", "regime"]),
    # KG second-order propagation
    ("kg",          ["sentiment", "materiality", "credibility", "novelty", "surprise", "regime", "kg"]),
    # Phase 1 §11: factor neutralisation residual
    ("factor",      ["sentiment", "materiality", "credibility", "novelty", "surprise", "regime", "kg", "factor"]),
]


def attribute_event(ev: dict, horizon: int = 1) -> Optional[EventAttribution]:
    """
    Attribute a single event's P&L across all components.
    Returns None if the event lacks a realised forward return.
    """
    key = f"fwd_ret_{horizon}d"
    fwd_ret_raw = ev.get(key) or ev.get("fwd_ret")
    if fwd_ret_raw is None or not math.isfinite(float(fwd_ret_raw)):
        return None

    fwd_ret = float(fwd_ret_raw)
    sig     = float(ev.get("signal_score") or 0.0)

    # Strategy P&L: sign(signal) × fwd_ret
    direction     = "BULLISH" if sig > 0.05 else ("BEARISH" if sig < -0.05 else "NEUTRAL")
    strategy_pnl  = (fwd_ret if sig >= 0 else -fwd_ret)

    # Execution costs
    slippage_bps  = float(ev.get("slippage_bps") or _DEFAULT_SLIPPAGE_BPS)
    tc_rt_bps     = float(ev.get("tc_rt_bps")    or _DEFAULT_TC_RT_BPS)
    execution_drag = -(slippage_bps / 10_000)
    tc_drag        = -(tc_rt_bps    / 10_000)
    net_pnl        = strategy_pnl + execution_drag + tc_drag

    # Sequential incremental P&L attribution
    prev_score = 0.0
    component_pnls: dict[str, float] = {}
    for comp_name, comp_list in _COMPONENT_SEQUENCE:
        curr_score = _incremental_score(ev, comp_list)
        # Incremental contribution to signed P&L
        incr_pnl   = (curr_score - prev_score) * abs(fwd_ret) * (1 if fwd_ret >= 0 else -1)
        component_pnls[comp_name] = incr_pnl
        prev_score = curr_score

    # Residual
    explained = sum(component_pnls.values())
    residual  = strategy_pnl - explained

    return EventAttribution(
        event_id       = str(ev.get("event_id") or ""),
        fwd_ret        = round(fwd_ret, 6),
        strategy_pnl   = round(strategy_pnl, 6),
        net_pnl        = round(net_pnl, 6),
        sentiment_pnl  = round(component_pnls.get("sentiment",   0.0), 6),
        novelty_pnl    = round(component_pnls.get("novelty",     0.0), 6),
        surprise_pnl   = round(component_pnls.get("surprise",    0.0), 6),
        regime_pnl     = round(component_pnls.get("regime",      0.0), 6),
        kg_pnl         = round(component_pnls.get("kg",          0.0), 6),
        factor_pnl     = round(component_pnls.get("factor",      0.0), 6),
        execution_drag = round(execution_drag, 6),
        tc_drag        = round(tc_drag, 6),
        residual       = round(residual, 6),
        signal_score   = round(sig, 4),
        direction      = direction,
        market_regime  = (ev.get("market_regime") or "NEUTRAL").upper(),
    )


def attribute_batch(
    events:  list[dict],
    horizon: int = 1,
) -> AttributionReport:
    """
    Run attribution across a batch of events and return an aggregate report.

    Each event should carry realised forward returns (fwd_ret_{horizon}d)
    and the signal component fields written by the pipeline.
    """
    attributions: list[EventAttribution] = []
    skipped = 0

    for ev in events:
        att = attribute_event(ev, horizon=horizon)
        if att is None:
            skipped += 1
            continue
        attributions.append(att)

    if not attributions:
        logger.warning("attribute_batch: no events with fwd_ret_%dd (skipped %d)", horizon, skipped)
        return AttributionReport(n_events=0, horizon=horizon,
                                 total_strategy_pnl=0.0, total_net_pnl=0.0)

    n = len(attributions)

    # Aggregate P&L by component
    comp_fields = [
        "sentiment_pnl", "novelty_pnl", "surprise_pnl",
        "regime_pnl", "kg_pnl", "factor_pnl",
        "execution_drag", "tc_drag", "residual",
    ]
    pnl_by_comp: dict[str, float] = {
        f.replace("_pnl", "").replace("_drag", "_drag"): sum(getattr(a, f) for a in attributions)
        for f in comp_fields
    }
    # Rename for cleaner keys
    pnl_by_comp = {
        "sentiment":    sum(a.sentiment_pnl  for a in attributions),
        "novelty":      sum(a.novelty_pnl    for a in attributions),
        "surprise":     sum(a.surprise_pnl   for a in attributions),
        "regime":       sum(a.regime_pnl     for a in attributions),
        "kg":           sum(a.kg_pnl         for a in attributions),
        "factor":       sum(a.factor_pnl     for a in attributions),
        "execution_drag": sum(a.execution_drag for a in attributions),
        "tc_drag":      sum(a.tc_drag        for a in attributions),
        "residual":     sum(a.residual       for a in attributions),
    }

    total_strategy = sum(a.strategy_pnl for a in attributions)
    total_net      = sum(a.net_pnl      for a in attributions)

    # IC per component (signal vs fwd_ret)
    fwd_rets    = [a.fwd_ret for a in attributions]
    ic_by_comp  = {}
    comp_scores = {
        "sentiment":   [_signed_sentiment(events[i]) for i in range(len(events))
                        if attribute_event(events[i], horizon) is not None],
    }
    # Simpler: compute IC from the P&L proxy (component P&L correlation with fwd_ret)
    for comp in pnl_by_comp:
        if comp in ("execution_drag", "tc_drag", "residual"):
            ic_by_comp[comp] = float("nan")
            continue
        comp_pnls = [getattr(a, comp + "_pnl" if not comp.endswith("drag") else comp)
                     for a in attributions]
        ic_by_comp[comp] = _spearman(comp_pnls, fwd_rets)

    # Fraction explained
    total_abs = abs(total_strategy) or 1.0
    frac_exp  = {k: round(v / total_abs, 4) for k, v in pnl_by_comp.items()
                 if k not in ("execution_drag", "tc_drag")}

    # Hit rate
    hit_rate = sum(
        1 for a in attributions
        if (a.signal_score > 0.05 and a.fwd_ret > 0)
        or (a.signal_score < -0.05 and a.fwd_ret < 0)
    ) / n

    # Net Sharpe (annualised)
    net_rets = [a.net_pnl for a in attributions]
    mu_net   = sum(net_rets) / n
    std_net  = math.sqrt(sum((r - mu_net)**2 for r in net_rets) / max(n-1, 1))
    sharpe   = (mu_net / std_net) * math.sqrt(_ANNUALISE_FACTOR) if std_net > 1e-9 else 0.0

    mean_sig = sum(a.signal_score for a in attributions) / n

    logger.info(
        "Attribution complete: n=%d  strategy_pnl=%.4f%%  net_pnl=%.4f%%  "
        "hit_rate=%.3f  sharpe=%.2f",
        n, total_strategy*100, total_net*100, hit_rate, sharpe,
    )

    return AttributionReport(
        n_events           = n,
        horizon            = horizon,
        total_strategy_pnl = round(total_strategy, 6),
        total_net_pnl      = round(total_net, 6),
        pnl_by_component   = {k: round(v, 6) for k, v in pnl_by_comp.items()},
        ic_by_component    = {k: round(v, 5) if math.isfinite(v) else 0.0
                              for k, v in ic_by_comp.items()},
        fraction_explained = frac_exp,
        events             = attributions,
        hit_rate           = round(hit_rate, 4),
        sharpe             = round(sharpe, 3),
        mean_signal        = round(mean_sig, 4),
    )
