"""
drift_monitor.py — §18 Drift Monitoring & Live Health System.

Detects strategy degradation before it becomes catastrophic by running
rolling IC, Sharpe, and prediction-drift checks on live event data.

Architecture
------------
DriftMonitor maintains rolling windows of:
  - IC (Spearman rank correlation of signal_score vs realised fwd_ret)
  - Sharpe (signal-weighted strategy return annualised)
  - Prediction error (signed deviation of predicted vs realised direction)

It exposes:
  - is_healthy()     → bool: gate before publishing signals
  - health_report()  → HealthReport: full diagnostics
  - Prometheus gauges updated in-place so Grafana dashboards reflect live state

Auto-disable logic
------------------
When rolling IC drops below IC_DISABLE_THRESHOLD for IC_DISABLE_LOOKBACK
consecutive windows, the monitor sets _signal_gate = False.
All callers should check drift_monitor.gate_open() before publishing signals.

Gate reopens automatically when IC recovers above IC_RECOVER_THRESHOLD
for IC_RECOVER_LOOKBACK consecutive windows.

Regime mismatch alert
---------------------
If the current market_regime differs from the regime the model was
primarily trained on (stored in calibration result), a regime_mismatch
warning is raised. Signals are not disabled but are logged prominently.

Usage
-----
    from drift_monitor import DriftMonitor

    monitor = DriftMonitor()
    monitor.ingest(events_with_realised_returns)

    if not monitor.gate_open():
        logger.warning("Signal gate closed — IC below threshold")
        return

    report = monitor.health_report()
    print(report.summary)
"""
from __future__ import annotations

import logging
import math
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------

IC_DISABLE_THRESHOLD  = 0.00    # IC at or below this → strike
IC_DISABLE_LOOKBACK   = 3       # consecutive bad windows to close gate
IC_RECOVER_THRESHOLD  = 0.04    # IC above this → good window
IC_RECOVER_LOOKBACK   = 2       # consecutive good windows to reopen gate

SHARPE_WARN_THRESHOLD = -0.50   # rolling Sharpe below this → warning (not disable)
HIT_RATE_WARN         = 0.45    # hit rate below this → warning

WINDOW_SIZE           = 50      # events per rolling window
MIN_WINDOW_EVENTS     = 10      # minimum to compute a valid IC


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class WindowStats:
    window_id:   int
    n_events:    int
    ic:          float           # Spearman IC
    sharpe:      float           # signal-weighted Sharpe (annualised)
    hit_rate:    float           # fraction of correct direction predictions
    mean_signal: float           # mean |signal_score| in window
    computed_at: str             # ISO timestamp


@dataclass
class HealthReport:
    is_healthy:        bool
    gate_open:         bool
    rolling_ic:        float
    rolling_sharpe:    float
    rolling_hit_rate:  float
    n_windows:         int
    consecutive_bad:   int
    consecutive_good:  int
    last_window:       Optional[WindowStats]
    regime_mismatch:   bool
    current_regime:    str
    alerts:            list[str]
    summary:           str


# ---------------------------------------------------------------------------
# Spearman IC (pure Python — no scipy at runtime)
# ---------------------------------------------------------------------------

def _spearman(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 3:
        return float("nan")

    def _rank(lst: list[float]) -> list[float]:
        s = sorted(range(n), key=lambda i: lst[i])
        r = [0.0] * n
        for rank, i in enumerate(s):
            r[i] = float(rank)
        return r

    rx, ry = _rank(xs), _rank(ys)
    mx = sum(rx) / n
    my = sum(ry) / n
    num   = sum((rx[i] - mx) * (ry[i] - my) for i in range(n))
    den_x = math.sqrt(sum((rx[i] - mx) ** 2 for i in range(n)))
    den_y = math.sqrt(sum((ry[i] - my) ** 2 for i in range(n)))
    denom = den_x * den_y
    return num / denom if denom > 1e-9 else 0.0


def _sharpe(signal_scores: list[float], realised_rets: list[float]) -> float:
    """Signal-weighted strategy Sharpe, annualised. Returns nan when std is zero."""
    n = len(signal_scores)
    if n < 3:
        return float("nan")
    strategy_rets = [
        (ret if sig >= 0 else -ret)
        for sig, ret in zip(signal_scores, realised_rets)
    ]
    mu  = sum(strategy_rets) / n
    var = sum((r - mu) ** 2 for r in strategy_rets) / max(n - 1, 1)
    std = math.sqrt(var)
    if std < 1e-9:
        return float("nan")   # degenerate (all returns identical) — not meaningful
    return (mu / std) * math.sqrt(252)


# ---------------------------------------------------------------------------
# DriftMonitor
# ---------------------------------------------------------------------------

class DriftMonitor:
    """
    Rolling IC/Sharpe health monitor with automatic gate control.

    Events are accumulated in a deque.  When the deque reaches WINDOW_SIZE,
    a window is evaluated and appended to window_history.  The deque is then
    cleared and accumulation restarts (non-overlapping windows).
    """

    def __init__(
        self,
        window_size:           int   = WINDOW_SIZE,
        ic_disable_threshold:  float = IC_DISABLE_THRESHOLD,
        ic_disable_lookback:   int   = IC_DISABLE_LOOKBACK,
        ic_recover_threshold:  float = IC_RECOVER_THRESHOLD,
        ic_recover_lookback:   int   = IC_RECOVER_LOOKBACK,
        sharpe_warn_threshold: float = SHARPE_WARN_THRESHOLD,
        hit_rate_warn:         float = HIT_RATE_WARN,
    ):
        self.window_size           = window_size
        self.ic_disable_threshold  = ic_disable_threshold
        self.ic_disable_lookback   = ic_disable_lookback
        self.ic_recover_threshold  = ic_recover_threshold
        self.ic_recover_lookback   = ic_recover_lookback
        self.sharpe_warn_threshold = sharpe_warn_threshold
        self.hit_rate_warn         = hit_rate_warn

        self._buffer: deque[dict] = deque()
        self.window_history: list[WindowStats] = []
        self._window_id    = 0

        self._gate_open       = True
        self._consecutive_bad = 0
        self._consecutive_good= 0

        self._current_regime  = "NEUTRAL"

        # Prometheus gauges (optional — safe no-op when prometheus_client absent)
        self._prom_ic      = None
        self._prom_sharpe  = None
        self._prom_gate    = None
        self._init_prometheus()

    def _init_prometheus(self) -> None:
        try:
            from prometheus_client import Gauge
            self._prom_ic     = Gauge("strategy_rolling_ic",     "Rolling Spearman IC")
            self._prom_sharpe = Gauge("strategy_rolling_sharpe", "Rolling strategy Sharpe")
            self._prom_gate   = Gauge("strategy_gate_open",      "1 = signals enabled")
        except Exception:
            pass

    def _update_prometheus(self, ic: float, sharpe: float) -> None:
        try:
            if self._prom_ic and math.isfinite(ic):
                self._prom_ic.set(ic)
            if self._prom_sharpe and math.isfinite(sharpe):
                self._prom_sharpe.set(sharpe)
            if self._prom_gate:
                self._prom_gate.set(1.0 if self._gate_open else 0.0)
        except Exception:
            pass

    # ── Ingestion ───────────────────────────────────────────────────────────

    def ingest(self, events: list[dict], horizon: int = 1) -> list[WindowStats]:
        """
        Ingest a batch of events that carry realised forward returns.
        Returns a list of any WindowStats computed during this call
        (empty when the buffer has not yet filled a complete window).

        Required keys per event:
            signal_score       float
            signal_direction   str  (BULLISH/BEARISH/NEUTRAL)
            fwd_ret_{horizon}d float
        """
        key     = f"fwd_ret_{horizon}d"
        computed: list[WindowStats] = []

        for ev in events:
            ret = ev.get(key) or ev.get("fwd_ret")
            if ret is None or not math.isfinite(float(ret)):
                continue
            sig = ev.get("signal_score")
            if sig is None:
                continue

            self._buffer.append({
                "signal_score":     float(sig),
                "signal_direction": (ev.get("signal_direction") or "NEUTRAL").upper(),
                "fwd_ret":          float(ret),
            })

            if len(self._buffer) >= self.window_size:
                ws = self._evaluate_window()
                computed.append(ws)
                self.window_history.append(ws)
                self._update_gate(ws.ic)
                self._update_prometheus(ws.ic, ws.sharpe)
                self._buffer.clear()
                self._window_id += 1

        return computed

    def ingest_one(self, signal_score: float, direction: str, realised_ret: float) -> None:
        """Convenience method for single-observation ingestion."""
        self.ingest([{
            "signal_score":     signal_score,
            "signal_direction": direction,
            "fwd_ret_1d":       realised_ret,
        }])

    # ── Window evaluation ───────────────────────────────────────────────────

    def _evaluate_window(self) -> WindowStats:
        buf   = list(self._buffer)
        sigs  = [ev["signal_score"] for ev in buf]
        rets  = [ev["fwd_ret"]      for ev in buf]
        dirs  = [ev["signal_direction"] for ev in buf]

        n  = len(buf)
        ic = _spearman(sigs, rets) if n >= MIN_WINDOW_EVENTS else float("nan")
        sh = _sharpe(sigs, rets)   if n >= MIN_WINDOW_EVENTS else float("nan")

        # Hit rate: fraction where sign(signal) matches sign(realised_ret)
        correct = sum(
            1 for s, r, d in zip(sigs, rets, dirs)
            if (d == "BULLISH" and r > 0) or (d == "BEARISH" and r < 0)
        )
        hit_rate   = correct / n if n > 0 else float("nan")
        mean_signal = sum(abs(s) for s in sigs) / n if n > 0 else 0.0

        if math.isfinite(ic):
            flag = "✓" if ic > self.ic_recover_threshold else "✗"
            logger.info(
                "DriftMonitor window %d: IC=%s%.4f  Sharpe=%.2f  HitRate=%.3f  n=%d",
                self._window_id, flag, ic, sh if math.isfinite(sh) else 0.0, hit_rate, n,
            )
        else:
            logger.warning("DriftMonitor window %d: insufficient data (n=%d)", self._window_id, n)

        return WindowStats(
            window_id   = self._window_id,
            n_events    = n,
            ic          = round(ic, 5) if math.isfinite(ic) else 0.0,
            sharpe      = round(sh, 3) if math.isfinite(sh) else 0.0,
            hit_rate    = round(hit_rate, 4) if math.isfinite(hit_rate) else 0.5,
            mean_signal = round(mean_signal, 4),
            computed_at = datetime.now(timezone.utc).isoformat(),
        )

    # ── Gate logic ──────────────────────────────────────────────────────────

    def _update_gate(self, ic: float) -> None:
        if not math.isfinite(ic):
            return

        if self._gate_open:
            # ── Gate is open: watch for deterioration ──────────────────────
            if ic <= self.ic_disable_threshold:
                self._consecutive_bad  += 1
                self._consecutive_good  = 0
            else:
                self._consecutive_bad   = 0   # single good window resets bad streak

            if self._consecutive_bad >= self.ic_disable_lookback:
                self._gate_open        = False
                self._consecutive_good = 0    # fresh start for recovery counting
                logger.warning(
                    "DriftMonitor: SIGNAL GATE CLOSED — IC %.4f below %.4f "
                    "for %d consecutive windows",
                    ic, self.ic_disable_threshold, self._consecutive_bad,
                )
        else:
            # ── Gate is closed: watch for recovery ─────────────────────────
            if ic >= self.ic_recover_threshold:
                self._consecutive_good += 1
                self._consecutive_bad   = 0
            else:
                self._consecutive_good  = 0   # reset recovery progress

            if self._consecutive_good >= self.ic_recover_lookback:
                self._gate_open       = True
                self._consecutive_bad = 0
                logger.info(
                    "DriftMonitor: SIGNAL GATE REOPENED — IC %.4f recovered "
                    "above %.4f for %d consecutive windows",
                    ic, self.ic_recover_threshold, self._consecutive_good,
                )

    def gate_open(self) -> bool:
        return self._gate_open

    def set_regime(self, regime: str) -> None:
        """Inform the monitor of the current market regime (from market_state)."""
        self._current_regime = regime.upper()

    # ── Health report ───────────────────────────────────────────────────────

    def health_report(self, regime_mismatch: bool = False) -> HealthReport:
        """Return a full diagnostic HealthReport."""
        recent = self.window_history[-10:] if self.window_history else []
        last   = self.window_history[-1] if self.window_history else None

        rolling_ic     = (sum(w.ic      for w in recent) / len(recent)) if recent else 0.0
        rolling_sharpe = (sum(w.sharpe  for w in recent) / len(recent)) if recent else 0.0
        rolling_hr     = (sum(w.hit_rate for w in recent) / len(recent)) if recent else 0.5

        alerts: list[str] = []
        if not self._gate_open:
            alerts.append(f"GATE_CLOSED: rolling IC={rolling_ic:.4f} below threshold")
        if rolling_sharpe < self.sharpe_warn_threshold:
            alerts.append(f"SHARPE_WARN: rolling Sharpe={rolling_sharpe:.2f}")
        if rolling_hr < self.hit_rate_warn and recent:
            alerts.append(f"HIT_RATE_WARN: hit_rate={rolling_hr:.3f}")
        if regime_mismatch:
            alerts.append(f"REGIME_MISMATCH: model not calibrated for {self._current_regime}")

        is_healthy = len(alerts) == 0
        summary    = "Healthy" if is_healthy else f"{len(alerts)} alert(s): {alerts[0]}"

        return HealthReport(
            is_healthy        = is_healthy,
            gate_open         = self._gate_open,
            rolling_ic        = round(rolling_ic, 5),
            rolling_sharpe    = round(rolling_sharpe, 3),
            rolling_hit_rate  = round(rolling_hr, 4),
            n_windows         = len(self.window_history),
            consecutive_bad   = self._consecutive_bad,
            consecutive_good  = self._consecutive_good,
            last_window       = last,
            regime_mismatch   = regime_mismatch,
            current_regime    = self._current_regime,
            alerts            = alerts,
            summary           = summary,
        )

    def reset(self) -> None:
        """Hard reset — clears all state. Use during testing or strategy restarts."""
        self._buffer.clear()
        self.window_history.clear()
        self._window_id      = 0
        self._gate_open      = True
        self._consecutive_bad  = 0
        self._consecutive_good = 0


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_monitor: Optional[DriftMonitor] = None


def get_monitor() -> DriftMonitor:
    global _monitor
    if _monitor is None:
        _monitor = DriftMonitor()
    return _monitor
