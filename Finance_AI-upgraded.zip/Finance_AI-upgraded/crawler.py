"""
crawler.py — domain-scoped async crawler with:
  - noindex / nofollow meta tag + X-Robots-Tag compliance
  - Persistent PostgreSQL-backed queue (crash-safe)
  - Domain scoping (never follows links off the seed domain)
  - Content-type guard before link extraction
"""
from __future__ import annotations
import asyncio
import logging
from urllib.parse import urlparse, urljoin

import aiohttp
from bs4 import BeautifulSoup

from config import settings
from crawl_rules import is_content_url
from link_extractor import extract_links
from robots_cache import is_allowed, crawl_delay
from url_queue import enqueue_urls, dequeue_batch

logger = logging.getLogger(__name__)


def _same_domain(base_url: str, link: str) -> bool:
    base_host = urlparse(base_url).netloc
    link_host = urlparse(link).netloc
    return not link_host or link_host == base_host


def _noindex_nofollow(html: str, response_headers: dict) -> tuple[bool, bool]:
    """Return (noindex, nofollow) from meta tags and X-Robots-Tag header."""
    noindex = nofollow = False
    # Check HTTP header first
    x_robots = response_headers.get("X-Robots-Tag", "").lower()
    if "noindex" in x_robots:
        noindex = True
    if "nofollow" in x_robots:
        nofollow = True

    # Check meta tags
    try:
        soup = BeautifulSoup(html[:8192], "lxml")   # only need <head>
        for tag in soup.find_all("meta", attrs={"name": "robots"}):
            content = (tag.get("content") or "").lower()
            if "noindex" in content:
                noindex = True
            if "nofollow" in content:
                nofollow = True
    except Exception:
        pass
    return noindex, nofollow


async def _fetch_html(url: str, session: aiohttp.ClientSession) -> tuple[str, dict]:
    """Fetch raw HTML + response headers. Returns ("", {}) on failure."""
    from headers import random_headers
    timeout = aiohttp.ClientTimeout(connect=5, sock_read=15)
    try:
        async with session.get(url, headers=random_headers(), timeout=timeout,
                               allow_redirects=True) as r:
            ct = r.headers.get("Content-Type", "")
            if "text/html" not in ct:
                return "", {}
            raw = await r.content.read(settings.scrape_max_response_bytes)
            return raw.decode("utf-8", errors="replace"), dict(r.headers)
    except Exception as exc:
        logger.debug("Crawler fetch failed for %s: %s", url, exc)
        return "", {}


async def crawl(
    pool,
    seed_urls: list[str],
    max_pages: int = 50,
    content_only: bool = True,
    stay_on_domain: bool = True,
) -> list[str]:
    """
    Crawl from seed_urls, returning a list of discovered page URLs.
    Uses a persistent PostgreSQL queue — safe to interrupt and resume.
    """
    # Robots compliance on seeds
    allowed_seeds = [u for u in seed_urls if is_allowed(u)]
    await enqueue_urls(pool, allowed_seeds)

    discovered: list[str] = []

    async with aiohttp.ClientSession() as session:
        while len(discovered) < max_pages:
            batch = await dequeue_batch(pool, batch_size=10)
            if not batch:
                break

            for url in batch:
                if len(discovered) >= max_pages:
                    break

                # Per-domain crawl delay
                domain = urlparse(url).netloc
                await asyncio.sleep(crawl_delay(url))

                html, headers = await _fetch_html(url, session)
                if not html:
                    continue

                noindex, nofollow = _noindex_nofollow(html, headers)
                if noindex:
                    logger.debug("noindex: skipping %s", url)
                    continue

                discovered.append(url)

                if nofollow:
                    continue   # don't follow links from this page

                # Extract and enqueue links
                links = extract_links(html, url)
                filtered = []
                for link in links:
                    if not is_allowed(link):
                        continue
                    if stay_on_domain and not _same_domain(url, link):
                        continue
                    if content_only and not is_content_url(link):
                        continue
                    filtered.append(link)

                await enqueue_urls(pool, filtered)

    logger.info("Crawler finished: %d pages discovered", len(discovered))
    return discovered
