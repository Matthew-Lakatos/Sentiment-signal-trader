"""
expectation_model.py — §2 Expectation Surprise & Guidance Revision Scoring.

Moves beyond naïve polarity scoring into expectation-discrepancy modelling:

  1. Sentiment surprise
     Query the DB for the entity's prior mean signed-sentiment over the last
     N days (default 30).  The z-score of current sentiment vs. prior mean is
     the "surprise" component — a strongly positive article from a company
     that's been consistently negative is a bigger signal than one that merely
     confirms an ongoing narrative.

  2. Guidance revision scoring
     Scan text for positive/negative/neutral guidance language and compute a
     net guidance direction score in [-1, 1].  A guidance upgrade on top of a
     positive sentiment surprise is multiplicatively reinforcing.

  3. Combined surprise score
     combined = 0.60 × sentiment_surprise_z + 0.40 × guidance_score
     Clamped to [-1, 1].

All values are stored in SurpriseResult and fed into signal_ranker.py as
an additional optional component.  Returns None (not 0) when insufficient
prior history exists so the caller can distinguish "no data" from "neutral".
"""
from __future__ import annotations

import logging
import math
import re
from dataclasses import dataclass
from typing import Optional

from config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Guidance language lexicons
# ---------------------------------------------------------------------------

_POS_GUIDANCE: list[str] = [
    r"\braised?\s+guidance\b",
    r"\bincreased?\s+(?:full[- ]?year\s+)?(?:guidance|forecast|outlook)\b",
    r"\bupward\s+revision\b",
    r"\bbeat\s+(?:analyst\s+)?estimates\b",
    r"\bexceeded?\s+(?:analyst\s+)?expectations\b",
    r"\babove\s+(?:analyst\s+)?consensus\b",
    r"\bupside\s+surprise\b",
    r"\brecord\s+(?:revenue|profit|earnings|sales)\b",
    r"\bstrong(?:er)?[- ]than[- ]expected\b",
    r"\bahead\s+of\s+(?:estimates?|expectations?|guidance)\b",
    r"\bpositive\s+(?:guidance|outlook|surprise)\b",
]

_NEG_GUIDANCE: list[str] = [
    # [\w-]+ handles hyphenated words (e.g. "full-year"); {0,3} slots cover
    # constructions like "lowered its full-year outlook"
    r"\blower(?:ed|s)?\s+(?:[\w-]+\s+){0,3}(?:guidance|forecast|outlook)\b",
    r"\breduced?\s+(?:[\w-]+\s+){0,3}(?:guidance|forecast|outlook)\b",
    r"\bcut\s+(?:[\w-]+\s+){0,3}(?:guidance|forecast|outlook)\b",
    r"\bmissed?\s+(?:analyst\s+)?estimates\b",
    r"\bbelow\s+(?:analyst\s+)?(?:estimates?|expectations?|consensus)\b",
    r"\bdownside\s+surprise\b",
    r"\bprofit\s+warning\b",
    r"\brevenue\s+warning\b",
    r"\bguidance\s+cut\b",
    r"\bwithdr[ae]w\s+(?:[\w-]+\s+){0,3}(?:guidance|forecast|outlook)\b",
    r"\bsuspended?\s+(?:[\w-]+\s+){0,3}(?:guidance|forecast|outlook)\b",
    r"\bweaker[- ]than[- ]expected\b",
    r"\bmissed?\s+expectations\b",
    r"\bnegative\s+(?:guidance|outlook|surprise)\b",
]

_NEU_GUIDANCE: list[str] = [
    r"\breaffirmed?\s+guidance\b",
    r"\bmaintained?\s+guidance\b",
    r"\breiterated?\s+(?:guidance|outlook|forecast)\b",
    r"\bin[- ]line\s+with\s+(?:expectations?|estimates?|consensus)\b",
    r"\bmet\s+(?:analyst\s+)?estimates\b",
    r"\bon\s+track\b",
]

_POS_PATTERNS = [re.compile(p, re.I) for p in _POS_GUIDANCE]
_NEG_PATTERNS = [re.compile(p, re.I) for p in _NEG_GUIDANCE]
_NEU_PATTERNS = [re.compile(p, re.I) for p in _NEU_GUIDANCE]


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class GuidanceRevision:
    score: float          # [-1, 1]; positive = guidance upgrade
    pos_hits: int         # number of positive guidance phrases found
    neg_hits: int         # number of negative guidance phrases found
    neu_hits: int         # number of neutral guidance phrases found
    phrases_found: list[str]


@dataclass
class SurpriseResult:
    surprise_score: float         # combined, clamped [-1, 1]
    sentiment_surprise_z: float   # z-score of current vs prior
    guidance_score: float         # guidance revision score [-1, 1]
    prior_mean: Optional[float]   # prior signed-sentiment mean (None if no data)
    prior_std: Optional[float]
    n_prior_events: int
    is_estimate: bool             # True if < min_prior_events available


# ---------------------------------------------------------------------------
# Guidance revision detection
# ---------------------------------------------------------------------------

def detect_guidance_revision(text: str) -> GuidanceRevision:
    """
    Scan text for positive, negative, and neutral guidance language.
    Returns a GuidanceRevision with a net score in [-1, 1].
    """
    t = text[:4000]   # scan first 4000 chars only — most guidance is in lede
    pos_hits, neg_hits, neu_hits = 0, 0, 0
    phrases: list[str] = []

    for pat in _POS_PATTERNS:
        m = pat.search(t)
        if m:
            pos_hits += 1
            phrases.append(m.group(0))

    for pat in _NEG_PATTERNS:
        m = pat.search(t)
        if m:
            neg_hits += 1
            phrases.append(m.group(0))

    for pat in _NEU_PATTERNS:
        m = pat.search(t)
        if m:
            neu_hits += 1
            phrases.append(m.group(0))

    total = pos_hits + neg_hits
    if total == 0:
        score = 0.0
    else:
        # Net positive fraction, dampened by neutral hits
        raw   = (pos_hits - neg_hits) / total
        damp  = 1.0 / (1.0 + 0.5 * neu_hits)
        score = raw * damp

    return GuidanceRevision(
        score        = round(max(-1.0, min(1.0, score)), 4),
        pos_hits     = pos_hits,
        neg_hits     = neg_hits,
        neu_hits     = neu_hits,
        phrases_found = phrases,
    )


# ---------------------------------------------------------------------------
# DB-backed prior sentiment lookup
# ---------------------------------------------------------------------------

async def _query_prior_sentiment(
    pool,
    entities: list[str],
    lookback_days: int,
) -> tuple[Optional[float], Optional[float], int]:
    """
    Return (mean_signed_sentiment, std_sentiment, n_events) for the given
    entity list over the lookback window.

    Signed sentiment: POSITIVE × score, NEGATIVE × −score, else 0.
    Returns (None, None, 0) when no matching events exist.
    """
    if not entities or pool is None:
        return None, None, 0

    # Normalise entity names for partial matching
    normalised = [e.lower().strip() for e in entities if e.strip()]
    if not normalised:
        return None, None, 0

    # Build OR condition over all entity names using ILIKE for partial match
    conditions = " OR ".join(
        f"LOWER(summary) LIKE ${i + 2}" for i in range(len(normalised))
    )
    params: list = [lookback_days] + [f"%{e}%" for e in normalised]

    try:
        row = await pool.fetchrow(
            f"""
            SELECT
                AVG(
                    CASE
                        WHEN sentiment_label = 'POSITIVE' THEN  sentiment_score
                        WHEN sentiment_label = 'NEGATIVE' THEN -sentiment_score
                        ELSE 0.0
                    END
                )                  AS mean_signed,
                -- Bug fix: std must be computed on SIGNED sentiment, not magnitude.
                -- STDDEV(magnitude) is systematically ~4-5x smaller than STDDEV(signed),
                -- causing z-scores to be inflated by the same factor.
                STDDEV(
                    CASE
                        WHEN sentiment_label = 'POSITIVE' THEN  sentiment_score
                        WHEN sentiment_label = 'NEGATIVE' THEN -sentiment_score
                        ELSE 0.0
                    END
                )                  AS std_sentiment,
                COUNT(*)           AS n
            FROM scraped_events
            WHERE
                scraped_at > NOW() - ($1 || ' days')::INTERVAL
                AND scraped_at < NOW() - INTERVAL '1 hour'
                AND NOT is_duplicate
                AND ({conditions})
            """,
            *params,
        )
        if row is None or row["n"] == 0:
            return None, None, 0
        return (
            float(row["mean_signed"]) if row["mean_signed"] is not None else None,
            float(row["std_sentiment"]) if row["std_sentiment"] is not None else None,
            int(row["n"]),
        )
    except Exception as exc:
        logger.warning("Prior sentiment query failed: %s", exc)
        return None, None, 0


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def compute_surprise(
    pool,
    targets: list[str],
    current_sentiment_label: str,
    current_sentiment_score: float,
    text: str,
    lookback_days: Optional[int] = None,
    ticker: Optional[str] = None,       # if known, enables real EPS SUE
) -> Optional[SurpriseResult]:
    """
    Compute the expectation surprise score for the current article.

    Signal hierarchy (highest to lowest reliability):
    1. EPS SUE (standardised unexpected earnings) — when ticker is known
       Academic IC: 0.10-0.15. Replaces the sentiment proxy when available.
    2. Sentiment z-score vs rolling prior — always computed
    3. Guidance revision — always computed

    Parameters
    ----------
    pool                    asyncpg Pool (may be None in tests)
    targets                 list of entity strings from target_profiles
    current_sentiment_label POSITIVE / NEGATIVE / NEUTRAL / UNCERTAIN
    current_sentiment_score magnitude [0, 1] from FinBERT
    text                    full article text for guidance scan
    lookback_days           lookback window in days (default from settings)
    ticker                  resolved ticker symbol (enables EPS SUE)
    """
    if not targets:
        return None

    if lookback_days is None:
        lookback_days = int(getattr(settings, "expectation_lookback_days", 30))

    min_prior = int(getattr(settings, "expectation_min_prior_events", 5))

    # ── 1. Guidance revision ────────────────────────────────────────────────
    guidance = detect_guidance_revision(text)

    # ── 2. EPS SUE (real earnings surprise — primary signal when available) ──
    eps_sue_score = 0.0
    eps_sue_raw   = None
    has_eps_sue   = False

    if ticker:
        try:
            from earnings_surprise import get_engine as _get_earn_engine
            earn_feat = await _get_earn_engine().get_features(ticker)
            if not earn_feat.is_stale and earn_feat.eps_surprise_sue is not None:
                eps_sue_raw   = earn_feat.eps_surprise_sue
                # SUE normalised to [-1, 1]: SUE of ±3 maps to ±1
                eps_sue_score = max(-1.0, min(1.0, earn_feat.eps_surprise_sue / 3.0))
                has_eps_sue   = True
        except Exception as exc:
            logger.debug("EPS SUE fetch failed for %s: %s", ticker, exc)

    # ── 3. Prior sentiment baseline ────────────────────────────────────────
    prior_mean, prior_std, n_prior = await _query_prior_sentiment(
        pool, targets, lookback_days
    )

    # ── 4. Sentiment z-score ───────────────────────────────────────────────
    label = (current_sentiment_label or "NEUTRAL").upper()
    if label == "POSITIVE":
        signed_current = current_sentiment_score
    elif label == "NEGATIVE":
        signed_current = -current_sentiment_score
    else:
        signed_current = 0.0

    if prior_mean is None or n_prior < min_prior:
        sentiment_z = 0.0
        is_estimate = True
    else:
        std   = prior_std if (prior_std and prior_std > 1e-4) else 0.2
        raw_z = (signed_current - prior_mean) / std
        sentiment_z = max(-1.0, min(1.0, raw_z / 3.0))
        is_estimate = False

    # ── 5. Combined surprise score ─────────────────────────────────────────
    # When EPS SUE is available it replaces the sentiment proxy (higher IC)
    # Weights: SUE 50% | sentiment_z 30% | guidance 20%  (with real EPS)
    #          sentiment_z 60% | guidance 40%              (without real EPS)
    if has_eps_sue:
        w_sue      = 0.50
        w_sent     = 0.30
        w_guidance = 0.20
        combined   = (w_sue * eps_sue_score
                    + w_sent * sentiment_z
                    + w_guidance * guidance.score)
    else:
        w_sent     = 0.60
        w_guidance = 0.40
        combined   = w_sent * sentiment_z + w_guidance * guidance.score

    combined = round(max(-1.0, min(1.0, combined)), 4)

    return SurpriseResult(
        surprise_score       = combined,
        sentiment_surprise_z = round(sentiment_z, 4),
        guidance_score       = guidance.score,
        prior_mean           = round(prior_mean, 4) if prior_mean is not None else None,
        prior_std            = round(prior_std, 4) if prior_std is not None else None,
        n_prior_events       = n_prior,
        is_estimate          = is_estimate,
    )
