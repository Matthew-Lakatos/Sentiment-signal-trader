"""
factor_model.py — §11 Sector & Market Factor Neutralisation.

Ensures alpha signals capture company-specific information rather than
broad sector or market-level moves.

Two neutralisation layers
--------------------------
1. Sector neutralisation
   Compute the sector-median signal across all events in the batch.
   Residual alpha = raw_signal − sector_median.
   This isolates stock-specific surprise from sector-wide trends (e.g.
   oil stocks all moving on an OPEC headline should not each generate
   independent "strong" signals).

2. Market-direction adjustment (simplified single-factor)
   Compute the batch-level mean signal as a proxy for market sentiment.
   Apply a beta discount: factor_neutral = sector_residual − β × market_mean
   where β (default 0.30) represents the fraction of a signal explained
   by broad market direction.  Configurable via FACTOR_MARKET_BETA.

Entity → GICS sector classification
-------------------------------------
classify_entity_sector(targets, topics) resolves entity names and topic
tags to one of the 11 GICS sectors.  Falls through to "unknown" when no
mapping is found (these events are treated as their own peer group).

Usage
-----
    from factor_model import neutralise_batch

    enriched = neutralise_batch(events)   # adds factor_neutral_score + sector
    for ev in enriched:
        print(ev["primary_sector"], ev["factor_neutral_score"])
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from typing import Optional

from config import settings

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Entity → GICS sector mapping  (lowercase, partial-match friendly)
# ---------------------------------------------------------------------------

ENTITY_SECTOR: dict[str, str] = {
    # Information Technology
    "apple":          "technology",
    "microsoft":      "technology",
    "nvidia":         "technology",
    "alphabet":       "technology",
    "google":         "technology",
    "meta":           "technology",
    "tsmc":           "technology",
    "samsung":        "technology",
    "intel":          "technology",
    "amd":            "technology",
    "qualcomm":       "technology",
    "broadcom":       "technology",
    "oracle":         "technology",
    "salesforce":     "technology",
    "adobe":          "technology",
    "ibm":            "technology",
    "cisco":          "technology",
    "hp":             "technology",
    "dell":           "technology",
    "micron":         "technology",
    "asml":           "technology",
    "arm":            "technology",
    "palantir":       "technology",
    "snowflake":      "technology",
    "servicenow":     "technology",
    # Communication
    "netflix":        "communication",
    "disney":         "communication",
    "at&t":           "communication",
    "verizon":        "communication",
    "t-mobile":       "communication",
    "comcast":        "communication",
    "charter":        "communication",
    "fox":            "communication",
    "spotify":        "communication",
    "tencent":        "communication",
    "baidu":          "communication",
    "twitter":        "communication",
    "x corp":         "communication",
    "snap":           "communication",
    # Financials
    "jpmorgan":       "financials",
    "jp morgan":      "financials",
    "goldman sachs":  "financials",
    "goldman":        "financials",
    "morgan stanley": "financials",
    "bank of america":"financials",
    "wells fargo":    "financials",
    "citigroup":      "financials",
    "citi":           "financials",
    "berkshire":      "financials",
    "blackrock":      "financials",
    "visa":           "financials",
    "mastercard":     "financials",
    "american express":"financials",
    "charles schwab": "financials",
    "paypal":         "financials",
    "stripe":         "financials",
    "hsbc":           "financials",
    "barclays":       "financials",
    "deutsche bank":  "financials",
    "ubs":            "financials",
    "credit suisse":  "financials",
    # Healthcare
    "johnson & johnson": "healthcare",
    "j&j":              "healthcare",
    "unitedhealth":     "healthcare",
    "eli lilly":        "healthcare",
    "lilly":            "healthcare",
    "pfizer":           "healthcare",
    "merck":            "healthcare",
    "abbvie":           "healthcare",
    "bristol-myers":    "healthcare",
    "bristol myers":    "healthcare",
    "moderna":          "healthcare",
    "astrazeneca":      "healthcare",
    "novartis":         "healthcare",
    "roche":            "healthcare",
    "biontech":         "healthcare",
    "novo nordisk":     "healthcare",
    "novo":             "healthcare",
    # Consumer Discretionary
    "amazon":         "consumer_discretionary",
    "tesla":          "consumer_discretionary",
    "home depot":     "consumer_discretionary",
    "mcdonald's":     "consumer_discretionary",
    "mcdonalds":      "consumer_discretionary",
    "nike":           "consumer_discretionary",
    "starbucks":      "consumer_discretionary",
    "booking":        "consumer_discretionary",
    "airbnb":         "consumer_discretionary",
    "uber":           "consumer_discretionary",
    "lyft":           "consumer_discretionary",
    "ford":           "consumer_discretionary",
    "gm":             "consumer_discretionary",
    "general motors": "consumer_discretionary",
    "volkswagen":     "consumer_discretionary",
    "bmw":            "consumer_discretionary",
    "mercedes":       "consumer_discretionary",
    "toyota":         "consumer_discretionary",
    # Consumer Staples
    "walmart":        "consumer_staples",
    "procter & gamble":"consumer_staples",
    "p&g":            "consumer_staples",
    "coca-cola":      "consumer_staples",
    "cocacola":       "consumer_staples",
    "pepsi":          "consumer_staples",
    "pepsico":        "consumer_staples",
    "unilever":       "consumer_staples",
    "nestle":         "consumer_staples",
    "costco":         "consumer_staples",
    "target":         "consumer_staples",
    # Energy
    "exxon":          "energy",
    "exxonmobil":     "energy",
    "chevron":        "energy",
    "conocophillips": "energy",
    "shell":          "energy",
    "bp":             "energy",
    "totalenergies":  "energy",
    "total":          "energy",
    "pioneer":        "energy",
    "halliburton":    "energy",
    "schlumberger":   "energy",
    "opec":           "energy",
    # Industrials
    "caterpillar":    "industrials",
    "boeing":         "industrials",
    "honeywell":      "industrials",
    "ups":            "industrials",
    "fedex":          "industrials",
    "ge":             "industrials",
    "general electric":"industrials",
    "lockheed":       "industrials",
    "raytheon":       "industrials",
    "deere":          "industrials",
    "john deere":     "industrials",
    "union pacific":  "industrials",
    # Materials
    "3m":             "materials",
    "linde":          "materials",
    "air products":   "materials",
    "dow":            "materials",
    "basf":           "materials",
    "rio tinto":      "materials",
    "bhp":            "materials",
    "freeport":       "materials",
    # Utilities
    "nextera":        "utilities",
    "duke energy":    "utilities",
    "southern company":"utilities",
    "dominion":       "utilities",
    # Real Estate
    "american tower": "real_estate",
    "prologis":       "real_estate",
    "equinix":        "real_estate",
    "simon property": "real_estate",
}

# Topic tag → fallback sector
_TOPIC_SECTOR: dict[str, str] = {
    "technology":    "technology",
    "finance":       "financials",
    "health":        "healthcare",
    "energy":        "energy",
    "retail":        "consumer_discretionary",
    "media":         "communication",
    "industrials":   "industrials",
    "utilities":     "utilities",
    "real_estate":   "real_estate",
    "materials":     "materials",
    "science":       "healthcare",   # close enough for news alpha
    "politics":      "unknown",
}


# ---------------------------------------------------------------------------
# Sector classification
# ---------------------------------------------------------------------------

def classify_entity_sector(
    targets: list[str],
    topics: list[str],
) -> str:
    """
    Return the primary GICS sector for this event.

    Resolution order:
    1. Exact match of entity name in ENTITY_SECTOR
    2. Whole-word substring match (map_key contained in entity string),
       guarded by minimum key length to prevent "ge" matching "large"
    3. Topic tag fallback via TOPIC_SECTOR
    4. "unknown"

    Bug fix: the previous bidirectional match `map_key in key OR key in map_key`
    caused dangerous false positives. "ge" matched "large", "hedge", "merger".
    "bp" matched "ibm" (no — "bp" not in "ibm", but "arm" matched "pharmacy").
    New rule: only match if the map_key is a whole word inside the entity string
    AND the map_key is at least 4 characters (prevents 2-3 char key explosions).
    """
    import re
    for entity in targets:
        key = entity.lower().strip()

        # 1. Exact match — always safe
        if key in ENTITY_SECTOR:
            return ENTITY_SECTOR[key]

        # 2. Whole-word forward match only (map_key IS a word in the entity string)
        #    Minimum key length of 4 chars prevents "ge", "hp", "bp" false matches.
        #    Short well-known tickers must be caught by exact match above.
        for map_key, sector in ENTITY_SECTOR.items():
            if len(map_key) < 4:
                continue   # too short for safe partial matching
            # Use word-boundary regex: map_key must appear as a whole word
            if re.search(r'\b' + re.escape(map_key) + r'\b', key):
                return sector

    for topic in topics:
        if topic.lower() in _TOPIC_SECTOR:
            return _TOPIC_SECTOR[topic.lower()]

    return "unknown"


# ---------------------------------------------------------------------------
# Neutralisation result
# ---------------------------------------------------------------------------

@dataclass
class FactorNeutralResult:
    factor_neutral_score: float    # residual after sector + market adjustment
    primary_sector: str
    sector_median: float           # sector median used for neutralisation
    market_mean: float             # batch market mean used for beta adjustment


# ---------------------------------------------------------------------------
# Batch neutralisation
# ---------------------------------------------------------------------------

def _median(values: list[float]) -> float:
    if not values:
        return 0.0
    s = sorted(values)
    n = len(s)
    mid = n // 2
    return s[mid] if n % 2 else (s[mid - 1] + s[mid]) / 2.0


def neutralise_batch(events: list[dict]) -> list[dict]:
    """
    Add ``factor_neutral_score`` and ``primary_sector`` to each event dict
    in-place, and return the same list.

    Each event must have:
        signal_score      float
        targets           list[str]   (entity names)
        topics            list[str]

    The function is a pure transform — no I/O, no side effects.
    """
    if not events:
        return events

    market_beta = float(getattr(settings, "factor_market_beta", 0.30))

    # ── 1. Classify each event's sector ────────────────────────────────────
    for ev in events:
        ev["primary_sector"] = classify_entity_sector(
            ev.get("targets") or [],
            ev.get("topics")  or [],
        )

    # ── 2. Compute sector medians ───────────────────────────────────────────
    sector_scores: dict[str, list[float]] = {}
    for ev in events:
        sector = ev["primary_sector"]
        sector_scores.setdefault(sector, []).append(float(ev.get("signal_score", 0.0)))

    sector_medians: dict[str, float] = {
        s: _median(scores) for s, scores in sector_scores.items()
    }

    # ── 3. Compute batch market mean ────────────────────────────────────────
    all_scores  = [float(ev.get("signal_score", 0.0)) for ev in events]
    market_mean = sum(all_scores) / len(all_scores) if all_scores else 0.0

    # ── 4. Apply neutralisation ─────────────────────────────────────────────
    for ev in events:
        raw    = float(ev.get("signal_score", 0.0))
        sector = ev["primary_sector"]
        s_med  = sector_medians.get(sector, 0.0)

        # Sector-residual: remove within-sector median
        sector_residual = raw - s_med

        # Market-beta adjustment (corrected formula).
        # Bug fix: previously used `- β × market_mean` which penalises stocks in
        # sectors above the market average even when they are sector-neutral.
        # Correct: remove β times the market's deviation FROM this sector.
        # factor_neutral = (raw - s_med) - β × (market_mean - s_med)
        #                = raw - s_med(1-β) - β×market_mean
        # When a stock = sector_median and sector_median = market_mean → fn = 0 ✓
        # When a stock = sector_median and sector_median > market_mean → fn > 0 ✓
        factor_neutral  = sector_residual - market_beta * (market_mean - s_med)

        # Clamp to [-1, 1] and round
        ev["factor_neutral_score"] = round(max(-1.0, min(1.0, factor_neutral)), 4)
        ev["_sector_median"]       = round(s_med, 4)
        ev["_market_mean"]         = round(market_mean, 4)

    return events
