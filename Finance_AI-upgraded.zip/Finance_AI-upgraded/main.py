"""
main.py — production pipeline entry point.

Phase 1 additions
-----------------
  §9  Market state fetched once per pipeline run, cached for TTL.
      compute_signal receives the MarketState for regime conditioning.

  §2  Expectation surprise computed per event (async DB lookup for prior
      sentiment baseline + synchronous guidance revision scan).
      Stored in surprise_score and guidance_revision_score on the event.

  §11 Factor neutralisation applied as a batch post-processing step after
      all events in the run are assembled.  Adds factor_neutral_score and
      primary_sector to every event before the final DB write.

  §10 Cross-sectional ranking applied immediately after factor neutralisation.
      Adds cs_percentile, cs_sector_percentile, cs_score.

Integration notes
-----------------
- All Phase 1 modules are guarded by feature flags in settings so they
  can be disabled individually without code changes:
    ENABLE_MARKET_STATE             (default: true)
    ENABLE_EXPECTATION_SURPRISE     (default: true)
    ENABLE_FACTOR_NEUTRALISATION    (default: true)
    ENABLE_CROSS_SECTIONAL_RANKING  (default: true)

- Factor neutralisation and CS ranking operate on the full batch of
  events collected in a single pipeline run.  With small batches
  (n < 2) CS ranking degrades gracefully to cs_score = 0.

- The DB insert is deferred until after the batch phase so that all
  Phase 1 fields are populated before writing.
"""
from __future__ import annotations

import asyncio
import logging
import sys
from datetime import datetime, timezone
from typing import Optional
from urllib.parse import urlparse

from analyzer import analyze_all
from alert_engine import (
    AlertPayload, dispatch_alerts,
    rule_sentiment_shift, rule_high_propaganda, rule_critical_materiality,
)
from cache import is_cache_valid, update_cache
from config import settings
from crawler import crawl
from cross_section import rank_batch
from database import get_pool, insert_event
from dedup import find_duplicate
from discovery import discover_urls
from events import ScrapedEvent
from expectation_model import compute_surprise
from factor_model import neutralise_batch
from knowledge_graph import flush_knowledge_graph, init_knowledge_graph
from logging_config import setup_logging
from market_state import get_market_state
from materiality import score_materiality
from monitor import Monitor, Timer, record_scrape, record_nlp, record_pipeline_run
from novelty import compute_novelty_score, novelty_label
from scraper import scrape_all_urls
from signal_ranker import compute_signal
from source_health import is_dead, domain_of

# ── Governance subsystem ─────────────────────────────────────────────────────
from governance_engine import GovernanceEngine, get_engine as get_governance_engine
from liquidity_engine import LiquidityEngine, get_engine as get_liquidity_engine
from positioning_engine import PositioningEngine, get_engine as get_positioning_engine
from risk_throttle import RiskThrottle, get_throttle
from kill_switch import KillSwitch, get_switch

# ── Shadow trading infrastructure ────────────────────────────────────────────
from ticker_resolver import resolve_tickers_batch, resolve_ticker
from eod_price_cache import EODPriceCache, get_cache as get_price_cache
from shadow_portfolio import ShadowPortfolio
from exposure_engine import ExposureEngine, get_engine as get_exposure_engine
from portfolio_lifecycle_log import LifecycleLogger

setup_logging()
logger = logging.getLogger(__name__)

DEFAULT_URLS: list[str] = [
    "https://www.bbc.com/news/technology",
    "https://www.theverge.com/tech",
    "https://finance.yahoo.com/news/",
    "https://www.reuters.com/markets/",
    "https://www.marketwatch.com/latest-news",
    "https://home.treasury.gov/news/press-releases",
]

from target_profiles import ALL_FINANCE_URLS
from alt_data_sources import get_extended_urls

# Merge base finance URLs with extended alternative data sources
FINANCE_URLS: list[str] = list(dict.fromkeys(ALL_FINANCE_URLS + get_extended_urls()))


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

async def run_discovery(topic: str, max_pages: int = 50) -> None:
    pool = await get_pool()
    urls = discover_urls(topic)
    crawled = await crawl(pool, urls, max_pages=max_pages)
    await run_pipeline(crawled)


async def run_finance_pipeline() -> None:
    logger.info("Starting finance pipeline (%d URLs)", len(FINANCE_URLS))
    await run_pipeline(FINANCE_URLS)


# ---------------------------------------------------------------------------
# Core pipeline
# ---------------------------------------------------------------------------

async def run_pipeline(
    urls: list[str],
    monitor: Optional[Monitor] = None,
) -> None:
    pool = await get_pool()
    await init_knowledge_graph(pool)
    record_pipeline_run()

    if monitor is None:
        monitor = Monitor()

    logger.info("Pipeline starting: %d URL(s)", len(urls))

    # ── One-time startup tasks (idempotent — fast if already done) ──────────
    # 1. Build FAISS dedup index from stored embeddings
    from dedup import build_index as build_faiss_index
    await build_faiss_index(pool)

    # 2. Warm EOD price cache for any tickers already in the shadow portfolio
    _price_cache = get_price_cache()
    tracked_tickers = []
    try:
        rows = await pool.fetch(
            "SELECT DISTINCT ticker FROM portfolio_lifecycle WHERE closed_at IS NULL LIMIT 50"
        )
        tracked_tickers = [r["ticker"] for r in rows]
    except Exception:
        pass
    if tracked_tickers:
        await _price_cache.warm(tracked_tickers)

    # 3. Warm Amihud accumulators for tracked tickers
    if tracked_tickers:
        from amihud_accumulator import warm_all as warm_amihud
        await warm_amihud(tracked_tickers[:20])  # cap at 20 to avoid startup delay

    # ── §9 Fetch market state once for the entire run ───────────────────────
    if settings.enable_market_state:
        market_state = await get_market_state()
        logger.info(
            "Market state: VIX=%.1f (%s)  regime=%s  earnings_season=%s",
            market_state.vix, market_state.vix_regime,
            market_state.risk_regime, market_state.earnings_season,
        )
    else:
        market_state = None

    # ── §16/17/23 Governance, throttle, and kill-switch assessment ──────────
    _liquidity_engine   = get_liquidity_engine()
    _positioning_engine = get_positioning_engine()
    _gov_engine = get_governance_engine(
        liquidity_engine   = _liquidity_engine,
        positioning_engine = _positioning_engine,
    )
    _kill_switch = get_switch(pool=pool)
    _throttle    = get_throttle()

    gov_report = await _gov_engine.assess(market_state=market_state)
    throttle_state = _throttle.update(gov_report)

    # Record cycle health to kill-switch
    ks_state = await _kill_switch.record_cycle(
        governance_confidence = gov_report.governance_confidence,
        liquidity_stress      = (
            (await _liquidity_engine.get_snapshot()).liquidity_stress_index
            if not (await _liquidity_engine.get_snapshot()).is_stale else None
        ),
    )

    if not _kill_switch.is_deployable():
        logger.critical(
            "Kill switch ENGAGED (%s) — pipeline aborted. trigger=%s",
            ks_state.value, _kill_switch.current_trigger.value,
        )
        return

    if not throttle_state.new_positions_ok:
        logger.error(
            "Throttle SUSPENDED (confidence=%.3f) — skipping signal deployment",
            gov_report.governance_confidence,
        )
        # Still run scraping/NLP/DB write — just don't deploy signals
        # (signals persist to DB for analysis even when not acted upon)


    # Deduplicate URL list
    unique_urls = list(dict.fromkeys(urls))

    # Filter dead sources and cached URLs
    active_urls: list[str] = []
    for url in unique_urls:
        domain = domain_of(url)
        if await is_dead(pool, domain):
            logger.info("Skipping dead source: %s", domain)
            continue
        if await is_cache_valid(pool, url):
            logger.debug("Cached: %s", url)
            monitor.record_cached()
            continue
        active_urls.append(url)

    if not active_urls:
        logger.info("Nothing to scrape — all URLs cached or dead.")
        return

    # ── Scrape ──────────────────────────────────────────────────────────────
    with Timer() as t_scrape:
        scraped_results = await scrape_all_urls(active_urls, pool=pool)
    logger.info("Scraped %d URLs in %.2fs", len(scraped_results), t_scrape.duration)

    # ── Per-event processing: NLP, materiality, dedup, signal ───────────────
    # We collect all pending events before writing to DB so that
    # batch-level Phase 1 transforms (factor neutralisation, CS ranking)
    # can be applied to the full set before any DB insert.
    pending_events: list[ScrapedEvent] = []
    pending_urls:   list[str]          = []
    alerts_this_run: list[AlertPayload] = []
    prev_sentiment:  dict[str, float]   = {}

    for item in scraped_results:
        url    = item["url"]
        text   = item.get("text") or ""
        domain = domain_of(url)

        if not text:
            continue

        # NLP
        with Timer() as t_nlp:
            analysis = await analyze_all(text, url=url)
        monitor.record_nlp(t_nlp.duration)
        record_nlp(t_nlp.duration)
        record_scrape(domain, success=True, duration=t_scrape.duration)

        sentiment = analysis["sentiment"]
        raw_hash  = ScrapedEvent.hash_text(text)
        embedding = analysis.get("embedding")

        # Materiality (v2 — entity-aware + numerically grounded)
        mat = score_materiality(
            text            = analysis["summary"] or text[:500],
            keywords        = analysis["keywords"],
            credibility     = analysis["credibility"],
            sentiment_score = sentiment["score"],
            event_type      = analysis.get("event_type", "unknown"),
            entities        = analysis.get("targets", []),
        )

        # Deduplication
        canonical_id = await find_duplicate(pool, raw_hash, embedding)
        is_dup       = canonical_id is not None
        if is_dup:
            monitor.record_duplicate()

        # Novelty scoring
        novelty   = await compute_novelty_score(pool, embedding)
        nov_label = novelty_label(novelty)

        # ── §2 Expectation surprise (async DB lookup + sync guidance scan) ──
        surprise_result = None
        resolved_ticker = None
        if settings.enable_expectation_surprise and analysis.get("targets"):
            # Resolve ticker for EPS SUE integration
            raw_entity = analysis["targets"][0] if analysis["targets"] else ""
            if raw_entity:
                resolved_ticker = await resolve_ticker(raw_entity)
            surprise_result = await compute_surprise(
                pool                     = pool,
                targets                  = analysis["targets"],
                current_sentiment_label  = sentiment["label"],
                current_sentiment_score  = abs(sentiment["score"]),
                text                     = text,
                ticker                   = resolved_ticker,
            )

        surprise_score          = surprise_result.surprise_score         if surprise_result else None
        guidance_revision_score = surprise_result.guidance_score         if surprise_result else None

        # ── Phase 2: Financial feature conditioning ──────────────────────────
        fin_features   = None
        fin_feat_dict  = {}
        if resolved_ticker and settings.enable_financial_features:
            try:
                from financial_features import get_engine as _get_fin_engine
                fin_features = await _get_fin_engine().get_features(resolved_ticker)
                fin_feat_dict = fin_features.as_flat_dict()
            except Exception as exc:
                logger.debug("Financial features failed for %s: %s", resolved_ticker, exc)

        # ── §9 Composite alpha signal (market-state + financial conditioned) ─
        scraped_now = datetime.now(timezone.utc)
        signal = compute_signal(
            sentiment_label    = sentiment["label"],
            sentiment_score    = abs(sentiment["score"]),
            materiality_score  = mat.score,
            novelty_score      = novelty,
            credibility_score  = analysis["credibility"],
            materiality_tier   = mat.tier,
            event_type         = analysis.get("event_type", "unknown"),
            scraped_at         = scraped_now,
            market_state       = market_state,
            surprise_score     = surprise_score,
            financial_features = fin_features,       # Phase 2 conditioning
        )

        # Build validated event
        try:
            ev = ScrapedEvent(
                url                     = url,
                source_domain           = domain,
                scraped_at              = scraped_now,
                http_status             = item.get("status"),
                raw_text_hash           = raw_hash,
                summary                 = analysis["summary"],
                sentiment_label         = sentiment["label"],
                sentiment_score         = abs(sentiment["score"]),
                sentiment_confident     = sentiment.get("confident", True),
                keywords                = analysis["keywords"],
                topics                  = analysis["topics"],
                emotions                = analysis["emotions"],
                embedding               = embedding,
                embedding_model         = analysis.get("embedding_model", ""),
                credibility_score       = analysis["credibility"],
                propaganda_score        = analysis["propaganda"]["score"],
                propaganda_flags        = analysis["propaganda"]["flags"],
                materiality_score       = mat.score,
                materiality_tier        = mat.tier,
                is_duplicate            = is_dup,
                canonical_event_id      = canonical_id,
                event_type              = analysis.get("event_type", "unknown"),
                event_confidence        = analysis.get("event_confidence", 0.0),
                novelty_score           = novelty,
                novelty_label           = nov_label,
                signal_score            = signal.score,
                signal_direction        = signal.direction,
                signal_tier             = signal.rank_tier,
                dollar_value            = analysis.get("dollar_value"),
                pct_change              = analysis.get("pct_change"),
                # Phase 1 entity intelligence
                targets                 = analysis.get("targets", []),
                surprise_score          = surprise_score,
                guidance_revision_score = guidance_revision_score,
                eps_surprise_sue        = surprise_result.eps_sue_raw if surprise_result and hasattr(surprise_result, 'eps_sue_raw') else None,
                # Phase 1 market context
                market_regime           = (market_state.risk_regime if market_state else "NEUTRAL"),
                vix_level               = (market_state.vix if market_state else None),
                yield_curve_slope       = (market_state.yield_slope if market_state else None),
                # Phase 2: price features
                price_momentum_1m      = fin_feat_dict.get("price_momentum_1m"),
                price_momentum_3m      = fin_feat_dict.get("price_momentum_3m"),
                price_momentum_12m     = fin_feat_dict.get("price_momentum_12m"),
                price_vol_30d          = fin_feat_dict.get("price_vol_30d"),
                price_vol_regime       = fin_feat_dict.get("price_vol_regime"),
                price_week52_pct       = fin_feat_dict.get("price_week52_pct"),
                price_beta_30d         = fin_feat_dict.get("price_beta_30d"),
                price_dollar_vol_log   = fin_feat_dict.get("price_dollar_vol_log"),
                # Phase 2: fundamental features
                fund_pe_ratio          = fin_feat_dict.get("fund_pe_ratio"),
                fund_fcf_yield         = fin_feat_dict.get("fund_fcf_yield"),
                fund_revenue_growth    = fin_feat_dict.get("fund_revenue_growth"),
                fund_roe               = fin_feat_dict.get("fund_roe"),
                fund_debt_to_equity    = fin_feat_dict.get("fund_debt_to_equity"),
                fund_short_pct_float   = fin_feat_dict.get("fund_short_pct_float"),
                fund_finra_short_vol   = fin_feat_dict.get("fund_finra_short_vol"),
                fund_value_score       = fin_feat_dict.get("fund_value_score"),
                fund_quality_score     = fin_feat_dict.get("fund_quality_score"),
                fund_fragility_score   = fin_feat_dict.get("fund_fragility_score"),
                # Phase 2: earnings features
                earn_eps_sue           = fin_feat_dict.get("earn_eps_sue"),
                earn_beat_rate         = fin_feat_dict.get("earn_beat_rate"),
                earn_revision_momentum = fin_feat_dict.get("earn_revision_momentum"),
                earn_pt_upside         = fin_feat_dict.get("earn_pt_upside"),
                earn_implied_move      = fin_feat_dict.get("earn_implied_move"),
                earn_next_er_days      = fin_feat_dict.get("earn_next_er_days"),
                # Phase 2: macro features (FRED + ECB + Treasury + CBOE)
                macro_hy_spread        = fin_feat_dict.get("macro_hy_spread"),
                macro_tsy_10y          = fin_feat_dict.get("macro_tsy_10y"),
                macro_tsy_spread_10_2  = fin_feat_dict.get("macro_tsy_spread_10_2"),
                macro_vix_term_slope   = fin_feat_dict.get("macro_vix_term_slope"),
                macro_stress_score     = fin_feat_dict.get("macro_stress_score"),
                macro_eurusd           = fin_feat_dict.get("macro_eurusd"),
                financial_signal_mult  = signal.components.get("financial_mult"),
            )
        except Exception as exc:
            logger.warning("Event validation failed for %s: %s", url, exc)
            continue

        pending_events.append(ev)
        pending_urls.append(url)

        # Alert-rule inputs tracked for later dispatch
        if not is_dup:
            prop_alert = rule_high_propaganda(ev.propaganda_score, domain)
            if prop_alert:
                alerts_this_run.append(prop_alert)
            mat_alert = rule_critical_materiality(mat.tier, ev.summary, domain)
            if mat_alert:
                alerts_this_run.append(mat_alert)
            prev = prev_sentiment.get(domain)
            sent_alert = rule_sentiment_shift(sentiment["score"], prev, domain)
            if sent_alert:
                alerts_this_run.append(sent_alert)
            prev_sentiment[domain] = sentiment["score"]

    # ── §11 Factor neutralisation (batch) ──────────────────────────────────
    if pending_events and settings.enable_factor_neutralisation:
        ev_dicts = [ev.model_dump() for ev in pending_events]
        neutralise_batch(ev_dicts)

        # Write factor fields back to the Pydantic models
        for ev, d in zip(pending_events, ev_dicts):
            object.__setattr__(ev, "factor_neutral_score", d.get("factor_neutral_score"))
            object.__setattr__(ev, "primary_sector",       d.get("primary_sector", "unknown"))

    # ── §10 Cross-sectional ranking (batch) ────────────────────────────────
    if pending_events and settings.enable_cross_sectional_ranking:
        # Build minimal dicts for rank_batch (needs factor_neutral_score + primary_sector)
        cs_dicts = [
            {
                "factor_neutral_score": ev.factor_neutral_score or ev.signal_score,
                "primary_sector":       ev.primary_sector,
            }
            for ev in pending_events
        ]
        rank_batch(cs_dicts)

        for ev, d in zip(pending_events, cs_dicts):
            object.__setattr__(ev, "cs_percentile",        d.get("cs_percentile"))
            object.__setattr__(ev, "cs_sector_percentile", d.get("cs_sector_percentile"))
            object.__setattr__(ev, "cs_score",             d.get("cs_score"))

    # ── DB write (deferred until all batch transforms complete) ────────────
    for ev, url in zip(pending_events, pending_urls):
        await insert_event(pool, ev)
        await update_cache(pool, url)
        monitor.persisted += 1

    # ── Shadow portfolio: open positions for high-conviction signals ─────────
    if pending_events and throttle_state.new_positions_ok:
        _shadow   = ShadowPortfolio()
        _exposure = get_exposure_engine()
        _lifecycle = LifecycleLogger(pool=pool)
        _price_cache = get_price_cache()

        # Collect tickers that need pricing
        signal_events = [
            ev for ev in pending_events
            if not ev.is_duplicate
            and ev.signal_score is not None
            and abs(ev.signal_score) >= throttle_state.signal_min_score
        ]

        # Resolve entity → ticker for all qualifying events
        entity_list = list({ev.targets[0] if ev.targets else "" for ev in signal_events})
        entity_list = [e for e in entity_list if e]
        if entity_list:
            ticker_map = await resolve_tickers_batch(entity_list, max_concurrency=6)

            # Warm price cache for all resolved tickers
            tickers_needed = [t for t in ticker_map.values() if t]
            if tickers_needed:
                await _price_cache.warm(tickers_needed)

        for ev in signal_events:
            # Resolve ticker
            raw_entity = ev.targets[0] if ev.targets else ""
            ticker = ticker_map.get(raw_entity) if entity_list else None
            if not ticker:
                continue

            # Exposure pre-check
            notional = settings.base_shadow_notional * throttle_state.size_scalar
            exp_check = _exposure.check_new_position(
                ticker    = ticker,
                direction = ev.signal_direction,
                notional  = notional,
                sector    = ev.primary_sector or "Unknown",
                beta      = 1.0,
            )
            if not exp_check.approved:
                logger.debug("Shadow position rejected by exposure engine: %s %s (%s)",
                             ev.signal_direction, ticker, exp_check.violations)
                continue

            # Open shadow position
            pos = await _shadow.open_position(
                event_id              = str(ev.raw_text_hash or id(ev)),
                ticker                = ticker,
                direction             = ev.signal_direction,
                signal_score          = ev.signal_score,
                governance_confidence = gov_report.governance_confidence,
                throttle_mode         = throttle_state.mode,
                kill_switch_state     = ks_state.value,
                size_scalar           = throttle_state.size_scalar,
            )
            if pos:
                # Update exposure book
                _exposure.record_fill(
                    ticker    = ticker,
                    direction = ev.signal_direction,
                    notional  = pos.effective_notional,
                    sector    = ev.primary_sector or "Unknown",
                )
                # Lifecycle log
                await _lifecycle.record_entry(
                    event_id              = pos.event_id,
                    ticker                = ticker,
                    direction             = ev.signal_direction,
                    signal_score          = ev.signal_score,
                    entry_reason          = f"{ev.event_type}_{ev.signal_tier}_{ticker}",
                    governance_confidence = gov_report.governance_confidence,
                    governance_uncertainty = gov_report.governance_uncertainty,
                    throttle_mode         = throttle_state.mode,
                    kill_switch_state     = ks_state.value,
                    liquidity_regime      = (await get_liquidity_engine().get_snapshot()).regime,
                    market_regime         = ev.market_regime or "NEUTRAL",
                    notional              = notional,
                    filled_notional       = pos.effective_notional,
                    fill_pct              = 1.0,
                    fill_price            = pos.entry_price,
                    size_scalar_applied   = throttle_state.size_scalar,
                    signal_tier           = ev.signal_tier or "",
                    is_shadow_trade       = True,
                )

    # ── Flush knowledge graph edges ─────────────────────────────────────────
    await flush_knowledge_graph()

    # ── Dispatch all alerts ──────────────────────────────────────────────────
    if alerts_this_run:
        await dispatch_alerts(pool, alerts_this_run)

    logger.info("Pipeline complete: %s", monitor.summary())


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    urls = sys.argv[1:] if len(sys.argv) > 1 else DEFAULT_URLS
    asyncio.run(run_pipeline(urls))


if __name__ == "__main__":
    main()
