"""
macro_features.py — Global macro feature engine.

Data sources
------------
1. FRED (Federal Reserve Economic Data)
   https://fred.stlouisfed.org
   API: https://api.stlouisfed.org/fred/series/observations
   No API key required for anonymous access (25 req/day limit).
   Key: set FRED_API_KEY env var for 120 req/min.

2. ECB Statistical Data Warehouse
   https://data.ecb.europa.eu
   REST API: https://data.ecb.europa.eu/api/data/{dataset}/{key}
   No auth required. Key series: EUR/USD, EURIBOR, sovereign spreads.

3. U.S. Treasury Yield Data (direct)
   https://home.treasury.gov/resource-center/data-chart-center/interest-rates
   CSV endpoint — more reliable than yfinance ^TNX for official Treasury data.

4. CBOE VIX Term Structure
   https://www.cboe.com
   Public CSV: VIX9D, VIX, VIX3M, VIX6M for term structure shape.

Features produced
-----------------
  US Macro
    fred_unemployment        : UNRATE — unemployment rate
    fred_cpi_yoy             : CPI year-over-year change
    fred_industrial_prod     : INDPRO — industrial production index MoM
    fred_retail_sales        : RSAFS — retail sales MoM
    fred_initial_claims      : ICSA — initial jobless claims (weekly)
    fred_hy_spread           : BAMLH0A0HYM2 — HY OAS spread (bps/100)
    fred_ig_spread           : BAMLC0A0CM — IG OAS spread (bps/100)
    fred_breakeven_5y        : T5YIE — 5Y breakeven inflation
    fred_ted_spread          : TEDRATE — TED spread (credit stress proxy)

  US Treasury (direct)
    tsy_2y / tsy_5y / tsy_10y / tsy_30y : on-the-run yields
    tsy_10y_2y_spread                    : 10Y-2Y spread (inversion = stress)
    tsy_10y_3m_spread                    : 10Y-3M spread (most predictive)

  CBOE VIX Term Structure
    cboe_vix9d               : 9-day VIX
    cboe_vix                 : standard 30-day VIX
    cboe_vix3m               : 3-month VIX
    cboe_vix6m               : 6-month VIX
    cboe_vix_term_slope      : VIX3M - VIX (contango > 0, backwardation < 0)
    cboe_vix_term_score      : normalised stress score from term structure [0, 1]

  ECB / Global
    ecb_eurusd               : EUR/USD exchange rate
    ecb_euribor_3m           : 3-month EURIBOR
    ecb_de_bund_10y          : German 10Y Bund yield
    ecb_spread_ita_de        : Italy-Germany 10Y spread (contagion proxy)

  Composite regime
    macro_stress_score       : [0, 1] weighted composite of stress indicators
    macro_growth_score       : [0, 1] growth momentum composite
    global_risk_regime       : RISK_ON | NEUTRAL | RISK_OFF
"""
from __future__ import annotations

import asyncio
import csv
import io
import json
import logging
import os
import time
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger(__name__)

_FRED_KEY   = os.environ.get("FRED_API_KEY", "")
_FRED_BASE  = "https://api.stlouisfed.org/fred/series/observations"
_MACRO_TTL  = 3600     # 1 hour — macro data updates at most daily
_ECB_BASE   = "https://data.ecb.europa.eu/api/data"
_TSY_URL    = (
    "https://home.treasury.gov/resource-center/data-chart-center/"
    "interest-rates/daily-treasury-rates.csv/all/all?"
    "type=daily_treasury_yield_curve&field_tdr_date_value=all&download=true"
)
_CBOE_VIX_HISTORY = "https://cdn.cboe.com/api/global/us_indices/daily_prices/VIX_History.csv"
_CBOE_VX_TERM_URL = (
    "https://cdn.cboe.com/api/global/us_indices/daily_prices/{sym}_History.csv"
)

_FRED_SERIES = {
    "fred_unemployment":    "UNRATE",
    "fred_cpi_yoy":         "CPIAUCSL",
    "fred_industrial_prod": "INDPRO",
    "fred_retail_sales":    "RSAFS",
    "fred_initial_claims":  "ICSA",
    "fred_hy_spread":       "BAMLH0A0HYM2",
    "fred_ig_spread":       "BAMLC0A0CM",
    "fred_breakeven_5y":    "T5YIE",
    "fred_ted_spread":      "TEDRATE",
}


# ---------------------------------------------------------------------------
# Output dataclass
# ---------------------------------------------------------------------------

@dataclass
class MacroFeatureSnapshot:
    # FRED
    fred_unemployment:    Optional[float] = None
    fred_cpi_yoy:         Optional[float] = None
    fred_industrial_prod: Optional[float] = None
    fred_retail_sales:    Optional[float] = None
    fred_initial_claims:  Optional[float] = None
    fred_hy_spread:       Optional[float] = None
    fred_ig_spread:       Optional[float] = None
    fred_breakeven_5y:    Optional[float] = None
    fred_ted_spread:      Optional[float] = None

    # US Treasury
    tsy_2y:              Optional[float] = None
    tsy_5y:              Optional[float] = None
    tsy_10y:             Optional[float] = None
    tsy_30y:             Optional[float] = None
    tsy_10y_2y_spread:   Optional[float] = None
    tsy_10y_3m_spread:   Optional[float] = None
    tsy_3m:              Optional[float] = None

    # CBOE VIX term structure
    cboe_vix9d:          Optional[float] = None
    cboe_vix:            Optional[float] = None
    cboe_vix3m:          Optional[float] = None
    cboe_vix6m:          Optional[float] = None
    cboe_vix_term_slope: Optional[float] = None   # VIX3M - VIX
    cboe_vix_term_score: Optional[float] = None   # [0, 1] stress from term structure

    # ECB / global
    ecb_eurusd:          Optional[float] = None
    ecb_euribor_3m:      Optional[float] = None
    ecb_de_bund_10y:     Optional[float] = None
    ecb_spread_ita_de:   Optional[float] = None

    # Composite
    macro_stress_score:  Optional[float] = None   # [0, 1]
    macro_growth_score:  Optional[float] = None   # [0, 1]
    global_risk_regime:  str = "NEUTRAL"

    fetched_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    is_stale:   bool = True
    sources_ok: dict = field(default_factory=dict)

    def as_feature_dict(self) -> dict[str, Optional[float]]:
        return {
            "macro_unemployment":   self.fred_unemployment,
            "macro_cpi_yoy":        self.fred_cpi_yoy,
            "macro_initial_claims": self.fred_initial_claims,
            "macro_hy_spread":      self.fred_hy_spread,
            "macro_ig_spread":      self.fred_ig_spread,
            "macro_tsy_10y":        self.tsy_10y,
            "macro_tsy_spread_10_2": self.tsy_10y_2y_spread,
            "macro_tsy_spread_10_3m": self.tsy_10y_3m_spread,
            "macro_vix_term_slope": self.cboe_vix_term_slope,
            "macro_vix_term_score": self.cboe_vix_term_score,
            "macro_eurusd":         self.ecb_eurusd,
            "macro_bund_10y":       self.ecb_de_bund_10y,
            "macro_ita_spread":     self.ecb_spread_ita_de,
            "macro_stress_score":   self.macro_stress_score,
            "macro_growth_score":   self.macro_growth_score,
        }


# ---------------------------------------------------------------------------
# FRED fetcher
# ---------------------------------------------------------------------------

def _fetch_fred_series_sync(series_id: str, limit: int = 2) -> Optional[float]:
    """Fetch the most recent observation for a FRED series."""
    try:
        params = f"series_id={series_id}&sort_order=desc&limit={limit}&file_type=json"
        if _FRED_KEY:
            params += f"&api_key={_FRED_KEY}"
        url = f"{_FRED_BASE}?{params}"
        req = urllib.request.Request(
            url, headers={"User-Agent": "FinanceAI research@financeai.dev"}
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())
        observations = data.get("observations", [])
        for obs in observations:
            val = obs.get("value")
            if val and val != ".":
                return float(val)
        return None
    except Exception as exc:
        logger.debug("FRED %s fetch failed: %s", series_id, exc)
        return None


def _fetch_all_fred_sync() -> dict[str, Optional[float]]:
    """Fetch all FRED series concurrently (in thread — uses multiple sockets)."""
    results = {}
    for feat_name, series_id in _FRED_SERIES.items():
        results[feat_name] = _fetch_fred_series_sync(series_id)
    return results


# ---------------------------------------------------------------------------
# US Treasury direct fetch
# ---------------------------------------------------------------------------

def _fetch_treasury_yields_sync() -> dict[str, Optional[float]]:
    """
    Fetch current Treasury yield curve from Treasury.gov official CSV.
    More reliable than yfinance ^TNX for official par yields.
    https://home.treasury.gov/resource-center/data-chart-center/interest-rates
    """
    try:
        req = urllib.request.Request(
            _TSY_URL,
            headers={"User-Agent": "FinanceAI research@financeai.dev"},
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            content = resp.read().decode("utf-8", errors="replace")

        reader = csv.DictReader(io.StringIO(content))
        rows   = list(reader)

        if not rows:
            return {}

        # Most recent row is last
        last = rows[-1]

        def _get(keys: list) -> Optional[float]:
            for k in keys:
                v = last.get(k)
                if v and v.strip():
                    try:
                        return round(float(v.strip()) / 100, 5)
                    except ValueError:
                        pass
            return None

        tsy_3m  = _get(["3 Mo", "3-Month"])
        tsy_2y  = _get(["2 Yr", "2-Year"])
        tsy_5y  = _get(["5 Yr", "5-Year"])
        tsy_10y = _get(["10 Yr", "10-Year"])
        tsy_30y = _get(["30 Yr", "30-Year"])

        result = {
            "tsy_3m":  tsy_3m,
            "tsy_2y":  tsy_2y,
            "tsy_5y":  tsy_5y,
            "tsy_10y": tsy_10y,
            "tsy_30y": tsy_30y,
        }

        if tsy_10y and tsy_2y:
            result["tsy_10y_2y_spread"] = round(tsy_10y - tsy_2y, 5)
        if tsy_10y and tsy_3m:
            result["tsy_10y_3m_spread"] = round(tsy_10y - tsy_3m, 5)

        return result

    except Exception as exc:
        logger.warning("Treasury yield fetch failed: %s", exc)
        return {}


# ---------------------------------------------------------------------------
# CBOE VIX term structure
# ---------------------------------------------------------------------------

def _fetch_cboe_vix_term_sync() -> dict[str, Optional[float]]:
    """
    Fetch VIX term structure from CBOE public data.
    https://www.cboe.com/tradable_products/vix/vix_historical_data/
    Symbols: VIX9D, VIX (30d), VIX3M, VIX6M
    """
    result: dict[str, Optional[float]] = {}
    symbols = {"VIX9D": "cboe_vix9d", "VIX": "cboe_vix",
               "VIX3M": "cboe_vix3m", "VIX6M": "cboe_vix6m"}

    for sym, feat_name in symbols.items():
        try:
            url = _CBOE_VX_TERM_URL.format(sym=sym)
            req = urllib.request.Request(
                url,
                headers={"User-Agent": "FinanceAI research@financeai.dev"},
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                content = resp.read().decode("utf-8", errors="replace")

            reader = csv.DictReader(io.StringIO(content))
            rows   = [r for r in reader if r.get("CLOSE") and r["CLOSE"].strip()]
            if rows:
                close_val = rows[-1].get("CLOSE") or rows[-1].get("Close")
                if close_val:
                    result[feat_name] = round(float(close_val.strip()), 2)
        except Exception as exc:
            logger.debug("CBOE %s fetch failed: %s", sym, exc)

    # Compute term structure metrics
    vix    = result.get("cboe_vix")
    vix3m  = result.get("cboe_vix3m")
    vix9d  = result.get("cboe_vix9d")
    vix6m  = result.get("cboe_vix6m")

    if vix and vix3m:
        slope = vix3m - vix
        result["cboe_vix_term_slope"] = round(slope, 3)
        # Score: backwardation (slope < 0) = stress = high score
        result["cboe_vix_term_score"] = round(
            min(1.0, max(0.0, -slope / 5.0 + 0.5)), 4
        )

    return result


# ---------------------------------------------------------------------------
# ECB Statistical Data Warehouse
# ---------------------------------------------------------------------------

def _fetch_ecb_series_sync(dataset: str, key: str) -> Optional[float]:
    """
    Fetch the most recent observation from ECB SDW REST API.
    https://data.ecb.europa.eu/api/data/{dataset}/{key}?format=json&lastNObservations=1
    """
    try:
        url = f"{_ECB_BASE}/{dataset}/{key}?format=json&lastNObservations=1&detail=dataonly"
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "FinanceAI research@financeai.dev",
                "Accept":     "application/json",
            },
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read())

        # ECB JSON structure: dataSets[0].series[key].observations
        datasets = data.get("dataSets", [])
        if not datasets:
            return None
        series_dict = datasets[0].get("series", {})
        if not series_dict:
            return None
        first_series = next(iter(series_dict.values()))
        observations = first_series.get("observations", {})
        if not observations:
            return None
        last_obs = observations.get(str(max(int(k) for k in observations)), [None])
        if last_obs and last_obs[0] is not None:
            return float(last_obs[0])
        return None
    except Exception as exc:
        logger.debug("ECB SDW %s/%s failed: %s", dataset, key, exc)
        return None


def _fetch_ecb_data_sync() -> dict[str, Optional[float]]:
    """
    Fetch key ECB series:
    - EUR/USD: EXR/D.USD.EUR.SP00.A
    - 3M EURIBOR: FM/B.U2.EUR.RT.MM.EURIBOR3MD_.HSTA
    - German 10Y Bund: YC/B.U2.EUR.4F.G_N_A.SV_C_YM.SR_10Y
    - Italy-Germany spread: YC spread proxy
    """
    ecb_series = {
        "ecb_eurusd":       ("EXR", "D.USD.EUR.SP00.A"),
        "ecb_euribor_3m":   ("FM",  "B.U2.EUR.RT.MM.EURIBOR3MD_.HSTA"),
        "ecb_de_bund_10y":  ("YC",  "B.U2.EUR.4F.G_N_A.SV_C_YM.SR_10Y"),
        "ecb_it_10y":       ("YC",  "B.U2.EUR.4F.G_N_A.SV_C_YM.IT_SR_10Y"),
    }
    results = {}
    for name, (dataset, key) in ecb_series.items():
        results[name] = _fetch_ecb_series_sync(dataset, key)

    # Compute Italy-Germany spread
    de = results.get("ecb_de_bund_10y")
    it = results.get("ecb_it_10y")
    if de is not None and it is not None:
        results["ecb_spread_ita_de"] = round(it - de, 4)

    return results


# ---------------------------------------------------------------------------
# Composite scores
# ---------------------------------------------------------------------------

def _compute_macro_stress(snap: MacroFeatureSnapshot) -> Optional[float]:
    """
    Composite macro stress score [0, 1]. Higher = more stressed.
    """
    components = []

    # Credit stress: HY spread (normal ~300bps, stressed ~700bps+)
    if snap.fred_hy_spread is not None:
        hy_score = min(1.0, max(0.0, (snap.fred_hy_spread - 3.0) / 7.0))
        components.append(hy_score * 0.25)

    # Yield curve inversion: 10Y-2Y < 0 = stress
    if snap.tsy_10y_2y_spread is not None:
        inv_score = min(1.0, max(0.0, -snap.tsy_10y_2y_spread * 50 + 0.5))
        components.append(inv_score * 0.20)

    # VIX term structure: backwardation = stress
    if snap.cboe_vix_term_score is not None:
        components.append(snap.cboe_vix_term_score * 0.20)

    # Italy-Germany spread: >200bps = elevated European stress
    if snap.ecb_spread_ita_de is not None:
        eu_score = min(1.0, max(0.0, snap.ecb_spread_ita_de / 4.0))
        components.append(eu_score * 0.15)

    # TED spread: >100bps = severe interbank stress
    if snap.fred_ted_spread is not None:
        ted_score = min(1.0, max(0.0, snap.fred_ted_spread / 1.0))
        components.append(ted_score * 0.20)

    if not components:
        return None
    return round(sum(components), 4)


def _compute_macro_growth(snap: MacroFeatureSnapshot) -> Optional[float]:
    """
    Growth momentum score [0, 1]. Higher = stronger growth conditions.
    """
    components = []

    # Low unemployment = growth
    if snap.fred_unemployment is not None:
        emp_score = max(0.0, min(1.0, 1.0 - (snap.fred_unemployment - 3.5) / 6.0))
        components.append(emp_score * 0.30)

    # Falling initial claims = growth
    if snap.fred_initial_claims is not None:
        claims_score = max(0.0, min(1.0, 1.0 - (snap.fred_initial_claims - 200000) / 400000))
        components.append(claims_score * 0.25)

    # Industrial production positive
    if snap.fred_industrial_prod is not None:
        ip_score = min(1.0, max(0.0, snap.fred_industrial_prod / 100.0))
        components.append(ip_score * 0.25)

    # Positive retail sales
    if snap.fred_retail_sales is not None:
        rs_score = min(1.0, max(0.0, snap.fred_retail_sales / 100.0))
        components.append(rs_score * 0.20)

    if not components:
        return None
    return round(sum(components), 4)


def _classify_global_risk_regime(stress: Optional[float], growth: Optional[float]) -> str:
    if stress is None and growth is None:
        return "NEUTRAL"
    s = stress or 0.5
    g = growth or 0.5
    if s > 0.65:
        return "RISK_OFF"
    if s < 0.30 and g > 0.55:
        return "RISK_ON"
    return "NEUTRAL"


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class MacroFeatureEngine:
    """
    Fetches global macro data from FRED, ECB SDW, US Treasury, and CBOE.
    Cached at the market level (not per-ticker) — macro data is universal.
    """

    def __init__(self) -> None:
        self._cache: Optional[tuple[float, MacroFeatureSnapshot]] = None
        self._lock  = asyncio.Lock()

    async def get_snapshot(self, force_refresh: bool = False) -> MacroFeatureSnapshot:
        async with self._lock:
            now = time.monotonic()
            if not force_refresh and self._cache is not None:
                exp, cached = self._cache
                if now < exp:
                    return cached

        snap = await self._fetch_all()

        async with self._lock:
            self._cache = (time.monotonic() + _MACRO_TTL, snap)

        return snap

    async def _fetch_all(self) -> MacroFeatureSnapshot:
        loop = asyncio.get_running_loop()

        # Run all four fetchers concurrently
        fred_task  = loop.run_in_executor(None, _fetch_all_fred_sync)
        tsy_task   = loop.run_in_executor(None, _fetch_treasury_yields_sync)
        cboe_task  = loop.run_in_executor(None, _fetch_cboe_vix_term_sync)
        ecb_task   = loop.run_in_executor(None, _fetch_ecb_data_sync)

        fred_data, tsy_data, cboe_data, ecb_data = await asyncio.gather(
            fred_task, tsy_task, cboe_task, ecb_task,
            return_exceptions=True,
        )

        snap = MacroFeatureSnapshot()
        sources_ok = {}

        # FRED
        if isinstance(fred_data, dict):
            for k, v in fred_data.items():
                setattr(snap, k, v)
            sources_ok["fred"] = any(v is not None for v in fred_data.values())
        else:
            sources_ok["fred"] = False

        # Treasury
        if isinstance(tsy_data, dict) and tsy_data:
            snap.tsy_3m             = tsy_data.get("tsy_3m")
            snap.tsy_2y             = tsy_data.get("tsy_2y")
            snap.tsy_5y             = tsy_data.get("tsy_5y")
            snap.tsy_10y            = tsy_data.get("tsy_10y")
            snap.tsy_30y            = tsy_data.get("tsy_30y")
            snap.tsy_10y_2y_spread  = tsy_data.get("tsy_10y_2y_spread")
            snap.tsy_10y_3m_spread  = tsy_data.get("tsy_10y_3m_spread")
            sources_ok["treasury"] = snap.tsy_10y is not None
        else:
            sources_ok["treasury"] = False

        # CBOE
        if isinstance(cboe_data, dict) and cboe_data:
            snap.cboe_vix9d          = cboe_data.get("cboe_vix9d")
            snap.cboe_vix            = cboe_data.get("cboe_vix")
            snap.cboe_vix3m          = cboe_data.get("cboe_vix3m")
            snap.cboe_vix6m          = cboe_data.get("cboe_vix6m")
            snap.cboe_vix_term_slope = cboe_data.get("cboe_vix_term_slope")
            snap.cboe_vix_term_score = cboe_data.get("cboe_vix_term_score")
            sources_ok["cboe"] = snap.cboe_vix is not None
        else:
            sources_ok["cboe"] = False

        # ECB
        if isinstance(ecb_data, dict) and ecb_data:
            snap.ecb_eurusd        = ecb_data.get("ecb_eurusd")
            snap.ecb_euribor_3m    = ecb_data.get("ecb_euribor_3m")
            snap.ecb_de_bund_10y   = ecb_data.get("ecb_de_bund_10y")
            snap.ecb_spread_ita_de = ecb_data.get("ecb_spread_ita_de")
            sources_ok["ecb"] = snap.ecb_eurusd is not None
        else:
            sources_ok["ecb"] = False

        # Composite scores
        snap.macro_stress_score = _compute_macro_stress(snap)
        snap.macro_growth_score = _compute_macro_growth(snap)
        snap.global_risk_regime = _classify_global_risk_regime(
            snap.macro_stress_score, snap.macro_growth_score
        )

        snap.sources_ok = sources_ok
        snap.is_stale   = not any(sources_ok.values())

        logger.info(
            "Macro snapshot: stress=%.2f growth=%.2f regime=%s "
            "tsy10y=%.3f hy_spread=%.2f cboe_vix=%.1f eurusd=%.4f sources=%s",
            snap.macro_stress_score or -1,
            snap.macro_growth_score or -1,
            snap.global_risk_regime,
            snap.tsy_10y or -1,
            snap.fred_hy_spread or -1,
            snap.cboe_vix or -1,
            snap.ecb_eurusd or -1,
            sources_ok,
        )
        return snap


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_engine: Optional[MacroFeatureEngine] = None


def get_engine() -> MacroFeatureEngine:
    global _engine
    if _engine is None:
        _engine = MacroFeatureEngine()
    return _engine
