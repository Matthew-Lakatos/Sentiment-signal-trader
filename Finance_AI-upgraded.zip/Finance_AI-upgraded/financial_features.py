"""
financial_features.py — Financial feature orchestrator.

Combines price, fundamental, earnings surprise, and macro features into
a single FinancialFeatureVector consumed by signal_ranker and calibration.

Architecture
------------
  PriceFeatureEngine      — price momentum, vol, beta (no network, EOD cache)
  FundamentalFeatureEngine — valuation, quality, balance sheet (yfinance + FINRA)
  EarningsSurpriseEngine  — SUE, revision momentum, implied move (yfinance + AV + CBOE)
  MacroFeatureEngine      — FRED, ECB SDW, US Treasury, CBOE VIX term (global)

Caching
-------
  Per-ticker cache: 1 hour TTL for price + fundamentals + earnings
  Market-level cache: 1 hour TTL for macro (shared across all tickers)

Usage
-----
    from financial_features import FinancialFeatureEngine

    engine = FinancialFeatureEngine()

    # Per-event feature enrichment
    features = await engine.get_features(ticker="AAPL")
    signal_dict = features.as_signal_conditioning_dict()

    # Macro snapshot (market-level)
    macro = await engine.get_macro_snapshot()
"""
from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from price_features       import PriceFeatureVector,        get_engine as _get_price
from fundamental_features import FundamentalFeatureVector,  get_engine as _get_fund
from earnings_surprise    import EarningsSurpriseFeatures,  get_engine as _get_earn
from macro_features       import MacroFeatureSnapshot,      get_engine as _get_macro

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Combined vector
# ---------------------------------------------------------------------------

@dataclass
class FinancialFeatureVector:
    ticker: str

    price:       Optional[PriceFeatureVector]       = None
    fundamental: Optional[FundamentalFeatureVector]  = None
    earnings:    Optional[EarningsSurpriseFeatures]  = None
    macro:       Optional[MacroFeatureSnapshot]      = None

    computed_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    # ------------------------------------------------------------------
    # Signal conditioning (what signal_ranker consumes)
    # ------------------------------------------------------------------

    def signal_multiplier(self, sentiment_score: float) -> float:
        """
        Compute a conditioning multiplier for a raw sentiment signal.
        Returns a value in [0.3, 1.5] that scales the signal based on:
          - Valuation context (cheap vs expensive)
          - Momentum alignment
          - Earnings surprise context
          - Balance sheet fragility
          - Macro regime

        This is the core financial conditioning logic.
        """
        mult = 1.0
        sentiment_is_positive = sentiment_score > 0

        # ── Price momentum alignment ─────────────────────────────────────
        if self.price and not self.price.is_stale:
            m12 = self.price.momentum_12m or 0.0
            m1  = self.price.momentum_1m  or 0.0

            # Sentiment aligns with 12m momentum → confirm
            if sentiment_is_positive and m12 > 0.10:
                mult *= 1.12
            elif not sentiment_is_positive and m12 < -0.10:
                mult *= 1.12
            # Sentiment contradicts momentum → attenuate (contrarian risk)
            elif sentiment_is_positive and m12 < -0.20:
                mult *= 0.80
            elif not sentiment_is_positive and m12 > 0.20:
                mult *= 0.80

            # High vol regime → uncertainty discount
            if self.price.vol_regime and self.price.vol_regime > 1.5:
                mult *= 0.88

            # Low dollar volume → illiquidity discount
            if self.price.dollar_vol_log and self.price.dollar_vol_log < 7.0:
                mult *= 0.85   # very small stock

        # ── Valuation conditioning ───────────────────────────────────────
        if self.fundamental and not self.fundamental.is_stale:
            v_score = self.fundamental.value_score
            q_score = self.fundamental.quality_score
            f_score = self.fundamental.fragility_score

            # Positive sentiment on cheap+quality stock → amplify
            if sentiment_is_positive and v_score and v_score > 0.65:
                mult *= 1.10
            # Positive sentiment on expensive stock → attenuate (priced in)
            elif sentiment_is_positive and v_score and v_score < 0.25:
                mult *= 0.85

            # Negative sentiment on fragile/leveraged stock → amplify
            if not sentiment_is_positive and f_score and f_score > 0.65:
                mult *= 1.15
            # Negative sentiment on quality stock → attenuate (resilient)
            elif not sentiment_is_positive and q_score and q_score > 0.70:
                mult *= 0.85

        # ── Earnings surprise conditioning ───────────────────────────────
        if self.earnings and not self.earnings.is_stale:
            sue = self.earnings.eps_surprise_sue or 0.0
            rev = self.earnings.revision_momentum or 0.0

            # High positive SUE + positive sentiment → strong confirm
            if sentiment_is_positive and sue > 1.5:
                mult *= 1.20
            # High negative SUE + negative sentiment → strong confirm
            elif not sentiment_is_positive and sue < -1.5:
                mult *= 1.20

            # Analyst revisions aligned with sentiment
            if sentiment_is_positive and rev > 0.30:
                mult *= 1.08
            elif not sentiment_is_positive and rev < -0.30:
                mult *= 1.08

            # Near earnings → implied move discount (event risk)
            if self.earnings.next_earnings_days is not None:
                if self.earnings.next_earnings_days <= 5:
                    mult *= 0.70   # very near earnings = high event risk
                elif self.earnings.next_earnings_days <= 15:
                    mult *= 0.85

        # ── Macro regime conditioning ─────────────────────────────────────
        if self.macro and not self.macro.is_stale:
            regime = self.macro.global_risk_regime
            stress = self.macro.macro_stress_score or 0.5

            if regime == "RISK_OFF":
                if sentiment_is_positive:
                    mult *= 0.75   # bad time to be long anything
                else:
                    mult *= 1.10   # shorts work better in RISK_OFF

            elif regime == "RISK_ON":
                if sentiment_is_positive:
                    mult *= 1.08
                else:
                    mult *= 0.90

            # High macro stress → universal caution discount
            if stress > 0.70:
                mult *= 0.85

        return round(min(1.5, max(0.3, mult)), 4)

    def as_flat_dict(self) -> dict[str, Optional[float]]:
        """All features as a flat dict for the calibration matrix."""
        result = {}
        if self.price:
            result.update(self.price.as_feature_dict())
        if self.fundamental:
            result.update(self.fundamental.as_feature_dict())
        if self.earnings:
            result.update(self.earnings.as_feature_dict())
        if self.macro:
            result.update(self.macro.as_feature_dict())
        return result

    def as_signal_conditioning_dict(self) -> dict:
        """Structured conditioning for signal_ranker.py."""
        return {
            "multiplier_positive": self.signal_multiplier(+1.0),
            "multiplier_negative": self.signal_multiplier(-1.0),
            "value_score":         self.fundamental.value_score   if self.fundamental else None,
            "quality_score":       self.fundamental.quality_score if self.fundamental else None,
            "fragility_score":     self.fundamental.fragility_score if self.fundamental else None,
            "momentum_12m":        self.price.momentum_12m        if self.price else None,
            "eps_sue":             self.earnings.eps_surprise_sue if self.earnings else None,
            "revision_momentum":   self.earnings.revision_momentum if self.earnings else None,
            "macro_regime":        self.macro.global_risk_regime  if self.macro else "NEUTRAL",
            "macro_stress":        self.macro.macro_stress_score  if self.macro else None,
        }

    @property
    def is_usable(self) -> bool:
        return any([
            self.price and not self.price.is_stale,
            self.fundamental and not self.fundamental.is_stale,
            self.earnings and not self.earnings.is_stale,
        ])


# ---------------------------------------------------------------------------
# Main engine
# ---------------------------------------------------------------------------

class FinancialFeatureEngine:
    """
    Orchestrates all four financial feature engines for a given ticker.

    Fetches price, fundamental, earnings, and macro features concurrently.
    Macro is cached at the market level — only fetched once per TTL period
    regardless of how many tickers are queried.
    """

    def __init__(self) -> None:
        self._price_eng = _get_price()
        self._fund_eng  = _get_fund()
        self._earn_eng  = _get_earn()
        self._macro_eng = _get_macro()

    async def get_features(
        self,
        ticker:        str,
        force_refresh: bool = False,
    ) -> FinancialFeatureVector:
        """
        Fetch all features for a single ticker.
        Macro snapshot is reused from cache across concurrent calls.
        """
        price_task = self._price_eng.get_features(ticker, force_refresh)
        fund_task  = self._fund_eng.get_features(ticker, force_refresh)
        earn_task  = self._earn_eng.get_features(ticker, force_refresh)
        macro_task = self._macro_eng.get_snapshot(force_refresh)

        price, fund, earn, macro = await asyncio.gather(
            price_task, fund_task, earn_task, macro_task,
            return_exceptions=True,
        )

        fv = FinancialFeatureVector(ticker=ticker)
        fv.price       = price       if isinstance(price, PriceFeatureVector)       else None
        fv.fundamental = fund        if isinstance(fund,  FundamentalFeatureVector)  else None
        fv.earnings    = earn        if isinstance(earn,  EarningsSurpriseFeatures)  else None
        fv.macro       = macro       if isinstance(macro, MacroFeatureSnapshot)      else None

        if not fv.is_usable:
            logger.debug("FinancialFeatureVector for %s is empty/stale", ticker)

        return fv

    async def get_features_batch(
        self,
        tickers:       list[str],
        max_concurrent: int = 5,
    ) -> dict[str, FinancialFeatureVector]:
        """
        Fetch features for multiple tickers with concurrency limiting.
        Macro is fetched once and shared.
        """
        sem = asyncio.Semaphore(max_concurrent)

        async def _one(t: str) -> tuple[str, FinancialFeatureVector]:
            async with sem:
                return t, await self.get_features(t)

        results = await asyncio.gather(*[_one(t) for t in tickers])
        return dict(results)

    async def get_macro_snapshot(self) -> MacroFeatureSnapshot:
        return await self._macro_eng.get_snapshot()


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_engine: Optional[FinancialFeatureEngine] = None


def get_engine() -> FinancialFeatureEngine:
    global _engine
    if _engine is None:
        _engine = FinancialFeatureEngine()
    return _engine
