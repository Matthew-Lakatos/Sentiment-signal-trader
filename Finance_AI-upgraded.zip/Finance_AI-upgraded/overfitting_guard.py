"""
overfitting_guard.py — strict train / validation / test split with robustness gating.

Why this matters
----------------
With 6+ modules and 10+ hyperparameters, it is easy to accidentally:
  1. Tune thresholds on data that will later be used to evaluate performance
  2. Run calibration → check test IC → adjust → recalibrate (p-hacking loop)
  3. Report the IC of the best-looking window as the "true" IC

This module enforces a strict three-way split and a one-shot evaluation protocol:

  TRAIN     60%  — calibrate weights, tune thresholds
  VALIDATE  20%  — select between methods (ridge vs rank_ic vs grid)
                   choose horizon, choose filter thresholds
  TEST      20%  — single evaluation; results are FINAL and not tunable

The test set is locked behind evaluate_on_test(), which can only be called
ONCE per experiment (enforced by a flag written to disk).

Usage
-----
    from overfitting_guard import DataSplitter, OverfittingGuard

    splitter = DataSplitter(events, train=0.6, val=0.2, test=0.2)
    train_ev, val_ev, test_ev = splitter.split()

    # Step 1: calibrate on train
    from calibration import calibrate
    result = calibrate(train_ev, horizon=1)

    # Step 2: select method on val (no peeking at test)
    val_ic = splitter.evaluate_on_val(val_ev, result.weights, horizon=1)

    # Step 3: ONE-SHOT evaluation on test
    guard = OverfittingGuard(experiment_id="exp_001", lock_dir="/tmp")
    test_report = guard.evaluate_on_test(test_ev, result.weights, horizon=1)
    # Calling evaluate_on_test a second time raises RuntimeError
"""
from __future__ import annotations

import json
import logging
import math
import os
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Metric helpers
# ---------------------------------------------------------------------------

def _spearman(xs: list[float], ys: list[float]) -> float:
    n = len(xs)
    if n < 3:
        return float("nan")
    try:
        from scipy.stats import spearmanr
        r, _ = spearmanr(xs, ys)
        return float(r) if math.isfinite(r) else float("nan")
    except ImportError:
        return float("nan")


def _sharpe(rets: list[float]) -> float:
    n = len(rets)
    if n < 2:
        return float("nan")
    mu  = sum(rets) / n
    std = math.sqrt(sum((r - mu) ** 2 for r in rets) / (n - 1))
    return (mu / std * math.sqrt(252)) if std > 1e-9 else float("nan")


def _hit_rate(sigs: list[float], rets: list[float], thr: float = 0.05) -> float:
    pairs = [(s, r) for s, r in zip(sigs, rets) if abs(s) > thr]
    if not pairs:
        return float("nan")
    return sum(1 for s, r in pairs if (s > 0 and r > 0) or (s < 0 and r < 0)) / len(pairs)


# ---------------------------------------------------------------------------
# Data splitter
# ---------------------------------------------------------------------------

class DataSplitter:
    """
    Time-ordered train / validation / test split.

    Events MUST be sorted by scraped_at before splitting.
    Random shuffling before splitting leaks future data into training.
    """

    def __init__(
        self,
        events:     list[dict],
        train:      float = 0.60,
        val:        float = 0.20,
        test:       float = 0.20,
    ):
        assert abs(train + val + test - 1.0) < 1e-6, "train+val+test must sum to 1"
        self._events = sorted(events, key=lambda e: str(e.get("scraped_at") or ""))
        self._n      = len(self._events)
        self._t1     = int(self._n * train)
        self._t2     = int(self._n * (train + val))

    def split(self) -> tuple[list[dict], list[dict], list[dict]]:
        """Return (train, val, test) — time-ordered, never shuffled."""
        train = self._events[:self._t1]
        val   = self._events[self._t1:self._t2]
        test  = self._events[self._t2:]
        logger.info(
            "DataSplitter: total=%d train=%d val=%d test=%d",
            self._n, len(train), len(val), len(test),
        )
        return train, val, test

    def summary(self) -> dict:
        train, val, test = self.split()
        def _date_range(evs):
            if not evs:
                return ("", "")
            dates = [str(e.get("scraped_at") or "")[:10] for e in evs]
            return min(dates), max(dates)
        tr_r = _date_range(train)
        va_r = _date_range(val)
        te_r = _date_range(test)
        return {
            "total":  self._n,
            "train":  {"n": len(train), "start": tr_r[0], "end": tr_r[1]},
            "val":    {"n": len(val),   "start": va_r[0], "end": va_r[1]},
            "test":   {"n": len(test),  "start": te_r[0], "end": te_r[1]},
        }


# ---------------------------------------------------------------------------
# Evaluation helpers
# ---------------------------------------------------------------------------

def _score_events(
    events:   list[dict],
    weights:  dict[str, float],
    horizon:  int,
) -> tuple[list[float], list[float]]:
    """Apply calibrated weights and return (signals, returns)."""
    from calibration import apply_calibrated_weights

    ret_key = f"fwd_ret_{horizon}d"
    sigs, rets = [], []
    for ev in events:
        ret = ev.get(ret_key)
        if ret is None or not math.isfinite(float(ret)):
            continue
        sig = apply_calibrated_weights(
            weights,
            ev.get("sentiment_label", "NEUTRAL"),
            float(ev.get("sentiment_score",   0.0)),
            float(ev.get("materiality_score", 0.0)),
            float(ev.get("novelty_score",     0.5)),
            float(ev.get("credibility_score", 0.5)),
        )
        sigs.append(sig)
        rets.append(float(ret))
    return sigs, rets


@dataclass
class EvaluationResult:
    split_name:  str
    n:           int
    ic:          float
    sharpe:      float
    hit_rate:    float
    mean_ret:    float
    red_flags:   list[str]

    def summary(self) -> str:
        lines = [
            f"  [{self.split_name.upper()}]  n={self.n}",
            f"    IC:        {self.ic:.4f}",
            f"    Sharpe:    {self.sharpe:.2f}",
            f"    Hit rate:  {self.hit_rate:.1%}",
            f"    Mean ret:  {self.mean_ret:.4f}%",
        ]
        for f in self.red_flags:
            lines.append(f"    🚨 {f}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "split":     self.split_name,
            "n":         self.n,
            "ic":        self.ic,
            "sharpe":    self.sharpe,
            "hit_rate":  self.hit_rate,
            "mean_ret":  self.mean_ret,
            "red_flags": self.red_flags,
        }


def _eval_split(events: list[dict], weights: dict, horizon: int, name: str) -> EvaluationResult:
    sigs, rets = _score_events(events, weights, horizon)
    ic       = _spearman(sigs, rets)
    sharpe   = _sharpe(rets)
    hit_rate = _hit_rate(sigs, rets)
    mean_ret = sum(rets) / len(rets) if rets else 0.0

    flags = []
    if math.isfinite(ic) and ic > 0.15:
        flags.append(f"IC={ic:.4f} > 0.15 — verify no look-ahead leakage")
    if math.isfinite(sharpe) and sharpe > 2.0:
        flags.append(f"Sharpe={sharpe:.2f} > 2.0 — check for data leakage")
    if math.isfinite(hit_rate) and hit_rate > 0.65:
        flags.append(f"Hit rate={hit_rate:.1%} > 65% — check timestamp alignment")

    return EvaluationResult(
        split_name = name,
        n          = len(sigs),
        ic         = round(ic, 4)       if math.isfinite(ic)       else 0.0,
        sharpe     = round(sharpe, 4)   if math.isfinite(sharpe)   else 0.0,
        hit_rate   = round(hit_rate, 4) if math.isfinite(hit_rate) else 0.5,
        mean_ret   = round(mean_ret, 4),
        red_flags  = flags,
    )


# ---------------------------------------------------------------------------
# Overfitting guard
# ---------------------------------------------------------------------------

class OverfittingGuard:
    """
    Enforces single-use test-set evaluation.

    Once evaluate_on_test() is called for a given experiment_id, calling it
    again raises RuntimeError.  This prevents accidental p-hacking on the
    test set.
    """

    def __init__(self, experiment_id: str, lock_dir: str = "/tmp"):
        self.experiment_id = experiment_id
        self._lock_path    = os.path.join(lock_dir, f"_oguard_{experiment_id}.lock")

    def _is_locked(self) -> bool:
        return os.path.exists(self._lock_path)

    def _lock(self, result: EvaluationResult) -> None:
        with open(self._lock_path, "w") as f:
            json.dump({
                "experiment_id": self.experiment_id,
                "evaluated_at":  datetime.now(timezone.utc).isoformat(),
                "result":        result.to_dict(),
            }, f, indent=2)

    def evaluate_on_val(
        self,
        val_events: list[dict],
        weights:    dict[str, float],
        horizon:    int = 1,
    ) -> EvaluationResult:
        """Evaluate on validation set. May be called multiple times for method selection."""
        return _eval_split(val_events, weights, horizon, "validation")

    def evaluate_on_test(
        self,
        test_events: list[dict],
        weights:     dict[str, float],
        horizon:     int = 1,
    ) -> EvaluationResult:
        """
        ONE-SHOT evaluation on the held-out test set.
        Raises RuntimeError if called more than once for the same experiment_id.
        """
        if self._is_locked():
            raise RuntimeError(
                f"Test set for experiment '{self.experiment_id}' has already been evaluated. "
                "Adjust calibration only on train/val, then create a new experiment_id."
            )
        result = _eval_split(test_events, weights, horizon, "test")
        self._lock(result)
        logger.info(
            "Test evaluation complete for '%s': IC=%.4f Sharpe=%.2f",
            self.experiment_id, result.ic, result.sharpe,
        )
        return result

    def full_evaluation(
        self,
        train_events: list[dict],
        val_events:   list[dict],
        test_events:  list[dict],
        weights:      dict[str, float],
        horizon:      int = 1,
    ) -> dict:
        """
        Evaluate on all three splits and print a summary.
        Test is only evaluated once; subsequent calls raise RuntimeError.
        """
        tr_res  = _eval_split(train_events, weights, horizon, "train")
        val_res = self.evaluate_on_val(val_events, weights, horizon)
        te_res  = self.evaluate_on_test(test_events, weights, horizon)

        print(f"\n{'═'*50}")
        print(f"  EXPERIMENT: {self.experiment_id}")
        print(f"{'═'*50}")
        for res in [tr_res, val_res, te_res]:
            print(res.summary())

        # Overfitting check: train IC >> test IC is a red flag
        if math.isfinite(tr_res.ic) and math.isfinite(te_res.ic):
            decay = tr_res.ic - te_res.ic
            if decay > 0.03:
                logger.warning(
                    "Overfitting signal: train IC=%.4f vs test IC=%.4f (gap=%.4f)",
                    tr_res.ic, te_res.ic, decay,
                )
                print(f"\n  ⚠  Overfitting: train IC ({tr_res.ic:.4f}) >> test IC ({te_res.ic:.4f})")
            else:
                print(f"\n  ✓  No major overfitting (IC gap = {decay:.4f})")

        return {
            "train":      tr_res.to_dict(),
            "validation": val_res.to_dict(),
            "test":       te_res.to_dict(),
        }
