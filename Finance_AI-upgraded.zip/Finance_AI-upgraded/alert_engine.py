"""
alert_engine.py — alert rules, dedup, and multi-channel delivery.

Rules return AlertPayload | None.
dispatch_alerts() persists every alert to alert_log then delivers via
webhook and/or SMTP. Deduplication is enforced at the DB level
(UNIQUE on type+domain+hour) so the same condition never fires twice
in the same hour.
"""
from __future__ import annotations
import json
import logging
import smtplib
import statistics
from dataclasses import dataclass, field
from datetime import datetime, timezone
from email.mime.text import MIMEText
from typing import Optional
from uuid import UUID

import httpx
from asyncpg.pool import Pool

from config import settings

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Payload
# ---------------------------------------------------------------------------

@dataclass
class AlertPayload:
    alert_type:    str
    severity:      str          # CRITICAL | HIGH | MEDIUM
    source_domain: str
    headline:      str
    detail:        str
    fired_at:      datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def to_dict(self) -> dict:
        return {
            "alert_type":    self.alert_type,
            "severity":      self.severity,
            "source_domain": self.source_domain,
            "headline":      self.headline,
            "detail":        self.detail,
            "fired_at":      self.fired_at.isoformat(),
        }


# ---------------------------------------------------------------------------
# Rules
# ---------------------------------------------------------------------------

def rule_narrative_spike(
    current: int,
    history: list[int],
    domain: str,
) -> Optional[AlertPayload]:
    """3-sigma spike detection on story volume."""
    if len(history) < 3:
        return None
    mean  = statistics.mean(history)
    stdev = statistics.stdev(history) if len(history) > 1 else 0.0
    threshold = mean + 3 * stdev
    if stdev > 0 and current > threshold:
        return AlertPayload(
            alert_type="NARRATIVE_SPIKE",
            severity="HIGH",
            source_domain=domain,
            headline=f"Story volume spike on {domain}",
            detail=f"current={current}, mean={mean:.1f}, 3σ threshold={threshold:.1f}",
        )
    return None


def rule_sentiment_shift(
    current: float,
    previous: Optional[float],
    domain: str,
) -> Optional[AlertPayload]:
    """Significant sentiment reversal between pipeline runs."""
    if previous is None:
        return None
    delta = abs(current - previous)
    if delta > 0.4:
        return AlertPayload(
            alert_type="SENTIMENT_SHIFT",
            severity="CRITICAL" if delta > 0.65 else "HIGH",
            source_domain=domain,
            headline=f"Sentiment shift on {domain}",
            detail=f"Δ={delta:.2f} ({previous:.2f} → {current:.2f})",
        )
    return None


def rule_source_dead(domain: str) -> AlertPayload:
    return AlertPayload(
        alert_type="SOURCE_DEAD",
        severity="MEDIUM",
        source_domain=domain,
        headline=f"Source unresponsive: {domain}",
        detail=f"Exceeded {settings.dead_source_threshold} consecutive failures",
    )


def rule_high_propaganda(score: float, domain: str) -> Optional[AlertPayload]:
    if score > 0.75:
        return AlertPayload(
            alert_type="HIGH_PROPAGANDA",
            severity="CRITICAL",
            source_domain=domain,
            headline=f"High propaganda score on {domain}",
            detail=f"score={score:.2f}",
        )
    return None


def rule_critical_materiality(tier: str, headline: str, domain: str) -> Optional[AlertPayload]:
    if tier == "CRITICAL":
        return AlertPayload(
            alert_type="CRITICAL_EVENT",
            severity="CRITICAL",
            source_domain=domain,
            headline=f"Critical-tier event: {headline[:120]}",
            detail=f"Materiality tier=CRITICAL on {domain}",
        )
    return None


def evaluate_alert_rules(row: dict) -> list[AlertPayload]:
    """Convenience: run all rules against a single event row dict."""
    alerts = []
    p = rule_high_propaganda(row.get("propaganda_score", 0.0), row.get("source_domain", ""))
    if p:
        alerts.append(p)
    m = rule_critical_materiality(
        row.get("materiality_tier", "LOW"),
        row.get("summary", "")[:120],
        row.get("source_domain", ""),
    )
    if m:
        alerts.append(m)
    return alerts


# ---------------------------------------------------------------------------
# Delivery channels
# ---------------------------------------------------------------------------

async def _deliver_webhook(payload: AlertPayload, url: str) -> bool:
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.post(url, json=payload.to_dict())
            return r.status_code < 300
    except Exception as exc:
        logger.error("Webhook delivery failed: %s", exc)
        return False


def _deliver_email(payload: AlertPayload) -> bool:
    if not all([settings.alert_smtp_host, settings.alert_smtp_user,
                settings.alert_smtp_password, settings.alert_smtp_from,
                settings.alert_smtp_to]):
        return False
    try:
        body = f"{payload.headline}\n\n{payload.detail}\n\nFired at: {payload.fired_at}"
        msg = MIMEText(body)
        msg["Subject"] = f"[{payload.severity}] {payload.alert_type} — {payload.source_domain}"
        msg["From"]    = settings.alert_smtp_from
        msg["To"]      = settings.alert_smtp_to
        with smtplib.SMTP_SSL(settings.alert_smtp_host, settings.alert_smtp_port) as s:
            s.login(settings.alert_smtp_user, settings.alert_smtp_password)
            s.send_message(msg)
        return True
    except Exception as exc:
        logger.error("Email delivery failed: %s", exc)
        return False


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_TIER_ORDER = {"CRITICAL": 3, "HIGH": 2, "MEDIUM": 1, "LOW": 0}

async def dispatch_alerts(
    pool: Pool,
    alerts: list[AlertPayload],
    webhook_url: Optional[str] = None,
) -> None:
    """
    Persist each alert to alert_log (with DB-level hourly dedup),
    then deliver via webhook → email in that order.
    The min alert tier from settings gates what gets delivered.
    """
    min_tier = _TIER_ORDER.get(settings.materiality_min_alert_tier, 1)

    for a in alerts:
        if _TIER_ORDER.get(a.severity, 0) < min_tier:
            continue

        # Persist first — no alert is ever lost even if delivery fails
        try:
            row = await pool.fetchrow("""
                INSERT INTO alert_log (alert_type, severity, source_domain, payload)
                VALUES ($1, $2, $3, $4::jsonb)
                ON CONFLICT (alert_type, source_domain,
                             date_trunc('hour', fired_at)) DO NOTHING
                RETURNING alert_id
            """, a.alert_type, a.severity, a.source_domain,
                json.dumps({"headline": a.headline, "detail": a.detail}))
        except Exception as exc:
            logger.error("Failed to persist alert: %s", exc)
            continue

        if row is None:
            logger.debug("Alert deduped (already fired this hour): %s / %s",
                         a.alert_type, a.source_domain)
            continue

        delivered = False
        error_msg = None

        wh = webhook_url or settings.alert_webhook_url
        if wh:
            delivered = await _deliver_webhook(a, wh)

        if not delivered:
            import asyncio
            loop = asyncio.get_running_loop()
            delivered = await loop.run_in_executor(None, _deliver_email, a)

        if not delivered:
            error_msg = "All delivery channels failed"
            logger.warning("Alert not delivered: %s / %s", a.alert_type, a.source_domain)

        try:
            await pool.execute("""
                UPDATE alert_log SET delivered=$1, delivery_error=$2
                WHERE alert_id=$3
            """, delivered, error_msg, row["alert_id"])
        except Exception:
            pass
