"""
scaling_framework.py — #8 Unified Scaling & Normalisation Framework.

Every engine in the platform normalises data internally, creating
inconsistent scales that make cross-module comparisons unreliable.
This module provides a single, versioned, tested scaling implementation.

Methods
-------
  minmax(x, lo, hi)          → [0, 1]  absolute bounds
  zscore(x, mu, sigma)       → N(0,1)  standardised
  robust(x, med, iqr)        → centred on median, scaled by IQR
  ewma(series, alpha)        → exponentially weighted moving average
  rolling_zscore(series, w)  → z-score relative to rolling window
  clamp(x, lo, hi)           → clip to bounds

RollingScaler
-------------
  A stateful scaler that updates its parameters (mean, std, min, max)
  incrementally from a stream of observations.  Thread-safe via a lock.

Usage
-----
    from scaling_framework import minmax, zscore, robust, ewma, RollingScaler

    # One-shot scaling
    score = minmax(raw, lo=0, hi=100)
    z     = zscore(raw, mu=0.5, sigma=0.1)

    # Streaming / stateful
    scaler = RollingScaler(window=60, method='zscore')
    scaler.update(new_value)
    normalised = scaler.transform(new_value)
    stability  = scaler.stability_score()  # [0,1]; 1 = very stable params
"""
from __future__ import annotations

import math
import threading
from collections import deque
from typing import Literal, Optional

import numpy as np


# ---------------------------------------------------------------------------
# Stateless helpers
# ---------------------------------------------------------------------------

def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def minmax(x: float, lo: float, hi: float, out_lo: float = 0.0, out_hi: float = 1.0) -> float:
    """Linear interpolation from [lo, hi] → [out_lo, out_hi]. Clips at bounds."""
    if hi == lo:
        return (out_lo + out_hi) / 2.0
    return clamp(out_lo + (x - lo) / (hi - lo) * (out_hi - out_lo), out_lo, out_hi)


def zscore(x: float, mu: float, sigma: float, clip: float = 3.0) -> float:
    """Z-score normalisation, clipped to [-clip, clip]."""
    if sigma == 0.0:
        return 0.0
    return clamp((x - mu) / sigma, -clip, clip)


def robust(x: float, median: float, iqr: float, scale: float = 1.35) -> float:
    """
    Robust scaling using median and inter-quartile range.
    Equivalent to sklearn RobustScaler.
    scale=1.35 makes IQR-scaled values ~ comparable to z-scores for Normal data.
    """
    denom = iqr * scale
    if denom == 0.0:
        return 0.0
    return (x - median) / denom


def ewma(series: list[float], alpha: float = 0.1) -> list[float]:
    """
    Exponentially weighted moving average.
    alpha closer to 1 → more responsive; closer to 0 → smoother.
    """
    if not series:
        return []
    out = [series[0]]
    for v in series[1:]:
        out.append(alpha * v + (1.0 - alpha) * out[-1])
    return out


def ewma_last(series: list[float], alpha: float = 0.1) -> Optional[float]:
    """Return only the last EWMA value (efficient for append-then-query)."""
    if not series:
        return None
    val = series[0]
    for v in series[1:]:
        val = alpha * v + (1.0 - alpha) * val
    return val


def rolling_zscore(
    series: list[float],
    window: int = 20,
    clip:   float = 3.0,
) -> list[float]:
    """
    Per-observation z-score relative to the trailing window.
    Returns NaN for the first (window-1) observations.
    """
    arr = np.array(series, dtype=float)
    out = np.full_like(arr, np.nan)
    for i in range(window, len(arr) + 1):
        w   = arr[i - window: i]
        mu  = np.nanmean(w[:-1])    # exclude current observation from mean
        sig = np.nanstd(w[:-1])
        if sig > 0:
            out[i - 1] = np.clip((arr[i - 1] - mu) / sig, -clip, clip)
        else:
            out[i - 1] = 0.0
    return out.tolist()


def percentile_rank(x: float, history: list[float]) -> float:
    """
    Rank x within history as a percentile [0, 1].
    Equivalent to the empirical CDF evaluated at x.
    """
    if not history:
        return 0.5
    below = sum(1 for v in history if v < x)
    return below / len(history)


# ---------------------------------------------------------------------------
# Stateful rolling scaler
# ---------------------------------------------------------------------------

ScalingMethod = Literal["minmax", "zscore", "robust", "ewma", "percentile"]


class RollingScaler:
    """
    Streaming / stateful scaler that maintains rolling statistics.

    Parameters
    ----------
    window  : number of observations to keep in the rolling window
    method  : scaling method to apply in transform()
    alpha   : EWMA decay factor (used when method='ewma')

    Thread-safe via an internal lock.
    """

    def __init__(
        self,
        window: int = 60,
        method: ScalingMethod = "zscore",
        alpha:  float = 0.1,
    ) -> None:
        self._window   = window
        self._method   = method
        self._alpha    = alpha
        self._buf:     deque[float] = deque(maxlen=window)
        self._ewma_val: Optional[float] = None
        self._lock     = threading.Lock()

        # Stability tracking: track variance of the last N parameter estimates
        self._param_history: deque[float] = deque(maxlen=20)

    # ------------------------------------------------------------------
    # Update (ingest a new observation)
    # ------------------------------------------------------------------

    def update(self, x: float) -> None:
        with self._lock:
            if math.isfinite(x):
                self._buf.append(x)
                # Update EWMA state
                if self._ewma_val is None:
                    self._ewma_val = x
                else:
                    self._ewma_val = self._alpha * x + (1.0 - self._alpha) * self._ewma_val
                # Track the "location" parameter for stability
                self._param_history.append(self._location())

    def _location(self) -> float:
        if not self._buf:
            return 0.0
        arr = np.array(self._buf)
        if self._method in ("zscore", "minmax"):
            return float(np.mean(arr))
        elif self._method == "robust":
            return float(np.median(arr))
        return float(np.mean(arr))

    # ------------------------------------------------------------------
    # Transform
    # ------------------------------------------------------------------

    def transform(self, x: float) -> float:
        """Scale x using the current rolling statistics."""
        with self._lock:
            if len(self._buf) < 2:
                return 0.0
            arr = np.array(self._buf)

            if self._method == "zscore":
                mu  = float(np.mean(arr))
                sig = float(np.std(arr))
                return zscore(x, mu, sig)

            elif self._method == "minmax":
                return minmax(x, float(arr.min()), float(arr.max()))

            elif self._method == "robust":
                med = float(np.median(arr))
                q75, q25 = np.percentile(arr, [75, 25])
                return robust(x, med, q75 - q25)

            elif self._method == "ewma":
                if self._ewma_val is None:
                    return 0.0
                # Return deviation from EWMA, normalised by rolling std
                sig = float(np.std(arr)) or 1.0
                return zscore(x, self._ewma_val, sig)

            elif self._method == "percentile":
                return percentile_rank(x, list(arr))

            return x

    def update_and_transform(self, x: float) -> float:
        """Convenience: update + transform in one call."""
        self.update(x)
        return self.transform(x)

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    def stability_score(self) -> float:
        """
        [0, 1] — how stable the scaler's parameters have been recently.
        1 = very stable; 0 = highly volatile (parameters shifting rapidly).
        """
        if len(self._param_history) < 3:
            return 0.5   # not enough history
        ph  = np.array(self._param_history)
        cv  = np.std(ph) / (abs(np.mean(ph)) + 1e-9)  # coefficient of variation
        return float(clamp(1.0 - min(cv, 1.0)))

    def stats(self) -> dict:
        """Return current rolling statistics."""
        with self._lock:
            if not self._buf:
                return {"n": 0}
            arr = np.array(self._buf)
            q25, q50, q75 = np.percentile(arr, [25, 50, 75])
            return {
                "n":       len(arr),
                "mean":    round(float(np.mean(arr)),   4),
                "std":     round(float(np.std(arr)),    4),
                "min":     round(float(arr.min()),      4),
                "max":     round(float(arr.max()),      4),
                "q25":     round(float(q25),            4),
                "q50":     round(float(q50),            4),
                "q75":     round(float(q75),            4),
                "ewma":    round(self._ewma_val or 0.0, 4),
                "stability": round(self.stability_score(), 4),
            }

    @property
    def n(self) -> int:
        return len(self._buf)

    @property
    def is_warm(self) -> bool:
        """True once the buffer has enough data to produce reliable estimates."""
        return len(self._buf) >= max(10, self._window // 3)


# ---------------------------------------------------------------------------
# ScalerRegistry — module-level named scalers shared across engines
# ---------------------------------------------------------------------------

class ScalerRegistry:
    """
    A global registry of named RollingScaler instances.
    Allows different modules to share and reuse scalers without coupling.

    Usage
    -----
        registry = get_registry()
        registry.register("crowding_score", window=60, method="zscore")
        z = registry.update_and_transform("crowding_score", raw_value)
    """

    def __init__(self) -> None:
        self._scalers: dict[str, RollingScaler] = {}
        self._lock    = threading.Lock()

    def register(
        self,
        name:   str,
        window: int = 60,
        method: ScalingMethod = "zscore",
        alpha:  float = 0.1,
    ) -> RollingScaler:
        with self._lock:
            if name not in self._scalers:
                self._scalers[name] = RollingScaler(window=window, method=method, alpha=alpha)
            return self._scalers[name]

    def get(self, name: str) -> Optional[RollingScaler]:
        return self._scalers.get(name)

    def update_and_transform(self, name: str, x: float) -> float:
        scaler = self._scalers.get(name)
        if scaler is None:
            raise KeyError(f"Scaler '{name}' not registered")
        return scaler.update_and_transform(x)

    def stability_report(self) -> dict[str, float]:
        return {name: s.stability_score() for name, s in self._scalers.items()}

    def stats_report(self) -> dict[str, dict]:
        return {name: s.stats() for name, s in self._scalers.items()}


_registry: Optional[ScalerRegistry] = None


def get_registry() -> ScalerRegistry:
    global _registry
    if _registry is None:
        _registry = ScalerRegistry()
    return _registry
