"""
data_reliability.py — #7 Data Reliability Layer.

Every data-fetching engine assumes inputs are correct. In practice:
  - yfinance returns NaN-filled DataFrames during market closures
  - FRED API can return stale cached series
  - Options chains can have zero open interest (empty expiries)
  - Network timeouts silently return None
  - Extreme outliers can be data errors, not real moves

This module wraps all fetched data with:
  1. Missing-data detection    — flag missing fields, compute completeness ratio
  2. Stale-data detection      — compare fetch timestamp to staleness thresholds
  3. Anomaly detection         — z-score and IQR outlier detection
  4. Fallback source registry  — define ordered fallback chains per data series
  5. DataQualityReport         — structured output consumed by governance engine

Architecture
------------
Every engine wraps its raw fetch result with:

    report = DataQualityChecker.check(data, schema, context="liquidity_engine")
    if report.quality < 0.5:
        logger.warning("Low quality data: %s", report.issues)
        # use fallback or degrade gracefully

Usage
-----
    from data_reliability import DataQualityChecker, DataQualityReport, register_fallback

    # Check a dict of fetched values
    checker = DataQualityChecker()
    report  = checker.check(
        data    = {"vix": 18.5, "spread": None, "vol_10d": 0.15},
        schema  = {"vix": float, "spread": float, "vol_10d": float},
        context = "liquidity_engine",
    )
    print(report.quality, report.issues, report.usable_fields)
"""
from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any, Callable, Optional, Type

import numpy as np

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data Quality Report
# ---------------------------------------------------------------------------

@dataclass
class DataQualityReport:
    context:        str
    quality:        float           # [0, 1]; 1 = perfect, 0 = completely unusable
    completeness:   float           # fraction of non-None fields
    freshness:      float           # [0, 1]; 1 = fresh, 0 = stale/expired
    anomaly_score:  float           # [0, 1]; 1 = severe anomalies present
    usable_fields:  list[str]       # fields that passed all checks
    missing_fields: list[str]       # None or NaN
    stale_fields:   list[str]       # older than staleness threshold
    anomaly_fields: list[str]       # flagged as outliers
    issues:         list[str]       # human-readable issue descriptions
    checked_at:     datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def is_usable(self) -> bool:
        return self.quality >= 0.4 and self.completeness >= 0.3

    @property
    def degraded(self) -> bool:
        return 0.3 <= self.quality < 0.7

    def summary(self) -> str:
        return (
            f"DataQuality[{self.context}]: quality={self.quality:.2f}  "
            f"complete={self.completeness:.2f}  fresh={self.freshness:.2f}  "
            f"anomaly={self.anomaly_score:.2f}  issues={self.issues}"
        )


# ---------------------------------------------------------------------------
# Anomaly detection helpers
# ---------------------------------------------------------------------------

def _is_anomaly_zscore(
    value:   float,
    history: list[float],
    threshold: float = 3.5,
) -> bool:
    if len(history) < 5:
        return False
    arr = np.array(history)
    mu  = np.nanmean(arr)
    sig = np.nanstd(arr)
    if sig == 0:
        return False
    return abs((value - mu) / sig) > threshold


def _is_anomaly_iqr(
    value:   float,
    history: list[float],
    k:       float = 3.0,
) -> bool:
    if len(history) < 5:
        return False
    arr = np.array(history)
    q25, q75 = np.percentile(arr, [25, 75])
    iqr = q75 - q25
    if iqr == 0:
        return False
    return (value < q25 - k * iqr) or (value > q75 + k * iqr)


# ---------------------------------------------------------------------------
# Fallback registry
# ---------------------------------------------------------------------------

# Maps (context, field_name) → ordered list of fallback callables
_fallback_registry: dict[tuple[str, str], list[Callable]] = {}


def register_fallback(
    context:    str,
    field:      str,
    *fallbacks: Callable,
) -> None:
    """
    Register one or more fallback fetch callables for a (context, field) pair.
    They are tried in order; the first non-None result is used.

    Example
    -------
        register_fallback("liquidity", "credit_spread_hy",
            lambda: fetch_fred("BAMLH0A0HYM2"),
            lambda: fetch_fred("BAMLH0A0HYM2EY"),  # backup series
        )
    """
    _fallback_registry[(context, field)] = list(fallbacks)


def try_fallback(context: str, field: str) -> Optional[float]:
    """Attempt fallback fetch for a (context, field) pair. Returns None if all fail."""
    fallbacks = _fallback_registry.get((context, field), [])
    for fn in fallbacks:
        try:
            result = fn()
            if result is not None and math.isfinite(float(result)):
                logger.debug("Fallback succeeded for %s.%s", context, field)
                return float(result)
        except Exception as exc:
            logger.debug("Fallback failed for %s.%s: %s", context, field, exc)
    return None


# ---------------------------------------------------------------------------
# Per-field history store for anomaly detection
# ---------------------------------------------------------------------------

_field_history: dict[tuple[str, str], list[float]] = {}
_MAX_HISTORY = 200


def _record_history(context: str, field: str, value: float) -> None:
    key = (context, field)
    if key not in _field_history:
        _field_history[key] = []
    _field_history[key].append(value)
    if len(_field_history[key]) > _MAX_HISTORY:
        _field_history[key] = _field_history[key][-_MAX_HISTORY:]


def _get_history(context: str, field: str) -> list[float]:
    return _field_history.get((context, field), [])


# ---------------------------------------------------------------------------
# DataQualityChecker
# ---------------------------------------------------------------------------

class DataQualityChecker:
    """
    Checks a dict of fetched values against a schema, detecting:
      - missing/None fields
      - NaN or Inf values
      - values outside plausible bounds
      - anomalous values relative to historical distribution
      - stale values (if timestamps provided)

    Parameters
    ----------
    bounds          : optional dict of field → (lo, hi) plausible bounds
    staleness_ttl   : max seconds before a value is considered stale
    anomaly_z       : z-score threshold for anomaly flagging
    use_iqr         : also run IQR outlier detection (slower)
    """

    def __init__(
        self,
        bounds:         Optional[dict[str, tuple[float, float]]] = None,
        staleness_ttl:  float = 3600.0,
        anomaly_z:      float = 3.5,
        use_iqr:        bool  = True,
    ) -> None:
        self._bounds       = bounds or {}
        self._staleness_ttl = staleness_ttl
        self._anomaly_z    = anomaly_z
        self._use_iqr      = use_iqr

    def check(
        self,
        data:       dict[str, Any],
        schema:     dict[str, Type],             # field → expected type
        context:    str = "unknown",
        timestamps: Optional[dict[str, datetime]] = None,  # field → fetch time
    ) -> DataQualityReport:
        """
        Check data quality.

        data       : the fetched values dict
        schema     : expected fields and their types
        context    : calling engine name (for logging + fallback lookup)
        timestamps : optional per-field fetch times (for staleness)
        """
        timestamps = timestamps or {}
        now        = datetime.now(timezone.utc)

        missing_fields:  list[str] = []
        stale_fields:    list[str] = []
        anomaly_fields:  list[str] = []
        usable_fields:   list[str] = []
        issues:          list[str] = []

        total_fields = len(schema)

        for field_name, expected_type in schema.items():
            value = data.get(field_name)

            # 1. Missing / None / NaN / Inf check
            if value is None:
                # Attempt fallback
                fallback = try_fallback(context, field_name)
                if fallback is not None:
                    data[field_name] = fallback
                    value = fallback
                    issues.append(f"{field_name}: used_fallback")
                else:
                    missing_fields.append(field_name)
                    continue

            # Check for NaN/Inf
            if expected_type in (float, int):
                try:
                    fv = float(value)
                    if not math.isfinite(fv):
                        missing_fields.append(field_name)
                        issues.append(f"{field_name}: non_finite({fv})")
                        continue
                    value = fv
                except (TypeError, ValueError):
                    missing_fields.append(field_name)
                    issues.append(f"{field_name}: type_error")
                    continue

            # 2. Bounds check
            if field_name in self._bounds and expected_type in (float, int):
                lo, hi = self._bounds[field_name]
                if not (lo <= float(value) <= hi):
                    issues.append(f"{field_name}: out_of_bounds({value:.4g} not in [{lo},{hi}])")
                    # Don't mark as missing — bounds violations can be real; just warn

            # 3. Staleness check
            if field_name in timestamps:
                age = (now - timestamps[field_name]).total_seconds()
                if age > self._staleness_ttl:
                    stale_fields.append(field_name)
                    issues.append(f"{field_name}: stale({age:.0f}s > {self._staleness_ttl:.0f}s)")

            # 4. Anomaly detection (numeric fields with history)
            if expected_type in (float, int) and isinstance(value, (int, float)):
                history = _get_history(context, field_name)
                is_anom = _is_anomaly_zscore(float(value), history, self._anomaly_z)
                if not is_anom and self._use_iqr:
                    is_anom = _is_anomaly_iqr(float(value), history)
                if is_anom:
                    anomaly_fields.append(field_name)
                    issues.append(f"{field_name}: anomaly({value:.4g})")
                # Record to history (even anomalous values — they're real)
                _record_history(context, field_name, float(value))

            usable_fields.append(field_name)

        # ── Compute composite quality score ──────────────────────────────────
        completeness = len(usable_fields) / max(total_fields, 1)

        # Freshness: penalise stale fields
        freshness = 1.0 - (len(stale_fields) / max(total_fields, 1)) * 0.5

        # Anomaly: penalise anomalous fields
        anomaly_score = len(anomaly_fields) / max(total_fields, 1)

        # Quality: weighted combination
        quality = (
            0.50 * completeness
          + 0.30 * freshness
          + 0.20 * (1.0 - anomaly_score)
        )
        quality = max(0.0, min(1.0, quality))

        report = DataQualityReport(
            context        = context,
            quality        = round(quality,        4),
            completeness   = round(completeness,   4),
            freshness      = round(freshness,      4),
            anomaly_score  = round(anomaly_score,  4),
            usable_fields  = usable_fields,
            missing_fields = missing_fields,
            stale_fields   = stale_fields,
            anomaly_fields = anomaly_fields,
            issues         = issues,
        )

        if not report.is_usable:
            logger.warning("Low-quality data in %s: %s", context, report.summary())

        return report


# ---------------------------------------------------------------------------
# DataReliabilityGuard — wraps an async data-fetch coroutine
# ---------------------------------------------------------------------------

class DataReliabilityGuard:
    """
    Decorator / wrapper that adds quality checking to any async fetch function.

    Returns (data, report) tuple. If quality is below `min_quality`,
    optionally raises DataQualityError or returns (None, report) depending
    on `raise_on_low_quality`.

    Example
    -------
        guard = DataReliabilityGuard(min_quality=0.4, context="positioning")

        @guard.wrap
        async def fetch_short_interest(ticker):
            return await _raw_fetch(ticker)

        data, report = await fetch_short_interest("AAPL")
    """

    def __init__(
        self,
        checker:              Optional[DataQualityChecker] = None,
        min_quality:          float = 0.35,
        context:              str   = "unknown",
        raise_on_low_quality: bool  = False,
    ) -> None:
        self._checker   = checker or DataQualityChecker()
        self._min_q     = min_quality
        self._context   = context
        self._raise     = raise_on_low_quality

    def evaluate(
        self,
        data:      dict,
        schema:    dict,
        timestamps: Optional[dict] = None,
    ) -> DataQualityReport:
        return self._checker.check(data, schema, context=self._context, timestamps=timestamps)


class DataQualityError(RuntimeError):
    def __init__(self, report: DataQualityReport) -> None:
        super().__init__(f"Data quality too low: {report.summary()}")
        self.report = report
