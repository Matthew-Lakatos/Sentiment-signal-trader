"""
feature_attribution_dashboard.py — #19 Feature Attribution Dashboard.

Streamlit dashboard showing IC contribution, Sharpe contribution,
feature drift, stability, and interaction effects per signal component.

Run standalone:
    streamlit run feature_attribution_dashboard.py

Or mount alongside the main dashboard.py under a multi-page app.
"""
import asyncio
import json
import os
from datetime import datetime, timezone, timedelta
from typing import Optional

import numpy as np
import pandas as pd
import streamlit as st

st.set_page_config(
    page_title="Signal Attribution",
    page_icon="📊",
    layout="wide",
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

FEATURES = [
    "sentiment_score", "materiality_score", "novelty_score",
    "credibility_score", "surprise_score", "event_type_weight",
    "time_decay_multiplier", "market_regime_multiplier",
    "factor_neutral_score", "cs_percentile",
]

def _load_events_from_db(pool, limit: int = 2000) -> pd.DataFrame:
    """Pull recent events with signal scores from DB."""
    try:
        import asyncpg
        async def _fetch():
            rows = await pool.fetch(f"""
                SELECT
                    created_at, target_entity, signal_score, signal_tier,
                    sentiment_score, materiality_score, novelty_score,
                    credibility_score, surprise_score, event_type_weight,
                    time_decay_multiplier, market_regime_multiplier,
                    factor_neutral_score, cs_percentile,
                    realised_return_1d, realised_return_5d
                FROM scraped_events
                WHERE signal_score IS NOT NULL
                ORDER BY created_at DESC
                LIMIT {limit}
            """)
            return [dict(r) for r in rows]
        return pd.DataFrame(asyncio.get_event_loop().run_until_complete(_fetch()))
    except Exception:
        return _synthetic_data()


def _synthetic_data(n: int = 500) -> pd.DataFrame:
    """Generate realistic synthetic data for demo when DB unavailable."""
    rng = np.random.default_rng(42)
    now = datetime.now(timezone.utc)
    dates = [now - timedelta(hours=i * 2) for i in range(n)]

    true_weights = {
        "sentiment_score": 0.35, "materiality_score": 0.25,
        "novelty_score": 0.15, "credibility_score": 0.10,
        "surprise_score": 0.10, "event_type_weight": 0.05,
    }
    data = {"created_at": dates}
    feature_vals = {}
    for feat in FEATURES:
        v = rng.normal(0, 0.3, n)
        v = np.clip(v, -1, 1)
        data[feat] = v
        feature_vals[feat] = v

    # Synthetic signal and realised returns with noise
    signal = sum(true_weights.get(f, 0.02) * feature_vals[f] for f in FEATURES)
    signal = np.clip(signal + rng.normal(0, 0.05, n), -1, 1)
    data["signal_score"]        = signal
    data["signal_tier"]         = np.where(np.abs(signal) > 0.6, "A",
                                  np.where(np.abs(signal) > 0.4, "B", "C"))
    data["realised_return_1d"]  = signal * 0.4 + rng.normal(0, 0.02, n)
    data["realised_return_5d"]  = signal * 0.6 + rng.normal(0, 0.03, n)
    data["target_entity"]       = rng.choice(
        ["AAPL","MSFT","NVDA","GOOGL","META","TSLA","AMZN","JPM","GS","BAC"], n
    )
    return pd.DataFrame(data)


def _ic(predictions: np.ndarray, realisations: np.ndarray) -> float:
    """Spearman rank IC."""
    from scipy.stats import spearmanr
    mask = np.isfinite(predictions) & np.isfinite(realisations)
    if mask.sum() < 10:
        return 0.0
    rho, _ = spearmanr(predictions[mask], realisations[mask])
    return round(float(rho), 4)


def _rolling_ic(df: pd.DataFrame, feature: str, target: str, window: int = 50) -> pd.Series:
    """Rolling IC of a feature vs realised return."""
    from scipy.stats import spearmanr
    ics = []
    dates = []
    for i in range(window, len(df)):
        w = df.iloc[i - window: i]
        mask = w[feature].notna() & w[target].notna()
        if mask.sum() < 10:
            ics.append(np.nan)
        else:
            rho, _ = spearmanr(w.loc[mask, feature], w.loc[mask, target])
            ics.append(float(rho))
        dates.append(df.iloc[i]["created_at"])
    return pd.Series(ics, index=dates)


# ---------------------------------------------------------------------------
# Dashboard layout
# ---------------------------------------------------------------------------

st.title("📊 Signal Feature Attribution Dashboard")
st.markdown(
    "IC contribution · Sharpe contribution · Drift · Stability · Interactions  \n"
    "Answers: *which components are genuinely driving alpha right now?*"
)

# ── Data source ──────────────────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Settings")
    use_synthetic = st.checkbox("Use synthetic data (no DB)", value=True)
    horizon = st.selectbox("Return horizon", ["1d", "5d"], index=0)
    rolling_window = st.slider("Rolling IC window (events)", 20, 200, 60)
    ic_threshold   = st.slider("IC significance threshold", 0.01, 0.15, 0.04)
    show_interactions = st.checkbox("Show feature interactions", value=True)

target_col = f"realised_return_{horizon}"

if use_synthetic:
    df = _synthetic_data(800)
    st.info("ℹ️ Showing synthetic data. Uncheck 'Use synthetic data' to connect to DB.")
else:
    with st.spinner("Loading events from database..."):
        df = _load_events_from_db(None)
    if df.empty:
        st.warning("DB unavailable — falling back to synthetic data.")
        df = _synthetic_data(800)

df["created_at"] = pd.to_datetime(df["created_at"], utc=True)
df = df.sort_values("created_at").reset_index(drop=True)

available_features = [f for f in FEATURES if f in df.columns and df[f].notna().sum() > 20]
has_returns = target_col in df.columns and df[target_col].notna().sum() > 20

st.markdown(f"**{len(df):,} events** · **{len(available_features)} features** · "
            f"**{df['created_at'].min().date()} → {df['created_at'].max().date()}**")

# ── Tab layout ───────────────────────────────────────────────────────────────
tab_ic, tab_sharpe, tab_drift, tab_stability, tab_interact = st.tabs([
    "📈 IC Attribution", "💰 Sharpe Attribution",
    "📉 Feature Drift", "🔒 Stability", "🔗 Interactions"
])

# ════════════════════════════════════════════════════════════════════════════
# TAB 1 — IC Attribution
# ════════════════════════════════════════════════════════════════════════════
with tab_ic:
    st.subheader(f"Information Coefficient — {horizon} horizon")

    if not has_returns:
        st.warning("No realised returns available. IC cannot be computed.")
    else:
        ics = {}
        for feat in available_features:
            pred = df[feat].values.astype(float)
            ret  = df[target_col].values.astype(float)
            ics[feat] = _ic(pred, ret)

        ic_df = pd.DataFrame({
            "Feature":     list(ics.keys()),
            "IC":          list(ics.values()),
            "IC_abs":      [abs(v) for v in ics.values()],
            "Significant": [abs(v) >= ic_threshold for v in ics.values()],
        }).sort_values("IC_abs", ascending=False)

        col1, col2 = st.columns([2, 1])
        with col1:
            st.bar_chart(
                ic_df.set_index("Feature")["IC"],
                color="#4CAF50",
                use_container_width=True,
            )
        with col2:
            st.dataframe(
                ic_df[["Feature", "IC", "Significant"]].style.format({"IC": "{:.4f}"}),
                height=300, use_container_width=True,
            )

        n_sig = ic_df["Significant"].sum()
        st.metric("Significant features", f"{n_sig}/{len(available_features)}",
                  delta=f"threshold ≥ {ic_threshold:.2f}")

        # Rolling IC for top features
        st.subheader("Rolling IC Over Time")
        top_features = ic_df.head(4)["Feature"].tolist()
        rolling_data = {}
        for feat in top_features:
            s = _rolling_ic(df, feat, target_col, window=rolling_window)
            if not s.empty:
                rolling_data[feat] = s
        if rolling_data:
            rolling_df = pd.DataFrame(rolling_data)
            st.line_chart(rolling_df, use_container_width=True)

# ════════════════════════════════════════════════════════════════════════════
# TAB 2 — Sharpe Attribution
# ════════════════════════════════════════════════════════════════════════════
with tab_sharpe:
    st.subheader(f"Sharpe Contribution — {horizon} horizon")

    if not has_returns:
        st.warning("No realised returns available.")
    else:
        sharpe_contribs = {}
        for feat in available_features:
            mask = df[feat].notna() & df[target_col].notna()
            sub  = df[mask]
            if len(sub) < 20:
                continue
            # Rank into quintiles, compute avg return per quintile
            sub = sub.copy()
            sub["quintile"] = pd.qcut(sub[feat], 5, labels=False, duplicates="drop")
            q_returns = sub.groupby("quintile")[target_col].mean()
            if len(q_returns) >= 2:
                ls_return = float(q_returns.iloc[-1] - q_returns.iloc[0])
                ls_std    = float(sub[target_col].std()) or 1e-9
                sharpe_contribs[feat] = round(ls_return / ls_std * np.sqrt(252), 4)

        if sharpe_contribs:
            sh_df = pd.DataFrame({
                "Feature": list(sharpe_contribs.keys()),
                "L/S Sharpe": list(sharpe_contribs.values()),
            }).sort_values("L/S Sharpe", ascending=False)

            st.bar_chart(sh_df.set_index("Feature")["L/S Sharpe"], use_container_width=True)

            col1, col2, col3 = st.columns(3)
            col1.metric("Best contributor", sh_df.iloc[0]["Feature"],
                        delta=f"{sh_df.iloc[0]['L/S Sharpe']:.2f}")
            col2.metric("Worst contributor", sh_df.iloc[-1]["Feature"],
                        delta=f"{sh_df.iloc[-1]['L/S Sharpe']:.2f}")
            col3.metric("Positive contributors",
                        f"{(sh_df['L/S Sharpe'] > 0).sum()}/{len(sh_df)}")

# ════════════════════════════════════════════════════════════════════════════
# TAB 3 — Feature Drift
# ════════════════════════════════════════════════════════════════════════════
with tab_drift:
    st.subheader("Feature Distribution Drift (recent vs historical)")

    split = int(len(df) * 0.7)
    df_hist   = df.iloc[:split]
    df_recent = df.iloc[split:]

    drift_data = []
    for feat in available_features:
        h_mu  = float(df_hist[feat].mean())
        r_mu  = float(df_recent[feat].mean())
        h_std = float(df_hist[feat].std()) or 1e-9
        z_drift = (r_mu - h_mu) / h_std
        drift_data.append({
            "Feature":      feat,
            "Hist μ":       round(h_mu, 4),
            "Recent μ":     round(r_mu, 4),
            "Drift (z)":    round(z_drift, 3),
            "Drifting":     abs(z_drift) > 1.5,
        })

    drift_df = pd.DataFrame(drift_data).sort_values("Drift (z)", key=abs, ascending=False)
    n_drifting = drift_df["Drifting"].sum()

    col1, col2 = st.columns([2, 1])
    with col1:
        st.bar_chart(drift_df.set_index("Feature")["Drift (z)"], use_container_width=True)
    with col2:
        st.dataframe(
            drift_df[["Feature","Hist μ","Recent μ","Drift (z)","Drifting"]]
            .style.format({"Hist μ":"{:.3f}","Recent μ":"{:.3f}","Drift (z)":"{:.3f}"}),
            height=300, use_container_width=True,
        )

    if n_drifting > 0:
        st.warning(f"⚠️ {n_drifting} feature(s) drifting significantly (|z| > 1.5)")
    else:
        st.success("✓ No significant feature drift detected")

# ════════════════════════════════════════════════════════════════════════════
# TAB 4 — Stability
# ════════════════════════════════════════════════════════════════════════════
with tab_stability:
    st.subheader("Feature Rank Stability (Spearman autocorrelation)")
    st.markdown("High autocorrelation = stable signals. Low = noisy / non-persistent.")

    stab_data = []
    for feat in available_features:
        series = df[feat].dropna().values
        if len(series) < 40:
            continue
        # Lag-1 and lag-5 Spearman autocorrelation
        from scipy.stats import spearmanr
        rho1, _ = spearmanr(series[:-1],  series[1:])
        rho5, _ = spearmanr(series[:-5],  series[5:]) if len(series) > 10 else (0, 0)
        stab_data.append({
            "Feature":     feat,
            "Autocorr(1)": round(float(rho1), 4),
            "Autocorr(5)": round(float(rho5), 4),
            "Stable":      float(rho1) > 0.30,
        })

    if stab_data:
        stab_df = pd.DataFrame(stab_data).sort_values("Autocorr(1)", ascending=False)
        st.dataframe(
            stab_df.style.format({
                "Autocorr(1)": "{:.3f}", "Autocorr(5)": "{:.3f}"
            }).background_gradient(cmap="RdYlGn", subset=["Autocorr(1)"]),
            use_container_width=True,
        )

        n_stable = stab_df["Stable"].sum()
        st.metric("Stable features (lag-1 autocorr > 0.30)",
                  f"{n_stable}/{len(stab_df)}")

# ════════════════════════════════════════════════════════════════════════════
# TAB 5 — Feature Interactions
# ════════════════════════════════════════════════════════════════════════════
with tab_interact:
    st.subheader("Feature Interaction Effects")

    if not show_interactions:
        st.info("Enable 'Show feature interactions' in the sidebar.")
    elif not has_returns:
        st.warning("No realised returns available.")
    else:
        st.markdown(
            "Interaction IC: how much does combining two features improve "
            "predictive power vs either alone?"
        )
        top4 = available_features[:5]
        interact_rows = []
        for i, f1 in enumerate(top4):
            for f2 in top4[i + 1:]:
                mask = df[f1].notna() & df[f2].notna() & df[target_col].notna()
                sub  = df[mask]
                if len(sub) < 30:
                    continue
                interact = sub[f1] * sub[f2]
                ic_f1    = _ic(sub[f1].values, sub[target_col].values)
                ic_f2    = _ic(sub[f2].values, sub[target_col].values)
                ic_int   = _ic(interact.values, sub[target_col].values)
                lift     = round(ic_int - max(abs(ic_f1), abs(ic_f2)), 4)
                interact_rows.append({
                    "Feature 1": f1, "Feature 2": f2,
                    "IC(f1)": ic_f1, "IC(f2)": ic_f2,
                    "IC(f1×f2)": ic_int, "Interaction Lift": lift,
                    "Useful": lift > 0.01,
                })

        if interact_rows:
            int_df = pd.DataFrame(interact_rows).sort_values(
                "Interaction Lift", ascending=False
            )
            st.dataframe(
                int_df.style.format({
                    "IC(f1)": "{:.3f}", "IC(f2)": "{:.3f}",
                    "IC(f1×f2)": "{:.3f}", "Interaction Lift": "{:.3f}",
                }).background_gradient(cmap="RdYlGn", subset=["Interaction Lift"]),
                use_container_width=True,
            )
            useful_n = int_df["Useful"].sum()
            if useful_n > 0:
                st.success(f"✓ {useful_n} interaction(s) provide meaningful IC lift (> 0.01)")

st.divider()
st.caption(f"Finance AI — Feature Attribution Dashboard · {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}")
