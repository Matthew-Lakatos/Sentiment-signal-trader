"""
meta_model_health.py — §18 Meta-Model Health Engine.

Split from drift_monitor.py, which conflates two concerns:
  - drift_monitor  → signal gating (is IC above the threshold to publish?)
  - meta_model_health → structural health (is the model itself decaying?)

DriftMonitor answers: "Should we publish signals right now?"
MetaModelHealth answers: "Is the model silently degrading?"

These are different questions with different audiences:
  - DriftMonitor feeds the kill-switch and throttle (operational)
  - MetaModelHealth feeds the research team and self-improvement engine (strategic)

Components
----------
1. Attribution Stability
   Are the same features contributing to alpha over time?
   Tracked as rolling Spearman rank-correlation of feature importances.

2. Calibration Decay
   Are the fitted weights drifting away from their long-run values?
   Tracked as EWMA of weight vector L2 norm change.

3. Regime Consistency
   Is the model performing consistently across regimes?
   Tracked as dispersion of IC across vol regimes.

4. Disagreement Spike
   Are the ensemble models significantly disagreeing?
   Tracked as spread of model predictions.

5. Feature Correlation Shift
   Are previously uncorrelated features becoming correlated?
   Tracked as rolling average of pairwise feature correlations.

Output (ModelHealthReport)
--------------------------
  health_score         ∈ [0, 1]   — overall model health (1 = healthy)
  degradation_severity str        — HEALTHY | DEGRADING | CRITICAL
  requires_retraining  bool
  component_scores     dict
  recommendations      list[str]
"""
from __future__ import annotations

import logging
import math
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import numpy as np

from scaling_framework import RollingScaler, ewma_last

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Thresholds
# ---------------------------------------------------------------------------

_ATTRIBUTION_STABILITY_WARN  = 0.50  # Spearman rho of importances drops below this
_CALIBRATION_DECAY_WARN      = 0.20  # L2 weight change exceeds this
_REGIME_IC_DISPERSION_WARN   = 0.08  # std of regime-ICs exceeds this
_DISAGREEMENT_WARN           = 0.15  # model prediction spread exceeds this
_RETRAINING_HEALTH_THRESHOLD = 0.45  # health below this → recommend retraining


# ---------------------------------------------------------------------------
# Health report
# ---------------------------------------------------------------------------

@dataclass
class ModelHealthReport:
    health_score:          float           # [0, 1]
    degradation_severity:  str             # HEALTHY | DEGRADING | CRITICAL
    requires_retraining:   bool
    component_scores: dict[str, float]     # sub-component breakdowns
    warnings:         list[str]
    recommendations:  list[str]
    computed_at:      datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def summary(self) -> str:
        return (
            f"ModelHealth: score={self.health_score:.3f}  "
            f"severity={self.degradation_severity}  "
            f"retrain={self.requires_retraining}  "
            f"warnings={self.warnings}"
        )


# ---------------------------------------------------------------------------
# Sub-tracker: Attribution Stability
# ---------------------------------------------------------------------------

class AttributionTracker:
    """
    Tracks whether feature importances are stable over time.
    Uses Spearman rank correlation of consecutive importance vectors.
    """

    def __init__(self, window: int = 10) -> None:
        self._history: deque[list[float]] = deque(maxlen=window)

    def update(self, importances: dict[str, float]) -> Optional[float]:
        """
        Ingest a new feature importance vector.
        Returns Spearman rho vs the previous vector (or None on first call).
        """
        vec = [importances.get(k, 0.0) for k in sorted(importances)]
        self._history.append(vec)
        if len(self._history) < 2:
            return None
        prev = list(self._history)[-2]
        if len(prev) != len(vec):
            return None
        return self._spearman(prev, vec)

    @staticmethod
    def _spearman(x: list[float], y: list[float]) -> float:
        if not x:
            return 0.0
        rx = _rank(x)
        ry = _rank(y)
        n  = len(rx)
        cov = sum((rx[i] - sum(rx)/n) * (ry[i] - sum(ry)/n) for i in range(n))
        sx  = math.sqrt(sum((v - sum(rx)/n)**2 for v in rx))
        sy  = math.sqrt(sum((v - sum(ry)/n)**2 for v in ry))
        return cov / (sx * sy) if sx * sy > 0 else 0.0

    @property
    def stability(self) -> Optional[float]:
        """Return most recent Spearman rho, or None."""
        if len(self._history) < 2:
            return None
        prev = list(self._history)[-2]
        curr = list(self._history)[-1]
        if len(prev) != len(curr):
            return None
        return self._spearman(prev, curr)


def _rank(lst: list[float]) -> list[float]:
    sorted_vals = sorted(enumerate(lst), key=lambda x: x[1])
    ranks = [0.0] * len(lst)
    for rank, (idx, _) in enumerate(sorted_vals):
        ranks[idx] = float(rank + 1)
    return ranks


# ---------------------------------------------------------------------------
# Sub-tracker: Calibration Decay
# ---------------------------------------------------------------------------

class CalibrationDecayTracker:
    """
    Tracks drift in fitted model weights.
    Measures L2 norm of weight changes from their long-run average.
    """

    def __init__(self, alpha: float = 0.1) -> None:
        self._alpha    = alpha
        self._ewma_w:  Optional[list[float]] = None
        self._changes: deque[float] = deque(maxlen=50)

    def update(self, weights: dict[str, float]) -> Optional[float]:
        """Ingest new weight vector. Returns relative L2 change."""
        w = [weights.get(k, 0.0) for k in sorted(weights)]
        if not w:
            return None

        if self._ewma_w is None:
            self._ewma_w = w
            return 0.0

        if len(w) != len(self._ewma_w):
            self._ewma_w = w
            return None

        # L2 distance from EWMA
        diff = math.sqrt(sum((a - b)**2 for a, b in zip(w, self._ewma_w)))
        norm = math.sqrt(sum(a**2 for a in self._ewma_w)) or 1.0
        rel_change = diff / norm

        # Update EWMA
        self._ewma_w = [
            self._alpha * wi + (1 - self._alpha) * ei
            for wi, ei in zip(w, self._ewma_w)
        ]
        self._changes.append(rel_change)
        return rel_change

    @property
    def recent_decay(self) -> Optional[float]:
        """Return EWMA of recent weight changes."""
        if not self._changes:
            return None
        return ewma_last(list(self._changes), alpha=0.2)


# ---------------------------------------------------------------------------
# Sub-tracker: Regime IC Consistency
# ---------------------------------------------------------------------------

class RegimeConsistencyTracker:
    """
    Tracks whether IC is consistent across market regimes.
    High IC dispersion across regimes indicates regime-specific overfitting.
    """

    def __init__(self) -> None:
        self._regime_ics: dict[str, deque[float]] = {}

    def update(self, ic: float, regime: str) -> None:
        if regime not in self._regime_ics:
            self._regime_ics[regime] = deque(maxlen=30)
        self._regime_ics[regime].append(ic)

    @property
    def ic_dispersion(self) -> Optional[float]:
        """
        Standard deviation of per-regime average ICs.
        High = model behaves very differently across regimes (unstable).
        """
        regime_means = [
            float(np.mean(list(ics)))
            for ics in self._regime_ics.values()
            if len(ics) >= 3
        ]
        if len(regime_means) < 2:
            return None
        return float(np.std(regime_means))

    @property
    def worst_regime(self) -> Optional[str]:
        avgs = {
            r: float(np.mean(list(ics)))
            for r, ics in self._regime_ics.items()
            if len(ics) >= 3
        }
        if not avgs:
            return None
        return min(avgs, key=lambda r: avgs[r])


# ---------------------------------------------------------------------------
# MetaModelHealth
# ---------------------------------------------------------------------------

class MetaModelHealth:
    """
    Tracks structural model degradation across four dimensions.

    Designed to be updated once per calibration cycle (not per event),
    and queried by the governance engine and experiment tracker.
    """

    def __init__(self) -> None:
        self._attribution  = AttributionTracker(window=15)
        self._calibration  = CalibrationDecayTracker(alpha=0.10)
        self._regime       = RegimeConsistencyTracker()
        self._disagreements: deque[float] = deque(maxlen=50)
        self._health_history: deque[float] = deque(maxlen=100)

    # ------------------------------------------------------------------
    # Ingestion
    # ------------------------------------------------------------------

    def update_attribution(self, importances: dict[str, float]) -> None:
        rho = self._attribution.update(importances)
        if rho is not None and rho < _ATTRIBUTION_STABILITY_WARN:
            logger.warning("Feature attribution unstable: Spearman rho=%.3f", rho)

    def update_weights(self, weights: dict[str, float]) -> None:
        decay = self._calibration.update(weights)
        if decay is not None and decay > _CALIBRATION_DECAY_WARN:
            logger.warning("Calibration decay detected: L2 change=%.4f", decay)

    def update_regime_ic(self, ic: float, regime: str) -> None:
        self._regime.update(ic, regime)

    def update_disagreement(self, model_predictions: dict[str, float]) -> None:
        """
        Record ensemble disagreement as std of model predictions.
        model_predictions: {model_name: predicted_score}
        """
        if len(model_predictions) < 2:
            return
        vals = list(model_predictions.values())
        spread = float(np.std(vals))
        self._disagreements.append(spread)
        if spread > _DISAGREEMENT_WARN:
            logger.warning("Model disagreement spike: spread=%.4f", spread)

    # ------------------------------------------------------------------
    # Health report
    # ------------------------------------------------------------------

    def health_report(self) -> ModelHealthReport:
        warnings:       list[str] = []
        recommendations: list[str] = []
        components:      dict[str, float] = {}

        # ── Attribution stability ────────────────────────────────────────────
        attr_stability = self._attribution.stability
        if attr_stability is None:
            attr_score = 0.7   # neutral — not enough history
        else:
            attr_score = max(0.0, min(1.0, attr_stability))
            if attr_stability < _ATTRIBUTION_STABILITY_WARN:
                warnings.append("attribution_unstable")
                recommendations.append("Investigate feature importance drift")
        components["attribution_stability"] = round(attr_score, 4)

        # ── Calibration decay ────────────────────────────────────────────────
        decay = self._calibration.recent_decay
        if decay is None:
            cal_score = 0.7
        else:
            cal_score = max(0.0, 1.0 - decay / _CALIBRATION_DECAY_WARN)
            if decay > _CALIBRATION_DECAY_WARN:
                warnings.append("calibration_decay")
                recommendations.append("Recalibrate model weights")
        components["calibration_stability"] = round(cal_score, 4)

        # ── Regime consistency ───────────────────────────────────────────────
        dispersion = self._regime.ic_dispersion
        if dispersion is None:
            regime_score = 0.7
        else:
            regime_score = max(0.0, 1.0 - dispersion / _REGIME_IC_DISPERSION_WARN)
            if dispersion > _REGIME_IC_DISPERSION_WARN:
                worst = self._regime.worst_regime
                warnings.append(f"regime_inconsistency(worst={worst})")
                recommendations.append(f"Fit regime-specific model for {worst}")
        components["regime_consistency"] = round(regime_score, 4)

        # ── Disagreement ─────────────────────────────────────────────────────
        if not self._disagreements:
            disagree_score = 0.7
        else:
            avg_spread = float(np.mean(list(self._disagreements)[-10:]))
            disagree_score = max(0.0, 1.0 - avg_spread / _DISAGREEMENT_WARN)
            if avg_spread > _DISAGREEMENT_WARN:
                warnings.append("model_disagreement_spike")
                recommendations.append("Audit ensemble model alignment")
        components["model_agreement"] = round(disagree_score, 4)

        # ── Composite health score ───────────────────────────────────────────
        health_score = (
            0.35 * attr_score
          + 0.30 * cal_score
          + 0.20 * regime_score
          + 0.15 * disagree_score
        )
        health_score = round(max(0.0, min(1.0, health_score)), 4)
        self._health_history.append(health_score)

        # Severity
        if health_score >= 0.75:
            severity = "HEALTHY"
        elif health_score >= 0.50:
            severity = "DEGRADING"
        else:
            severity = "CRITICAL"
            recommendations.insert(0, "URGENT: Full model retraining required")

        requires_retraining = health_score < _RETRAINING_HEALTH_THRESHOLD

        report = ModelHealthReport(
            health_score         = health_score,
            degradation_severity = severity,
            requires_retraining  = requires_retraining,
            component_scores     = components,
            warnings             = warnings,
            recommendations      = recommendations,
        )

        if severity != "HEALTHY":
            logger.warning("MetaModelHealth: %s", report.summary())

        return report

    @property
    def health_trend(self) -> Optional[float]:
        """
        Linear trend of recent health scores.
        Negative = declining. Positive = improving.
        """
        hist = list(self._health_history)[-20:]
        if len(hist) < 5:
            return None
        x = np.arange(len(hist), dtype=float)
        slope = float(np.polyfit(x, hist, 1)[0])
        return round(slope, 6)


# ---------------------------------------------------------------------------
# Module-level singleton
# ---------------------------------------------------------------------------

_health: Optional[MetaModelHealth] = None


def get_health() -> MetaModelHealth:
    global _health
    if _health is None:
        _health = MetaModelHealth()
    return _health
