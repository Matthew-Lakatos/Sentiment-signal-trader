"""
signal_ranker.py — composite alpha signal scoring.

Phase 1 additions
-----------------
  market_state conditioning (§9)
    - RISK_OFF regime multiplies score by settings.signal_risk_off_multiplier (0.60)
    - RISK_ON  regime multiplies score by settings.signal_risk_on_multiplier  (1.10)
    - VIX SPIKE applies an additional discount (settings.signal_vix_spike_multiplier 0.50)
    - During earnings_season, 'earnings' event type is boosted
      by settings.signal_earnings_season_earnings_boost (1.30)

  expectation surprise (§2)
    - When surprise_score is provided, it adds a signed contribution
      weighted by settings.signal_w_surprise (0.10, default)
    - A positive surprise on a positive event reinforces the signal;
      a negative surprise acts as a contrarian damper

All additions are optional keyword arguments — existing call sites that
pass only the original 8 parameters continue to work without modification.

Original formula (pre-Phase-1)
-------------------------------
    alpha = (
        w_sentiment   × |sentiment_score|  × sentiment_sign
      + w_materiality × materiality_score
      + w_novelty     × novelty_score
      + w_credibility × credibility_score
    ) × time_decay × event_type_weight

Phase 1 formula
---------------
    alpha_p1 = (
        w_sentiment   × |sentiment_score| × sentiment_sign
      + w_materiality × materiality_score
      + w_novelty     × novelty_score
      + w_credibility × credibility_score
      + w_surprise    × surprise_score         [NEW — when provided]
    ) × time_decay × event_type_weight
      × market_regime_multiplier               [NEW — from MarketState]
      × earnings_season_boost                  [NEW — calendar-aware]

Factor neutralisation and cross-sectional ranking (§11, §10) are applied
as a batch post-processing step in main.py via factor_model.neutralise_batch
and cross_section.rank_batch — they are NOT part of this function.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import TYPE_CHECKING, Optional

from config import settings
from time_decay import time_decay_multiplier

if TYPE_CHECKING:
    from market_state import MarketState

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Event-type signal multipliers
# ---------------------------------------------------------------------------

_EVENT_TYPE_WEIGHTS: dict[str, float] = {
    "earnings":       1.20,
    "macro":          1.15,
    "contract":       1.10,
    "product_launch": 1.05,
    "regulation":     1.10,
    "rumor":          0.70,
    "analysis":       0.80,
    "geopolitical":   1.10,
    "unknown":        0.90,
}

# ---------------------------------------------------------------------------
# Component weights
# ---------------------------------------------------------------------------

def _w(attr: str, default: float) -> float:
    return float(getattr(settings, attr, default))

_W_SENTIMENT   = _w("signal_w_sentiment",   0.25)
_W_MATERIALITY = _w("signal_w_materiality", 0.35)
_W_NOVELTY     = _w("signal_w_novelty",     0.25)
_W_CREDIBILITY = _w("signal_w_credibility", 0.15)
# Phase 1 — surprise weight (deficit taken from sentiment)
_W_SURPRISE    = _w("signal_w_surprise",    0.10)

# Re-normalise base weights when surprise is active
# Total without surprise = 1.0; with surprise the weights compress slightly
_SURPRISE_BASE_SCALE = 1.0 - _W_SURPRISE   # ≈ 0.90

# ---------------------------------------------------------------------------
# Phase 1 — market regime multipliers (read lazily so tests don't need them)
# ---------------------------------------------------------------------------

def _risk_off_mult() -> float:
    return float(getattr(settings, "signal_risk_off_multiplier", 0.60))

def _risk_on_mult() -> float:
    return float(getattr(settings, "signal_risk_on_multiplier", 1.10))

def _vix_spike_mult() -> float:
    return float(getattr(settings, "signal_vix_spike_multiplier", 0.50))

def _earnings_season_boost() -> float:
    return float(getattr(settings, "signal_earnings_season_earnings_boost", 1.30))


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class SignalResult:
    score:      float           # composite alpha in [-1, 1]
    direction:  str             # BULLISH | BEARISH | NEUTRAL
    rank_tier:  str             # STRONG | MODERATE | WEAK | NOISE
    components: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "score":      self.score,
            "direction":  self.direction,
            "rank_tier":  self.rank_tier,
            "components": self.components,
        }


def _direction(score: float) -> str:
    if score >  0.10:
        return "BULLISH"
    if score < -0.10:
        return "BEARISH"
    return "NEUTRAL"


def _rank_tier(abs_score: float) -> str:
    if abs_score >= 0.60:
        return "STRONG"
    if abs_score >= 0.35:
        return "MODERATE"
    if abs_score >= 0.15:
        return "WEAK"
    return "NOISE"


# ---------------------------------------------------------------------------
# Core scorer
# ---------------------------------------------------------------------------

def compute_signal(
    sentiment_label:   str,
    sentiment_score:   float,
    materiality_score: float,
    novelty_score:     float,
    credibility_score: float,
    materiality_tier:  str            = "LOW",
    event_type:        str            = "unknown",
    scraped_at:        Optional[datetime] = None,
    # ── Phase 1 additions (all optional — fully backward-compatible) ──
    market_state:      Optional["MarketState"] = None,
    surprise_score:    Optional[float]         = None,
    # ── Financial features conditioning (Phase 2) ──────────────────
    financial_features: Optional[object]       = None,  # FinancialFeatureVector
) -> SignalResult:
    """
    Compute the composite alpha signal.

    All inputs are clipped before weighting.
    Phase 1 parameters (market_state, surprise_score) are optional so
    existing test call-sites work without modification.
    """
    # ── Input normalisation ─────────────────────────────────────────────────
    mat      = max(0.0, min(1.0, materiality_score))
    nov      = max(0.0, min(1.0, novelty_score))
    cred     = max(0.0, min(1.0, credibility_score))
    sent_abs = max(0.0, min(1.0, sentiment_score))

    label = (sentiment_label or "NEUTRAL").upper()
    sign  = +1.0 if label == "POSITIVE" else (-1.0 if label == "NEGATIVE" else 0.0)

    # ── Surprise component ──────────────────────────────────────────────────
    # IMPORTANT: surprise_score is already SIGNED [-1, 1] and must NOT be
    # multiplied by sentiment sign later. It is added AFTER sign application.
    surprise_contrib_signed   = 0.0   # added post-sign (already carries direction)
    has_surprise              = surprise_score is not None
    if has_surprise:
        sur = max(-1.0, min(1.0, float(surprise_score)))
        surprise_contrib_signed = _W_SURPRISE * sur
        # Compress base weights proportionally to make room for surprise
        scale = _SURPRISE_BASE_SCALE
    else:
        scale = 1.0

    # ── Base component scores (unsigned magnitudes — sign applied later) ────
    sent_mag     = scale * _W_SENTIMENT   * sent_abs
    mat_contrib  = scale * _W_MATERIALITY * mat
    nov_contrib  = scale * _W_NOVELTY     * nov
    cred_contrib = scale * _W_CREDIBILITY * cred

    # unsigned base magnitude (sentiment, materiality, novelty, credibility)
    base_magnitude = sent_mag + mat_contrib + nov_contrib + cred_contrib

    # ── Event-type multiplier ───────────────────────────────────────────────
    et_weight = _EVENT_TYPE_WEIGHTS.get(event_type.lower(), 0.90)

    # ── Time decay ─────────────────────────────────────────────────────────
    if scraped_at:
        decay = time_decay_multiplier(scraped_at, materiality_tier)
    else:
        decay = 1.0

    magnitude = base_magnitude * et_weight * decay

    # ── Phase 1: Market regime conditioning ────────────────────────────────
    market_mult   = 1.0
    market_regime = "NEUTRAL"

    if market_state is not None:
        market_regime = market_state.risk_regime   # RISK_ON / RISK_OFF / NEUTRAL

        if market_state.vix_regime == "SPIKE":
            market_mult *= _vix_spike_mult()
        elif market_state.risk_regime == "RISK_OFF":
            market_mult *= _risk_off_mult()
        elif market_state.risk_regime == "RISK_ON":
            market_mult *= _risk_on_mult()

        # Earnings season boost for earnings-type events
        if market_state.earnings_season and event_type.lower() == "earnings":
            market_mult *= _earnings_season_boost()

        # Inverted yield curve: discount all signals (uncertainty/recession risk)
        if market_state.yield_curve_state == "INVERTED":
            market_mult *= 0.85

        scaled = magnitude * market_mult

    # ── Direction application — sign applies ONLY to base NLP magnitude ─────
    # surprise_contrib_signed is already directional and must NOT be re-signed
    if label == "NEUTRAL":
        score = scaled * 0.15 + surprise_contrib_signed
    else:
        score = sign * scaled + surprise_contrib_signed

    score = round(max(-1.0, min(1.0, score)), 4)

    # ── Financial feature conditioning (Phase 2) ────────────────────────────
    financial_mult = 1.0
    financial_conditioning = {}
    if financial_features is not None:
        try:
            financial_mult = financial_features.signal_multiplier(score if score != 0 else sign)
            financial_conditioning = financial_features.as_signal_conditioning_dict()
        except Exception:
            pass

    score = round(max(-1.0, min(1.0, score * financial_mult)), 4)

    return SignalResult(
        score     = score,
        direction = _direction(score),
        rank_tier = _rank_tier(abs(score)),
        components = {
            "sentiment_contrib":    round(scale * _W_SENTIMENT * sent_abs * sign, 4),
            "materiality_contrib":  round(mat_contrib,   4),
            "novelty_contrib":      round(nov_contrib,   4),
            "credibility_contrib":  round(cred_contrib,  4),
            "surprise_contrib":     round(surprise_contrib_signed, 4),
            "event_type_weight":    et_weight,
            "time_decay":           round(decay,          4),
            "market_regime":        market_regime,
            "market_regime_mult":   round(market_mult,   4),
            "financial_mult":       round(financial_mult, 4),
            **{f"fin_{k}": v for k, v in financial_conditioning.items()
               if v is not None},
        },
    )


# ---------------------------------------------------------------------------
# Batch ranker
# ---------------------------------------------------------------------------

def rank_signals(events: list[dict]) -> list[dict]:
    """
    Given a list of event dicts, compute the signal for each, attach it,
    and return sorted by |score| descending.

    Required keys per event dict:
        sentiment_label, sentiment_score, materiality_score,
        novelty_score, credibility_score, materiality_tier,
        event_type, scraped_at (datetime or ISO string)

    Optional Phase 1 keys (silently ignored if absent):
        surprise_score   float

    market_state is not accepted here (batch ranker is for offline use).
    Use main.py's run_pipeline for live market-conditioned scoring.
    """
    import datetime as _dt

    ranked = []
    for ev in events:
        sat = ev.get("scraped_at")
        if isinstance(sat, str):
            try:
                sat = _dt.datetime.fromisoformat(sat)
            except Exception:
                sat = None

        sur = ev.get("surprise_score")
        sur = float(sur) if sur is not None else None

        sig = compute_signal(
            sentiment_label   = ev.get("sentiment_label",   "NEUTRAL"),
            sentiment_score   = float(ev.get("sentiment_score",   0.0)),
            materiality_score = float(ev.get("materiality_score", 0.0)),
            novelty_score     = float(ev.get("novelty_score",     0.5)),
            credibility_score = float(ev.get("credibility_score", 0.5)),
            materiality_tier  = ev.get("materiality_tier",  "LOW"),
            event_type        = ev.get("event_type",        "unknown"),
            scraped_at        = sat,
            surprise_score    = sur,
        )
        ranked.append({**ev, "signal": sig.to_dict()})

    ranked.sort(key=lambda x: abs(x["signal"]["score"]), reverse=True)
    return ranked
