"""
events.py — canonical Pydantic write models.
Every write path validates through ScrapedEvent before touching the DB.

Phase 1 additions
-----------------
  targets              list[str]   — detected entity names (stored for expectation model)
  primary_sector       str         — GICS sector from factor_model (§11)
  surprise_score       float|None  — expectation surprise score (§2)
  guidance_revision_score float|None — guidance revision score (§2)
  factor_neutral_score float|None  — sector+market neutralised signal (§11)
  cs_percentile        float|None  — global cross-sectional percentile (§10)
  cs_sector_percentile float|None  — within-sector cross-sectional percentile (§10)
  cs_score             float|None  — cs_percentile mapped to [-1, 1] (§10)
  market_regime        str         — RISK_ON / RISK_OFF / NEUTRAL (§9)
  vix_level            float|None  — VIX at time of scrape (§9)
  yield_curve_slope    float|None  — 10Y-3M spread at time of scrape (§9)
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Optional
from uuid import UUID, uuid4

from pydantic import BaseModel, Field, field_validator


class ScrapedEvent(BaseModel):
    event_id:            UUID     = Field(default_factory=uuid4)
    url:                 str
    source_domain:       str
    scraped_at:          datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    http_status:         Optional[int] = None
    raw_text_hash:       str
    raw_text:            Optional[str] = None
    summary:             str      = ""
    sentiment_label:     str      = "NEUTRAL"
    sentiment_score:     float    = 0.0
    sentiment_confident: bool     = True
    keywords:            list[str] = Field(default_factory=list)
    topics:              list[str] = Field(default_factory=list)
    emotions:            dict      = Field(default_factory=dict)
    embedding:           Optional[list[float]] = None
    embedding_model:     str      = ""
    credibility_score:   float    = 0.5
    propaganda_score:    float    = 0.0
    propaganda_flags:    list[str] = Field(default_factory=list)
    materiality_score:   float    = 0.0
    materiality_tier:    str      = "LOW"
    is_duplicate:        bool     = False
    canonical_event_id:  Optional[UUID] = None

    # ── Signal Intelligence (v2) ────────────────────────────────────────────
    event_type:          str      = "unknown"
    event_confidence:    float    = 0.0
    novelty_score:       float    = 0.5
    novelty_label:       str      = "PARTIAL"
    signal_score:        float    = 0.0
    signal_direction:    str      = "NEUTRAL"
    signal_tier:         str      = "NOISE"
    dollar_value:        Optional[float] = None
    pct_change:          Optional[float] = None

    # ── Phase 1: Entity intelligence (§2, §10, §11) ─────────────────────────
    targets:             list[str] = Field(default_factory=list)
    primary_sector:      str       = "unknown"

    # §2 — Expectation surprise
    surprise_score:            Optional[float] = None   # combined [-1, 1]
    guidance_revision_score:   Optional[float] = None   # guidance-only [-1, 1]
    eps_surprise_sue:          Optional[float] = None   # real EPS SUE z-score

    # §11 — Factor neutralisation
    factor_neutral_score:      Optional[float] = None   # [-1, 1]

    # §10 — Cross-sectional ranking
    cs_percentile:             Optional[float] = None   # [0, 1]
    cs_sector_percentile:      Optional[float] = None   # [0, 1]
    cs_score:                  Optional[float] = None   # [-1, 1]

    # §9 — Market state context
    market_regime:             str            = "NEUTRAL"
    vix_level:                 Optional[float] = None
    yield_curve_slope:         Optional[float] = None

    # ── Phase 2: Financial features (price, fundamental, earnings, macro) ────
    # Price features
    price_momentum_1m:   Optional[float] = None
    price_momentum_3m:   Optional[float] = None
    price_momentum_12m:  Optional[float] = None
    price_vol_30d:       Optional[float] = None
    price_vol_regime:    Optional[float] = None   # short/long vol ratio
    price_week52_pct:    Optional[float] = None   # distance from 52w high
    price_beta_30d:      Optional[float] = None
    price_dollar_vol_log: Optional[float] = None

    # Fundamental features
    fund_pe_ratio:       Optional[float] = None
    fund_fcf_yield:      Optional[float] = None
    fund_revenue_growth: Optional[float] = None
    fund_roe:            Optional[float] = None
    fund_debt_to_equity: Optional[float] = None
    fund_short_pct_float: Optional[float] = None
    fund_finra_short_vol: Optional[float] = None  # FINRA REGSHO ratio
    fund_value_score:    Optional[float] = None   # composite [0,1]
    fund_quality_score:  Optional[float] = None
    fund_fragility_score: Optional[float] = None

    # Earnings surprise features
    earn_eps_sue:         Optional[float] = None   # primary EPS signal
    earn_beat_rate:       Optional[float] = None
    earn_revision_momentum: Optional[float] = None
    earn_pt_upside:       Optional[float] = None   # analyst price target upside
    earn_implied_move:    Optional[float] = None   # CBOE options implied move
    earn_next_er_days:    Optional[float] = None

    # Macro features (from FRED + ECB + Treasury + CBOE)
    macro_hy_spread:      Optional[float] = None   # FRED HY OAS spread
    macro_tsy_10y:        Optional[float] = None   # US Treasury 10Y
    macro_tsy_spread_10_2: Optional[float] = None  # 10Y-2Y spread
    macro_vix_term_slope: Optional[float] = None   # CBOE VIX term structure
    macro_stress_score:   Optional[float] = None   # composite [0,1]
    macro_eurusd:         Optional[float] = None   # ECB EUR/USD

    # Financial conditioning multiplier applied to signal
    financial_signal_mult: Optional[float] = None  # [0.3, 1.5]

    # ── Realised returns (filled in retrospect for calibration) ──────────────
    realised_return_1d:  Optional[float] = None
    realised_return_5d:  Optional[float] = None
    realised_return_20d: Optional[float] = None

    # ---------------------------------------------------------------------------
    # Validators
    # ---------------------------------------------------------------------------

    @field_validator("sentiment_label")
    @classmethod
    def valid_sentiment(cls, v: str) -> str:
        allowed = {"POSITIVE", "NEGATIVE", "NEUTRAL", "UNCERTAIN"}
        v = v.upper()
        if v not in allowed:
            raise ValueError(f"sentiment_label must be one of {allowed}")
        return v

    @field_validator(
        "credibility_score", "propaganda_score", "materiality_score",
        "sentiment_score", "event_confidence", "novelty_score",
    )
    @classmethod
    def unit_range(cls, v: float) -> float:
        return max(0.0, min(1.0, float(v)))

    @field_validator("signal_score")
    @classmethod
    def signal_range(cls, v: float) -> float:
        return max(-1.0, min(1.0, float(v)))

    @field_validator("surprise_score", "guidance_revision_score",
                     "factor_neutral_score", "cs_score", mode="before")
    @classmethod
    def optional_signed_unit(cls, v) -> Optional[float]:
        if v is None:
            return None
        return max(-1.0, min(1.0, float(v)))

    @field_validator("cs_percentile", "cs_sector_percentile", mode="before")
    @classmethod
    def optional_percentile(cls, v) -> Optional[float]:
        if v is None:
            return None
        return max(0.0, min(1.0, float(v)))

    @field_validator("market_regime")
    @classmethod
    def valid_regime(cls, v: str) -> str:
        allowed = {"RISK_ON", "RISK_OFF", "NEUTRAL"}
        v = v.upper()
        if v not in allowed:
            return "NEUTRAL"
        return v

    # ---------------------------------------------------------------------------
    # Utilities
    # ---------------------------------------------------------------------------

    @staticmethod
    def hash_text(text: str) -> str:
        return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()
