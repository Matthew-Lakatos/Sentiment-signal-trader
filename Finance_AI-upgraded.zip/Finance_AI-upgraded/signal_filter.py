"""
signal_filter.py — select actionable signals from a scored event stream.

Without selection logic, every scored event becomes a trade — noise dominates.

This module provides three complementary selection gates:

    1. Threshold gate   — absolute score cutoff (e.g. |score| > 0.30)
    2. Top-N%           — take only the top percentile of each batch
    3. Confidence gate  — require all component scores above floor values
    4. Staleness gate   — reject events older than max_age_hours

They can be composed: an event must pass ALL enabled gates to be selected.

Usage
-----
    from signal_filter import SignalFilter, FilterConfig

    cfg    = FilterConfig(min_score=0.25, top_pct=0.20, min_novelty=0.4)
    filt   = SignalFilter(cfg)
    passed = filt.apply(events)          # list of event dicts that passed
    report = filt.report(events, passed) # metrics on filter efficiency
"""
from __future__ import annotations

import math
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class FilterConfig:
    # Threshold gate
    min_score:       float = 0.20   # |signal_score| must exceed this
    # Top-percentile gate (0–1; 0 = disabled)
    top_pct:         float = 0.0    # keep top X% by |score|; 0 = keep all
    # Confidence gates (0 = disabled)
    min_materiality: float = 0.10
    min_novelty:     float = 0.30
    min_credibility: float = 0.40
    min_event_conf:  float = 0.0    # event_classifier confidence floor
    # Staleness gate (0 = disabled)
    max_age_hours:   float = 48.0
    # Tier allowlist (empty = allow all)
    allowed_tiers:   list[str] = field(default_factory=lambda: ["STRONG", "MODERATE"])
    # Event type blocklist (always exclude these)
    blocked_types:   list[str] = field(default_factory=lambda: ["unknown"])


# ---------------------------------------------------------------------------
# Filter engine
# ---------------------------------------------------------------------------

class SignalFilter:

    def __init__(self, config: Optional[FilterConfig] = None):
        self.cfg = config or FilterConfig()

    # ------------------------------------------------------------------
    # Individual gates
    # ------------------------------------------------------------------

    def _gate_threshold(self, ev: dict) -> tuple[bool, str]:
        score = float(ev.get("signal_score") or ev.get("signal", {}).get("score", 0.0))
        if abs(score) < self.cfg.min_score:
            return False, f"score {abs(score):.3f} < threshold {self.cfg.min_score}"
        return True, ""

    def _gate_tier(self, ev: dict) -> tuple[bool, str]:
        if not self.cfg.allowed_tiers:
            return True, ""
        tier = (ev.get("signal_tier") or
                ev.get("signal", {}).get("rank_tier", "NOISE")).upper()
        if tier not in self.cfg.allowed_tiers:
            return False, f"tier {tier} not in {self.cfg.allowed_tiers}"
        return True, ""

    def _gate_materiality(self, ev: dict) -> tuple[bool, str]:
        if self.cfg.min_materiality <= 0:
            return True, ""
        val = float(ev.get("materiality_score") or 0.0)
        if val < self.cfg.min_materiality:
            return False, f"materiality {val:.3f} < {self.cfg.min_materiality}"
        return True, ""

    def _gate_novelty(self, ev: dict) -> tuple[bool, str]:
        if self.cfg.min_novelty <= 0:
            return True, ""
        val = float(ev.get("novelty_score") or 0.5)
        if val < self.cfg.min_novelty:
            return False, f"novelty {val:.3f} < {self.cfg.min_novelty}"
        return True, ""

    def _gate_credibility(self, ev: dict) -> tuple[bool, str]:
        if self.cfg.min_credibility <= 0:
            return True, ""
        val = float(ev.get("credibility_score") or 0.5)
        if val < self.cfg.min_credibility:
            return False, f"credibility {val:.3f} < {self.cfg.min_credibility}"
        return True, ""

    def _gate_event_confidence(self, ev: dict) -> tuple[bool, str]:
        if self.cfg.min_event_conf <= 0:
            return True, ""
        val = float(ev.get("event_confidence") or 0.0)
        if val < self.cfg.min_event_conf:
            return False, f"event_confidence {val:.3f} < {self.cfg.min_event_conf}"
        return True, ""

    def _gate_staleness(self, ev: dict) -> tuple[bool, str]:
        if self.cfg.max_age_hours <= 0:
            return True, ""
        ts = ev.get("scraped_at")
        if ts is None:
            return True, ""
        if isinstance(ts, str):
            try:
                ts = datetime.fromisoformat(ts)
            except Exception:
                return True, ""
        if ts.tzinfo is None:
            ts = ts.replace(tzinfo=timezone.utc)
        age_h = (datetime.now(timezone.utc) - ts).total_seconds() / 3600.0
        if age_h > self.cfg.max_age_hours:
            return False, f"age {age_h:.1f}h > max {self.cfg.max_age_hours}h"
        return True, ""

    def _gate_blocked_type(self, ev: dict) -> tuple[bool, str]:
        if not self.cfg.blocked_types:
            return True, ""
        et = (ev.get("event_type") or "unknown").lower()
        if et in [t.lower() for t in self.cfg.blocked_types]:
            return False, f"event_type '{et}' is blocked"
        return True, ""

    # ------------------------------------------------------------------
    # Compose all gates
    # ------------------------------------------------------------------

    def _passes_all_gates(self, ev: dict) -> tuple[bool, list[str]]:
        reasons = []
        for gate in [
            self._gate_threshold,
            self._gate_tier,
            self._gate_materiality,
            self._gate_novelty,
            self._gate_credibility,
            self._gate_event_confidence,
            self._gate_staleness,
            self._gate_blocked_type,
        ]:
            ok, reason = gate(ev)
            if not ok:
                reasons.append(reason)
        return len(reasons) == 0, reasons

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def apply(
        self,
        events: list[dict],
        annotate: bool = False,
    ) -> list[dict]:
        """
        Return events that pass all configured gates.

        Parameters
        ----------
        events    list of event dicts with signal scores
        annotate  if True, attach _filter_pass / _filter_reasons to each event

        Returns events sorted by |signal_score| descending.
        """
        passed = []
        for ev in events:
            ok, reasons = self._passes_all_gates(ev)
            if annotate:
                ev = {**ev, "_filter_pass": ok, "_filter_reasons": reasons}
            if ok:
                passed.append(ev)

        # Apply top-percentile gate
        if self.cfg.top_pct > 0 and passed:
            k = max(1, math.ceil(len(passed) * self.cfg.top_pct))

            def _score(e):
                return abs(float(e.get("signal_score") or
                                 e.get("signal", {}).get("score", 0.0)))

            passed = sorted(passed, key=_score, reverse=True)[:k]

        return passed

    def report(self, all_events: list[dict], passed: list[dict]) -> dict:
        """
        Return efficiency metrics for the filter run.
        """
        total    = len(all_events)
        n_passed = len(passed)

        # Rejection breakdown
        reasons_count: dict[str, int] = {}
        for ev in all_events:
            ok, reasons = self._passes_all_gates(ev)
            if not ok:
                for r in reasons:
                    key = r.split(" ")[0]  # e.g. "score", "tier", "novelty"
                    reasons_count[key] = reasons_count.get(key, 0) + 1

        scores_passed = [
            abs(float(ev.get("signal_score") or 0.0)) for ev in passed
        ]
        return {
            "total_events":      total,
            "passed":            n_passed,
            "rejected":          total - n_passed,
            "pass_rate":         round(n_passed / max(1, total), 4),
            "mean_score_passed": round(sum(scores_passed) / max(1, len(scores_passed)), 4),
            "rejection_reasons": reasons_count,
        }
