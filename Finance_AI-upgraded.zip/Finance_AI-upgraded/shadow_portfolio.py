"""
shadow_portfolio.py — #11 Shadow-Mode / Paper Governance Engine.

Simulates a live portfolio in parallel with the real system,
tracking hypothetical fills, slippage drift, execution mismatch,
and shadow governance decisions — all without touching real capital.

Mandatory before live deployment. A shadow portfolio that consistently
outperforms the live portfolio indicates execution or governance issues.
One that consistently underperforms identifies data-leakage risks.

Components
----------
1. Shadow fills       — hypothetical fills at realistic simulated prices
2. Shadow P&L         — MTM and realised returns on shadow positions
3. Shadow slippage    — actual vs expected slippage comparison
4. Shadow governance  — record what governance confidence was at each entry
5. Deviation alerts   — warn when shadow vs live results diverge

Usage
-----
    from shadow_portfolio import ShadowPortfolio

    shadow = ShadowPortfolio()

    # On signal
    fill = await shadow.open_position(
        event_id    = "evt-123",
        ticker      = "AAPL",
        direction   = "LONG",
        signal_score = 0.72,
        governance_confidence = 0.85,
        throttle_mode = "FULL",
    )

    # On close
    result = await shadow.close_position(
        event_id   = "evt-123",
        exit_price = 195.40,
        exit_reason = "horizon_reached",
    )

    # Get P&L report
    report = shadow.pnl_report()
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Position record
# ---------------------------------------------------------------------------

@dataclass
class ShadowPosition:
    event_id:             str
    ticker:               str
    direction:            str            # LONG | SHORT
    signal_score:         float
    governance_confidence: float
    throttle_mode:        str
    kill_switch_state:    str

    # Fill details
    entry_price:          float
    entry_ts:             datetime
    notional:             float         # base notional before size scalar
    size_scalar:          float         # governance size scalar applied
    effective_notional:   float         # notional × size_scalar
    expected_slippage_bps: float

    # Exit details (filled on close)
    exit_price:           Optional[float] = None
    exit_ts:              Optional[datetime] = None
    exit_reason:          str = ""
    actual_slippage_bps:  Optional[float] = None
    realised_pnl:         Optional[float] = None   # $ P&L
    realised_pct:         Optional[float] = None   # % return

    # Governance state at exit
    exit_governance_confidence: Optional[float] = None
    exit_kill_state:            str = ""

    @property
    def is_open(self) -> bool:
        return self.exit_price is None

    @property
    def hold_days(self) -> Optional[float]:
        if self.exit_ts is None:
            return None
        return (self.exit_ts - self.entry_ts).total_seconds() / 86400.0

    def mtm(self, current_price: float) -> float:
        """Mark-to-market P&L at current_price."""
        if self.direction == "LONG":
            return (current_price / self.entry_price - 1) * self.effective_notional
        else:
            return (self.entry_price / current_price - 1) * self.effective_notional


# ---------------------------------------------------------------------------
# Shadow P&L report
# ---------------------------------------------------------------------------

@dataclass
class ShadowPnLReport:
    n_positions:          int
    n_open:               int
    n_closed:             int
    total_realised_pnl:   float
    win_rate:             float         # fraction of closed positions with positive P&L
    avg_return_pct:       float
    avg_hold_days:        float
    avg_slippage_bps:     float
    avg_governance_at_entry: float
    sharpe:               Optional[float]
    max_drawdown_pct:     float
    best_trade_pct:       float
    worst_trade_pct:      float
    governance_breakdown: dict[str, float]  # mode → avg return
    deviation_from_expected: float          # MAE of actual vs expected slippage
    computed_at:          datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def summary(self) -> str:
        return (
            f"Shadow P&L: n={self.n_closed}  total=${self.total_realised_pnl:.0f}  "
            f"win_rate={self.win_rate:.1%}  avg_ret={self.avg_return_pct:.2%}  "
            f"Sharpe={self.sharpe:.2f if self.sharpe else 'N/A'}  "
            f"slippage_mae={self.deviation_from_expected:.1f}bps"
        )


# ---------------------------------------------------------------------------
# Price fetcher (sync — runs in executor)
# ---------------------------------------------------------------------------

def _fetch_current_price_sync(ticker: str) -> Optional[float]:
    try:
        import yfinance as yf
        info = yf.Ticker(ticker).fast_info
        price = getattr(info, "last_price", None) or getattr(info, "regular_market_price", None)
        return float(price) if price else None
    except Exception as exc:
        logger.debug("Price fetch failed for %s: %s", ticker, exc)
        return None


# ---------------------------------------------------------------------------
# ShadowPortfolio
# ---------------------------------------------------------------------------

class ShadowPortfolio:
    """
    Paper-trades signals to validate execution, governance, and slippage
    assumptions before deploying real capital.
    """

    def __init__(
        self,
        base_slippage_bps: float = 10.0,
        base_notional:     float = 10_000.0,
    ) -> None:
        self._slippage_bps = base_slippage_bps
        self._notional     = base_notional
        self._positions:   dict[str, ShadowPosition] = {}
        self._closed:      list[ShadowPosition]      = []
        self._lock         = asyncio.Lock()

    # ------------------------------------------------------------------
    # Open
    # ------------------------------------------------------------------

    async def open_position(
        self,
        event_id:             str,
        ticker:               str,
        direction:            str,
        signal_score:         float,
        governance_confidence: float,
        throttle_mode:        str   = "FULL",
        kill_switch_state:    str   = "ACTIVE",
        size_scalar:          float = 1.0,
        custom_entry_price:   Optional[float] = None,
    ) -> Optional[ShadowPosition]:
        """
        Open a shadow position. Fetches current price unless overridden.
        Returns None if price is unavailable.
        """
        async with self._lock:
            if event_id in self._positions:
                logger.debug("Shadow position %s already open", event_id)
                return self._positions[event_id]

        # Fetch price
        if custom_entry_price is not None:
            price = custom_entry_price
        else:
            loop  = asyncio.get_running_loop()
            price = await loop.run_in_executor(None, _fetch_current_price_sync, ticker)

        if price is None:
            logger.warning("Cannot open shadow position for %s: no price available", ticker)
            return None

        # Apply realistic slippage to entry
        slippage_factor = (self._slippage_bps / 10000.0)
        if direction == "LONG":
            fill_price = price * (1 + slippage_factor)
        else:
            fill_price = price * (1 - slippage_factor)

        pos = ShadowPosition(
            event_id              = event_id,
            ticker                = ticker,
            direction             = direction,
            signal_score          = signal_score,
            governance_confidence = governance_confidence,
            throttle_mode         = throttle_mode,
            kill_switch_state     = kill_switch_state,
            entry_price           = round(fill_price, 4),
            entry_ts              = datetime.now(timezone.utc),
            notional              = self._notional,
            size_scalar           = size_scalar,
            effective_notional    = self._notional * size_scalar,
            expected_slippage_bps = self._slippage_bps,
        )

        async with self._lock:
            self._positions[event_id] = pos

        logger.info(
            "Shadow OPEN: %s %s %s @ %.4f  notional=%.0f  gov=%.2f  mode=%s",
            event_id, direction, ticker, fill_price,
            pos.effective_notional, governance_confidence, throttle_mode,
        )
        return pos

    # ------------------------------------------------------------------
    # Close
    # ------------------------------------------------------------------

    async def close_position(
        self,
        event_id:              str,
        exit_reason:           str = "",
        exit_governance_confidence: Optional[float] = None,
        exit_kill_state:       str = "ACTIVE",
        custom_exit_price:     Optional[float] = None,
    ) -> Optional[ShadowPosition]:
        async with self._lock:
            pos = self._positions.get(event_id)
            if pos is None:
                logger.warning("Shadow position %s not found", event_id)
                return None

        # Fetch exit price
        if custom_exit_price is not None:
            price = custom_exit_price
        else:
            loop  = asyncio.get_running_loop()
            price = await loop.run_in_executor(None, _fetch_current_price_sync, pos.ticker)

        if price is None:
            logger.warning("Cannot close shadow position %s: no exit price", event_id)
            return None

        # Apply exit slippage
        slippage_factor = self._slippage_bps / 10000.0
        if pos.direction == "LONG":
            exit_price = price * (1 - slippage_factor)
        else:
            exit_price = price * (1 + slippage_factor)

        # Compute actual slippage vs expected
        actual_slippage_bps = abs(exit_price - price) / price * 10000.0
        slippage_deviation  = abs(actual_slippage_bps - self._slippage_bps)

        # Compute P&L
        if pos.direction == "LONG":
            ret_pct = (exit_price / pos.entry_price) - 1.0
        else:
            ret_pct = (pos.entry_price / exit_price) - 1.0

        realised_pnl = ret_pct * pos.effective_notional

        async with self._lock:
            pos.exit_price                  = round(exit_price, 4)
            pos.exit_ts                     = datetime.now(timezone.utc)
            pos.exit_reason                 = exit_reason
            pos.actual_slippage_bps         = round(actual_slippage_bps, 2)
            pos.realised_pnl                = round(realised_pnl, 2)
            pos.realised_pct                = round(ret_pct * 100, 4)
            pos.exit_governance_confidence  = exit_governance_confidence
            pos.exit_kill_state             = exit_kill_state
            del self._positions[event_id]
            self._closed.append(pos)

        logger.info(
            "Shadow CLOSE: %s %s @ %.4f  P&L=$%.2f (%.2f%%)  reason=%s",
            event_id, pos.ticker, exit_price, realised_pnl, ret_pct * 100, exit_reason,
        )
        return pos

    # ------------------------------------------------------------------
    # P&L Report
    # ------------------------------------------------------------------

    def pnl_report(self) -> ShadowPnLReport:
        closed = list(self._closed)

        if not closed:
            return ShadowPnLReport(
                n_positions=0, n_open=len(self._positions), n_closed=0,
                total_realised_pnl=0, win_rate=0, avg_return_pct=0,
                avg_hold_days=0, avg_slippage_bps=0, avg_governance_at_entry=0,
                sharpe=None, max_drawdown_pct=0, best_trade_pct=0,
                worst_trade_pct=0, governance_breakdown={}, deviation_from_expected=0,
            )

        returns = [p.realised_pct or 0.0 for p in closed]
        pnls    = [p.realised_pnl  or 0.0 for p in closed]
        slippage = [p.actual_slippage_bps or 0.0 for p in closed]
        gov_confs = [p.governance_confidence for p in closed]
        hold_days = [p.hold_days or 0.0 for p in closed]

        # Sharpe
        if len(returns) >= 3 and np.std(returns) > 0:
            sharpe = float(np.mean(returns) / np.std(returns) * np.sqrt(252))
        else:
            sharpe = None

        # Max drawdown (on cumulative returns)
        cum = np.cumsum(returns)
        peak = np.maximum.accumulate(cum)
        drawdowns = cum - peak
        max_dd = float(drawdowns.min()) if len(drawdowns) > 0 else 0.0

        # Governance mode breakdown
        gov_breakdown: dict[str, list[float]] = {}
        for p in closed:
            mode = p.throttle_mode
            if mode not in gov_breakdown:
                gov_breakdown[mode] = []
            gov_breakdown[mode].append(p.realised_pct or 0.0)
        gov_summary = {mode: round(float(np.mean(rets)), 4) for mode, rets in gov_breakdown.items()}

        # Slippage MAE
        slippage_mae = float(np.mean([abs(s - self._slippage_bps) for s in slippage]))

        return ShadowPnLReport(
            n_positions           = len(closed) + len(self._positions),
            n_open                = len(self._positions),
            n_closed              = len(closed),
            total_realised_pnl    = round(sum(pnls), 2),
            win_rate              = round(sum(1 for r in returns if r > 0) / len(returns), 4),
            avg_return_pct        = round(float(np.mean(returns)), 4),
            avg_hold_days         = round(float(np.mean(hold_days)), 2),
            avg_slippage_bps      = round(float(np.mean(slippage)), 2),
            avg_governance_at_entry = round(float(np.mean(gov_confs)), 4),
            sharpe                = round(sharpe, 3) if sharpe else None,
            max_drawdown_pct      = round(max_dd, 4),
            best_trade_pct        = round(max(returns), 4),
            worst_trade_pct       = round(min(returns), 4),
            governance_breakdown  = gov_summary,
            deviation_from_expected = round(slippage_mae, 2),
        )

    # ------------------------------------------------------------------
    # Open position MTM
    # ------------------------------------------------------------------

    async def mark_to_market(self) -> dict[str, float]:
        """Return current MTM P&L for all open positions."""
        loop   = asyncio.get_running_loop()
        result = {}
        async with self._lock:
            positions = dict(self._positions)

        for event_id, pos in positions.items():
            price = await loop.run_in_executor(None, _fetch_current_price_sync, pos.ticker)
            if price is not None:
                result[event_id] = round(pos.mtm(price), 2)
        return result
