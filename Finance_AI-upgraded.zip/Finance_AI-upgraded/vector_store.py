"""
vector_store.py — pgvector-backed semantic search.
Replaces FAISS. Single source of truth for embeddings (no divergent indexes).
No pickle, no local files, no per-replica divergence.
"""
from __future__ import annotations
import logging
from typing import Optional

from asyncpg.pool import Pool
from config import settings

logger = logging.getLogger(__name__)


async def semantic_search(
    pool: Pool,
    query_embedding: list[float],
    k: int = 5,
    min_similarity: float = 0.0,
    domain_filter: Optional[str] = None,
) -> list[dict]:
    """
    Return up to k events most similar to query_embedding.
    Uses pgvector cosine distance operator (<=>) over scraped_events.
    """
    emb_str = f"[{','.join(str(x) for x in query_embedding)}]"
    query = """
        SELECT
            event_id,
            url,
            source_domain,
            scraped_at,
            summary,
            sentiment_label,
            sentiment_score,
            materiality_tier,
            1 - (embedding <=> $1::vector) AS similarity
        FROM scraped_events
        WHERE embedding IS NOT NULL
          AND NOT is_duplicate
          AND 1 - (embedding <=> $1::vector) > $2
    """
    params: list = [emb_str, min_similarity]

    if domain_filter:
        query += " AND source_domain = $3"
        params.append(domain_filter)

    query += f" ORDER BY embedding <=> $1::vector LIMIT {int(k)}"

    rows = await pool.fetch(query, *params)
    return [
        {
            "event_id":       str(r["event_id"]),
            "url":            r["url"],
            "source_domain":  r["source_domain"],
            "scraped_at":     r["scraped_at"].isoformat(),
            "summary":        r["summary"],
            "sentiment":      r["sentiment_label"],
            "sentiment_score": r["sentiment_score"],
            "materiality":    r["materiality_tier"],
            "similarity":     round(float(r["similarity"]), 4),
        }
        for r in rows
    ]


async def store_embedding(pool: Pool, event_id, embedding: list[float], model_version: str) -> None:
    """Update the embedding column for an existing event."""
    emb_str = f"[{','.join(str(x) for x in embedding)}]"
    await pool.execute("""
        UPDATE scraped_events
        SET embedding = $1::vector, embedding_model = $2
        WHERE event_id = $3
    """, emb_str, model_version, event_id)


async def reindex_embeddings(pool: Pool, model_version: str) -> int:
    """
    Recompute embeddings for all events that have a different embedding_model
    than the current version. Returns the number of rows updated.
    Used after a model upgrade.
    """
    from embeddings import generate_embedding, embedding_model_version
    current = embedding_model_version()
    rows = await pool.fetch("""
        SELECT event_id, summary FROM scraped_events
        WHERE embedding_model != $1 OR embedding IS NULL
        LIMIT 1000
    """, current)

    updated = 0
    for row in rows:
        emb = await generate_embedding(row["summary"] or "")
        if emb:
            await store_embedding(pool, row["event_id"], emb, current)
            updated += 1

    logger.info("Reindexed %d embeddings to model version %s", updated, current)
    return updated
