"""
scheduler.py — production scheduler with:
  - Exponential backoff on failure (never silent crash)
  - PostgreSQL advisory lock for distributed coordination
    (only one replica runs the pipeline at a time)
"""
from __future__ import annotations
import asyncio
import logging
import random
from typing import Callable, Awaitable

from asyncpg.pool import Pool

logger = logging.getLogger(__name__)

# Stable integer key for pg_try_advisory_lock
_PIPELINE_LOCK_ID = 7_331_000


async def _backoff(attempt: int, cap: float = 300.0) -> None:
    delay = min(cap, 2.0 ** attempt)
    jitter = random.uniform(0, delay)
    logger.info("Scheduler backing off %.1fs (attempt %d)", jitter, attempt)
    await asyncio.sleep(jitter)


async def run_with_backoff(
    coro_factory: Callable[[], Awaitable],
    interval_s: int,
    name: str = "pipeline",
    max_backoff_s: float = 300.0,
) -> None:
    """
    Run coro_factory() on a fixed interval forever.
    On failure: exponential backoff, then resume schedule.
    """
    consecutive_failures = 0

    while True:
        start = asyncio.get_event_loop().time()
        try:
            await coro_factory()
            consecutive_failures = 0
            elapsed   = asyncio.get_event_loop().time() - start
            sleep_for = max(0.0, interval_s - elapsed)
            logger.info("%s completed in %.1fs — sleeping %.1fs", name, elapsed, sleep_for)
            await asyncio.sleep(sleep_for)

        except Exception as exc:
            consecutive_failures += 1
            logger.error(
                "%s failed (attempt %d): %s",
                name, consecutive_failures, exc,
                exc_info=True,
            )
            await _backoff(consecutive_failures, cap=max_backoff_s)


async def with_pg_lock(
    pool: Pool,
    coro_factory: Callable[[], Awaitable],
    lock_id: int = _PIPELINE_LOCK_ID,
) -> None:
    """
    Try to acquire a PostgreSQL session-level advisory lock.
    If another replica already holds it, skip this cycle gracefully.
    Releases the lock when coro_factory finishes (or raises).
    """
    async with pool.acquire() as conn:
        acquired = await conn.fetchval("SELECT pg_try_advisory_lock($1)", lock_id)
        if not acquired:
            logger.info("Another replica holds the pipeline lock — skipping this cycle")
            return
        try:
            await coro_factory()
        finally:
            await conn.fetchval("SELECT pg_advisory_unlock($1)", lock_id)


async def run_scheduled_pipeline(
    pool: Pool,
    pipeline_coro_factory: Callable[[], Awaitable],
    interval_s: int,
) -> None:
    """
    Top-level entry point: runs the pipeline on interval, with
    distributed lock and failure backoff.
    """
    async def _locked():
        await with_pg_lock(pool, pipeline_coro_factory)

    await run_with_backoff(_locked, interval_s, name="pipeline")
