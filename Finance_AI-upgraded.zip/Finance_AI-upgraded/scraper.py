"""
scraper.py — production async scraper with:
  - Split connect/read timeouts
  - Randomised browser headers per request
  - Exponential backoff with full jitter (up to 5 retries)
  - Retry-After header honoured on 429/503
  - Content-Type guard (HTML only)
  - Max response-size limit (configurable, default 5 MB)
  - robots.txt compliance + per-domain pacing
  - Dead source detection
  - SSRF protection (blocks private IP ranges)
  - Parser fallback chain: readability → trafilatura → direct-p → full strip
  - Selenium fallback for JS-heavy pages
"""
from __future__ import annotations
import asyncio
import ipaddress
import logging
import random
import socket
from typing import Any
from urllib.parse import urlparse

import aiohttp
from aiohttp import ClientError, ClientTimeout
from bs4 import BeautifulSoup
from readability import Document

from config import settings
from headers import random_headers
from robots_cache import crawl_delay, is_allowed

logger = logging.getLogger(__name__)

# Per-domain asyncio locks prevent concurrent requests to the same host
_domain_locks: dict[str, asyncio.Lock] = {}
_domain_last_request: dict[str, float] = {}

_TIMEOUT = ClientTimeout(
    connect=settings.scrape_timeout_connect,
    sock_read=settings.scrape_timeout_read,
)
_SEMAPHORE = asyncio.Semaphore(settings.concurrency_limit)

# Private/link-local ranges — never fetch these (SSRF protection)
_PRIVATE_NETWORKS = [
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("169.254.0.0/16"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
]


def _is_private_url(url: str) -> bool:
    """Return True if *url* resolves to a private/loopback address."""
    try:
        host = urlparse(url).hostname or ""
        addr = ipaddress.ip_address(socket.gethostbyname(host))
        return any(addr in net for net in _PRIVATE_NETWORKS)
    except Exception:
        return False


async def _backoff(attempt: int, base: float = 1.0, cap: float = 30.0) -> None:
    delay = min(cap, base * (2 ** attempt))
    await asyncio.sleep(random.uniform(0, delay))


async def _pace_domain(domain: str) -> None:
    """Enforce per-domain crawl-delay before each request."""
    lock = _domain_locks.setdefault(domain, asyncio.Lock())
    async with lock:
        last = _domain_last_request.get(domain, 0.0)
        wait = crawl_delay(f"https://{domain}/") - (asyncio.get_event_loop().time() - last)
        if wait > 0:
            await asyncio.sleep(wait)
        _domain_last_request[domain] = asyncio.get_event_loop().time()


async def _extract_text(html: str) -> str:
    """
    Extract readable text from HTML.

    Parser chain (fastest-first):
    1. Pure lxml XPath       — no Python tree traversal; ~5× faster than BS4
    2. python-readability    — article extraction for news pages
    3. trafilatura           — alternative extraction library
    4. lxml direct <p> walk  — reliable fallback
    5. Full-page strip       — last resort

    All passes use lxml (libxml2 C backend) — BeautifulSoup is only used
    as a convenience wrapper when the lxml tree is already available.
    """
    _MIN = 200

    # ── Pre-parse with lxml once (reused across all passes) ──────────────────
    try:
        from lxml import etree, html as lxml_html
        tree = lxml_html.fromstring(html.encode("utf-8", errors="replace"))
    except Exception:
        tree = None

    # ── Pass 1: pure lxml XPath — fastest path ───────────────────────────────
    if tree is not None:
        try:
            # Remove boilerplate nodes in-place (C-level, no Python iteration)
            etree.strip_elements(tree, "script", "style", "nav", "footer",
                                 "header", "aside", "form", with_tail=False)
            # Extract <p> and <article> text via XPath
            paragraphs = tree.xpath(
                "//article//p/text() | //main//p/text() | //p/text()"
            )
            text = " ".join(p.strip() for p in paragraphs if p.strip())
            if len(text) >= _MIN:
                return text
        except Exception:
            pass

    # ── Pass 2: python-readability ────────────────────────────────────────────
    try:
        from readability import Document
        from lxml import html as lxml_html
        doc     = Document(html)
        cleaned = doc.summary(html_partial=True)
        clean_tree = lxml_html.fromstring(cleaned.encode("utf-8", errors="replace"))
        text = " ".join(
            t.strip()
            for t in clean_tree.xpath("//p/text()")
            if t.strip()
        )
        if len(text) >= _MIN:
            return text
    except Exception:
        pass

    # ── Pass 3: trafilatura ───────────────────────────────────────────────────
    try:
        import trafilatura
        text = trafilatura.extract(html, include_comments=False,
                                   include_tables=False) or ""
        if len(text) >= _MIN:
            return text
    except Exception:
        pass

    # ── Pass 4: lxml direct <p> walk ─────────────────────────────────────────
    if tree is not None:
        try:
            text = " ".join(
                t.strip()
                for t in tree.xpath("//p/text()")
                if t.strip()
            )
            if len(text) >= _MIN:
                return text
        except Exception:
            pass

    # ── Pass 5: full-page strip (last resort) ─────────────────────────────────
    if tree is not None:
        try:
            return " ".join(tree.text_content().split())
        except Exception:
            pass

    # Absolute fallback — BeautifulSoup (original behaviour)
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, "lxml")
    for tag in soup(["script", "style", "nav", "footer", "header"]):
        tag.decompose()
    return soup.get_text(separator=" ", strip=True)


def _scrape_dynamic(url: str) -> str:
    """Selenium headless Chrome fallback. Runs in a thread executor."""
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--disable-gpu")
    # --no-sandbox is intentionally OMITTED for security
    if settings.chromedriver_path:
        from selenium.webdriver.chrome.service import Service
        driver = webdriver.Chrome(service=Service(settings.chromedriver_path), options=opts)
    else:
        driver = webdriver.Chrome(options=opts)
    try:
        driver.set_page_load_timeout(30)
        driver.get(url)
        html = driver.page_source
    finally:
        driver.quit()
    doc     = Document(html)
    cleaned = doc.summary()
    soup    = BeautifulSoup(cleaned, "html.parser")
    return " ".join(p.get_text(strip=True) for p in soup.find_all("p"))


async def scrape_url(
    url: str,
    session: aiohttp.ClientSession,
) -> dict[str, Any]:
    """
    Fetch and extract text from *url* with full retry/backoff/pacing.
    Returns {"url", "text", "status"}.
    """
    # SSRF guard
    if _is_private_url(url):
        logger.warning("Blocked private URL: %s", url)
        return {"url": url, "text": "", "status": None}

    # robots.txt compliance
    if not is_allowed(url):
        logger.info("Blocked by robots.txt: %s", url)
        return {"url": url, "text": "", "status": None}

    domain = urlparse(url).netloc
    await _pace_domain(domain)

    for attempt in range(settings.scrape_retries):
        try:
            async with _SEMAPHORE:
                async with session.get(
                    url,
                    headers=random_headers(),
                    timeout=_TIMEOUT,
                    allow_redirects=True,
                    max_redirects=5,
                ) as response:
                    # Honour Retry-After on 429 / 503
                    if response.status in (429, 503):
                        ra = response.headers.get("Retry-After")
                        wait = float(ra) if ra else None
                        if wait:
                            await asyncio.sleep(wait)
                        else:
                            await _backoff(attempt)
                        continue

                    if response.status != 200:
                        return {"url": url, "text": "", "status": response.status}

                    # Content-Type guard — HTML only
                    ct = response.headers.get("Content-Type", "")
                    if "text/html" not in ct and "application/xhtml" not in ct:
                        logger.debug("Skipping non-HTML response (%s) for %s", ct, url)
                        return {"url": url, "text": "", "status": response.status}

                    # Max response size
                    chunks = []
                    total = 0
                    async for chunk in response.content.iter_chunked(65536):
                        total += len(chunk)
                        if total > settings.scrape_max_response_bytes:
                            logger.warning("Response too large (>%d bytes): %s",
                                           settings.scrape_max_response_bytes, url)
                            return {"url": url, "text": "", "status": response.status}
                        chunks.append(chunk)

                    html = b"".join(chunks).decode("utf-8", errors="replace")
                    text = await _extract_text(html)
                    return {"url": url, "text": text, "status": response.status}

        except (ClientError, asyncio.TimeoutError) as exc:
            if attempt < settings.scrape_retries - 1:
                logger.debug("scrape_url: %s failed (%s) attempt %d — backing off",
                             url, exc, attempt + 1)
                await _backoff(attempt)
            else:
                logger.warning("scrape_url: %s failed after %d attempts", url,
                               settings.scrape_retries)
                return {"url": url, "text": "", "status": None}

    return {"url": url, "text": "", "status": None}


async def scrape_all_urls(
    urls: list[str],
    pool=None,
    use_dynamic_fallback: bool = True,
) -> list[dict[str, Any]]:
    """
    Scrape all *urls* concurrently.
    Records success/failure in source_health when *pool* is provided.
    """
    from source_health import domain_of, record_success, record_failure

    async with aiohttp.ClientSession() as session:
        tasks   = [scrape_url(u, session) for u in urls]
        results = await asyncio.gather(*tasks, return_exceptions=False)

    # Record health metrics
    if pool:
        for r in results:
            domain = domain_of(r["url"])
            if r["text"]:
                await record_success(pool, domain)
            else:
                became_dead = await record_failure(pool, domain)
                if became_dead:
                    from alert_engine import AlertPayload, dispatch_alerts
                    from source_health import is_dead as _is_dead_check
                    alert = AlertPayload(
                        alert_type="SOURCE_DEAD",
                        severity="MEDIUM",
                        source_domain=domain,
                        headline=f"Source unresponsive: {domain}",
                        detail=f"Exceeded {settings.dead_source_threshold} consecutive failures",
                    )
                    await dispatch_alerts(pool, [alert],
                                          webhook_url=settings.alert_webhook_url)

    # Selenium fallback for empty-text pages
    if use_dynamic_fallback and settings.enable_selenium_fallback:
        loop = asyncio.get_running_loop()
        for r in results:
            if not r["text"]:
                try:
                    text = await loop.run_in_executor(None, _scrape_dynamic, r["url"])
                    r["text"] = text or ""
                except Exception:
                    logger.debug("Dynamic fallback failed for %s", r["url"], exc_info=True)

    return results
