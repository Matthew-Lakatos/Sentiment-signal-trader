"""
capacity.py — capacity and scaling awareness.

Problems this solves
---------------------
1. Signal frequency     — how many trades per day/week does the strategy generate?
2. Average trade size   — is the notional consistent with realistic liquidity?
3. Market impact        — estimated slippage at different AUM levels (Almgren-Chriss lite)
4. Capacity ceiling     — maximum AUM before alpha erodes from impact
5. Second-order alpha   — signals derived from the knowledge graph's propagated
                          sentiment (entity A → entity B via shared topics)

Market impact model (simplified Almgren-Chriss)
------------------------------------------------
    temporary_impact = η × (Q / V) ^ 0.6
where
    η = 0.1  (empirical constant for liquid US equities)
    Q = trade size in shares
    V = average daily volume

Capacity ceiling:
    When impact ≈ alpha, further AUM destroys edge.
    ceiling_AUM = (alpha_bps / η) ^ (1/0.6) × V × price

Usage
-----
    from capacity import CapacityAnalyser, SecondOrderAlpha

    cap = CapacityAnalyser(avg_daily_volume=5_000_000, avg_price=150.0)
    print(cap.report(orders, signal_alpha_bps=30))

    soa = SecondOrderAlpha(pool)
    signals = await soa.propagate(entity="NVIDIA", base_score=0.7)
"""
from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Almgren-Chriss lite constants
# ---------------------------------------------------------------------------

_ETA      = 0.10   # market impact coefficient (liquid US equities)
_BETA     = 0.60   # price impact exponent


# ---------------------------------------------------------------------------
# Capacity analyser
# ---------------------------------------------------------------------------

@dataclass
class CapacityReport:
    avg_notional_per_trade: float     # $
    trades_per_day:         float
    trades_per_week:        float
    gross_daily_notional:   float     # $
    estimated_impact_bps:   float     # at avg_notional
    capacity_ceiling_usd:   float     # AUM at which impact = alpha
    pct_adv:                float     # avg trade as % of avg daily vol
    warnings:               list[str]

    def summary(self) -> str:
        lines = [
            f"\n{'─'*60}",
            f"  CAPACITY ANALYSIS",
            f"{'─'*60}",
            f"  Avg notional / trade:   ${self.avg_notional_per_trade:>12,.0f}",
            f"  Trades per day:         {self.trades_per_day:>10.1f}",
            f"  Trades per week:        {self.trades_per_week:>10.1f}",
            f"  Gross daily notional:   ${self.gross_daily_notional:>12,.0f}",
            f"  % of ADV per trade:     {self.pct_adv:>10.2f}%",
            f"  Est. market impact:     {self.estimated_impact_bps:>10.1f} bps",
            f"  Capacity ceiling (~):   ${self.capacity_ceiling_usd:>12,.0f}",
        ]
        for w in self.warnings:
            lines.append(f"  ⚠  {w}")
        if not self.warnings:
            lines.append("  ✓  Capacity looks healthy at current trade sizes")
        lines.append(f"{'─'*60}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "avg_notional_per_trade": self.avg_notional_per_trade,
            "trades_per_day":         self.trades_per_day,
            "trades_per_week":        self.trades_per_week,
            "gross_daily_notional":   self.gross_daily_notional,
            "pct_adv":                self.pct_adv,
            "estimated_impact_bps":   self.estimated_impact_bps,
            "capacity_ceiling_usd":   self.capacity_ceiling_usd,
            "warnings":               self.warnings,
        }


class CapacityAnalyser:
    """
    Estimate market impact and capacity ceiling for a set of orders.

    Parameters
    ----------
    avg_daily_volume  shares traded per day (use median of recent 20 days)
    avg_price         current share price
    """

    def __init__(
        self,
        avg_daily_volume: float = 1_000_000,
        avg_price:        float = 100.0,
    ):
        self.adv   = avg_daily_volume
        self.price = avg_price

    def _impact_bps(self, notional: float) -> float:
        """
        Simplified Almgren-Chriss temporary impact in basis points.
        impact = η × (Q/V) ^ β   expressed as fraction of price × 10000 for bps.
        """
        if self.adv <= 0 or self.price <= 0:
            return 0.0
        shares = notional / self.price
        ratio  = shares / self.adv
        impact = _ETA * (ratio ** _BETA)        # as fraction of price
        return round(impact * 10_000, 2)         # convert to bps

    def _capacity_ceiling(self, alpha_bps: float) -> float:
        """
        AUM at which market impact equals alpha.
        Solving: alpha/10000 = η × (Q/(adv))^β
            → Q = adv × (alpha/(10000 × η))^(1/β)
        """
        if alpha_bps <= 0 or self.adv <= 0:
            return 0.0
        ratio  = (alpha_bps / (10_000 * _ETA)) ** (1.0 / _BETA)
        shares = ratio * self.adv
        return round(shares * self.price, 0)

    def report(
        self,
        orders:          list,           # list of Order objects or dicts
        signal_alpha_bps: float = 30.0,  # expected gross alpha in bps per trade
        trading_days_in_window: int = 21,  # days the orders span
    ) -> CapacityReport:
        """
        Produce a full capacity report for a set of orders.

        Parameters
        ----------
        orders                list of portfolio.Order objects or dicts with .notional
        signal_alpha_bps      expected gross alpha per trade (bps); default 30 bps
        trading_days_in_window number of trading days the order list spans
        """
        if not orders:
            return CapacityReport(
                avg_notional_per_trade = 0.0,
                trades_per_day         = 0.0,
                trades_per_week        = 0.0,
                gross_daily_notional   = 0.0,
                estimated_impact_bps   = 0.0,
                capacity_ceiling_usd   = self._capacity_ceiling(signal_alpha_bps),
                pct_adv                = 0.0,
                warnings               = ["No orders to analyse"],
            )

        # Support both Order dataclasses and plain dicts
        def _notional(o) -> float:
            return float(o.notional if hasattr(o, "notional") else o.get("notional", 0))

        notionals = [_notional(o) for o in orders]
        total_n   = len(notionals)
        avg_n     = sum(notionals) / total_n
        gross     = sum(notionals)

        tpd  = total_n / max(1, trading_days_in_window)
        tpw  = tpd * 5

        avg_shares = avg_n / max(self.price, 1e-6)
        pct_adv    = round(avg_shares / max(self.adv, 1) * 100, 3)
        impact_bps = self._impact_bps(avg_n)
        ceiling    = self._capacity_ceiling(signal_alpha_bps)

        warnings = []
        if pct_adv > 5.0:
            warnings.append(
                f"Avg trade = {pct_adv:.1f}% ADV — expect significant market impact"
            )
        if pct_adv > 20.0:
            warnings.append(
                "Avg trade > 20% ADV — strategy is not scalable at this trade size"
            )
        if impact_bps >= signal_alpha_bps * 0.5:
            warnings.append(
                f"Impact ({impact_bps:.1f} bps) ≥ 50% of alpha ({signal_alpha_bps} bps)"
                " — net alpha may be negligible"
            )
        if gross / max(1, trading_days_in_window) > ceiling:
            warnings.append(
                f"Daily gross ${gross/trading_days_in_window:,.0f} "
                f"> capacity ceiling ${ceiling:,.0f}"
            )

        return CapacityReport(
            avg_notional_per_trade = round(avg_n, 2),
            trades_per_day         = round(tpd, 2),
            trades_per_week        = round(tpw, 2),
            gross_daily_notional   = round(gross / max(1, trading_days_in_window), 2),
            estimated_impact_bps   = impact_bps,
            capacity_ceiling_usd   = ceiling,
            pct_adv                = pct_adv,
            warnings               = warnings,
        )


# ---------------------------------------------------------------------------
# Second-order alpha
# ---------------------------------------------------------------------------

class SecondOrderAlpha:
    """
    Generate alpha signals for entities that are indirectly related to a
    primary event via the knowledge graph's sentiment propagation.

    Example
    -------
    NVIDIA reports strong earnings (primary signal, score = +0.7).
    TSMC → shares "semiconductor" topic with NVIDIA.
    SecondOrderAlpha propagates: TSMC gets a positive secondary signal
    with a hop-decay applied.

    This is the "second-order effects" upgrade.
    """

    HOP_DECAY = 0.45   # fraction of primary score passed to 1-hop peer

    def __init__(self, pool=None):
        self._pool = pool

    async def propagate(
        self,
        entity:      str,
        base_score:  float,
        min_score:   float = 0.10,
    ) -> list[dict]:
        """
        Return secondary signals for entities related to *entity* in the KG.

        Parameters
        ----------
        entity      the primary entity (e.g. "nvidia")
        base_score  the primary alpha score (signed, [-1, 1])
        min_score   minimum |secondary_score| to include

        Returns
        -------
        list of dicts: {entity, secondary_score, topic_bridge, hops}
        """
        if self._pool is None:
            logger.warning("SecondOrderAlpha: no DB pool — returning empty")
            return []

        from knowledge_graph import propagate_sentiment

        try:
            propagated = await propagate_sentiment(entity, hops=2)
        except Exception as exc:
            logger.warning("KG propagation failed for %s: %s", entity, exc)
            return []

        results = []
        for peer in propagated:
            # KG gives normalised sentiment in [-1, 1]; blend with primary score
            kg_sent   = float(peer.get("propagated_sentiment") or 0.0)
            # Secondary score: primary direction modulated by KG sentiment alignment
            alignment = 1.0 if (base_score * kg_sent >= 0) else -0.5   # penalise contra-signal
            secondary = base_score * self.HOP_DECAY * abs(kg_sent) * alignment

            if abs(secondary) < min_score:
                continue

            results.append({
                "entity":           peer["entity"],
                "secondary_score":  round(secondary, 4),
                "topic_bridge":     peer.get("topic_bridge", ""),
                "hops":             peer.get("hops", 2),
                "kg_sentiment":     round(kg_sent, 4),
                "source_entity":    entity,
                "source_score":     round(base_score, 4),
            })

        results.sort(key=lambda x: abs(x["secondary_score"]), reverse=True)
        return results

    def propagate_sync(
        self,
        propagated_peers: list[dict],
        base_score:       float,
        min_score:        float = 0.10,
    ) -> list[dict]:
        """
        Synchronous version for use in non-async contexts.
        Accepts pre-fetched propagated_peers (from knowledge_graph.propagate_sentiment).
        """
        results = []
        for peer in propagated_peers:
            kg_sent   = float(peer.get("propagated_sentiment") or 0.0)
            alignment = 1.0 if (base_score * kg_sent >= 0) else -0.5
            secondary = base_score * self.HOP_DECAY * abs(kg_sent) * alignment
            if abs(secondary) < min_score:
                continue
            results.append({
                "entity":          peer["entity"],
                "secondary_score": round(secondary, 4),
                "topic_bridge":    peer.get("topic_bridge", ""),
                "hops":            peer.get("hops", 2),
                "kg_sentiment":    round(kg_sent, 4),
                "source_entity":   "primary",
                "source_score":    round(base_score, 4),
            })
        results.sort(key=lambda x: abs(x["secondary_score"]), reverse=True)
        return results
