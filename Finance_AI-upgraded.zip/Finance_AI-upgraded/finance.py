"""
finance.py — market price data with:
  - Primary source: yfinance (Yahoo Finance)
  - Fallback: Alpha Vantage (set ALPHA_VANTAGE_KEY in .env)
  - In-process LRU price cache (5-minute TTL) to prevent on-demand Pearson
    calculations from hitting Yahoo on every API request
  - Publication-time alignment: uses scraped_at from scraped_events, not last_scraped
"""
from __future__ import annotations
import logging
import time
from datetime import datetime, timezone, timedelta
from functools import lru_cache
from typing import Optional

import pandas as pd

from config import settings

logger = logging.getLogger(__name__)

_CACHE: dict[str, tuple[float, pd.DataFrame]] = {}   # ticker → (expires_at, df)
_CACHE_TTL = 300   # 5 minutes


def _yf():
    try:
        import yfinance as yf
        return yf
    except ImportError:
        raise ImportError("pip install yfinance")


def _alpha_vantage(ticker: str, days: int) -> Optional[pd.DataFrame]:
    """Fallback: Alpha Vantage TIME_SERIES_DAILY."""
    key = settings.__dict__.get("alpha_vantage_key") or __import__("os").getenv("ALPHA_VANTAGE_KEY", "")
    if not key:
        return None
    try:
        import requests
        url = (
            f"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY"
            f"&symbol={ticker}&outputsize=compact&apikey={key}"
        )
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        data = r.json().get("Time Series (Daily)", {})
        if not data:
            return None
        rows = []
        cutoff = datetime.now(timezone.utc) - timedelta(days=days)
        for date_str, ohlcv in data.items():
            dt = datetime.strptime(date_str, "%Y-%m-%d")
            if dt < cutoff.replace(tzinfo=None):
                continue
            rows.append({
                "date":   dt,
                "Open":   float(ohlcv["1. open"]),
                "High":   float(ohlcv["2. high"]),
                "Low":    float(ohlcv["3. low"]),
                "Close":  float(ohlcv["4. close"]),
                "Volume": int(ohlcv["5. volume"]),
            })
        if not rows:
            return None
        df = pd.DataFrame(rows).set_index("date").sort_index()
        return df
    except Exception as exc:
        logger.debug("Alpha Vantage fallback failed for %s: %s", ticker, exc)
        return None


def get_price_history(ticker: str, days: int = 30) -> Optional[pd.DataFrame]:
    """Fetch OHLCV history. Returns cached data if available and fresh."""
    cached = _CACHE.get(ticker)
    if cached and time.time() < cached[0]:
        return cached[1]

    df = None
    # Primary: yfinance
    try:
        yf    = _yf()
        end   = datetime.now(timezone.utc)
        start = end - timedelta(days=days)
        obj   = yf.Ticker(ticker)
        df    = obj.history(start=start.strftime("%Y-%m-%d"),
                            end=end.strftime("%Y-%m-%d"), interval="1d")
        if df is not None and not df.empty:
            df.index = pd.to_datetime(df.index).normalize().tz_localize(None)
            df = df[["Open", "High", "Low", "Close", "Volume"]]
        else:
            df = None
    except Exception:
        logger.debug("yfinance failed for %s — trying Alpha Vantage", ticker)

    # Fallback: Alpha Vantage
    if df is None or df.empty:
        df = _alpha_vantage(ticker, days)

    if df is not None and not df.empty:
        _CACHE[ticker] = (time.time() + _CACHE_TTL, df)
    return df if df is not None and not df.empty else None


def get_current_price(ticker: str) -> Optional[float]:
    df = get_price_history(ticker, days=5)
    if df is None or df.empty:
        return None
    return round(float(df["Close"].iloc[-1]), 4)


def get_multi_ticker_summary(tickers: list[str]) -> pd.DataFrame:
    from target_profiles import TICKER_MAP
    rows = []
    for ticker in tickers:
        df = get_price_history(ticker, days=10)
        if df is not None and len(df) >= 2:
            price  = round(float(df["Close"].iloc[-1]), 2)
            chg_1d = round((df["Close"].iloc[-1] / df["Close"].iloc[-2] - 1) * 100, 2)
            idx5   = max(0, len(df) - 6)
            chg_5d = round((df["Close"].iloc[-1] / df["Close"].iloc[idx5] - 1) * 100, 2)
        else:
            price = chg_1d = chg_5d = float("nan")
        rows.append({
            "ticker": ticker,
            "name": TICKER_MAP.get(ticker, ticker),
            "price": price,
            "change_1d_%": chg_1d,
            "change_5d_%": chg_5d,
        })
    return pd.DataFrame(rows)


def correlate_sentiment_price(
    ticker: str,
    sentiment_rows: list[dict],
    days: int = 30,
) -> Optional[dict]:
    """Pearson correlation between daily mean sentiment and next-day price return."""
    try:
        from scipy.stats import pearsonr
    except ImportError:
        logger.warning("scipy not installed — pip install scipy")
        return None

    price_df = get_price_history(ticker, days=days + 5)
    if price_df is None or len(price_df) < 5:
        return None

    records = []
    for row in sentiment_rows:
        try:
            # Use scraped_at (not last_scraped) for accuracy
            dt_raw = row.get("scraped_at") or row.get("last_scraped")
            dt = pd.to_datetime(dt_raw).normalize().tz_localize(None)
            records.append({"date": dt, "score": float(row["score"])})
        except Exception:
            continue

    if not records:
        return None

    sent_df = (
        pd.DataFrame(records)
        .groupby("date")["score"]
        .mean()
        .rename("mean_sentiment")
        .reset_index()
    )

    price_df = price_df.copy()
    price_df["next_day_return"] = price_df["Close"].pct_change().shift(-1)
    price_df = price_df.dropna(subset=["next_day_return"]).reset_index()
    price_df = price_df.rename(columns={"index": "date"})
    price_df["date"] = pd.to_datetime(price_df["date"]).dt.normalize()

    merged = pd.merge(sent_df, price_df[["date", "next_day_return"]], on="date", how="inner")
    if len(merged) < 3:
        return None

    corr, p_val = pearsonr(merged["mean_sentiment"], merged["next_day_return"])
    return {
        "correlation": round(corr, 4),
        "p_value":     round(p_val, 4),
        "n_days":      len(merged),
        "merged_df":   merged,
    }
