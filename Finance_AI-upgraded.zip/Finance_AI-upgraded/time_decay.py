"""
time_decay.py — event age weighting for the signal ranking layer.

Two decay regimes:
  1. Breaking-news boost   — events < 2 h old get a super-linear bump
  2. Exponential decay     — standard half-life model beyond 2 h

The output is a multiplier in (0, 1] applied to the composite alpha score.

Half-life defaults:
  CRITICAL   6 h   (market-moving events fade fast)
  HIGH      12 h
  MEDIUM    24 h
  LOW       48 h

These can be overridden via environment variables (DECAY_HALFLIFE_*_HOURS).
"""
from __future__ import annotations

import math
from datetime import datetime, timezone
from typing import Optional

from config import settings

# ---------------------------------------------------------------------------
# Half-life table (hours)
# ---------------------------------------------------------------------------

_HALFLIFE_HOURS: dict[str, float] = {
    "CRITICAL": float(getattr(settings, "decay_halflife_critical_hours", 6)),
    "HIGH":     float(getattr(settings, "decay_halflife_high_hours",     12)),
    "MEDIUM":   float(getattr(settings, "decay_halflife_medium_hours",   24)),
    "LOW":      float(getattr(settings, "decay_halflife_low_hours",      48)),
}

_BREAKING_NEWS_WINDOW_HOURS = 2.0   # events younger than this get a boost
_BREAKING_NEWS_BOOST        = 1.25  # maximum boost multiplier


def time_decay_multiplier(
    scraped_at:       datetime,
    materiality_tier: str = "MEDIUM",
    now:              Optional[datetime] = None,
) -> float:
    """
    Return a decay multiplier in (0, 1] for an event scraped at *scraped_at*.

    Breaking-news boost:
        events < BREAKING_NEWS_WINDOW_HOURS old are multiplied by a linear
        ramp from _BREAKING_NEWS_BOOST (age=0) down to 1.0 at the window edge.

    Exponential decay:
        beyond the breaking-news window, standard half-life model.

    Parameters
    ----------
    scraped_at       UTC datetime when the event was ingested
    materiality_tier tier string (CRITICAL / HIGH / MEDIUM / LOW)
    now              reference time (defaults to UTC now)
    """
    if now is None:
        now = datetime.now(timezone.utc)

    # Ensure both tz-aware
    if scraped_at.tzinfo is None:
        scraped_at = scraped_at.replace(tzinfo=timezone.utc)

    age_hours = (now - scraped_at).total_seconds() / 3600.0
    age_hours = max(0.0, age_hours)

    halflife = _HALFLIFE_HOURS.get(materiality_tier.upper(), 24.0)

    if age_hours <= _BREAKING_NEWS_WINDOW_HOURS:
        # Linear ramp from boost → 1.0 over the window
        frac   = age_hours / _BREAKING_NEWS_WINDOW_HOURS
        boost  = _BREAKING_NEWS_BOOST - frac * (_BREAKING_NEWS_BOOST - 1.0)
        decay  = math.exp(-math.log(2) * age_hours / halflife)
        return round(min(1.5, boost * decay), 4)   # cap at 1.5 to avoid runaway

    # Standard exponential decay beyond the window
    decay = math.exp(-math.log(2) * age_hours / halflife)
    return round(max(1e-4, decay), 4)


def recency_score(scraped_at: datetime, now: Optional[datetime] = None) -> float:
    """
    Simplified recency score in [0, 1] — useful for display / ranking tables.
    1.0 = just scraped, 0.0 = very old.
    Uses a fixed 72 h half-life regardless of tier.
    """
    if now is None:
        now = datetime.now(timezone.utc)
    if scraped_at.tzinfo is None:
        scraped_at = scraped_at.replace(tzinfo=timezone.utc)
    age_hours = max(0.0, (now - scraped_at).total_seconds() / 3600.0)
    return round(math.exp(-math.log(2) * age_hours / 72.0), 4)
