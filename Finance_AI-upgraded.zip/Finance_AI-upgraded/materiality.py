"""
materiality.py — Materiality 2.0: entity-aware, numerically-grounded scoring.

Improvements over the original keyword-only approach
-----------------------------------------------------
1. Entity-specific weight overrides per company/sector
2. Numerical extraction — USD contract size, % change → score amplification
3. Event-type context — earnings beats scored differently from rumours
4. Credibility multiplier (retained from v1)
5. Extreme-sentiment amplification (retained from v1)
6. Market-cap normalisation stub (scales $ value relative to implied mkt cap)

All v1 fields are preserved; the function signature is backward-compatible.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

# ---------------------------------------------------------------------------
# Base keyword signals (v1 — preserved verbatim)
# ---------------------------------------------------------------------------

_SIGNALS: dict[str, float] = {
    # Macro / monetary policy
    "federal reserve": 0.30, "interest rate": 0.25, "rate hike": 0.28,
    "rate cut": 0.28,        "quantitative easing": 0.25, "inflation": 0.20,
    "deflation": 0.22,       "gdp": 0.20,          "recession": 0.28,
    "stagflation": 0.30,     "monetary policy": 0.22,
    # Corporate events
    "bankruptcy": 0.35,      "default": 0.30,       "acquisition": 0.22,
    "merger": 0.22,          "ipo": 0.20,           "earnings": 0.18,
    "dividend": 0.15,        "buyback": 0.15,       "layoffs": 0.20,
    "restructuring": 0.20,
    # Geopolitical / regulatory
    "sanctions": 0.28,       "war": 0.25,           "election": 0.18,
    "tariff": 0.22,          "trade war": 0.28,     "regulation": 0.15,
    "sec investigation": 0.30, "fraud": 0.30,
    # Market stress
    "market crash": 0.35,    "circuit breaker": 0.35, "flash crash": 0.35,
    "volatility": 0.15,      "liquidity crisis": 0.32,
}

_TIERS: list[tuple[float, str]] = [
    (0.70, "CRITICAL"),
    (0.45, "HIGH"),
    (0.20, "MEDIUM"),
    (0.00, "LOW"),
]

# ---------------------------------------------------------------------------
# NEW: Entity-specific weight boosts
# ---------------------------------------------------------------------------

_ENTITY_WEIGHTS: dict[str, float] = {
    "apple":           0.08, "microsoft":       0.08, "nvidia":          0.10,
    "alphabet":        0.08, "google":          0.08, "amazon":          0.08,
    "meta":            0.07, "tesla":           0.09, "berkshire":       0.07,
    "jpmorgan":        0.09, "goldman sachs":   0.09, "morgan stanley":  0.08,
    "bank of america": 0.08, "citigroup":       0.08, "wells fargo":     0.07,
    "federal reserve": 0.12, "ecb":             0.10, "bank of england": 0.10,
    "imf":             0.09, "world bank":      0.08,
    "boe":             0.10, "ftse":            0.07, "lse":             0.06,
}

# ---------------------------------------------------------------------------
# NEW: Event-type materiality multipliers
# ---------------------------------------------------------------------------

_EVENT_TYPE_MULTIPLIERS: dict[str, float] = {
    "earnings":       1.20,
    "macro":          1.15,
    "contract":       1.05,
    "product_launch": 1.00,
    "regulation":     1.10,
    "rumor":          0.75,
    "analysis":       0.85,
    "geopolitical":   1.10,
    "unknown":        1.00,
}

# ---------------------------------------------------------------------------
# NEW: Numerical extraction helpers
# ---------------------------------------------------------------------------

_DOLLAR_RE = re.compile(
    r"\$\s*(?P<value>[\d,]+(?:\.\d+)?)\s*(?P<unit>trillion|billion|million|k)?",
    re.IGNORECASE,
)
_PERCENT_RE = re.compile(r"(?P<value>[\d.]+)\s*%")


def _largest_dollar_amount(text: str) -> Optional[float]:
    best = 0.0
    for m in _DOLLAR_RE.finditer(text):
        raw  = float(m.group("value").replace(",", ""))
        unit = (m.group("unit") or "").lower()
        mult = {"trillion": 1e12, "billion": 1e9, "million": 1e6, "k": 1e3}.get(unit, 1.0)
        best = max(best, raw * mult)
    return best if best > 0 else None


def _largest_pct_change(text: str) -> Optional[float]:
    vals = [float(m.group("value")) for m in _PERCENT_RE.finditer(text)]
    return max(vals) if vals else None


def _dollar_boost(usd_value: float, implied_market_cap: float = 1e10) -> float:
    """
    Convert a USD contract/deal/loss value into an additive materiality weight.
    Log-normalised relative to implied_market_cap; capped at 0.25.
    """
    import math
    ratio = usd_value / max(1.0, implied_market_cap)
    log_r = math.log10(max(1e-9, ratio)) + 2.0
    return min(0.25, max(0.0, log_r * 0.10))


# ---------------------------------------------------------------------------
# Result dataclass (v1-compatible + new fields)
# ---------------------------------------------------------------------------

@dataclass
class MaterialityResult:
    score:         float
    tier:          str
    reasons:       list[str]
    # NEW fields — never break existing callers
    entity_boost:  float = 0.0
    dollar_value:  Optional[float] = None
    pct_change:    Optional[float] = None
    event_type:    str = "unknown"


# ---------------------------------------------------------------------------
# Public API — backward-compatible signature
# ---------------------------------------------------------------------------

def score_materiality(
    text:               str,
    keywords:           list[str],
    credibility:        float,
    sentiment_score:    float,
    # NEW optional parameters — callers unaware of them get full v2 scoring
    event_type:         str        = "unknown",
    entities:           list[str]  = (),
    implied_market_cap: float      = 1e10,
) -> MaterialityResult:
    """
    Compute Materiality 2.0 score.

    Backward-compatible: callers that only pass the original four positional
    arguments will get the upgraded score automatically.
    """
    reasons: list[str] = []
    raw      = 0.0

    combined = (text + " " + " ".join(keywords)).lower()

    # Stage 1: keyword weights (v1 — preserved) ----------------------------
    for signal, weight in _SIGNALS.items():
        if signal in combined:
            raw += weight
            reasons.append(f"kw:{signal}")

    # Stage 2: entity-specific boosts (NEW) --------------------------------
    entity_boost = 0.0
    entity_set   = set(e.lower() for e in entities)
    for entity_key, boost in _ENTITY_WEIGHTS.items():
        if entity_key in combined or entity_key in entity_set:
            entity_boost += boost
            reasons.append(f"entity:{entity_key}")
    entity_boost = min(0.30, entity_boost)
    raw += entity_boost

    # Stage 3: numerical extraction (NEW) ----------------------------------
    usd_value  = _largest_dollar_amount(text)
    pct_change = _largest_pct_change(text)

    if usd_value is not None:
        db = _dollar_boost(usd_value, implied_market_cap)
        raw += db
        reasons.append(f"dollar_value:${usd_value:.0f}:+{db:.3f}")

    if pct_change is not None and pct_change > 5.0:
        pct_boost = min(0.15, (pct_change - 5.0) / 100.0)
        raw += pct_boost
        reasons.append(f"pct_change:{pct_change:.1f}%:+{pct_boost:.3f}")

    # Stage 4: credibility multiplier (v1 — preserved) ---------------------
    raw *= max(0.3, min(1.0, credibility))

    # Stage 5: event-type multiplier (NEW) ---------------------------------
    et_mult = _EVENT_TYPE_MULTIPLIERS.get(event_type.lower(), 1.0)
    raw    *= et_mult
    if et_mult != 1.0:
        reasons.append(f"event_type:{event_type}:×{et_mult}")

    # Stage 6: extreme sentiment amplification (v1 — preserved) -----------
    if abs(sentiment_score) > 0.80:
        raw = min(1.0, raw * 1.15)
        reasons.append("extreme_sentiment")

    score = min(1.0, raw)
    tier  = next(t for threshold, t in _TIERS if score >= threshold)

    return MaterialityResult(
        score        = round(score, 4),
        tier         = tier,
        reasons      = reasons,
        entity_boost = round(entity_boost, 4),
        dollar_value = usd_value,
        pct_change   = pct_change,
        event_type   = event_type,
    )
