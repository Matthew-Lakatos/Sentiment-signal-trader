"""
source_health.py — tracks consecutive failures per domain and marks dead sources.
"""
from __future__ import annotations
import logging
from datetime import datetime, timezone
from urllib.parse import urlparse

from asyncpg.pool import Pool
from config import settings

logger = logging.getLogger(__name__)


def domain_of(url: str) -> str:
    return urlparse(url).netloc


async def record_success(pool: Pool, domain: str) -> None:
    await pool.execute("""
        INSERT INTO source_health (domain, last_success_at, consecutive_fails, is_dead)
        VALUES ($1, NOW(), 0, FALSE)
        ON CONFLICT (domain) DO UPDATE
            SET last_success_at   = NOW(),
                consecutive_fails = 0,
                is_dead           = FALSE,
                dead_since        = NULL
    """, domain)


async def record_failure(pool: Pool, domain: str) -> bool:
    """Increment failure counter. Returns True if source just became dead."""
    row = await pool.fetchrow("""
        INSERT INTO source_health (domain, consecutive_fails, is_dead)
        VALUES ($1, 1, FALSE)
        ON CONFLICT (domain) DO UPDATE
            SET consecutive_fails = source_health.consecutive_fails + 1,
                is_dead = (source_health.consecutive_fails + 1 >= $2),
                dead_since = CASE
                    WHEN source_health.consecutive_fails + 1 >= $2
                     AND source_health.dead_since IS NULL THEN NOW()
                    ELSE source_health.dead_since END
        RETURNING is_dead, consecutive_fails
    """, domain, settings.dead_source_threshold)

    if row and row["is_dead"] and row["consecutive_fails"] == settings.dead_source_threshold:
        logger.warning("Source marked dead after %d consecutive failures: %s",
                       settings.dead_source_threshold, domain)
        return True
    return False


async def is_dead(pool: Pool, domain: str) -> bool:
    """Return True if domain is dead and not yet due for recheck."""
    row = await pool.fetchrow(
        "SELECT is_dead, dead_since FROM source_health WHERE domain = $1", domain
    )
    if not row or not row["is_dead"]:
        return False
    if row["dead_since"] is None:
        return True
    age_hours = (datetime.now(timezone.utc) - row["dead_since"]).total_seconds() / 3600
    return age_hours < settings.dead_source_recheck_hours


async def get_robots_delay(pool: Pool, domain: str) -> float:
    row = await pool.fetchrow(
        "SELECT robots_delay_s FROM source_health WHERE domain = $1", domain
    )
    return float(row["robots_delay_s"]) if row else settings.robots_default_delay


async def set_robots_delay(pool: Pool, domain: str, delay: float) -> None:
    await pool.execute("""
        INSERT INTO source_health (domain, robots_delay_s)
        VALUES ($1, $2)
        ON CONFLICT (domain) DO UPDATE SET robots_delay_s = $2
    """, domain, delay)
