"""
retention.py — data retention enforcer.

Deletes scraped_events older than RETENTION_DAYS (default 365).
Run as a weekly cron job or scheduled task:
    python retention.py --days 365 --dry-run
    python retention.py --days 365

Also provides GDPR Article 17 right-to-erasure for specific URLs.
"""
from __future__ import annotations
import argparse
import asyncio
import logging
from datetime import datetime, timezone, timedelta

from database import get_pool

logger = logging.getLogger(__name__)


async def delete_old_events(days: int, dry_run: bool = False) -> int:
    pool    = await get_pool()
    cutoff  = datetime.now(timezone.utc) - timedelta(days=days)
    if dry_run:
        count = await pool.fetchval("""
            SELECT COUNT(*) FROM scraped_events WHERE scraped_at < $1
        """, cutoff)
        logger.info("[DRY RUN] Would delete %d events older than %s", count, cutoff.date())
        return count
    result = await pool.execute("""
        DELETE FROM scraped_events WHERE scraped_at < $1
    """, cutoff)
    deleted = int(result.split()[-1])
    logger.info("Deleted %d events older than %s", deleted, cutoff.date())
    # Also prune cache and alert_log
    await pool.execute("DELETE FROM scrape_cache WHERE last_scraped_at < $1", cutoff)
    await pool.execute("DELETE FROM alert_log WHERE fired_at < $1", cutoff)
    return deleted


async def erase_url(url: str) -> int:
    """GDPR Article 17: delete all data for a specific URL."""
    pool = await get_pool()
    r1   = await pool.execute("DELETE FROM scraped_events WHERE url = $1", url)
    r2   = await pool.execute("DELETE FROM scrape_cache WHERE url = $1", url)
    deleted = int(r1.split()[-1]) + int(r2.split()[-1])
    logger.info("GDPR erasure: removed %d rows for URL %s", deleted, url)
    return deleted


async def _main(args: argparse.Namespace) -> None:
    logging.basicConfig(level=logging.INFO)
    if args.erase_url:
        n = await erase_url(args.erase_url)
        print(f"Erased {n} rows for: {args.erase_url}")
    else:
        n = await delete_old_events(args.days, dry_run=args.dry_run)
        if args.dry_run:
            print(f"[DRY RUN] Would delete {n} events older than {args.days} days")
        else:
            print(f"Deleted {n} events older than {args.days} days")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Data retention / GDPR erasure")
    parser.add_argument("--days",      type=int, default=365, help="Retain events newer than N days")
    parser.add_argument("--dry-run",   action="store_true",   help="Show count without deleting")
    parser.add_argument("--erase-url", type=str, default="",  help="GDPR: erase all data for this URL")
    asyncio.run(_main(parser.parse_args()))
