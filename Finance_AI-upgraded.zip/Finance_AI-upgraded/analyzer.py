"""
analyzer.py — central NLP pipeline.
All heavy inference runs in run_in_executor so the async event loop is
never blocked. FinBERT returns UNCERTAIN when confidence < threshold.
"""
from __future__ import annotations
import asyncio
import logging
from typing import Any

from config import settings
from nlp_extra import analyze_full_nlp
from credibility import compute_credibility
from embeddings import generate_embedding, embedding_model_version
from narrative_engine import engine as narrative_engine
from knowledge_graph import link_entity_topic
from target_profiles import detect_targets
from claim_extraction import extract_claims
from propaganda_detector import detect_propaganda
from event_classifier import classify as classify_event_type

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lightweight fallbacks
# ---------------------------------------------------------------------------

def _fallback_keywords(text: str) -> list[str]:
    from sklearn.feature_extraction.text import CountVectorizer
    try:
        vec = CountVectorizer(stop_words="english", max_features=10)
        vec.fit_transform([text])
        return vec.get_feature_names_out().tolist()
    except Exception:
        return []


_TOPIC_SETS: dict[str, list[str]] = {
    "technology": ["ai", "software", "data", "cloud", "algorithm"],
    "finance":    ["market", "stock", "crypto", "bank", "economy"],
    "health":     ["health", "medicine", "vaccine", "disease", "treatment"],
    "politics":   ["government", "election", "policy", "senate", "congress"],
    "science":    ["research", "study", "experiment", "discovery"],
}

_EMOTION_VOCAB: dict[str, list[str]] = {
    "joy":     ["happy", "great", "good", "love", "excellent", "wonderful"],
    "anger":   ["hate", "angry", "rage", "furious", "outraged"],
    "fear":    ["fear", "scared", "terrified", "anxious", "worried"],
    "sadness": ["sad", "cry", "depressed", "grief", "sorrow"],
}

def _fallback_topics(text: str) -> list[str]:
    words = set(text.lower().split())
    return [t for t, keys in _TOPIC_SETS.items() if any(k in words for k in keys)]

def _fallback_emotions(text: str) -> dict[str, int]:
    words = text.lower().split()
    return {e: sum(1 for w in words if w in v) for e, v in _EMOTION_VOCAB.items()}

def _fallback_summary(text: str) -> str:
    sentences = [s.strip() for s in text.split(".") if s.strip()]
    return ". ".join(sentences[:2]) + ("." if sentences else "")


# ---------------------------------------------------------------------------
# FinBERT — lazy-loaded, chunk-scored, confidence-gated
# ---------------------------------------------------------------------------

_finbert = None

# FIX: initialise at module level so all coroutines share one Lock object.
# asyncio.Lock() does not require a running event loop to construct in
# Python 3.10+, making this safe to place at import time.
_finbert_lock: asyncio.Lock = asyncio.Lock()


def _load_finbert():
    global _finbert
    if _finbert is None:
        from transformers import pipeline as hf_pipeline
        _finbert = hf_pipeline(
            "text-classification",
            model=settings.model_sentiment,
            top_k=None,
            truncation=True,
            max_length=512,
        )
        logger.info("FinBERT loaded: %s", settings.model_sentiment)
    return _finbert


_CHUNK_CHARS   = 1_600
_OVERLAP_CHARS = 180


def _score_sentiment_sync(text: str) -> dict[str, Any]:
    """Synchronous FinBERT scoring — called inside run_in_executor."""
    model = _load_finbert()
    chunks, start = [], 0
    while start < len(text):
        end = start + _CHUNK_CHARS
        chunks.append(text[start:end])
        if end >= len(text):
            break
        start = end - _OVERLAP_CHARS

    weighted_sum = weight_total = max_conf = 0.0
    for chunk in chunks:
        try:
            output = model(chunk)
            labels = output[0] if isinstance(output[0], list) else output
            scores = {item["label"].lower(): item["score"] for item in labels}
            p_pos, p_neg, p_neu = scores.get("positive", 0), scores.get("negative", 0), scores.get("neutral", 0)
            confidence   = 1.0 - p_neu
            signed       = p_pos - p_neg
            weighted_sum += signed * confidence
            weight_total += confidence
            max_conf      = max(max_conf, max(p_pos, p_neg, p_neu))
        except Exception:
            pass

    if weight_total < 1e-9:
        return {"label": "NEUTRAL", "score": 0.0, "confident": False}

    final = max(-1.0, min(1.0, weighted_sum / weight_total))
    label = "POSITIVE" if final > 0.05 else ("NEGATIVE" if final < -0.05 else "NEUTRAL")
    confident = max_conf >= settings.sentiment_confidence_threshold
    if not confident:
        label = "UNCERTAIN"
    return {"label": label, "score": round(final, 4), "confident": confident}


async def _score_sentiment(text: str) -> dict[str, Any]:
    if not text or not text.strip():
        return {"label": "NEUTRAL", "score": 0.0, "confident": True}
    async with _finbert_lock:
        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(None, _score_sentiment_sync, text.strip())
        except Exception:
            logger.warning("FinBERT failed", exc_info=True)
            return {"label": "NEUTRAL", "score": 0.0, "confident": False}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def analyze_all(text: str, url: str = "") -> dict[str, Any]:
    """
    Run the full NLP pipeline asynchronously.
    All heavy work runs in executor threads — never blocks the event loop.
    """
    if not text:
        return _empty_result()

    loop = asyncio.get_running_loop()

    # Run sentiment and NLP concurrently
    sentiment_task = asyncio.create_task(_score_sentiment(text))
    nlp_task = asyncio.create_task(
        asyncio.to_thread(analyze_full_nlp, text)
    )
    propaganda_task = asyncio.create_task(
        asyncio.to_thread(detect_propaganda, text)
    )
    embedding_task = asyncio.create_task(
        generate_embedding(text[:2000])  # use first 2000 chars for embedding
    )
    # NEW: event classification runs concurrently (pure CPU, no I/O)
    classification_task = asyncio.create_task(
        asyncio.to_thread(classify_event_type, text[:1500])
    )

    sentiment, nlp_result, prop_raw, embedding, classification = await asyncio.gather(
        sentiment_task, nlp_task, propaganda_task, embedding_task, classification_task,
        return_exceptions=True,
    )

    # Handle any task exceptions gracefully
    if isinstance(sentiment, Exception):
        sentiment = {"label": "NEUTRAL", "score": 0.0, "confident": False}
    if isinstance(nlp_result, Exception):
        nlp_result = {}
    if isinstance(prop_raw, Exception):
        prop_raw = {"score": 0.0, "flags": [], "confidence": "clean", "techniques": []}
    if isinstance(embedding, Exception):
        embedding = None
    if isinstance(classification, Exception):
        from event_classifier import ClassificationResult
        classification = ClassificationResult("unknown", 0.0, 0, None, None)

    keywords = (nlp_result.get("keywords") or []) if isinstance(nlp_result, dict) else _fallback_keywords(text)
    topics   = (nlp_result.get("topics")   or []) if isinstance(nlp_result, dict) else _fallback_topics(text)
    summary  = (nlp_result.get("summary")  or "") if isinstance(nlp_result, dict) else _fallback_summary(text)
    emotions = (nlp_result.get("emotions") or {}) if isinstance(nlp_result, dict) else _fallback_emotions(text)

    if not keywords: keywords = _fallback_keywords(text)
    if not topics:   topics   = _fallback_topics(text)
    if not summary:  summary  = _fallback_summary(text)
    if not emotions: emotions = _fallback_emotions(text)

    propaganda = prop_raw if isinstance(prop_raw, dict) else {
        "score": 0.0, "flags": [], "confidence": "clean", "techniques": []
    }

    credibility = 0.5
    try:
        credibility = await loop.run_in_executor(None, compute_credibility, url, text)
    except Exception:
        pass

    targets = []
    try:
        targets = await loop.run_in_executor(None, detect_targets, text)
    except Exception:
        pass

    claims = None
    try:
        claims = await loop.run_in_executor(None, extract_claims, text)
    except Exception:
        pass

    narrative_id = None
    try:
        narrative_id = await loop.run_in_executor(None, narrative_engine.add_article, text, summary)
    except Exception:
        pass

    # FIX: was `analysis.get(...)` — `analysis` is undefined at this point.
    # Use the already-resolved `targets` and `topics` locals instead.
    for target in targets:
        for topic in topics:
            try:
                link_entity_topic(target, topic, sentiment=sentiment.get("score", 0.0))
            except Exception:
                pass

    return {
        "sentiment":      sentiment,
        "keywords":       keywords,
        "topics":         topics,
        "summary":        summary,
        "emotions":       emotions,
        "propaganda":     propaganda,
        "credibility":    credibility,
        "targets":        targets,
        "claims":         claims,
        "narrative_id":   narrative_id,
        "embedding":      embedding,
        "embedding_model": embedding_model_version(),
        # NEW: event intelligence fields
        "event_type":       classification.event_type,
        "event_confidence": classification.confidence,
        "dollar_value":     classification.dollar_value,
        "pct_change":       classification.pct_change,
    }


def _empty_result() -> dict[str, Any]:
    return {
        "sentiment":      {"label": "NEUTRAL", "score": 0.0, "confident": True},
        "keywords":       [],
        "topics":         [],
        "summary":        "",
        "emotions":       {},
        "propaganda":     {"score": 0.0, "flags": [], "confidence": "clean", "techniques": []},
        "credibility":    0.5,
        "targets":        [],
        "claims":         None,
        "narrative_id":   None,
        "embedding":      None,
        "embedding_model": "",
        # NEW
        "event_type":       "unknown",
        "event_confidence": 0.0,
        "dollar_value":     None,
        "pct_change":       None,
    }
